const WORD_DATABASE = [
  {
    "id": 1,
    "word": "ABOLISH",
    "meaning_core": "廃止する",
    "syllables": [
      {
        "text": "A",
        "type": "weak"
      },
      {
        "text": "BOL",
        "type": "strong"
      },
      {
        "text": "ISH",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ELIMINATE": "排除する",
      "ANNUL": "無効にする",
      "CANCEL": "取り消す"
    },
    "distractors": [
      "ESTABLISH",
      "CREATE",
      "START",
      "KEEP"
    ],
    "meanings_expanded": [
      "廃止する",
      "撤廃する",
      "無効にする"
    ],
    "contexts": [
      {
        "parts": [
          "Abraham Lincoln helped to",
          "slavery."
        ],
        "full": "Abraham Lincoln helped to ABOLISH slavery.",
        "jp": "エイブラハム・リンカーンは奴隷制度の廃止に貢献した。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          " nuclear weapons."
        ],
        "full": "ABOLISH nuclear weapons.",
        "jp": "核兵器を廃止する。",
        "is_correct": true
      },
      {
        "parts": [
          "The government must ",
          " this law."
        ],
        "full": "The government must ABOLISH this law.",
        "jp": "政府はこの法律を廃止しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 2,
    "word": "ABOVE",
    "meaning_core": "～より上に",
    "syllables": [
      {
        "text": "A",
        "type": "weak"
      },
      {
        "text": "BOVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "OVER": "～の上に",
      "BEYOND": "～を超えて",
      "HIGHER": "より高く"
    },
    "distractors": [
      "BELOW",
      "UNDER",
      "DOWN",
      "WITHIN"
    ],
    "meanings_expanded": [
      "～より上に",
      "～を超えて",
      "頭上に"
    ],
    "contexts": [
      {
        "parts": [
          "The plane flew high",
          "the clouds."
        ],
        "full": "The plane flew high ABOVE the clouds.",
        "jp": "飛行機は雲の上高くを飛んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The temperature is ",
          " average."
        ],
        "full": "The temperature is ABOVE average.",
        "jp": "気温は平均より上だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The sign is placed ",
          " the door."
        ],
        "full": "The sign is placed ABOVE the door.",
        "jp": "その看板はドアの上に置かれている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 3,
    "word": "ABRIDGED",
    "meaning_core": "要約された",
    "syllables": [
      {
        "text": "A",
        "type": "weak"
      },
      {
        "text": "BRIDGED",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SHORTENED": "短縮された",
      "CONDENSED": "凝縮された",
      "BRIEF": "簡潔な"
    },
    "distractors": [
      "EXTENDED",
      "LONG",
      "FULL",
      "COMPLETE"
    ],
    "meanings_expanded": [
      "要約された",
      "短縮された",
      "簡約版の"
    ],
    "contexts": [
      {
        "parts": [
          "I read an",
          "version of the novel."
        ],
        "full": "I read an ABRIDGED version of the novel.",
        "jp": "私はその小説の要約版を読んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "I read the ",
          " version."
        ],
        "full": "I read the ABRIDGED version.",
        "jp": "私は要約版を読んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is an ",
          " edition of the novel."
        ],
        "full": "This is an ABRIDGED edition of the novel.",
        "jp": "これは小説の要約版です。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 4,
    "word": "ABRUPT",
    "meaning_core": "突然の",
    "syllables": [
      {
        "text": "A",
        "type": "weak"
      },
      {
        "text": "BRUPT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SUDDEN": "突然の",
      "UNEXPECTED": "予期せぬ",
      "SHARP": "急な"
    },
    "distractors": [
      "GRADUAL",
      "SLOW",
      "GENTLE",
      "SMOOTH"
    ],
    "meanings_expanded": [
      "突然の",
      "ぶっきらぼうな",
      "急な"
    ],
    "contexts": [
      {
        "parts": [
          "The bus came to an",
          "stop."
        ],
        "full": "The bus came to an ABRUPT stop.",
        "jp": "バスは突然停止した。",
        "is_correct": true
      },
      {
        "parts": [
          "There was an ",
          " change in plans."
        ],
        "full": "There was an ABRUPT change in plans.",
        "jp": "計画が突然変更された。",
        "is_correct": true
      },
      {
        "parts": [
          "His ",
          " manner upset her."
        ],
        "full": "His ABRUPT manner upset her.",
        "jp": "彼のぶっきらぼうな態度が彼女を怒らせた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 5,
    "word": "ABRUPTLY",
    "meaning_core": "不意に",
    "syllables": [
      {
        "text": "A",
        "type": "weak"
      },
      {
        "text": "BRUPT",
        "type": "strong"
      },
      {
        "text": "LY",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUDDENLY": "突然",
      "UNEXPECTEDLY": "思いがけず",
      "INSTANTLY": "即座に"
    },
    "distractors": [
      "GRADUALLY",
      "SLOWLY",
      "QUIETLY",
      "SOFTLY"
    ],
    "meanings_expanded": [
      "不意に",
      "突然",
      "急に"
    ],
    "contexts": [
      {
        "parts": [
          "The meeting ended",
          "when the fire alarm rang."
        ],
        "full": "The meeting ended ABRUPTLY when the fire alarm rang.",
        "jp": "火災報知器が鳴ると、会議は不意に終了した。",
        "is_correct": true
      },
      {
        "parts": [
          "The meeting ended ",
          "."
        ],
        "full": "The meeting ended ABRUPTLY.",
        "jp": "会議は不意に終わった。",
        "is_correct": true
      },
      {
        "parts": [
          "The car stopped ",
          "."
        ],
        "full": "The car stopped ABRUPTLY.",
        "jp": "車は突然停止した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 6,
    "word": "ABUNDANT",
    "meaning_core": "豊富な",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "BUN",
        "type": "strong"
      },
      {
        "text": "dant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PLENTIFUL": "たくさんの",
      "AMPLE": "十分な",
      "COPIOUS": "多量の"
    },
    "distractors": [
      "SCARCE",
      "RARE",
      "LACKING",
      "EMPTY"
    ],
    "meanings_expanded": [
      "豊富な",
      "豊かな",
      "潤沢な"
    ],
    "contexts": [
      {
        "parts": [
          "The country has an",
          "supply of oil."
        ],
        "full": "The country has an ABUNDANT supply of oil.",
        "jp": "その国には豊富な石油の供給がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Fish is ",
          " in this region."
        ],
        "full": "Fish is ABUNDANT in this region.",
        "jp": "この地域には魚が豊富だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They have an ",
          " supply of water."
        ],
        "full": "They have an ABUNDANT supply of water.",
        "jp": "彼らは十分な水の供給がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 7,
    "word": "ACCOMMODATE",
    "meaning_core": "収容する",
    "syllables": [
      {
        "text": "ac",
        "type": "weak"
      },
      {
        "text": "COM",
        "type": "strong"
      },
      {
        "text": "mo",
        "type": "weak"
      },
      {
        "text": "date",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HOUSE": "泊める",
      "HOLD": "収容する",
      "LODGE": "宿泊させる"
    },
    "distractors": [
      "REJECT",
      "REFUSE",
      "EXCLUDE",
      "BAR"
    ],
    "meanings_expanded": [
      "収容する",
      "適応させる",
      "宿泊させる"
    ],
    "contexts": [
      {
        "parts": [
          "The hotel can",
          "up to 500 guests."
        ],
        "full": "The hotel can ACCOMMODATE up to 500 guests.",
        "jp": "そのホテルは最大500人の客を収容できる。",
        "is_correct": true
      },
      {
        "parts": [
          "This hall can ",
          " 500 guests."
        ],
        "full": "This hall can ACCOMMODATE 500 guests.",
        "jp": "このホールは500人の客を収容できる。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " your request."
        ],
        "full": "We will ACCOMMODATE your request.",
        "jp": "あなたの要望に対応します。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 9,
    "word": "ACQUIRE",
    "meaning_core": "習得する",
    "syllables": [
      {
        "text": "ac",
        "type": "weak"
      },
      {
        "text": "QUIRE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "OBTAIN": "入手する",
      "GAIN": "得る",
      "EARN": "獲得する"
    },
    "distractors": [
      "LOSE",
      "GIVE",
      "FORFEIT",
      "MISS"
    ],
    "meanings_expanded": [
      "習得する",
      "獲得する",
      "手に入れる"
    ],
    "contexts": [
      {
        "parts": [
          "She managed to",
          "a new skill."
        ],
        "full": "She managed to ACQUIRE a new skill.",
        "jp": "彼女は新しいスキルを習得することに成功した。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " new knowledge."
        ],
        "full": "We must ACQUIRE new knowledge.",
        "jp": "私たちは新しい知識を習得しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "She will ",
          " the needed skills."
        ],
        "full": "She will ACQUIRE the needed skills.",
        "jp": "彼女は必要なスキルを習得するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 10,
    "word": "ACQUISITION",
    "meaning_core": "習得",
    "syllables": [
      {
        "text": "ac",
        "type": "weak"
      },
      {
        "text": "qui",
        "type": "weak"
      },
      {
        "text": "SI",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PURCHASE": "購入",
      "PROCUREMENT": "調達",
      "GAIN": "利益"
    },
    "distractors": [
      "LOSS",
      "SALE",
      "DISPOSAL",
      "DEFEAT"
    ],
    "meanings_expanded": [
      "習得",
      "獲得",
      "買収"
    ],
    "contexts": [
      {
        "parts": [
          "Second language",
          "is a complex process."
        ],
        "full": "Second language ACQUISITION is a complex process.",
        "jp": "第二言語習得は複雑なプロセスだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Language ",
          " takes time."
        ],
        "full": "Language ACQUISITION takes time.",
        "jp": "言語の習得には時間がかかる。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a profitable ",
          "."
        ],
        "full": "It was a profitable ACQUISITION.",
        "jp": "それは儲かる買収だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 11,
    "word": "ACUTE",
    "meaning_core": "鋭い",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "CUTE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SHARP": "鋭い",
      "SEVERE": "深刻な",
      "INTENSE": "激しい"
    },
    "distractors": [
      "MILD",
      "DULL",
      "BLUNT",
      "CHRONIC"
    ],
    "meanings_expanded": [
      "鋭い",
      "急性の",
      "深刻な"
    ],
    "contexts": [
      {
        "parts": [
          "He felt an",
          "pain in his chest."
        ],
        "full": "He felt an ACUTE pain in his chest.",
        "jp": "彼は胸に鋭い痛みを感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "He felt an ",
          " pain."
        ],
        "full": "He felt an ACUTE pain.",
        "jp": "彼は鋭い痛みを感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "There is an ",
          " shortage of doctors."
        ],
        "full": "There is an ACUTE shortage of doctors.",
        "jp": "医師が深刻に不足している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 12,
    "word": "ADAMANT",
    "meaning_core": "断固とした",
    "syllables": [
      {
        "text": "AD",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "mant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FIRM": "堅い",
      "UNYIELDING": "譲らない",
      "STUBBORN": "頑固な"
    },
    "distractors": [
      "FLEXIBLE",
      "YIELDING",
      "WEAK",
      "SOFT"
    ],
    "meanings_expanded": [
      "断固とした",
      "譲らない",
      "堅固な"
    ],
    "contexts": [
      {
        "parts": [
          "She was",
          "that she would not go."
        ],
        "full": "She was ADAMANT that she would not go.",
        "jp": "彼女は行かないと断固として主張した。",
        "is_correct": true
      },
      {
        "parts": [
          "She remained ",
          " about her decision."
        ],
        "full": "She remained ADAMANT about her decision.",
        "jp": "彼女は自分の決定について断固とした態度を崩さなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "He was ",
          " that he was right."
        ],
        "full": "He was ADAMANT that he was right.",
        "jp": "彼は自分が正しいと譲らなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 13,
    "word": "ADDICTION",
    "meaning_core": "中毒",
    "syllables": [
      {
        "text": "ad",
        "type": "weak"
      },
      {
        "text": "DIC",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEPENDENCE": "依存",
      "OBSESSION": "執着",
      "CRAVING": "渇望"
    },
    "distractors": [
      "FREEDOM",
      "DISLIKE",
      "HATRED",
      "AVERSION"
    ],
    "meanings_expanded": [
      "中毒",
      "依存症",
      "熱中"
    ],
    "contexts": [
      {
        "parts": [
          "He is fighting a drug",
          "."
        ],
        "full": "He is fighting a drug ADDICTION.",
        "jp": "彼は薬物中毒と戦っている。",
        "is_correct": true
      },
      {
        "parts": [
          "He overcame his drug ",
          "."
        ],
        "full": "He overcame his drug ADDICTION.",
        "jp": "彼は麻薬中毒を克服した。",
        "is_correct": true
      },
      {
        "parts": [
          "Internet ",
          " is a serious issue."
        ],
        "full": "Internet ADDICTION is a serious issue.",
        "jp": "インターネット中毒は深刻な問題だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 14,
    "word": "ADEQUATE",
    "meaning_core": "十分な",
    "syllables": [
      {
        "text": "AD",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "quate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUFFICIENT": "十分な",
      "ENOUGH": "足りる",
      "SUITABLE": "適切な"
    },
    "distractors": [
      "INSUFFICIENT",
      "LACKING",
      "POOR",
      "SCARCE"
    ],
    "meanings_expanded": [
      "十分な",
      "適切な",
      "まずまずの"
    ],
    "contexts": [
      {
        "parts": [
          "We have an",
          "supply of food."
        ],
        "full": "We have an ADEQUATE supply of food.",
        "jp": "私たちには十分な食料の蓄えがある。",
        "is_correct": true
      },
      {
        "parts": [
          "The food supply is ",
          "."
        ],
        "full": "The food supply is ADEQUATE.",
        "jp": "食糧供給は十分だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She has ",
          " experience for the job."
        ],
        "full": "She has ADEQUATE experience for the job.",
        "jp": "彼女はその仕事に十分な経験を持っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 15,
    "word": "ADEQUATELY",
    "meaning_core": "十分に",
    "syllables": [
      {
        "text": "AD",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "quate",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUFFICIENTLY": "十分に",
      "PROPERLY": "適切に",
      "WELL": "よく"
    },
    "distractors": [
      "POORLY",
      "BADLY",
      "INSUFFICIENTLY",
      "BARELY"
    ],
    "meanings_expanded": [
      "十分に",
      "適切に"
    ],
    "contexts": [
      {
        "parts": [
          "Make sure you are",
          "prepared."
        ],
        "full": "Make sure you are ADEQUATELY prepared.",
        "jp": "十分に準備ができているか確認しなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "You must be paid ",
          "."
        ],
        "full": "You must be paid ADEQUATELY.",
        "jp": "あなたは十分に支払われなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The job was not done ",
          "."
        ],
        "full": "The job was not done ADEQUATELY.",
        "jp": "その仕事は十分には行われなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 16,
    "word": "ADMINISTER",
    "meaning_core": "管理する",
    "syllables": [
      {
        "text": "ad",
        "type": "weak"
      },
      {
        "text": "MIN",
        "type": "strong"
      },
      {
        "text": "is",
        "type": "weak"
      },
      {
        "text": "ter",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MANAGE": "管理する",
      "DIRECT": "指揮する",
      "SUPERVISE": "監督する"
    },
    "distractors": [
      "FOLLOW",
      "OBEY",
      "NEGLECT",
      "IGNORE"
    ],
    "meanings_expanded": [
      "管理する",
      "運営する",
      "（薬などを）投与する"
    ],
    "contexts": [
      {
        "parts": [
          "It takes skill to",
          "a large corporation."
        ],
        "full": "It takes skill to ADMINISTER a large corporation.",
        "jp": "大企業を管理するにはスキルが必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They ",
          " the test scores."
        ],
        "full": "They ADMINISTER the test scores.",
        "jp": "彼らはテストの点数を管理する。",
        "is_correct": true
      },
      {
        "parts": [
          "A nurse will ",
          " the medicine."
        ],
        "full": "A nurse will ADMINISTER the medicine.",
        "jp": "看護師が薬を投与するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 17,
    "word": "ADOLESCENCE",
    "meaning_core": "青年期",
    "syllables": [
      {
        "text": "ad",
        "type": "weak"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "LES",
        "type": "strong"
      },
      {
        "text": "cence",
        "type": "weak"
      }
    ],
    "synonyms": {
      "YOUTH": "若さ",
      "TEENS": "十代",
      "PUBERTY": "思春期"
    },
    "distractors": [
      "INFANCY",
      "ADULTHOOD",
      "OLD AGE",
      "SENIORITY"
    ],
    "meanings_expanded": [
      "青年期",
      "思春期",
      "青春"
    ],
    "contexts": [
      {
        "parts": [
          "He struggled during his",
          "."
        ],
        "full": "He struggled during his ADOLESCENCE.",
        "jp": "彼は思春期の間、苦労した。",
        "is_correct": true
      },
      {
        "parts": [
          "He struggled through ",
          "."
        ],
        "full": "He struggled through ADOLESCENCE.",
        "jp": "彼は青年期を乗り越えるのに苦労した。",
        "is_correct": true
      },
      {
        "parts": [
          "The changes occur in ",
          "."
        ],
        "full": "The changes occur in ADOLESCENCE.",
        "jp": "その変化は青年期に起こる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 18,
    "word": "ADOLESCENT",
    "meaning_core": "思春期の若者",
    "syllables": [
      {
        "text": "ad",
        "type": "weak"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "LES",
        "type": "strong"
      },
      {
        "text": "cent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TEENAGER": "ティーンエイジャー",
      "YOUTH": "若者",
      "JUVENILE": "少年少女"
    },
    "distractors": [
      "ADULT",
      "ELDER",
      "INFANT",
      "BABY"
    ],
    "meanings_expanded": [
      "思春期の若者",
      "未熟な",
      "青春の"
    ],
    "contexts": [
      {
        "parts": [
          "Typical",
          "behavior includes rebellion."
        ],
        "full": "Typical ADOLESCENT behavior includes rebellion.",
        "jp": "典型的な思春期の行動には反抗が含まれる。",
        "is_correct": true
      },
      {
        "parts": [
          "She is an ",
          "."
        ],
        "full": "She is an ADOLESCENT.",
        "jp": "彼女は思春期の若者だ。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          " behavior is often difficult."
        ],
        "full": "ADOLESCENT behavior is often difficult.",
        "jp": "思春期の行動はしばしば難しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 19,
    "word": "ADVOCATE",
    "meaning_core": "主張する",
    "syllables": [
      {
        "text": "AD",
        "type": "strong"
      },
      {
        "text": "vo",
        "type": "weak"
      },
      {
        "text": "cate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUPPORT": "支持する",
      "RECOMMEND": "推奨する",
      "PROMOTE": "促進する"
    },
    "distractors": [
      "OPPOSE",
      "CRITICIZE",
      "REJECT",
      "BLOCK"
    ],
    "meanings_expanded": [
      "主張する",
      "支持する",
      "提唱者"
    ],
    "contexts": [
      {
        "parts": [
          "They",
          "for human rights."
        ],
        "full": "They ADVOCATE for human rights.",
        "jp": "彼らは人権を主張している。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a strong ",
          " for change."
        ],
        "full": "She is a strong ADVOCATE for change.",
        "jp": "彼女は変化の強力な支持者だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They ",
          " peace and justice."
        ],
        "full": "They ADVOCATE peace and justice.",
        "jp": "彼らは平和と正義を主張する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 20,
    "word": "AFFLUENT",
    "meaning_core": "裕福な",
    "syllables": [
      {
        "text": "AF",
        "type": "strong"
      },
      {
        "text": "flu",
        "type": "weak"
      },
      {
        "text": "ent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WEALTHY": "裕福な",
      "RICH": "金持ちの",
      "PROSPEROUS": "繁栄している"
    },
    "distractors": [
      "POOR",
      "NEEDY",
      "DESTITUTE",
      "BROKE"
    ],
    "meanings_expanded": [
      "裕福な",
      "豊富な",
      "豊潤な"
    ],
    "contexts": [
      {
        "parts": [
          "He lives in an",
          "neighborhood."
        ],
        "full": "He lives in an AFFLUENT neighborhood.",
        "jp": "彼は裕福な地域に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "They live in an ",
          " area."
        ],
        "full": "They live in an AFFLUENT area.",
        "jp": "彼らは裕福な地域に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "He comes from an ",
          " family."
        ],
        "full": "He comes from an AFFLUENT family.",
        "jp": "彼は裕福な家庭の出身だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 21,
    "word": "AGAINST",
    "meaning_core": "～に反対して",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "GAINST",
        "type": "strong"
      }
    ],
    "synonyms": {
      "OPPOSING": "反対の",
      "VERSUS": "対",
      "CONTRA": "反対"
    },
    "distractors": [
      "FOR",
      "SUPPORTING",
      "WITH",
      "ALONG"
    ],
    "meanings_expanded": [
      "～に反対して",
      "～を背景にして",
      "～にもたれて"
    ],
    "contexts": [
      {
        "parts": [
          "I voted",
          "the proposal."
        ],
        "full": "I voted AGAINST the proposal.",
        "jp": "私はその提案に反対票を投じた。",
        "is_correct": true
      },
      {
        "parts": [
          "We are fighting ",
          " poverty."
        ],
        "full": "We are fighting AGAINST poverty.",
        "jp": "私たちは貧困と闘っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The decision was ",
          " my wishes."
        ],
        "full": "The decision was AGAINST my wishes.",
        "jp": "その決定は私の望みに反していた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 22,
    "word": "ALIENATE",
    "meaning_core": "疎遠にする",
    "syllables": [
      {
        "text": "A",
        "type": "strong"
      },
      {
        "text": "lien",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ESTRANGE": "仲たがいさせる",
      "ISOLATE": "孤立させる",
      "DISTANCE": "距離を置く"
    },
    "distractors": [
      "UNITE",
      "BEFRIEND",
      "JOIN",
      "ATTRACT"
    ],
    "meanings_expanded": [
      "疎遠にする",
      "遠ざける",
      "不和にする"
    ],
    "contexts": [
      {
        "parts": [
          "His rude behavior might",
          "his friends."
        ],
        "full": "His rude behavior might ALIENATE his friends.",
        "jp": "彼の無礼な態度は友人を遠ざけるかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "His actions may ",
          " his friends."
        ],
        "full": "His actions may ALIENATE his friends.",
        "jp": "彼の行動は友人を疎遠にするかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "Policies that ",
          " voters should be avoided."
        ],
        "full": "Policies that ALIENATE voters should be avoided.",
        "jp": "有権者を遠ざける政策は避けるべきだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 23,
    "word": "ALLEGE",
    "meaning_core": "主張する",
    "syllables": [
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "LEGE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CLAIM": "主張する",
      "ASSERT": "断言する",
      "MAINTAIN": "主張し続ける"
    },
    "distractors": [
      "DENY",
      "WITHDRAW",
      "REFUTE",
      "CONCEAL"
    ],
    "meanings_expanded": [
      "（証拠なしに）主張する",
      "断言する"
    ],
    "contexts": [
      {
        "parts": [
          "Prosecutors",
          "that he stole the money."
        ],
        "full": "Prosecutors ALLEGE that he stole the money.",
        "jp": "検察官は彼がお金を盗んだと主張している。",
        "is_correct": true
      },
      {
        "parts": [
          "The report ",
          " fraud."
        ],
        "full": "The report ALLEGE fraud.",
        "jp": "その報告書は詐欺を主張している。",
        "is_correct": true
      },
      {
        "parts": [
          "They ",
          " that he lied."
        ],
        "full": "They ALLEGE that he lied.",
        "jp": "彼らは彼が嘘をついたと主張する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 24,
    "word": "ALLEGEDLY",
    "meaning_core": "伝えられるところによると",
    "syllables": [
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "LEGED",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REPORTEDLY": "報じられるところでは",
      "SUPPOSEDLY": "たぶん",
      "PURPORTEDLY": "噂によると"
    },
    "distractors": [
      "DEFINITELY",
      "CERTAINLY",
      "ACTUALLY",
      "TRULY"
    ],
    "meanings_expanded": [
      "伝えられるところによると",
      "申し立てによると"
    ],
    "contexts": [
      {
        "parts": [
          "He was",
          "involved in the scandal."
        ],
        "full": "He was ALLEGEDLY involved in the scandal.",
        "jp": "伝えられるところでは、彼はそのスキャンダルに関与していた。",
        "is_correct": true
      },
      {
        "parts": [
          "He was ",
          " involved in the crime."
        ],
        "full": "He was ALLEGEDLY involved in the crime.",
        "jp": "伝えられるところによると、彼はその犯罪に関わっていた。",
        "is_correct": true
      },
      {
        "parts": [
          "The company ",
          " broke the law."
        ],
        "full": "The company ALLEGEDLY broke the law.",
        "jp": "伝えられるところによると、その会社は法律を破った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 25,
    "word": "ALLEGIANCE",
    "meaning_core": "忠誠",
    "syllables": [
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "LE",
        "type": "strong"
      },
      {
        "text": "giance",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LOYALTY": "忠誠心",
      "FIDELITY": "忠実",
      "DEVOTION": "献身"
    },
    "distractors": [
      "TREACHERY",
      "TREASON",
      "BETRAYAL",
      "DISLOYALTY"
    ],
    "meanings_expanded": [
      "忠誠",
      "献身",
      "忠義"
    ],
    "contexts": [
      {
        "parts": [
          "They pledged",
          "to the flag."
        ],
        "full": "They pledged ALLEGIANCE to the flag.",
        "jp": "彼らは国旗への忠誠を誓った。",
        "is_correct": true
      },
      {
        "parts": [
          "They swore ",
          " to the flag."
        ],
        "full": "They swore ALLEGIANCE to the flag.",
        "jp": "彼らは国旗に忠誠を誓った。",
        "is_correct": true
      },
      {
        "parts": [
          "He questioned their ",
          "."
        ],
        "full": "He questioned their ALLEGIANCE.",
        "jp": "彼は彼らの忠誠心を疑った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 26,
    "word": "ALLEVIATE",
    "meaning_core": "緩和する",
    "syllables": [
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "LE",
        "type": "strong"
      },
      {
        "text": "vi",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RELIEVE": "和らげる",
      "EASE": "楽にする",
      "LESSEN": "減らす"
    },
    "distractors": [
      "AGGRAVATE",
      "WORSEN",
      "INTENSIFY",
      "INCREASE"
    ],
    "meanings_expanded": [
      "緩和する",
      "軽減する",
      "楽にする"
    ],
    "contexts": [
      {
        "parts": [
          "This medicine will",
          "the pain."
        ],
        "full": "This medicine will ALLEVIATE the pain.",
        "jp": "この薬は痛みを緩和するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "This medicine will ",
          " the pain."
        ],
        "full": "This medicine will ALLEVIATE the pain.",
        "jp": "この薬は痛みを緩和するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the traffic problem."
        ],
        "full": "We need to ALLEVIATE the traffic problem.",
        "jp": "私たちは交通問題を緩和する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 27,
    "word": "ALLOCATE",
    "meaning_core": "割り当てる",
    "syllables": [
      {
        "text": "AL",
        "type": "strong"
      },
      {
        "text": "lo",
        "type": "weak"
      },
      {
        "text": "cate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ASSIGN": "割り当てる",
      "DISTRIBUTE": "分配する",
      "ALLOT": "配分する"
    },
    "distractors": [
      "WITHHOLD",
      "KEEP",
      "RETAIN",
      "GATHER"
    ],
    "meanings_expanded": [
      "割り当てる",
      "配分する",
      "計上する"
    ],
    "contexts": [
      {
        "parts": [
          "We need to",
          "funds for research."
        ],
        "full": "We need to ALLOCATE funds for research.",
        "jp": "我々は研究のために資金を割り当てる必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " funds for the project."
        ],
        "full": "They will ALLOCATE funds for the project.",
        "jp": "彼らはプロジェクトに資金を割り当てるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " resources fairly."
        ],
        "full": "We need to ALLOCATE resources fairly.",
        "jp": "私たちは資源を公平に割り当てる必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 28,
    "word": "ALONG WITH",
    "meaning_core": "～と一緒に",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "LONG",
        "type": "strong"
      },
      {
        "text": "with",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TOGETHER WITH": "～と共に",
      "BESIDES": "～に加えて",
      "PLUS": "～を足して"
    },
    "distractors": [
      "INSTEAD OF",
      "WITHOUT",
      "EXCEPT",
      "MINUS"
    ],
    "meanings_expanded": [
      "～と一緒に",
      "～に加えて",
      "～と協力して"
    ],
    "contexts": [
      {
        "parts": [
          "I ordered coffee",
          "a sandwich."
        ],
        "full": "I ordered coffee ALONG WITH a sandwich.",
        "jp": "私はサンドイッチと一緒にコーヒーを注文した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 29,
    "word": "ALTER",
    "meaning_core": "変える",
    "syllables": [
      {
        "text": "AL",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CHANGE": "変える",
      "MODIFY": "修正する",
      "ADJUST": "調整する"
    },
    "distractors": [
      "PRESERVE",
      "KEEP",
      "MAINTAIN",
      "STAY"
    ],
    "meanings_expanded": [
      "変える",
      "改める",
      "作り直す"
    ],
    "contexts": [
      {
        "parts": [
          "We had to",
          "our plans."
        ],
        "full": "We had to ALTER our plans.",
        "jp": "私たちは計画を変更しなければならなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "The tailor can ",
          " the suit."
        ],
        "full": "The tailor can ALTER the suit.",
        "jp": "仕立て屋はそのスーツを直せる。",
        "is_correct": true
      },
      {
        "parts": [
          "You should ",
          " your eating habits."
        ],
        "full": "You should ALTER your eating habits.",
        "jp": "あなたは食習慣を変えるべきだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 30,
    "word": "ALTERNATIVE",
    "meaning_core": "代わりの",
    "syllables": [
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "TER",
        "type": "strong"
      },
      {
        "text": "na",
        "type": "weak"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUBSTITUTE": "代わりの",
      "OPTION": "選択肢",
      "CHOICE": "選択"
    },
    "distractors": [
      "PRIMARY",
      "MAIN",
      "OBLIGATION",
      "NECESSITY"
    ],
    "meanings_expanded": [
      "代わりの",
      "代替の",
      "二者択一の"
    ],
    "contexts": [
      {
        "parts": [
          "We need to find an",
          "energy source."
        ],
        "full": "We need to find an ALTERNATIVE energy source.",
        "jp": "私たちは代替エネルギー源を見つける必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Is there an ",
          " solution?"
        ],
        "full": "Is there an ALTERNATIVE solution?",
        "jp": "代わりの解決策はありますか。",
        "is_correct": true
      },
      {
        "parts": [
          "She found an ",
          " route home."
        ],
        "full": "She found an ALTERNATIVE route home.",
        "jp": "彼女は家に帰る別のルートを見つけた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 31,
    "word": "ALTITUDE",
    "meaning_core": "高度",
    "syllables": [
      {
        "text": "AL",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "tude",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HEIGHT": "高さ",
      "ELEVATION": "海抜",
      "LEVEL": "水準"
    },
    "distractors": [
      "DEPTH",
      "BOTTOM",
      "LOW",
      "BASE"
    ],
    "meanings_expanded": [
      "高度",
      "海抜",
      "標高"
    ],
    "contexts": [
      {
        "parts": [
          "The plane is flying at a high",
          "."
        ],
        "full": "The plane is flying at a high ALTITUDE.",
        "jp": "飛行機は高い高度を飛んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "The plane reached a high ",
          "."
        ],
        "full": "The plane reached a high ALTITUDE.",
        "jp": "飛行機は高い高度に達した。",
        "is_correct": true
      },
      {
        "parts": [
          "We trained at high ",
          "."
        ],
        "full": "We trained at high ALTITUDE.",
        "jp": "私たちは高地で訓練した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 32,
    "word": "AMBIGUITY",
    "meaning_core": "曖昧さ",
    "syllables": [
      {
        "text": "am",
        "type": "weak"
      },
      {
        "text": "bi",
        "type": "weak"
      },
      {
        "text": "GU",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VAGUENESS": "漠然",
      "UNCERTAINTY": "不確実",
      "OBSCURITY": "不明瞭"
    },
    "distractors": [
      "CLARITY",
      "CERTAINTY",
      "CLEARNESS",
      "PRECISION"
    ],
    "meanings_expanded": [
      "曖昧さ",
      "多義性",
      "不明瞭"
    ],
    "contexts": [
      {
        "parts": [
          "There is some",
          "in the contract."
        ],
        "full": "There is some AMBIGUITY in the contract.",
        "jp": "その契約書にはいくつかの曖昧さがある。",
        "is_correct": true
      },
      {
        "parts": [
          "The contract contains some ",
          "."
        ],
        "full": "The contract contains some AMBIGUITY.",
        "jp": "その契約にはいくつかの曖昧さが含まれている。",
        "is_correct": true
      },
      {
        "parts": [
          "We must avoid ",
          "."
        ],
        "full": "We must avoid AMBIGUITY.",
        "jp": "私たちは曖昧さを避けなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 33,
    "word": "AMBIGUOUS",
    "meaning_core": "曖昧な",
    "syllables": [
      {
        "text": "am",
        "type": "weak"
      },
      {
        "text": "BIG",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VAGUE": "漠然とした",
      "UNCLEAR": "不明瞭な",
      "INDEFINITE": "不確定な"
    },
    "distractors": [
      "CLEAR",
      "EXPLICIT",
      "DEFINITE",
      "OBVIOUS"
    ],
    "meanings_expanded": [
      "曖昧な",
      "多義の",
      "不明瞭な"
    ],
    "contexts": [
      {
        "parts": [
          "His answer was somewhat",
          "."
        ],
        "full": "His answer was somewhat AMBIGUOUS.",
        "jp": "彼の答えはいくぶん曖昧だった。",
        "is_correct": true
      },
      {
        "parts": [
          "His answer was somewhat ",
          "."
        ],
        "full": "His answer was somewhat AMBIGUOUS.",
        "jp": "彼の返事はいくらか曖昧だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The sign was too ",
          " to follow."
        ],
        "full": "The sign was too AMBIGUOUS to follow.",
        "jp": "その標識は曖昧すぎて従えなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 34,
    "word": "AMENITIES",
    "meaning_core": "快適な設備",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "MEN",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ties",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FACILITIES": "施設",
      "CONVENIENCES": "便利なもの",
      "COMFORTS": "快適さ"
    },
    "distractors": [
      "NECESSITIES",
      "BASICS",
      "HARDSHIPS",
      "BURDENS"
    ],
    "meanings_expanded": [
      "快適な設備",
      "アメニティ",
      "心地よさ"
    ],
    "contexts": [
      {
        "parts": [
          "The hotel offers many",
          "like a pool."
        ],
        "full": "The hotel offers many AMENITIES like a pool.",
        "jp": "そのホテルはプールなど多くの快適な設備を提供している。",
        "is_correct": true
      },
      {
        "parts": [
          "The hotel offers great ",
          "."
        ],
        "full": "The hotel offers great AMENITIES.",
        "jp": "そのホテルは素晴らしい設備を提供している。",
        "is_correct": true
      },
      {
        "parts": [
          "We enjoyed all the new ",
          "."
        ],
        "full": "We enjoyed all the new AMENITIES.",
        "jp": "私たちは新しい設備すべてを楽しんだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 35,
    "word": "AMIABLE",
    "meaning_core": "愛想の良い",
    "syllables": [
      {
        "text": "A",
        "type": "strong"
      },
      {
        "text": "mi",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FRIENDLY": "友好的な",
      "PLEASANT": "感じの良い",
      "AGREEABLE": "好ましい"
    },
    "distractors": [
      "HOSTILE",
      "UNFRIENDLY",
      "RUDE",
      "COLD"
    ],
    "meanings_expanded": [
      "愛想の良い",
      "好意的な",
      "社交的な"
    ],
    "contexts": [
      {
        "parts": [
          "She is known for her",
          "personality."
        ],
        "full": "She is known for her AMIABLE personality.",
        "jp": "彼女は愛想の良い性格で知られている。",
        "is_correct": true
      },
      {
        "parts": [
          "She has an ",
          " personality."
        ],
        "full": "She has an AMIABLE personality.",
        "jp": "彼女は愛想の良い性格をしている。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an ",
          " boss."
        ],
        "full": "He is an AMIABLE boss.",
        "jp": "彼はいやな顔をしない上司だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 36,
    "word": "AMONG",
    "meaning_core": "～の間で",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "MONG",
        "type": "strong"
      }
    ],
    "synonyms": {
      "AMIDST": "～の真ん中に",
      "BETWEEN": "～の間に",
      "IN": "～の中に"
    },
    "distractors": [
      "OUTSIDE",
      "APART",
      "AWAY",
      "BEYOND"
    ],
    "meanings_expanded": [
      "（3つ以上）の間で",
      "～に囲まれて",
      "～の中の一人で"
    ],
    "contexts": [
      {
        "parts": [
          "He is very popular",
          "the students."
        ],
        "full": "He is very popular AMONG the students.",
        "jp": "彼は生徒たちの間でとても人気がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The children were playing ",
          " the trees."
        ],
        "full": "The children were playing AMONG the trees.",
        "jp": "子供たちは木々の間で遊んでいた。",
        "is_correct": true
      },
      {
        "parts": [
          "Divide the cake ",
          " yourselves."
        ],
        "full": "Divide the cake AMONG yourselves.",
        "jp": "ケーキをあなたたち自身の間で分けなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 37,
    "word": "AMPLIFY",
    "meaning_core": "増幅する",
    "syllables": [
      {
        "text": "AM",
        "type": "strong"
      },
      {
        "text": "pli",
        "type": "weak"
      },
      {
        "text": "fy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INCREASE": "増やす",
      "BOOST": "高める",
      "MAGNIFY": "拡大する"
    },
    "distractors": [
      "REDUCE",
      "DECREASE",
      "LOWER",
      "DIMINISH"
    ],
    "meanings_expanded": [
      "増幅する",
      "拡大する",
      "詳しく述べる"
    ],
    "contexts": [
      {
        "parts": [
          "This device will",
          "the sound signals."
        ],
        "full": "This device will AMPLIFY the sound signals.",
        "jp": "この装置は音声信号を増幅する。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the sound."
        ],
        "full": "We must AMPLIFY the sound.",
        "jp": "私たちは音を増幅しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The speakers will ",
          " the voices."
        ],
        "full": "The speakers will AMPLIFY the voices.",
        "jp": "スピーカーが声を増幅するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 38,
    "word": "ANALYZE",
    "meaning_core": "分析する",
    "syllables": [
      {
        "text": "AN",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "lyze",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXAMINE": "調査する",
      "STUDY": "研究する",
      "INVESTIGATE": "調査する"
    },
    "distractors": [
      "IGNORE",
      "NEGLECT",
      "OVERLOOK",
      "GUESS"
    ],
    "meanings_expanded": [
      "分析する",
      "分解する",
      "検討する"
    ],
    "contexts": [
      {
        "parts": [
          "Scientists",
          "the data carefully."
        ],
        "full": "Scientists ANALYZE the data carefully.",
        "jp": "科学者たちはデータを慎重に分析する。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " the survey results."
        ],
        "full": "Please ANALYZE the survey results.",
        "jp": "アンケート結果を分析してください。",
        "is_correct": true
      },
      {
        "parts": [
          "Scientists will ",
          " the data."
        ],
        "full": "Scientists will ANALYZE the data.",
        "jp": "科学者たちはデータを分析するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 39,
    "word": "ANTIQUE",
    "meaning_core": "骨董品",
    "syllables": [
      {
        "text": "an",
        "type": "weak"
      },
      {
        "text": "TIQUE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "RELIC": "遺物",
      "ARTIFACT": "工芸品",
      "HEIRLOOM": "家宝"
    },
    "distractors": [
      "NOVELTY",
      "TRASH",
      "GARBAGE",
      "COPY"
    ],
    "meanings_expanded": [
      "骨董品",
      "古美術品",
      "古風な"
    ],
    "contexts": [
      {
        "parts": [
          "This vase is a valuable",
          "."
        ],
        "full": "This vase is a valuable ANTIQUE.",
        "jp": "この花瓶は貴重な骨董品だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She collects ",
          " furniture."
        ],
        "full": "She collects ANTIQUE furniture.",
        "jp": "彼女は骨董品の家具を集めている。",
        "is_correct": true
      },
      {
        "parts": [
          "The clock is a valuable ",
          "."
        ],
        "full": "The clock is a valuable ANTIQUE.",
        "jp": "その時計は貴重な骨董品だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 40,
    "word": "ANXIETY",
    "meaning_core": "不安",
    "syllables": [
      {
        "text": "ang",
        "type": "weak"
      },
      {
        "text": "ZI",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WORRY": "心配",
      "CONCERN": "懸念",
      "NERVOUSNESS": "神経質"
    },
    "distractors": [
      "CALM",
      "PEACE",
      "CONFIDENCE",
      "RELIEF"
    ],
    "meanings_expanded": [
      "不安",
      "心配",
      "切望"
    ],
    "contexts": [
      {
        "parts": [
          "She suffers from social",
          "."
        ],
        "full": "She suffers from social ANXIETY.",
        "jp": "彼女は社交不安に苦しんでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "He feels great ",
          " before tests."
        ],
        "full": "He feels great ANXIETY before tests.",
        "jp": "彼は試験の前に大きな不安を感じる。",
        "is_correct": true
      },
      {
        "parts": [
          "I suffer from exam ",
          "."
        ],
        "full": "I suffer from exam ANXIETY.",
        "jp": "私は試験の不安に苦しんでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 41,
    "word": "APPARENT",
    "meaning_core": "明白な",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "PAR",
        "type": "strong"
      },
      {
        "text": "ent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OBVIOUS": "明らかな",
      "CLEAR": "明確な",
      "EVIDENT": "明白な"
    },
    "distractors": [
      "HIDDEN",
      "OBSCURE",
      "UNCLEAR",
      "SECRET"
    ],
    "meanings_expanded": [
      "明白な",
      "一見して～らしい",
      "外見上の"
    ],
    "contexts": [
      {
        "parts": [
          "It became",
          "that he was lying."
        ],
        "full": "It became APPARENT that he was lying.",
        "jp": "彼が嘘をついていることが明白になった。",
        "is_correct": true
      },
      {
        "parts": [
          "His confusion was ",
          "."
        ],
        "full": "His confusion was APPARENT.",
        "jp": "彼の混乱は明白だった。",
        "is_correct": true
      },
      {
        "parts": [
          "It is ",
          " that he won."
        ],
        "full": "It is APPARENT that he won.",
        "jp": "彼が勝ったのは明らかだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 42,
    "word": "APPARENTLY",
    "meaning_core": "どうやら～らしい",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "PAR",
        "type": "strong"
      },
      {
        "text": "ent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SEEMINGLY": "見たところ",
      "EVIDENTLY": "明らかに",
      "SUPPOSEDLY": "たぶん"
    },
    "distractors": [
      "DEFINITELY",
      "ACTUALLY",
      "CERTAINLY",
      "SURELY"
    ],
    "meanings_expanded": [
      "見たところでは",
      "どうやら～らしい"
    ],
    "contexts": [
      {
        "parts": [
          "He is",
          "planning to resign."
        ],
        "full": "He is APPARENTLY planning to resign.",
        "jp": "彼はどうやら辞職するつもりのようだ。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          ", he left early."
        ],
        "full": "APPARENTLY, he left early.",
        "jp": "どうやら、彼は早く出発したらしい。",
        "is_correct": true
      },
      {
        "parts": [
          "The car, ",
          ", broke down."
        ],
        "full": "The car, APPARENTLY, broke down.",
        "jp": "どうやら、車が故障したらしい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 43,
    "word": "APPRAISAL",
    "meaning_core": "評価",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "PRAIS",
        "type": "strong"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ASSESSMENT": "査定",
      "EVALUATION": "評価",
      "ESTIMATE": "見積もり"
    },
    "distractors": [
      "NEGLECT",
      "DISREGARD",
      "GUESS",
      "IGNORANCE"
    ],
    "meanings_expanded": [
      "評価",
      "査定",
      "鑑定"
    ],
    "contexts": [
      {
        "parts": [
          "He received a positive performance",
          "."
        ],
        "full": "He received a positive performance APPRAISAL.",
        "jp": "彼は肯定的な業績評価を受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "She received a positive ",
          "."
        ],
        "full": "She received a positive APPRAISAL.",
        "jp": "彼女は肯定的な評価を受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a property ",
          "."
        ],
        "full": "We need a property APPRAISAL.",
        "jp": "私たちは不動産の評価が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 44,
    "word": "APPRECIATE",
    "meaning_core": "感謝する",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "PRE",
        "type": "strong"
      },
      {
        "text": "ci",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VALUE": "評価する",
      "CHERISH": "大事にする",
      "GRATEFUL": "感謝する"
    },
    "distractors": [
      "CRITICIZE",
      "DISREGARD",
      "SCORN",
      "HATE"
    ],
    "meanings_expanded": [
      "感謝する",
      "正しく評価する",
      "理解する"
    ],
    "contexts": [
      {
        "parts": [
          "I really",
          "your help."
        ],
        "full": "I really APPRECIATE your help.",
        "jp": "あなたの助けに本当に感謝しています。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " your help very much."
        ],
        "full": "I APPRECIATE your help very much.",
        "jp": "あなたの助けにとても感謝します。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " good health."
        ],
        "full": "We must APPRECIATE good health.",
        "jp": "私たちは健康に感謝しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 45,
    "word": "APPREHEND",
    "meaning_core": "逮捕する",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "HEND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ARREST": "逮捕する",
      "CAPTURE": "捕らえる",
      "SEIZE": "つかむ"
    },
    "distractors": [
      "RELEASE",
      "FREE",
      "MISS",
      "LOSE"
    ],
    "meanings_expanded": [
      "逮捕する",
      "理解する",
      "懸念する"
    ],
    "contexts": [
      {
        "parts": [
          "The police managed to",
          "the suspect."
        ],
        "full": "The police managed to APPREHEND the suspect.",
        "jp": "警察はどうにか容疑者を逮捕した。",
        "is_correct": true
      },
      {
        "parts": [
          "The police will ",
          " the suspect."
        ],
        "full": "The police will APPREHEND the suspect.",
        "jp": "警察は容疑者を逮捕するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "They attempted to ",
          " the thief."
        ],
        "full": "They attempted to APPREHEND the thief.",
        "jp": "彼らは泥棒を逮捕しようとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 46,
    "word": "APPREHENSION",
    "meaning_core": "不安",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "HEN",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANXIETY": "心配",
      "FEAR": "恐れ",
      "DREAD": "恐怖"
    },
    "distractors": [
      "CONFIDENCE",
      "CALM",
      "TRUST",
      "HOPE"
    ],
    "meanings_expanded": [
      "不安",
      "懸念",
      "逮捕"
    ],
    "contexts": [
      {
        "parts": [
          "He felt a sense of",
          "about the future."
        ],
        "full": "He felt a sense of APPREHENSION about the future.",
        "jp": "彼は将来に対して不安を感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "He felt growing ",
          " about the future."
        ],
        "full": "He felt growing APPREHENSION about the future.",
        "jp": "彼は将来に対する不安が募るのを感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "The news caused much ",
          "."
        ],
        "full": "The news caused much APPREHENSION.",
        "jp": "そのニュースは多くの不安を引き起こした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 47,
    "word": "APPROPRIATE",
    "meaning_core": "適切な",
    "syllables": [
      {
        "text": "ap",
        "type": "weak"
      },
      {
        "text": "PRO",
        "type": "strong"
      },
      {
        "text": "pri",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUITABLE": "適した",
      "PROPER": "適切な",
      "FITTING": "ふさわしい"
    },
    "distractors": [
      "IMPROPER",
      "WRONG",
      "UNSUITABLE",
      "INCORRECT"
    ],
    "meanings_expanded": [
      "適切な",
      "ふさわしい"
    ],
    "contexts": [
      {
        "parts": [
          "Wear clothes",
          "for the occasion."
        ],
        "full": "Wear clothes APPROPRIATE for the occasion.",
        "jp": "その場にふさわしい服を着なさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Wear ",
          " clothes for the party."
        ],
        "full": "Wear APPROPRIATE clothes for the party.",
        "jp": "パーティーには適切な服を着なさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Now is the ",
          " time to act."
        ],
        "full": "Now is the APPROPRIATE time to act.",
        "jp": "今が行動するのに適切な時だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 48,
    "word": "ARROGANT",
    "meaning_core": "尊大な",
    "syllables": [
      {
        "text": "AR",
        "type": "strong"
      },
      {
        "text": "ro",
        "type": "weak"
      },
      {
        "text": "gant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HAUGHTY": "高慢な",
      "PROUD": "誇り高い",
      "CONCEITED": "うぬぼれた"
    },
    "distractors": [
      "HUMBLE",
      "MODEST",
      "SHY",
      "MEEK"
    ],
    "meanings_expanded": [
      "尊大な",
      "傲慢な",
      "横柄な"
    ],
    "contexts": [
      {
        "parts": [
          "His",
          "attitude annoyed everyone."
        ],
        "full": "His ARROGANT attitude annoyed everyone.",
        "jp": "彼の傲慢な態度は皆をイライラさせた。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an ",
          " and rude person."
        ],
        "full": "He is an ARROGANT and rude person.",
        "jp": "彼はおごり高ぶっていて失礼な人だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Avoid his ",
          " attitude."
        ],
        "full": "Avoid his ARROGANT attitude.",
        "jp": "彼の尊大な態度は避けて。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 49,
    "word": "ARTIFICIAL",
    "meaning_core": "人工の",
    "syllables": [
      {
        "text": "ar",
        "type": "weak"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "FI",
        "type": "strong"
      },
      {
        "text": "cial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SYNTHETIC": "合成の",
      "MAN-MADE": "人造の",
      "FAKE": "偽の"
    },
    "distractors": [
      "NATURAL",
      "REAL",
      "GENUINE",
      "AUTHENTIC"
    ],
    "meanings_expanded": [
      "人工の",
      "模造の",
      "不自然な"
    ],
    "contexts": [
      {
        "parts": [
          "This juice contains",
          "flavors."
        ],
        "full": "This juice contains ARTIFICIAL flavors.",
        "jp": "このジュースには人工香料が含まれている。",
        "is_correct": true
      },
      {
        "parts": [
          "The flower is ",
          "."
        ],
        "full": "The flower is ARTIFICIAL.",
        "jp": "その花は造花だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He used ",
          " flavoring."
        ],
        "full": "He used ARTIFICIAL flavoring.",
        "jp": "彼は人工の香料を使った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 51,
    "word": "ASCERTAIN",
    "meaning_core": "確かめる",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "cer",
        "type": "weak"
      },
      {
        "text": "TAIN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONFIRM": "確認する",
      "DETERMINE": "特定する",
      "VERIFY": "検証する"
    },
    "distractors": [
      "GUESS",
      "IGNORE",
      "ASSUME",
      "DOUBT"
    ],
    "meanings_expanded": [
      "確かめる",
      "突き止める",
      "確認する"
    ],
    "contexts": [
      {
        "parts": [
          "We need to",
          "the cause of the fire."
        ],
        "full": "We need to ASCERTAIN the cause of the fire.",
        "jp": "我々は火事の原因を突き止める必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the facts."
        ],
        "full": "We must ASCERTAIN the facts.",
        "jp": "私たちは事実を確かめなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " his guilt."
        ],
        "full": "They will ASCERTAIN his guilt.",
        "jp": "彼らは彼の有罪を確かめるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 52,
    "word": "ASPECT",
    "meaning_core": "側面",
    "syllables": [
      {
        "text": "AS",
        "type": "strong"
      },
      {
        "text": "pect",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FEATURE": "特徴",
      "FACET": "面",
      "PHASE": "局面"
    },
    "distractors": [
      "WHOLE",
      "TOTALITY",
      "ENTITY",
      "ALL"
    ],
    "meanings_expanded": [
      "側面",
      "様相",
      "局面"
    ],
    "contexts": [
      {
        "parts": [
          "Climate change affects every",
          "of our lives."
        ],
        "full": "Climate change affects every ASPECT of our lives.",
        "jp": "気候変動は私たちの生活のあらゆる側面に影響を与える。",
        "is_correct": true
      },
      {
        "parts": [
          "Consider every ",
          " of the problem."
        ],
        "full": "Consider every ASPECT of the problem.",
        "jp": "問題のあらゆる側面を考慮しなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a key ",
          " of the plan."
        ],
        "full": "This is a key ASPECT of the plan.",
        "jp": "これは計画の重要な側面だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 53,
    "word": "ASPIRE",
    "meaning_core": "熱望する",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "PIRE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DESIRE": "強く望む",
      "AIM": "目指す",
      "SEEK": "追い求める"
    },
    "distractors": [
      "HATE",
      "DISLIKE",
      "AVOID",
      "REJECT"
    ],
    "meanings_expanded": [
      "熱望する",
      "目指す",
      "抱負を持つ"
    ],
    "contexts": [
      {
        "parts": [
          "Many young people",
          "to be famous."
        ],
        "full": "Many young people ASPIRE to be famous.",
        "jp": "多くの若者が有名になることを熱望している。",
        "is_correct": true
      },
      {
        "parts": [
          "She ",
          " to be a doctor."
        ],
        "full": "She ASPIRE to be a doctor.",
        "jp": "彼女は医者になることを熱望している。",
        "is_correct": true
      },
      {
        "parts": [
          "We should ",
          " to greatness."
        ],
        "full": "We should ASPIRE to greatness.",
        "jp": "私たちは偉大であることを熱望すべきだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 54,
    "word": "ASSEMBLE",
    "meaning_core": "集める",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SEM",
        "type": "strong"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "GATHER": "集める",
      "COLLECT": "収集する",
      "CONSTRUCT": "組み立てる"
    },
    "distractors": [
      "DISPERSE",
      "SCATTER",
      "BREAK",
      "SEPARATE"
    ],
    "meanings_expanded": [
      "集める",
      "組み立てる",
      "招集する"
    ],
    "contexts": [
      {
        "parts": [
          "The students began to",
          "in the hall."
        ],
        "full": "The students began to ASSEMBLE in the hall.",
        "jp": "生徒たちはホールに集まり始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " the product quickly."
        ],
        "full": "Please ASSEMBLE the product quickly.",
        "jp": "製品をすぐに組み立ててください。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " a team for the task."
        ],
        "full": "We will ASSEMBLE a team for the task.",
        "jp": "私たちはその仕事のためにチームを集めるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 55,
    "word": "ASSERT",
    "meaning_core": "断言する",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SERT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DECLARE": "宣言する",
      "CLAIM": "主張する",
      "INSIST": "言い張る"
    },
    "distractors": [
      "DENY",
      "DOUBT",
      "QUESTION",
      "HIDE"
    ],
    "meanings_expanded": [
      "断言する",
      "強く主張する",
      "権利を行使する"
    ],
    "contexts": [
      {
        "parts": [
          "He continued to",
          "his innocence."
        ],
        "full": "He continued to ASSERT his innocence.",
        "jp": "彼は自分の無実を断言し続けた。",
        "is_correct": true
      },
      {
        "parts": [
          "He needs to ",
          " his rights."
        ],
        "full": "He needs to ASSERT his rights.",
        "jp": "彼は自分の権利を主張する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She dared to ",
          " her opinion."
        ],
        "full": "She dared to ASSERT her opinion.",
        "jp": "彼女はあえて自分の意見を断言した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 56,
    "word": "ASSESS",
    "meaning_core": "評価する",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SESS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EVALUATE": "評価する",
      "ESTIMATE": "見積もる",
      "JUDGE": "判断する"
    },
    "distractors": [
      "GUESS",
      "IGNORE",
      "NEGLECT",
      "OVERLOOK"
    ],
    "meanings_expanded": [
      "評価する",
      "査定する",
      "見極める"
    ],
    "contexts": [
      {
        "parts": [
          "Experts will",
          "the damage caused by the storm."
        ],
        "full": "Experts will ASSESS the damage caused by the storm.",
        "jp": "専門家が嵐による被害を評価するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the risks first."
        ],
        "full": "We must ASSESS the risks first.",
        "jp": "私たちはまずリスクを評価しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " his performance."
        ],
        "full": "They will ASSESS his performance.",
        "jp": "彼らは彼の業績を評価するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 57,
    "word": "ASSET",
    "meaning_core": "資産",
    "syllables": [
      {
        "text": "AS",
        "type": "strong"
      },
      {
        "text": "set",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PROPERTY": "財産",
      "RESOURCE": "資源",
      "ADVANTAGE": "利点"
    },
    "distractors": [
      "LIABILITY",
      "DEBT",
      "DISADVANTAGE",
      "LOSS"
    ],
    "meanings_expanded": [
      "資産",
      "財産",
      "貴重なもの"
    ],
    "contexts": [
      {
        "parts": [
          "Good health is a great",
          "."
        ],
        "full": "Good health is a great ASSET.",
        "jp": "健康は偉大な資産だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Knowledge is a valuable ",
          "."
        ],
        "full": "Knowledge is a valuable ASSET.",
        "jp": "知識は貴重な財産だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The company's main ",
          " is its staff."
        ],
        "full": "The company's main ASSET is its staff.",
        "jp": "その会社の主な資産はスタッフだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 58,
    "word": "ASSIGN",
    "meaning_core": "割り当てる",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SIGN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ALLOCATE": "配分する",
      "APPOINT": "任命する",
      "DESIGNATE": "指定する"
    },
    "distractors": [
      "WITHDRAW",
      "REMOVE",
      "CANCEL",
      "KEEP"
    ],
    "meanings_expanded": [
      "割り当てる",
      "任命する",
      "指定する"
    ],
    "contexts": [
      {
        "parts": [
          "The teacher will",
          "homework to the class."
        ],
        "full": "The teacher will ASSIGN homework to the class.",
        "jp": "先生はクラスに宿題を割り当てるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "I will ",
          " you a new task."
        ],
        "full": "I will ASSIGN you a new task.",
        "jp": "あなたに新しい仕事を割り当てます。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " the homework by Friday."
        ],
        "full": "Please ASSIGN the homework by Friday.",
        "jp": "宿題を金曜日までに課してください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 59,
    "word": "ASSIMILATE",
    "meaning_core": "同化する",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SIM",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "late",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ABSORB": "吸収する",
      "INTEGRATE": "統合する",
      "DIGEST": "消化する"
    },
    "distractors": [
      "SEPARATE",
      "REJECT",
      "EXCLUDE",
      "ISOLATE"
    ],
    "meanings_expanded": [
      "同化する",
      "吸収する",
      "自分のものにする"
    ],
    "contexts": [
      {
        "parts": [
          "Immigrants often try to",
          "into the new culture."
        ],
        "full": "Immigrants often try to ASSIMILATE into the new culture.",
        "jp": "移民はしばしば新しい文化に同化しようとする。",
        "is_correct": true
      },
      {
        "parts": [
          "Immigrants often ",
          " into a new culture."
        ],
        "full": "Immigrants often ASSIMILATE into a new culture.",
        "jp": "移民はしばしば新しい文化に同化する。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the new information."
        ],
        "full": "We need to ASSIMILATE the new information.",
        "jp": "私たちは新しい情報を消化する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 60,
    "word": "ASSIST",
    "meaning_core": "助ける",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SIST",
        "type": "strong"
      }
    ],
    "synonyms": {
      "HELP": "手伝う",
      "AID": "援助する",
      "SUPPORT": "支持する"
    },
    "distractors": [
      "HINDER",
      "BLOCK",
      "PREVENT",
      "STOP"
    ],
    "meanings_expanded": [
      "助ける",
      "手伝う",
      "援助する"
    ],
    "contexts": [
      {
        "parts": [
          "The nurse will",
          "the doctor during surgery."
        ],
        "full": "The nurse will ASSIST the doctor during surgery.",
        "jp": "看護師は手術中に医師を補助する。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " me with this box?"
        ],
        "full": "Can you ASSIST me with this box?",
        "jp": "この箱を持つのを手伝ってくれますか。",
        "is_correct": true
      },
      {
        "parts": [
          "I will ",
          " the new manager."
        ],
        "full": "I will ASSIST the new manager.",
        "jp": "私は新しいマネージャーを補佐するつもりだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 61,
    "word": "ASSOCIATE",
    "meaning_core": "関連づける",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SO",
        "type": "strong"
      },
      {
        "text": "ci",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONNECT": "結びつける",
      "LINK": "リンクさせる",
      "RELATE": "関係させる"
    },
    "distractors": [
      "SEPARATE",
      "DISCONNECT",
      "DIVIDE",
      "ISOLATE"
    ],
    "meanings_expanded": [
      "関連づける",
      "連想する",
      "交際する"
    ],
    "contexts": [
      {
        "parts": [
          "People often",
          "green with nature."
        ],
        "full": "People often ASSOCIATE green with nature.",
        "jp": "人々はしばしば緑を自然と関連づける。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " with bad people."
        ],
        "full": "Do not ASSOCIATE with bad people.",
        "jp": "悪い人々と付き合ってはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " success with hard work."
        ],
        "full": "I ASSOCIATE success with hard work.",
        "jp": "私は成功を勤勉と関連づけて考える。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 62,
    "word": "ASSUME",
    "meaning_core": "仮定する",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SUME",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PRESUME": "推定する",
      "SUPPOSE": "思う",
      "UNDERTAKE": "引き受ける"
    },
    "distractors": [
      "KNOW",
      "PROVE",
      "VERIFY",
      "DOUBT"
    ],
    "meanings_expanded": [
      "仮定する",
      "思い込む",
      "（責任などを）引き受ける"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "you are tired after the trip."
        ],
        "full": "I ASSUME you are tired after the trip.",
        "jp": "旅行の後で君は疲れているだろうと思う。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " the worst."
        ],
        "full": "Do not ASSUME the worst.",
        "jp": "最悪の事態を想定してはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "We ",
          " he is telling the truth."
        ],
        "full": "We ASSUME he is telling the truth.",
        "jp": "私たちは彼が真実を話していると仮定する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 63,
    "word": "ASSURE",
    "meaning_core": "保証する",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "SURE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "GUARANTEE": "保証する",
      "PROMISE": "約束する",
      "CONVINCE": "納得させる"
    },
    "distractors": [
      "ALARM",
      "WORRY",
      "DOUBT",
      "THREATEN"
    ],
    "meanings_expanded": [
      "保証する",
      "請け合う",
      "安心させる"
    ],
    "contexts": [
      {
        "parts": [
          "I can",
          "you that he is safe."
        ],
        "full": "I can ASSURE you that he is safe.",
        "jp": "彼が無事であることを君に保証する。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " you I am fine."
        ],
        "full": "I ASSURE you I am fine.",
        "jp": "大丈夫だとあなたに保証します。",
        "is_correct": true
      },
      {
        "parts": [
          "His smile began to ",
          " her."
        ],
        "full": "His smile began to ASSURE her.",
        "jp": "彼の笑顔は彼女を安心させ始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 64,
    "word": "ASTONISH",
    "meaning_core": "驚かせる",
    "syllables": [
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "TON",
        "type": "strong"
      },
      {
        "text": "ish",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SURPRISE": "驚かす",
      "AMAZE": "びっくりさせる",
      "SHOCK": "衝撃を与える"
    },
    "distractors": [
      "BORE",
      "CALM",
      "EXPECT",
      "SOOTHE"
    ],
    "meanings_expanded": [
      "ひどく驚かせる",
      "びっくりさせる"
    ],
    "contexts": [
      {
        "parts": [
          "His magic tricks always",
          "the audience."
        ],
        "full": "His magic tricks always ASTONISH the audience.",
        "jp": "彼の手品はいつも観客を驚かせる。",
        "is_correct": true
      },
      {
        "parts": [
          "His skill will ",
          " the audience."
        ],
        "full": "His skill will ASTONISH the audience.",
        "jp": "彼の技術は観客を驚かせるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "She was ",
          " by the view."
        ],
        "full": "She was ASTONISH by the view.",
        "jp": "彼女はその眺めに驚いた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 65,
    "word": "ATMOSPHERE",
    "meaning_core": "雰囲気",
    "syllables": [
      {
        "text": "AT",
        "type": "strong"
      },
      {
        "text": "mos",
        "type": "weak"
      },
      {
        "text": "phere",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MOOD": "気分",
      "AMBIANCE": "環境",
      "AIR": "空気"
    },
    "distractors": [
      "VACUUM",
      "VOID",
      "SOLID",
      "NOTHINGNESS"
    ],
    "meanings_expanded": [
      "雰囲気",
      "大気",
      "空気"
    ],
    "contexts": [
      {
        "parts": [
          "The restaurant has a cozy",
          "."
        ],
        "full": "The restaurant has a cozy ATMOSPHERE.",
        "jp": "そのレストランは居心地の良い雰囲気だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The room had a relaxed ",
          "."
        ],
        "full": "The room had a relaxed ATMOSPHERE.",
        "jp": "その部屋はリラックスした雰囲気を持っていた。",
        "is_correct": true
      },
      {
        "parts": [
          "Earth's ",
          " protects us."
        ],
        "full": "Earth's ATMOSPHERE protects us.",
        "jp": "地球の大気は私たちを保護している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 66,
    "word": "ATTACH",
    "meaning_core": "取り付ける",
    "syllables": [
      {
        "text": "at",
        "type": "weak"
      },
      {
        "text": "TACH",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FASTEN": "留める",
      "CONNECT": "つなぐ",
      "AFFIX": "貼る"
    },
    "distractors": [
      "DETACH",
      "REMOVE",
      "SEPARATE",
      "LOOSEN"
    ],
    "meanings_expanded": [
      "取り付ける",
      "添付する",
      "愛着を持たせる"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "a photo to your application."
        ],
        "full": "Please ATTACH a photo to your application.",
        "jp": "申込書に写真を添付してください。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " the file to your email."
        ],
        "full": "Please ATTACH the file to your email.",
        "jp": "ファイルをあなたのメールに添付してください。",
        "is_correct": true
      },
      {
        "parts": [
          "She started to ",
          " importance to his words."
        ],
        "full": "She started to ATTACH importance to his words.",
        "jp": "彼女は彼の言葉に重要性を置き始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 67,
    "word": "ATTAIN",
    "meaning_core": "達成する",
    "syllables": [
      {
        "text": "at",
        "type": "weak"
      },
      {
        "text": "TAIN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ACHIEVE": "成し遂げる",
      "REACH": "到達する",
      "ACCOMPLISH": "完遂する"
    },
    "distractors": [
      "FAIL",
      "LOSE",
      "MISS",
      "ABANDON"
    ],
    "meanings_expanded": [
      "達成する",
      "到達する",
      "手に入れる"
    ],
    "contexts": [
      {
        "parts": [
          "He worked hard to",
          "his goals."
        ],
        "full": "He worked hard to ATTAIN his goals.",
        "jp": "彼は目標を達成するために懸命に働いた。",
        "is_correct": true
      },
      {
        "parts": [
          "You can ",
          " your goals."
        ],
        "full": "You can ATTAIN your goals.",
        "jp": "あなたは目標を達成できる。",
        "is_correct": true
      },
      {
        "parts": [
          "It is difficult to ",
          " perfection."
        ],
        "full": "It is difficult to ATTAIN perfection.",
        "jp": "完璧を達成するのは難しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 68,
    "word": "ATTEMPT",
    "meaning_core": "試みる",
    "syllables": [
      {
        "text": "at",
        "type": "weak"
      },
      {
        "text": "TEMPT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "TRY": "試す",
      "ENDEAVOR": "努力する",
      "SEEK": "努める"
    },
    "distractors": [
      "GIVE UP",
      "QUIT",
      "SUCCEED",
      "IGNORE"
    ],
    "meanings_expanded": [
      "試みる",
      "企てる",
      "試み"
    ],
    "contexts": [
      {
        "parts": [
          "Don't",
          "to do it alone."
        ],
        "full": "Don't ATTEMPT to do it alone.",
        "jp": "一人でやろうとしないで。",
        "is_correct": true
      },
      {
        "parts": [
          "I will ",
          " to finish the task."
        ],
        "full": "I will ATTEMPT to finish the task.",
        "jp": "私はその仕事を終わらせることを試みるつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "His first ",
          " failed completely."
        ],
        "full": "His first ATTEMPT failed completely.",
        "jp": "彼の最初の試みは完全に失敗した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 69,
    "word": "ATTEND",
    "meaning_core": "出席する",
    "syllables": [
      {
        "text": "at",
        "type": "weak"
      },
      {
        "text": "TEND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PRESENT": "出席している",
      "JOIN": "参加する",
      "SERVE": "仕える"
    },
    "distractors": [
      "MISS",
      "ABSENT",
      "LEAVE",
      "IGNORE"
    ],
    "meanings_expanded": [
      "出席する",
      "世話をする",
      "注意を払う"
    ],
    "contexts": [
      {
        "parts": [
          "I will",
          "the meeting tomorrow."
        ],
        "full": "I will ATTEND the meeting tomorrow.",
        "jp": "私は明日の会議に出席するつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Will you ",
          " the conference?"
        ],
        "full": "Will you ATTEND the conference?",
        "jp": "あなたはその会議に出席しますか。",
        "is_correct": true
      },
      {
        "parts": [
          "She did not ",
          " the class."
        ],
        "full": "She did not ATTEND the class.",
        "jp": "彼女はその授業に出なかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 70,
    "word": "ATTRIBUTE",
    "meaning_core": "～のせいにする",
    "syllables": [
      {
        "text": "at",
        "type": "weak"
      },
      {
        "text": "TRIB",
        "type": "strong"
      },
      {
        "text": "ute",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ASCRIBE": "～に帰する",
      "CREDIT": "功績があるとする",
      "IMPUTE": "転嫁する"
    },
    "distractors": [
      "DENY",
      "DISCONNECT",
      "SEPARATE",
      "REMOVE"
    ],
    "meanings_expanded": [
      "～のせいにする",
      "～のおかげと考える",
      "特質"
    ],
    "contexts": [
      {
        "parts": [
          "He",
          "his success to hard work."
        ],
        "full": "He attributes his success to hard work.",
        "jp": "彼は成功を勤勉のおかげだと考えている。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " my success to luck."
        ],
        "full": "I ATTRIBUTE my success to luck.",
        "jp": "私は自分の成功を運のせいにする。",
        "is_correct": true
      },
      {
        "parts": [
          "We ",
          " this quote to him."
        ],
        "full": "We ATTRIBUTE this quote to him.",
        "jp": "私たちはこの引用句を彼のものだと考える。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 71,
    "word": "AUDIBLE",
    "meaning_core": "聞こえる",
    "syllables": [
      {
        "text": "AU",
        "type": "strong"
      },
      {
        "text": "di",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PERCEPTIBLE": "知覚できる",
      "DISTINCT": "はっきりした",
      "CLEAR": "明瞭な"
    },
    "distractors": [
      "SILENT",
      "INVISIBLE",
      "MUTE",
      "QUIET"
    ],
    "meanings_expanded": [
      "聞こえる",
      "聞き取れる"
    ],
    "contexts": [
      {
        "parts": [
          "Her voice was barely",
          "above the noise."
        ],
        "full": "Her voice was barely AUDIBLE above the noise.",
        "jp": "騒音の中で彼女の声はかろうじて聞こえた。",
        "is_correct": true
      },
      {
        "parts": [
          "Her whisper was barely ",
          "."
        ],
        "full": "Her whisper was barely AUDIBLE.",
        "jp": "彼女のささやきはかろうじて聞こえた。",
        "is_correct": true
      },
      {
        "parts": [
          "The sound was loud and ",
          "."
        ],
        "full": "The sound was loud and AUDIBLE.",
        "jp": "その音は大きくて聞き取れた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 72,
    "word": "AUGMENT",
    "meaning_core": "増加させる",
    "syllables": [
      {
        "text": "aug",
        "type": "weak"
      },
      {
        "text": "MENT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INCREASE": "増やす",
      "ENHANCE": "高める",
      "BOOST": "押し上げる"
    },
    "distractors": [
      "DECREASE",
      "REDUCE",
      "LOWER",
      "SHORTEN"
    ],
    "meanings_expanded": [
      "増加させる",
      "増大させる",
      "補う"
    ],
    "contexts": [
      {
        "parts": [
          "He took a second job to",
          "his income."
        ],
        "full": "He took a second job to AUGMENT his income.",
        "jp": "彼は収入を増やすために副業をした。",
        "is_correct": true
      },
      {
        "parts": [
          "He needs to ",
          " his income."
        ],
        "full": "He needs to AUGMENT his income.",
        "jp": "彼は収入を増やす必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " the power supply."
        ],
        "full": "We will AUGMENT the power supply.",
        "jp": "私たちは電力供給を増加させるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 73,
    "word": "AUTHENTIC",
    "meaning_core": "本物の",
    "syllables": [
      {
        "text": "au",
        "type": "weak"
      },
      {
        "text": "THEN",
        "type": "strong"
      },
      {
        "text": "tic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "GENUINE": "正真正銘の",
      "REAL": "本物の",
      "ORIGINAL": "独自の"
    },
    "distractors": [
      "FAKE",
      "FALSE",
      "COUNTERFEIT",
      "ARTIFICIAL"
    ],
    "meanings_expanded": [
      "本物の",
      "信頼できる",
      "真正の"
    ],
    "contexts": [
      {
        "parts": [
          "This restaurant serves",
          "Italian food."
        ],
        "full": "This restaurant serves AUTHENTIC Italian food.",
        "jp": "このレストランは本場のイタリア料理を出す。",
        "is_correct": true
      },
      {
        "parts": [
          "Is the document ",
          "?"
        ],
        "full": "Is the document AUTHENTIC?",
        "jp": "その文書は本物ですか。",
        "is_correct": true
      },
      {
        "parts": [
          "We seek ",
          " Japanese food."
        ],
        "full": "We seek AUTHENTIC Japanese food.",
        "jp": "私たちは本物の日本食を探している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 74,
    "word": "AUTHORITY",
    "meaning_core": "権威",
    "syllables": [
      {
        "text": "au",
        "type": "weak"
      },
      {
        "text": "THOR",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POWER": "権力",
      "CONTROL": "支配",
      "EXPERT": "専門家"
    },
    "distractors": [
      "WEAKNESS",
      "SERVANT",
      "FOLLOWER",
      "NOVICE"
    ],
    "meanings_expanded": [
      "権威",
      "権限",
      "当局"
    ],
    "contexts": [
      {
        "parts": [
          "She is an",
          "on ancient history."
        ],
        "full": "She is an AUTHORITY on ancient history.",
        "jp": "彼女は古代史の権威だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He has ",
          " over the staff."
        ],
        "full": "He has AUTHORITY over the staff.",
        "jp": "彼にはスタッフに対する権限がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The local ",
          " issued a warning."
        ],
        "full": "The local AUTHORITY issued a warning.",
        "jp": "地方当局が警告を発した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 75,
    "word": "AUTHORIZE",
    "meaning_core": "許可する",
    "syllables": [
      {
        "text": "AU",
        "type": "strong"
      },
      {
        "text": "thor",
        "type": "weak"
      },
      {
        "text": "ize",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PERMIT": "許可する",
      "ALLOW": "許す",
      "APPROVE": "承認する"
    },
    "distractors": [
      "FORBID",
      "BAN",
      "PROHIBIT",
      "DENY"
    ],
    "meanings_expanded": [
      "権限を与える",
      "認可する"
    ],
    "contexts": [
      {
        "parts": [
          "Only the manager can",
          "refunds."
        ],
        "full": "Only the manager can AUTHORIZE refunds.",
        "jp": "マネージャーだけが返金を許可できる。",
        "is_correct": true
      },
      {
        "parts": [
          "Who will ",
          " this expense?"
        ],
        "full": "Who will AUTHORIZE this expense?",
        "jp": "誰がこの費用を許可しますか。",
        "is_correct": true
      },
      {
        "parts": [
          "We did not ",
          " the changes."
        ],
        "full": "We did not AUTHORIZE the changes.",
        "jp": "私たちはその変更を許可しなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 76,
    "word": "AUTOMATIC",
    "meaning_core": "自動の",
    "syllables": [
      {
        "text": "au",
        "type": "weak"
      },
      {
        "text": "to",
        "type": "weak"
      },
      {
        "text": "MAT",
        "type": "strong"
      },
      {
        "text": "ic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MECHANICAL": "機械的な",
      "INSTANT": "即座の",
      "INVOLUNTARY": "無意識の"
    },
    "distractors": [
      "MANUAL",
      "HANDMADE",
      "DELIBERATE",
      "SLOW"
    ],
    "meanings_expanded": [
      "自動の",
      "無意識の",
      "機械的な"
    ],
    "contexts": [
      {
        "parts": [
          "The doors are",
          "."
        ],
        "full": "The doors are AUTOMATIC.",
        "jp": "そのドアは自動だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The door is ",
          "."
        ],
        "full": "The door is AUTOMATIC.",
        "jp": "そのドアは自動だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is an ",
          " payment system."
        ],
        "full": "This is an AUTOMATIC payment system.",
        "jp": "これは自動支払いシステムだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 77,
    "word": "AUTONOMY",
    "meaning_core": "自治",
    "syllables": [
      {
        "text": "au",
        "type": "weak"
      },
      {
        "text": "TON",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "my",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INDEPENDENCE": "独立",
      "SELF-RULE": "自治",
      "FREEDOM": "自由"
    },
    "distractors": [
      "DEPENDENCE",
      "SLAVERY",
      "CONTROL",
      "SUBJECTION"
    ],
    "meanings_expanded": [
      "自治権",
      "自主性",
      "自律"
    ],
    "contexts": [
      {
        "parts": [
          "The region demanded greater",
          "."
        ],
        "full": "The region demanded greater AUTONOMY.",
        "jp": "その地域はより大きな自治権を要求した。",
        "is_correct": true
      },
      {
        "parts": [
          "The region gained ",
          "."
        ],
        "full": "The region gained AUTONOMY.",
        "jp": "その地域は自治を獲得した。",
        "is_correct": true
      },
      {
        "parts": [
          "Workers desire greater ",
          "."
        ],
        "full": "Workers desire greater AUTONOMY.",
        "jp": "労働者はより大きな自律性を望んでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 78,
    "word": "AUXILIARY",
    "meaning_core": "補助の",
    "syllables": [
      {
        "text": "aux",
        "type": "weak"
      },
      {
        "text": "IL",
        "type": "strong"
      },
      {
        "text": "ia",
        "type": "weak"
      },
      {
        "text": "ry",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUPPLEMENTARY": "補足の",
      "ADDITIONAL": "追加の",
      "BACKUP": "予備の"
    },
    "distractors": [
      "MAIN",
      "PRIMARY",
      "CHIEF",
      "MAJOR"
    ],
    "meanings_expanded": [
      "補助の",
      "予備の",
      "助動詞"
    ],
    "contexts": [
      {
        "parts": [
          "The hospital has an",
          "power generator."
        ],
        "full": "The hospital has an AUXILIARY power generator.",
        "jp": "その病院には予備の発電機がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The ship has an ",
          " engine."
        ],
        "full": "The ship has an AUXILIARY engine.",
        "jp": "その船には補助エンジンがある。",
        "is_correct": true
      },
      {
        "parts": [
          "We hired some ",
          " staff."
        ],
        "full": "We hired some AUXILIARY staff.",
        "jp": "私たちは補助スタッフを数人雇った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 79,
    "word": "AVAIL",
    "meaning_core": "役立つ",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "VAIL",
        "type": "strong"
      }
    ],
    "synonyms": {
      "BENEFIT": "利益になる",
      "HELP": "助けになる",
      "USE": "益"
    },
    "distractors": [
      "HARM",
      "FAIL",
      "HINDER",
      "LOSE"
    ],
    "meanings_expanded": [
      "役立つ",
      "効力",
      "（～ oneself ofで）利用する"
    ],
    "contexts": [
      {
        "parts": [
          "Our efforts were to no",
          "."
        ],
        "full": "Our efforts were to no AVAIL.",
        "jp": "私たちの努力は無駄だった。",
        "is_correct": true
      },
      {
        "parts": [
          "I will",
          "myself of this opportunity."
        ],
        "full": "I will AVAIL myself of this opportunity.",
        "jp": "私はこの機会を利用するつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "All efforts were without ",
          "."
        ],
        "full": "All efforts were without AVAIL.",
        "jp": "すべての努力は無駄だった。",
        "is_correct": true
      },
      {
        "parts": [
          "His talents will ",
          " him little."
        ],
        "full": "His talents will AVAIL him little.",
        "jp": "彼の才能はほとんど役に立たないだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 80,
    "word": "AVAILABLE",
    "meaning_core": "利用できる",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "VAIL",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ACCESSIBLE": "アクセスできる",
      "OBTAINABLE": "入手可能な",
      "FREE": "空いている"
    },
    "distractors": [
      "OCCUPIED",
      "TAKEN",
      "BUSY",
      "UNAVAILABLE"
    ],
    "meanings_expanded": [
      "利用できる",
      "入手できる",
      "（人が）手が空いている"
    ],
    "contexts": [
      {
        "parts": [
          "Is this seat",
          "?"
        ],
        "full": "Is this seat AVAILABLE?",
        "jp": "この席は空いていますか？",
        "is_correct": true
      },
      {
        "parts": [
          "Is this book still ",
          "?"
        ],
        "full": "Is this book still AVAILABLE?",
        "jp": "この本はまだ利用可能ですか。",
        "is_correct": true
      },
      {
        "parts": [
          "The tickets are not ",
          "."
        ],
        "full": "The tickets are not AVAILABLE.",
        "jp": "チケットは入手できません。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 81,
    "word": "AVENUE",
    "meaning_core": "大通り",
    "syllables": [
      {
        "text": "AV",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "nue",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STREET": "通り",
      "ROUTE": "道",
      "METHOD": "手段"
    },
    "distractors": [
      "ALLEY",
      "WALL",
      "BARRIER",
      "BLOCK"
    ],
    "meanings_expanded": [
      "大通り",
      "手段",
      "道"
    ],
    "contexts": [
      {
        "parts": [
          "We should explore every",
          "to solve the problem."
        ],
        "full": "We should explore every AVENUE to solve the problem.",
        "jp": "問題解決のためにあらゆる手段を模索すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He lives on Fifth",
          "."
        ],
        "full": "He lives on Fifth AVENUE.",
        "jp": "彼は5番街に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "We drove down the main ",
          "."
        ],
        "full": "We drove down the main AVENUE.",
        "jp": "私たちはメインストリートを車で下った。",
        "is_correct": true
      },
      {
        "parts": [
          "Consider every possible ",
          "."
        ],
        "full": "Consider every possible AVENUE.",
        "jp": "あらゆる可能な手段を検討しなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 82,
    "word": "AVERT",
    "meaning_core": "避ける",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "VERT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PREVENT": "防ぐ",
      "AVOID": "避ける",
      "TURN AWAY": "そらす"
    },
    "distractors": [
      "CAUSE",
      "FACE",
      "CONFRONT",
      "INVITE"
    ],
    "meanings_expanded": [
      "（危険などを）避ける",
      "（目などを）そらす"
    ],
    "contexts": [
      {
        "parts": [
          "Diplomats tried to",
          "a war."
        ],
        "full": "Diplomats tried to AVERT a war.",
        "jp": "外交官たちは戦争を回避しようとした。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "your eyes."
        ],
        "full": "Don't AVERT your eyes.",
        "jp": "目をそらすな。",
        "is_correct": true
      },
      {
        "parts": [
          "She managed to ",
          " a crisis."
        ],
        "full": "She managed to AVERT a crisis.",
        "jp": "彼女は何とか危機を回避した。",
        "is_correct": true
      },
      {
        "parts": [
          "He tried to ",
          " his gaze."
        ],
        "full": "He tried to AVERT his gaze.",
        "jp": "彼は視線をそらそうとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 83,
    "word": "AVIATION",
    "meaning_core": "航空",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "vi",
        "type": "weak"
      },
      {
        "text": "A",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FLIGHT": "飛行",
      "AERONAUTICS": "航空学",
      "FLYING": "飛行"
    },
    "distractors": [
      "DRIVING",
      "SAILING",
      "WALKING",
      "DIVING"
    ],
    "meanings_expanded": [
      "航空",
      "飛行",
      "航空産業"
    ],
    "contexts": [
      {
        "parts": [
          "He works in the",
          "industry."
        ],
        "full": "He works in the AVIATION industry.",
        "jp": "彼は航空業界で働いている。",
        "is_correct": true
      },
      {
        "parts": [
          "He works in the ",
          " industry."
        ],
        "full": "He works in the AVIATION industry.",
        "jp": "彼は航空業界で働いている。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          " safety is very important."
        ],
        "full": "AVIATION safety is very important.",
        "jp": "航空安全は非常に重要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 84,
    "word": "AVOID",
    "meaning_core": "避ける",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "VOID",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EVADE": "逃れる",
      "SHUN": "避ける",
      "ESCAPE": "逃げる"
    },
    "distractors": [
      "SEEK",
      "CONFRONT",
      "FACE",
      "MEET"
    ],
    "meanings_expanded": [
      "避ける",
      "回避する",
      "無効にする"
    ],
    "contexts": [
      {
        "parts": [
          "You should",
          "making mistakes."
        ],
        "full": "You should AVOID making mistakes.",
        "jp": "間違いを犯さないようにすべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to",
          "the traffic jam."
        ],
        "full": "Try to AVOID the traffic jam.",
        "jp": "交通渋滞を避けるようにしなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "I try to ",
          " eating meat."
        ],
        "full": "I try to AVOID eating meat.",
        "jp": "私は肉を食べるのを避けようとしている。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " making mistakes."
        ],
        "full": "Please AVOID making mistakes.",
        "jp": "間違いを犯すのを避けてください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 85,
    "word": "AWAIT",
    "meaning_core": "待つ",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "WAIT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "WAIT FOR": "～を待つ",
      "EXPECT": "予期する",
      "ANTICIPATE": "楽しみに待つ"
    },
    "distractors": [
      "LEAVE",
      "DEPART",
      "IGNORE",
      "FORGET"
    ],
    "meanings_expanded": [
      "待つ",
      "待ち受ける"
    ],
    "contexts": [
      {
        "parts": [
          "We",
          "your reply."
        ],
        "full": "We AWAIT your reply.",
        "jp": "お返事をお待ちしております。",
        "is_correct": true
      },
      {
        "parts": [
          "A surprise",
          "you."
        ],
        "full": "A surprise awaits you.",
        "jp": "驚きがあなたを待っている。",
        "is_correct": true
      },
      {
        "parts": [
          "We ",
          " the test results anxiously."
        ],
        "full": "We AWAIT the test results anxiously.",
        "jp": "私たちはテスト結果を不安に待っている。",
        "is_correct": true
      },
      {
        "parts": [
          "Good fortune will ",
          " you."
        ],
        "full": "Good fortune will AWAIT you.",
        "jp": "幸運があなたを待っているだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 86,
    "word": "AWARD",
    "meaning_core": "賞",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "WARD",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PRIZE": "賞",
      "GRANT": "授与する",
      "REWARD": "報酬"
    },
    "distractors": [
      "PENALTY",
      "FINE",
      "PUNISHMENT",
      "LOSS"
    ],
    "meanings_expanded": [
      "賞",
      "授与する",
      "裁定"
    ],
    "contexts": [
      {
        "parts": [
          "She won an",
          "for her acting."
        ],
        "full": "She won an AWARD for her acting.",
        "jp": "彼女は演技で賞を獲得した。",
        "is_correct": true
      },
      {
        "parts": [
          "The jury will",
          "damages."
        ],
        "full": "The jury will AWARD damages.",
        "jp": "陪審員は損害賠償を認めるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "She won a prestigious ",
          "."
        ],
        "full": "She won a prestigious AWARD.",
        "jp": "彼女は権威ある賞を受賞した。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " the prize next month."
        ],
        "full": "They will AWARD the prize next month.",
        "jp": "彼らは来月、その賞を授与するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 87,
    "word": "AWARE",
    "meaning_core": "気づいている",
    "syllables": [
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "WARE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONSCIOUS": "意識している",
      "MINDFUL": "心に留めている",
      "INFORMED": "知らされている"
    },
    "distractors": [
      "IGNORANT",
      "UNAWARE",
      "BLIND",
      "OBLIVIOUS"
    ],
    "meanings_expanded": [
      "気づいている",
      "知っている",
      "意識の高い"
    ],
    "contexts": [
      {
        "parts": [
          "Are you",
          "of the risks?"
        ],
        "full": "Are you AWARE of the risks?",
        "jp": "リスクに気づいていますか？",
        "is_correct": true
      },
      {
        "parts": [
          "I was not ",
          " of the danger."
        ],
        "full": "I was not AWARE of the danger.",
        "jp": "私は危険に気づいていなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "She is fully ",
          " of her potential."
        ],
        "full": "She is fully AWARE of her potential.",
        "jp": "彼女は自分の可能性を完全に認識している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 88,
    "word": "AWE",
    "meaning_core": "畏敬",
    "syllables": [
      {
        "text": "AWE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "WONDER": "驚異",
      "ADMIRATION": "称賛",
      "RESPECT": "尊敬"
    },
    "distractors": [
      "CONTEMPT",
      "DISGUST",
      "SCORN",
      "BOREDOM"
    ],
    "meanings_expanded": [
      "畏敬",
      "畏怖",
      "恐れ多いと思わせる"
    ],
    "contexts": [
      {
        "parts": [
          "We watched in",
          "as the rocket launched."
        ],
        "full": "We watched in AWE as the rocket launched.",
        "jp": "ロケットが打ち上がるのを我々は畏敬の念を持って見守った。",
        "is_correct": true
      },
      {
        "parts": [
          "I felt",
          "at the beautiful view."
        ],
        "full": "I felt AWE at the beautiful view.",
        "jp": "美しい景色に畏敬の念を抱いた。",
        "is_correct": true
      },
      {
        "parts": [
          "The mountain inspired ",
          "."
        ],
        "full": "The mountain inspired AWE.",
        "jp": "その山は畏敬の念を抱かせた。",
        "is_correct": true
      },
      {
        "parts": [
          "We looked at the stars in ",
          "."
        ],
        "full": "We looked at the stars in AWE.",
        "jp": "私たちは星を畏敬の念をもって見上げた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 89,
    "word": "AWKWARD",
    "meaning_core": "気まずい",
    "syllables": [
      {
        "text": "AWK",
        "type": "strong"
      },
      {
        "text": "ward",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CLUMSY": "不器用な",
      "UNCOMFORTABLE": "心地悪い",
      "EMBARRASSING": "恥ずかしい"
    },
    "distractors": [
      "GRACEFUL",
      "COMFORTABLE",
      "EASY",
      "NATURAL"
    ],
    "meanings_expanded": [
      "気まずい",
      "不器用な",
      "扱いにくい"
    ],
    "contexts": [
      {
        "parts": [
          "There was an",
          "silence."
        ],
        "full": "There was an AWKWARD silence.",
        "jp": "気まずい沈黙があった。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an",
          "dancer."
        ],
        "full": "He is an AWKWARD dancer.",
        "jp": "彼は不器用なダンサーだ。",
        "is_correct": true
      },
      {
        "parts": [
          "It was an ",
          " silence."
        ],
        "full": "It was an AWKWARD silence.",
        "jp": "それは気まずい沈黙だった。",
        "is_correct": true
      },
      {
        "parts": [
          "She felt ",
          " standing alone."
        ],
        "full": "She felt AWKWARD standing alone.",
        "jp": "彼女は一人で立っていて居心地が悪く感じた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 90,
    "word": "BANISH",
    "meaning_core": "追放する",
    "syllables": [
      {
        "text": "BAN",
        "type": "strong"
      },
      {
        "text": "ish",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXILE": "追放する",
      "EXPEL": "追い出す",
      "DEPORT": "強制送還する"
    },
    "distractors": [
      "WELCOME",
      "INVITE",
      "ADMIT",
      "KEEP"
    ],
    "meanings_expanded": [
      "追放する",
      "追い払う",
      "心から取り除く"
    ],
    "contexts": [
      {
        "parts": [
          "The king decided to",
          "the traitor."
        ],
        "full": "The king decided to BANISH the traitor.",
        "jp": "王は裏切り者を追放することに決めた。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to",
          "negative thoughts."
        ],
        "full": "Try to BANISH negative thoughts.",
        "jp": "ネガティブな考えを追い払うようにしなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " him from the country."
        ],
        "full": "They will BANISH him from the country.",
        "jp": "彼らは彼を国から追放するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " all negative thoughts."
        ],
        "full": "We need to BANISH all negative thoughts.",
        "jp": "私たちはすべてのネガティブな考えを払いのける必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 91,
    "word": "BANKRUPT",
    "meaning_core": "破産した",
    "syllables": [
      {
        "text": "BANK",
        "type": "strong"
      },
      {
        "text": "rupt",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INSOLVENT": "支払い不能の",
      "RUINED": "破滅した",
      "BROKE": "一文無しの"
    },
    "distractors": [
      "WEALTHY",
      "RICH",
      "PROFITABLE",
      "SUCCESSFUL"
    ],
    "meanings_expanded": [
      "破産した",
      "支払い不能の",
      "破綻した"
    ],
    "contexts": [
      {
        "parts": [
          "The company went",
          "after the crisis."
        ],
        "full": "The company went BANKRUPT after the crisis.",
        "jp": "その会社は危機の後に破産した。",
        "is_correct": true
      },
      {
        "parts": [
          "The company went ",
          " last year."
        ],
        "full": "The company went BANKRUPT last year.",
        "jp": "その会社は昨年破産した。",
        "is_correct": true
      },
      {
        "parts": [
          "He was declared ",
          "."
        ],
        "full": "He was declared BANKRUPT.",
        "jp": "彼は破産宣告を受けた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 92,
    "word": "BARELY",
    "meaning_core": "かろうじて",
    "syllables": [
      {
        "text": "BARE",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HARDLY": "ほとんど～ない",
      "SCARCELY": "かろうじて",
      "ONLY": "～だけ"
    },
    "distractors": [
      "FULLY",
      "COMPLETELY",
      "EASILY",
      "TOTALLY"
    ],
    "meanings_expanded": [
      "かろうじて",
      "ほとんど～ない",
      "わずかに"
    ],
    "contexts": [
      {
        "parts": [
          "I could",
          "hear him speak."
        ],
        "full": "I could BARELY hear him speak.",
        "jp": "彼が話すのがかろうじて聞こえた。",
        "is_correct": true
      },
      {
        "parts": [
          "I can ",
          " see the sign."
        ],
        "full": "I can BARELY see the sign.",
        "jp": "私はかろうじてその看板が見える。",
        "is_correct": true
      },
      {
        "parts": [
          "She ",
          " finished the race."
        ],
        "full": "She BARELY finished the race.",
        "jp": "彼女はかろうじてレースを終えた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 93,
    "word": "BARGAIN",
    "meaning_core": "取引",
    "syllables": [
      {
        "text": "BAR",
        "type": "strong"
      },
      {
        "text": "gain",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEAL": "取引",
      "AGREEMENT": "合意",
      "DISCOUNT": "値引き"
    },
    "distractors": [
      "RIP-OFF",
      "LOSS",
      "DEBT",
      "PENALTY"
    ],
    "meanings_expanded": [
      "取引",
      "契約",
      "お買い得品"
    ],
    "contexts": [
      {
        "parts": [
          "I struck a",
          "with the seller."
        ],
        "full": "I struck a BARGAIN with the seller.",
        "jp": "私は売り手と取引をまとめた。",
        "is_correct": true
      },
      {
        "parts": [
          "We struck a good ",
          "."
        ],
        "full": "We struck a good BARGAIN.",
        "jp": "私たちは良い取引をした。",
        "is_correct": true
      },
      {
        "parts": [
          "The price was a real ",
          "."
        ],
        "full": "The price was a real BARGAIN.",
        "jp": "その価格は本当にお得だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 94,
    "word": "BARRIER",
    "meaning_core": "障壁",
    "syllables": [
      {
        "text": "BAR",
        "type": "strong"
      },
      {
        "text": "ri",
        "type": "weak"
      },
      {
        "text": "er",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OBSTACLE": "障害",
      "BLOCK": "妨げ",
      "HURDLE": "ハードル"
    },
    "distractors": [
      "OPENING",
      "BRIDGE",
      "LINK",
      "AID"
    ],
    "meanings_expanded": [
      "障壁",
      "防壁",
      "障害物"
    ],
    "contexts": [
      {
        "parts": [
          "Language can be a",
          "to communication."
        ],
        "full": "Language can be a BARRIER to communication.",
        "jp": "言語はコミュニケーションの障壁になり得る。",
        "is_correct": true
      },
      {
        "parts": [
          "Language is a major ",
          "."
        ],
        "full": "Language is a major BARRIER.",
        "jp": "言葉は大きな障壁だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The police set up a road ",
          "."
        ],
        "full": "The police set up a road BARRIER.",
        "jp": "警察は道路にバリケードを設置した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 95,
    "word": "BASIC",
    "meaning_core": "基本的な",
    "syllables": [
      {
        "text": "BA",
        "type": "strong"
      },
      {
        "text": "sic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FUNDAMENTAL": "根本的な",
      "ESSENTIAL": "不可欠な",
      "PRIMARY": "初歩的な"
    },
    "distractors": [
      "ADVANCED",
      "COMPLEX",
      "SECONDARY",
      "MINOR"
    ],
    "meanings_expanded": [
      "基本的な",
      "基礎の",
      "根本的な"
    ],
    "contexts": [
      {
        "parts": [
          "Food and water are",
          "needs."
        ],
        "full": "Food and water are BASIC needs.",
        "jp": "食料と水は基本的な欲求だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Learn the ",
          " rules first."
        ],
        "full": "Learn the BASIC rules first.",
        "jp": "まず基本的なルールを学びなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Water is a ",
          " human need."
        ],
        "full": "Water is a BASIC human need.",
        "jp": "水は人間にとって基本的な必要性だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 96,
    "word": "BASIS",
    "meaning_core": "基礎",
    "syllables": [
      {
        "text": "BA",
        "type": "strong"
      },
      {
        "text": "sis",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FOUNDATION": "土台",
      "BASE": "基盤",
      "GROUND": "根拠"
    },
    "distractors": [
      "TOP",
      "RESULT",
      "OUTCOME",
      "END"
    ],
    "meanings_expanded": [
      "基礎",
      "根拠",
      "基準"
    ],
    "contexts": [
      {
        "parts": [
          "Trust is the",
          "of friendship."
        ],
        "full": "Trust is the BASIS of friendship.",
        "jp": "信頼は友情の基礎だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We met on a daily ",
          "."
        ],
        "full": "We met on a daily BASIS.",
        "jp": "私たちは毎日会った。",
        "is_correct": true
      },
      {
        "parts": [
          "Trust is the ",
          " of friendship."
        ],
        "full": "Trust is the BASIS of friendship.",
        "jp": "信頼は友情の基礎だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 97,
    "word": "BEAR",
    "meaning_core": "耐える",
    "syllables": [
      {
        "text": "BEAR",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ENDURE": "我慢する",
      "TOLERATE": "許容する",
      "STAND": "耐える"
    },
    "distractors": [
      "COLLAPSE",
      "SURRENDER",
      "YIELD",
      "DROP"
    ],
    "meanings_expanded": [
      "耐える",
      "（責任を）負う",
      "（実を）結ぶ"
    ],
    "contexts": [
      {
        "parts": [
          "I cannot",
          "the pain anymore."
        ],
        "full": "I cannot BEAR the pain anymore.",
        "jp": "私はもう痛みに耐えられない。",
        "is_correct": true
      },
      {
        "parts": [
          "I cannot ",
          " this pain."
        ],
        "full": "I cannot BEAR this pain.",
        "jp": "私はこの痛みに耐えられない。",
        "is_correct": true
      },
      {
        "parts": [
          "The tree did not ",
          " fruit."
        ],
        "full": "The tree did not BEAR fruit.",
        "jp": "その木は実を結ばなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 98,
    "word": "BEHAVE",
    "meaning_core": "振る舞う",
    "syllables": [
      {
        "text": "be",
        "type": "weak"
      },
      {
        "text": "HAVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ACT": "行動する",
      "CONDUCT": "振る舞う",
      "FUNCTION": "機能する"
    },
    "distractors": [
      "MISBEHAVE",
      "STOP",
      "REST",
      "IDLE"
    ],
    "meanings_expanded": [
      "振る舞う",
      "行儀よくする",
      "作動する"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "yourself at the party."
        ],
        "full": "Please BEHAVE yourself at the party.",
        "jp": "パーティーでは行儀よくしなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " yourselves in class."
        ],
        "full": "Please BEHAVE yourselves in class.",
        "jp": "授業中は行儀よくしなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "How does your new computer ",
          "?"
        ],
        "full": "How does your new computer BEHAVE?",
        "jp": "あなたの新しいコンピューターの動作はどうですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 99,
    "word": "BEHAVIOR",
    "meaning_core": "振る舞い",
    "syllables": [
      {
        "text": "be",
        "type": "weak"
      },
      {
        "text": "HAV",
        "type": "strong"
      },
      {
        "text": "ior",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONDUCT": "品行",
      "ACTION": "行動",
      "MANNER": "態度"
    },
    "distractors": [
      "THOUGHT",
      "MIND",
      "BELIEF",
      "FEELING"
    ],
    "meanings_expanded": [
      "振る舞い",
      "行動",
      "習性"
    ],
    "contexts": [
      {
        "parts": [
          "His",
          "was strange yesterday."
        ],
        "full": "His BEHAVIOR was strange yesterday.",
        "jp": "昨日の彼の振る舞いは奇妙だった。",
        "is_correct": true
      },
      {
        "parts": [
          "His ",
          " was quite rude."
        ],
        "full": "His BEHAVIOR was quite rude.",
        "jp": "彼の振る舞いはかなり失礼だった。",
        "is_correct": true
      },
      {
        "parts": [
          "They study animal ",
          "."
        ],
        "full": "They study animal BEHAVIOR.",
        "jp": "彼らは動物の行動を研究する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 100,
    "word": "BELIEF",
    "meaning_core": "信念",
    "syllables": [
      {
        "text": "be",
        "type": "weak"
      },
      {
        "text": "LIEF",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FAITH": "信仰",
      "TRUST": "信頼",
      "CONVICTION": "確信"
    },
    "distractors": [
      "DOUBT",
      "DISBELIEF",
      "SKEPTICISM",
      "FACT"
    ],
    "meanings_expanded": [
      "信念",
      "信じること",
      "信仰"
    ],
    "contexts": [
      {
        "parts": [
          "He has a strong",
          "in god."
        ],
        "full": "He has a strong BELIEF in god.",
        "jp": "彼は神に対して強い信仰を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a strong ",
          " in justice."
        ],
        "full": "He has a strong BELIEF in justice.",
        "jp": "彼は正義を強く信じている。",
        "is_correct": true
      },
      {
        "parts": [
          "My ",
          " is that she is right."
        ],
        "full": "My BELIEF is that she is right.",
        "jp": "私の信念では、彼女が正しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 101,
    "word": "COINCIDENCE",
    "meaning_core": "偶然の一致",
    "syllables": [
      {
        "text": "co",
        "type": "weak"
      },
      {
        "text": "IN",
        "type": "strong"
      },
      {
        "text": "ci",
        "type": "weak"
      },
      {
        "text": "dence",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CHANCE": "偶然",
      "ACCIDENT": "予期せぬ出来事",
      "LUCK": "運"
    },
    "distractors": [
      "PLAN",
      "INTENTION",
      "PURPOSE",
      "DESIGN"
    ],
    "meanings_expanded": [
      "偶然の一致",
      "同時発生",
      "暗合"
    ],
    "contexts": [
      {
        "parts": [
          "It was a mere",
          "that we met."
        ],
        "full": "It was a mere COINCIDENCE that we met.",
        "jp": "私たちが会ったのは単なる偶然だった。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a strange ",
          "."
        ],
        "full": "It was a strange COINCIDENCE.",
        "jp": "それは奇妙な偶然の一致だった。",
        "is_correct": true
      },
      {
        "parts": [
          "By ",
          ", we met again."
        ],
        "full": "By COINCIDENCE, we met again.",
        "jp": "偶然、私たちは再会した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 102,
    "word": "COMMENCE",
    "meaning_core": "開始する",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "MENCE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "START": "始める",
      "BEGIN": "開始する",
      "INITIATE": "着手する"
    },
    "distractors": [
      "FINISH",
      "END",
      "STOP",
      "CEASE"
    ],
    "meanings_expanded": [
      "開始する",
      "始まる",
      "着手する"
    ],
    "contexts": [
      {
        "parts": [
          "The ceremony will",
          "at noon."
        ],
        "full": "The ceremony will COMMENCE at noon.",
        "jp": "式典は正午に開始される。",
        "is_correct": true
      },
      {
        "parts": [
          "The trial will ",
          " shortly."
        ],
        "full": "The trial will COMMENCE shortly.",
        "jp": "裁判はまもなく開始される。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " the meeting at noon."
        ],
        "full": "We will COMMENCE the meeting at noon.",
        "jp": "私たちは正午に会議を開始する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 103,
    "word": "COMMERCIAL",
    "meaning_core": "商業の",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "MER",
        "type": "strong"
      },
      {
        "text": "cial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BUSINESS": "ビジネスの",
      "TRADE": "貿易の",
      "PROFITABLE": "営利的な"
    },
    "distractors": [
      "PRIVATE",
      "PERSONAL",
      "NONPROFIT",
      "DOMESTIC"
    ],
    "meanings_expanded": [
      "商業の",
      "営利的な",
      "コマーシャル"
    ],
    "contexts": [
      {
        "parts": [
          "This area is zoned for",
          "use."
        ],
        "full": "This area is zoned for COMMERCIAL use.",
        "jp": "この地域は商業利用のために区分されている。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a ",
          " enterprise."
        ],
        "full": "This is a COMMERCIAL enterprise.",
        "jp": "これは商業的な事業だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They showed a TV ",
          "."
        ],
        "full": "They showed a TV COMMERCIAL.",
        "jp": "彼らはテレビコマーシャルを流した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 104,
    "word": "COMMIT",
    "meaning_core": "約束する",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "MIT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PLEDGE": "誓う",
      "PROMISE": "約束する",
      "PERFORM": "（犯罪などを）行う"
    },
    "distractors": [
      "WITHDRAW",
      "AVOID",
      "REFUSE",
      "DENY"
    ],
    "meanings_expanded": [
      "～を約束する",
      "（犯罪などを）犯す",
      "委ねる"
    ],
    "contexts": [
      {
        "parts": [
          "He decided to",
          "himself to the project."
        ],
        "full": "He decided to COMMIT himself to the project.",
        "jp": "彼はそのプロジェクトに専念することを決めた。",
        "is_correct": true
      },
      {
        "parts": [
          "Did he",
          "a crime?"
        ],
        "full": "Did he COMMIT a crime?",
        "jp": "彼は犯罪を犯しましたか？",
        "is_correct": true
      },
      {
        "parts": [
          "She chose to ",
          " to her job."
        ],
        "full": "She chose to COMMIT to her job.",
        "jp": "彼女は自分の仕事に専念することを選んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Who did ",
          " this awful crime?"
        ],
        "full": "Who did COMMIT this awful crime?",
        "jp": "誰がこの恐ろしい犯罪を犯したのか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 105,
    "word": "COMPATIBLE",
    "meaning_core": "互換性のある",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "PAT",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONSISTENT": "一致する",
      "SUITABLE": "適合する",
      "HARMONIOUS": "調和した"
    },
    "distractors": [
      "DIFFERENT",
      "OPPOSITE",
      "CONFLICTING",
      "UNSUITABLE"
    ],
    "meanings_expanded": [
      "互換性のある",
      "両立する",
      "相性が良い"
    ],
    "contexts": [
      {
        "parts": [
          "This software is",
          "with Mac."
        ],
        "full": "This software is COMPATIBLE with Mac.",
        "jp": "このソフトウェアはMacと互換性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They are a very",
          "couple."
        ],
        "full": "They are a very COMPATIBLE couple.",
        "jp": "彼らはとても相性の良いカップルだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Are these two systems ",
          "?"
        ],
        "full": "Are these two systems COMPATIBLE?",
        "jp": "この二つのシステムは互換性がありますか。",
        "is_correct": true
      },
      {
        "parts": [
          "We are highly ",
          " friends."
        ],
        "full": "We are highly COMPATIBLE friends.",
        "jp": "私たちは非常に気の合う友人だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 106,
    "word": "COMPEL",
    "meaning_core": "強制する",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "PEL",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FORCE": "強いる",
      "OBLIGE": "義務付ける",
      "COERCE": "強要する"
    },
    "distractors": [
      "ALLOW",
      "PERMIT",
      "LET",
      "FREE"
    ],
    "meanings_expanded": [
      "強制する",
      "無理に～させる"
    ],
    "contexts": [
      {
        "parts": [
          "Illness might",
          "him to retire."
        ],
        "full": "Illness might COMPEL him to retire.",
        "jp": "病気が彼に引退を強いるかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "The law will ",
          " obedience."
        ],
        "full": "The law will COMPEL obedience.",
        "jp": "法律は服従を強制するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "He felt ",
          " to confess."
        ],
        "full": "He felt COMPEL to confess.",
        "jp": "彼は告白せざるを得ないと感じた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 107,
    "word": "COMPENSATE",
    "meaning_core": "補う",
    "syllables": [
      {
        "text": "COM",
        "type": "strong"
      },
      {
        "text": "pen",
        "type": "weak"
      },
      {
        "text": "sate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MAKE UP": "埋め合わせる",
      "REPAY": "返済する",
      "BALANCE": "釣り合わせる"
    },
    "distractors": [
      "PENALIZE",
      "FINE",
      "DAMAGE",
      "LOSE"
    ],
    "meanings_expanded": [
      "補う",
      "償う",
      "補償する"
    ],
    "contexts": [
      {
        "parts": [
          "Nothing can",
          "for the loss."
        ],
        "full": "Nothing can COMPENSATE for the loss.",
        "jp": "その損失を埋め合わせることは何ものにもできない。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " him for his loss."
        ],
        "full": "We must COMPENSATE him for his loss.",
        "jp": "私たちは彼の損失を補償しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The pay should ",
          " for the risk."
        ],
        "full": "The pay should COMPENSATE for the risk.",
        "jp": "その給与はリスクに見合うべきだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 108,
    "word": "COMPLEX",
    "meaning_core": "複雑な",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "PLEX",
        "type": "strong"
      }
    ],
    "synonyms": {
      "COMPLICATED": "込み入った",
      "INTRICATE": "入り組んだ",
      "DIFFICULT": "難しい"
    },
    "distractors": [
      "SIMPLE",
      "EASY",
      "PLAIN",
      "CLEAR"
    ],
    "meanings_expanded": [
      "複雑な",
      "複合の",
      "コンプレックス"
    ],
    "contexts": [
      {
        "parts": [
          "The human brain is incredibly",
          "."
        ],
        "full": "The human brain is incredibly COMPLEX.",
        "jp": "人間の脳は信じられないほど複雑だ。",
        "is_correct": true
      },
      {
        "parts": [
          "It is a ",
          " problem to solve."
        ],
        "full": "It is a COMPLEX problem to solve.",
        "jp": "それは解決するのが複雑な問題だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The machine is very ",
          "."
        ],
        "full": "The machine is very COMPLEX.",
        "jp": "その機械は非常に複雑だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 109,
    "word": "COMPOSER",
    "meaning_core": "作曲家",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "POS",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MUSICIAN": "音楽家",
      "WRITER": "作家",
      "ARTIST": "芸術家"
    },
    "distractors": [
      "LISTENER",
      "AUDIENCE",
      "CRITIC",
      "FAN"
    ],
    "meanings_expanded": [
      "作曲家",
      "作者"
    ],
    "contexts": [
      {
        "parts": [
          "Beethoven is a famous",
          "."
        ],
        "full": "Beethoven is a famous COMPOSER.",
        "jp": "ベートーヴェンは有名な作曲家だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a great French ",
          "."
        ],
        "full": "He is a great French COMPOSER.",
        "jp": "彼は偉大なフランスの作曲家だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Who is the ",
          " of this music?"
        ],
        "full": "Who is the COMPOSER of this music?",
        "jp": "この曲の作曲家は誰ですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 110,
    "word": "COMPREHENSIVE",
    "meaning_core": "包括的な",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "HEN",
        "type": "strong"
      },
      {
        "text": "sive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLETE": "完全な",
      "THOROUGH": "徹底的な",
      "INCLUSIVE": "すべてを含んだ"
    },
    "distractors": [
      "PARTIAL",
      "LIMITED",
      "INCOMPLETE",
      "NARROW"
    ],
    "meanings_expanded": [
      "包括的な",
      "総合的な",
      "広範囲の"
    ],
    "contexts": [
      {
        "parts": [
          "We need a",
          "plan."
        ],
        "full": "We need a COMPREHENSIVE plan.",
        "jp": "私たちには包括的な計画が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The report is very ",
          "."
        ],
        "full": "The report is very COMPREHENSIVE.",
        "jp": "その報告書は非常に包括的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " review."
        ],
        "full": "We need a COMPREHENSIVE review.",
        "jp": "私たちは包括的な見直しが必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 111,
    "word": "COMPULSORY",
    "meaning_core": "義務的な",
    "syllables": [
      {
        "text": "com",
        "type": "weak"
      },
      {
        "text": "PUL",
        "type": "strong"
      },
      {
        "text": "so",
        "type": "weak"
      },
      {
        "text": "ry",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MANDATORY": "必須の",
      "REQUIRED": "求められる",
      "OBLIGATORY": "義務の"
    },
    "distractors": [
      "OPTIONAL",
      "VOLUNTARY",
      "FREE",
      "UNNECESSARY"
    ],
    "meanings_expanded": [
      "義務的な",
      "強制的な",
      "必修の"
    ],
    "contexts": [
      {
        "parts": [
          "English is a",
          "subject."
        ],
        "full": "English is a COMPULSORY subject.",
        "jp": "英語は必修科目だ。",
        "is_correct": true
      },
      {
        "parts": [
          "English is a ",
          " subject."
        ],
        "full": "English is a COMPULSORY subject.",
        "jp": "英語は義務的な科目だ。",
        "is_correct": true
      },
      {
        "parts": [
          "School attendance is ",
          "."
        ],
        "full": "School attendance is COMPULSORY.",
        "jp": "学校への出席は義務だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 112,
    "word": "CONCENTRATE",
    "meaning_core": "集中する",
    "syllables": [
      {
        "text": "CON",
        "type": "strong"
      },
      {
        "text": "cen",
        "type": "weak"
      },
      {
        "text": "trate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FOCUS": "焦点を合わせる",
      "CENTER": "中心に置く",
      "GATHER": "集める"
    },
    "distractors": [
      "DISTRACT",
      "DISPERSE",
      "IGNORE",
      "SCATTER"
    ],
    "meanings_expanded": [
      "集中する",
      "集結させる",
      "濃縮する"
    ],
    "contexts": [
      {
        "parts": [
          "I need to",
          "on my studies."
        ],
        "full": "I need to CONCENTRATE on my studies.",
        "jp": "私は勉強に集中する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "You need to ",
          " on your work."
        ],
        "full": "You need to CONCENTRATE on your work.",
        "jp": "あなたは仕事に集中する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She tried to ",
          " her efforts."
        ],
        "full": "She tried to CONCENTRATE her efforts.",
        "jp": "彼女は努力を集中させようとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 113,
    "word": "CONCERNED",
    "meaning_core": "心配して",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "CERNED",
        "type": "strong"
      }
    ],
    "synonyms": {
      "WORRIED": "心配な",
      "ANXIOUS": "不安な",
      "INVOLVED": "関わっている"
    },
    "distractors": [
      "INDIFFERENT",
      "CALM",
      "UNINTERESTED",
      "RELAXED"
    ],
    "meanings_expanded": [
      "心配して",
      "関心がある",
      "関係している"
    ],
    "contexts": [
      {
        "parts": [
          "I am",
          "about his health."
        ],
        "full": "I am CONCERNED about his health.",
        "jp": "私は彼の健康を心配している。",
        "is_correct": true
      },
      {
        "parts": [
          "He is",
          "with the project."
        ],
        "full": "He is involved with the project.",
        "jp": "彼はそのプロジェクトに関わっている。",
        "is_correct": true
      },
      {
        "parts": [
          "I am very ",
          " about your health."
        ],
        "full": "I am very CONCERNED about your health.",
        "jp": "私はあなたの健康を非常に心配している。",
        "is_correct": true
      },
      {
        "parts": [
          "The police are not ",
          " yet."
        ],
        "full": "The police are not CONCERNED yet.",
        "jp": "警察はまだ関与していない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 114,
    "word": "CONCISE",
    "meaning_core": "簡潔な",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "CISE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "BRIEF": "短い",
      "SHORT": "短い",
      "COMPACT": "コンパクトな"
    },
    "distractors": [
      "LONG",
      "WORDY",
      "LENGTHY",
      "REPETITIVE"
    ],
    "meanings_expanded": [
      "簡潔な",
      "簡明な"
    ],
    "contexts": [
      {
        "parts": [
          "Please keep your report",
          "."
        ],
        "full": "Please keep your report CONCISE.",
        "jp": "レポートは簡潔にまとめてください。",
        "is_correct": true
      },
      {
        "parts": [
          "His summary was clear and ",
          "."
        ],
        "full": "His summary was clear and CONCISE.",
        "jp": "彼の要約は明確で簡潔だった。",
        "is_correct": true
      },
      {
        "parts": [
          "Please write a ",
          " answer."
        ],
        "full": "Please write a CONCISE answer.",
        "jp": "簡潔な回答を書いてください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 115,
    "word": "CONDEMN",
    "meaning_core": "非難する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "DEMN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CRITICIZE": "批判する",
      "BLAME": "責める",
      "DENOUNCE": "公然と非難する"
    },
    "distractors": [
      "PRAISE",
      "APPROVE",
      "SUPPORT",
      "COMMEND"
    ],
    "meanings_expanded": [
      "非難する",
      "有罪を宣告する",
      "（運命などを）宣告する"
    ],
    "contexts": [
      {
        "parts": [
          "We must",
          "violence."
        ],
        "full": "We must CONDEMN violence.",
        "jp": "我々は暴力を非難しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We ",
          " all violence."
        ],
        "full": "We CONDEMN all violence.",
        "jp": "私たちはあらゆる暴力を非難する。",
        "is_correct": true
      },
      {
        "parts": [
          "The judge will ",
          " the prisoner."
        ],
        "full": "The judge will CONDEMN the prisoner.",
        "jp": "裁判官は囚人を非難するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 116,
    "word": "CONFIDENCE",
    "meaning_core": "自信",
    "syllables": [
      {
        "text": "CON",
        "type": "strong"
      },
      {
        "text": "fi",
        "type": "weak"
      },
      {
        "text": "dence",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TRUST": "信頼",
      "ASSURANCE": "確信",
      "BELIEF": "信念"
    },
    "distractors": [
      "DOUBT",
      "UNCERTAINTY",
      "FEAR",
      "SHYNESS"
    ],
    "meanings_expanded": [
      "自信",
      "信頼",
      "秘密"
    ],
    "contexts": [
      {
        "parts": [
          "He lacks",
          "in himself."
        ],
        "full": "He lacks CONFIDENCE in himself.",
        "jp": "彼は自分に自信がない。",
        "is_correct": true
      },
      {
        "parts": [
          "I have",
          "in your ability."
        ],
        "full": "I have faith in your ability.",
        "jp": "私はあなたの能力を信じている。",
        "is_correct": true
      },
      {
        "parts": [
          "She lacks ",
          " in herself."
        ],
        "full": "She lacks CONFIDENCE in herself.",
        "jp": "彼女は自分に自信がない。",
        "is_correct": true
      },
      {
        "parts": [
          "We spoke in strict ",
          "."
        ],
        "full": "We spoke in strict CONFIDENCE.",
        "jp": "私たちは厳密な秘密（信頼）のもとに話した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 117,
    "word": "CONFINE",
    "meaning_core": "閉じ込める",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "FINE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "RESTRICT": "制限する",
      "LIMIT": "限定する",
      "IMPRISON": "投獄する"
    },
    "distractors": [
      "FREE",
      "RELEASE",
      "LIBERATE",
      "EXPAND"
    ],
    "meanings_expanded": [
      "閉じ込める",
      "制限する",
      "（病気で）引きこもらせる"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "your remarks to the topic."
        ],
        "full": "Please CONFINE your remarks to the topic.",
        "jp": "発言は議題に限定してください。",
        "is_correct": true
      },
      {
        "parts": [
          "He was",
          "to bed by illness."
        ],
        "full": "He was confined to bed by illness.",
        "jp": "彼は病気で床に伏せっていた。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " the patient to bed."
        ],
        "full": "They will CONFINE the patient to bed.",
        "jp": "彼らは患者をベッドに閉じ込めるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " your comments to the topic."
        ],
        "full": "Please CONFINE your comments to the topic.",
        "jp": "コメントをトピックに限定してください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 118,
    "word": "CONFIRM",
    "meaning_core": "確認する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "FIRM",
        "type": "strong"
      }
    ],
    "synonyms": {
      "VERIFY": "検証する",
      "CHECK": "チェックする",
      "PROVE": "証明する"
    },
    "distractors": [
      "DENY",
      "REFUTE",
      "CANCEL",
      "IGNORE"
    ],
    "meanings_expanded": [
      "確認する",
      "（予約などを）確定する",
      "裏付ける"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "your reservation."
        ],
        "full": "Please CONFIRM your reservation.",
        "jp": "予約を確認してください。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " the appointment?"
        ],
        "full": "Can you CONFIRM the appointment?",
        "jp": "予約を確認してもらえますか。",
        "is_correct": true
      },
      {
        "parts": [
          "His actions ",
          " my doubts."
        ],
        "full": "His actions CONFIRM my doubts.",
        "jp": "彼の行動は私の疑念を裏付けた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 119,
    "word": "CONFIRMATION",
    "meaning_core": "確認",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "fir",
        "type": "weak"
      },
      {
        "text": "MA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PROOF": "証拠",
      "VERIFICATION": "検証",
      "APPROVAL": "承認"
    },
    "distractors": [
      "DENIAL",
      "REJECTION",
      "DOUBT",
      "CANCELLATION"
    ],
    "meanings_expanded": [
      "確認",
      "裏付け",
      "確証"
    ],
    "contexts": [
      {
        "parts": [
          "We are waiting for",
          "of the news."
        ],
        "full": "We are waiting for CONFIRMATION of the news.",
        "jp": "私たちはそのニュースの確認を待っている。",
        "is_correct": true
      },
      {
        "parts": [
          "I need a written ",
          "."
        ],
        "full": "I need a written CONFIRMATION.",
        "jp": "私は書面による確認が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The news requires ",
          "."
        ],
        "full": "The news requires CONFIRMATION.",
        "jp": "そのニュースは裏付けを必要とする。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 120,
    "word": "CONFLICT",
    "meaning_core": "対立",
    "syllables": [
      {
        "text": "CON",
        "type": "strong"
      },
      {
        "text": "flict",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISPUTE": "紛争",
      "CLASH": "衝突",
      "STRUGGLE": "闘争"
    },
    "distractors": [
      "AGREEMENT",
      "PEACE",
      "HARMONY",
      "ACCORD"
    ],
    "meanings_expanded": [
      "対立",
      "紛争",
      "衝突"
    ],
    "contexts": [
      {
        "parts": [
          "There is a",
          "of interest."
        ],
        "full": "There is a CONFLICT of interest.",
        "jp": "利益相反がある。",
        "is_correct": true
      },
      {
        "parts": [
          "There was a major ",
          " of interest."
        ],
        "full": "There was a major CONFLICT of interest.",
        "jp": "大きな利害の対立があった。",
        "is_correct": true
      },
      {
        "parts": [
          "The two reports ",
          "."
        ],
        "full": "The two reports CONFLICT.",
        "jp": "その二つの報告は矛盾している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 121,
    "word": "CONFRONT",
    "meaning_core": "直面する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "FRONT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FACE": "直面する",
      "ENCOUNTER": "出くわす",
      "CHALLENGE": "挑む"
    },
    "distractors": [
      "AVOID",
      "EVADE",
      "DODGE",
      "ESCAPE"
    ],
    "meanings_expanded": [
      "直面する",
      "立ち向かう",
      "突きつける"
    ],
    "contexts": [
      {
        "parts": [
          "You must",
          "your fears."
        ],
        "full": "You must CONFRONT your fears.",
        "jp": "君は自分の恐怖に立ち向かわなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "It is time to ",
          " the issue."
        ],
        "full": "It is time to CONFRONT the issue.",
        "jp": "その問題に直面する時が来た。",
        "is_correct": true
      },
      {
        "parts": [
          "You must ",
          " your fears."
        ],
        "full": "You must CONFRONT your fears.",
        "jp": "あなたは恐れに立ち向かわなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 122,
    "word": "CONGENIAL",
    "meaning_core": "気の合う",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "GEN",
        "type": "strong"
      },
      {
        "text": "ial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FRIENDLY": "友好的な",
      "AGREEABLE": "感じの良い",
      "COMPATIBLE": "相性の良い"
    },
    "distractors": [
      "UNPLEASANT",
      "HOSTILE",
      "DISAGREEABLE",
      "COLD"
    ],
    "meanings_expanded": [
      "気の合う",
      "快適な",
      "性分に合った"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "colleague."
        ],
        "full": "He is a CONGENIAL colleague.",
        "jp": "彼は気の合う同僚だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The atmosphere was ",
          "."
        ],
        "full": "The atmosphere was CONGENIAL.",
        "jp": "雰囲気は快適（気の合う）だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He found the work ",
          "."
        ],
        "full": "He found the work CONGENIAL.",
        "jp": "彼はその仕事が自分に合っていると感じた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 123,
    "word": "CONSENSUS",
    "meaning_core": "合意",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SEN",
        "type": "strong"
      },
      {
        "text": "sus",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AGREEMENT": "合意",
      "UNITY": "結束",
      "ACCORD": "一致"
    },
    "distractors": [
      "DISAGREEMENT",
      "CONFLICT",
      "DISPUTE",
      "DIVISION"
    ],
    "meanings_expanded": [
      "合意",
      "総意",
      "意見の一致"
    ],
    "contexts": [
      {
        "parts": [
          "We reached a",
          "on the issue."
        ],
        "full": "We reached a CONSENSUS on the issue.",
        "jp": "我々はその問題について合意に達した。",
        "is_correct": true
      },
      {
        "parts": [
          "We reached a clear ",
          "."
        ],
        "full": "We reached a clear CONSENSUS.",
        "jp": "私たちは明確な合意に達した。",
        "is_correct": true
      },
      {
        "parts": [
          "There is no ",
          " on this matter."
        ],
        "full": "There is no CONSENSUS on this matter.",
        "jp": "この問題について合意はない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 124,
    "word": "CONSEQUENTLY",
    "meaning_core": "その結果として",
    "syllables": [
      {
        "text": "CON",
        "type": "strong"
      },
      {
        "text": "se",
        "type": "weak"
      },
      {
        "text": "quent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "THEREFORE": "それゆえに",
      "THUS": "したがって",
      "AS A RESULT": "結果として"
    },
    "distractors": [
      "HOWEVER",
      "ALTHOUGH",
      "NEVERTHELESS",
      "BUT"
    ],
    "meanings_expanded": [
      "その結果として",
      "したがって"
    ],
    "contexts": [
      {
        "parts": [
          "It rained heavily;",
          ",",
          "the game was canceled."
        ],
        "full": "It rained heavily; CONSEQUENTLY, the game was canceled.",
        "jp": "激しく雨が降った。その結果、試合は中止になった。",
        "is_correct": true
      },
      {
        "parts": [
          "He lost the key; ",
          ", he was late."
        ],
        "full": "He lost the key; CONSEQUENTLY, he was late.",
        "jp": "彼は鍵をなくした。その結果、遅れた。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          ", profits rose sharply."
        ],
        "full": "CONSEQUENTLY, profits rose sharply.",
        "jp": "その結果として、利益は急増した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 125,
    "word": "CONSERVE",
    "meaning_core": "保存する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SERVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PRESERVE": "保護する",
      "SAVE": "節約する",
      "PROTECT": "守る"
    },
    "distractors": [
      "WASTE",
      "DESTROY",
      "SPEND",
      "SQUANDER"
    ],
    "meanings_expanded": [
      "保存する",
      "保護する",
      "節約する"
    ],
    "contexts": [
      {
        "parts": [
          "We must",
          "energy."
        ],
        "full": "We must CONSERVE energy.",
        "jp": "私たちはエネルギーを節約しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " our natural resources."
        ],
        "full": "We must CONSERVE our natural resources.",
        "jp": "私たちは天然資源を保護しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to ",
          " energy daily."
        ],
        "full": "Try to CONSERVE energy daily.",
        "jp": "日々、エネルギーを節約するように努めなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 126,
    "word": "CONSIDERABLE",
    "meaning_core": "かなりの",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SID",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUBSTANTIAL": "相当な",
      "SIGNIFICANT": "重要な",
      "LARGE": "大きな"
    },
    "distractors": [
      "INSIGNIFICANT",
      "TRIVIAL",
      "SMALL",
      "MINOR"
    ],
    "meanings_expanded": [
      "かなりの",
      "相当な",
      "重要な"
    ],
    "contexts": [
      {
        "parts": [
          "He spent a",
          "amount of money."
        ],
        "full": "He spent a CONSIDERABLE amount of money.",
        "jp": "彼はかなりの金額を使った。",
        "is_correct": true
      },
      {
        "parts": [
          "It requires a ",
          " amount of effort."
        ],
        "full": "It requires a CONSIDERABLE amount of effort.",
        "jp": "それはかなりの量の努力を必要とする。",
        "is_correct": true
      },
      {
        "parts": [
          "She saved a ",
          " sum of money."
        ],
        "full": "She saved a CONSIDERABLE sum of money.",
        "jp": "彼女はかなりの額のお金を貯めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 127,
    "word": "CONSIST",
    "meaning_core": "～から成る",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SIST",
        "type": "strong"
      }
    ],
    "synonyms": {
      "COMPRISE": "構成する",
      "CONTAIN": "含む",
      "INVOLVE": "伴う"
    },
    "distractors": [
      "LACK",
      "EXCLUDE",
      "MISS",
      "OMIT"
    ],
    "meanings_expanded": [
      "～から成る",
      "（～に）ある"
    ],
    "contexts": [
      {
        "parts": [
          "Water",
          "of hydrogen and oxygen."
        ],
        "full": "Water consists of hydrogen and oxygen.",
        "jp": "水は水素と酸素から成る。",
        "is_correct": true
      },
      {
        "parts": [
          "Success",
          "in hard work."
        ],
        "full": "Success lies in hard work.",
        "jp": "成功は勤勉にある。",
        "is_correct": true
      },
      {
        "parts": [
          "The team will ",
          " of ten members."
        ],
        "full": "The team will CONSIST of ten members.",
        "jp": "チームは10人のメンバーから成るだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Happiness does not ",
          " of money."
        ],
        "full": "Happiness does not CONSIST of money.",
        "jp": "幸福はお金から成るわけではない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 128,
    "word": "CONSISTENT",
    "meaning_core": "一貫した",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SIS",
        "type": "strong"
      },
      {
        "text": "tent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STEADY": "安定した",
      "CONSTANT": "不変の",
      "UNIFORM": "均一な"
    },
    "distractors": [
      "INCONSISTENT",
      "VARIABLE",
      "CHANGING",
      "ERRATIC"
    ],
    "meanings_expanded": [
      "一貫した",
      "矛盾のない",
      "着実な"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "worker."
        ],
        "full": "He is a CONSISTENT worker.",
        "jp": "彼は着実な働き手だ。",
        "is_correct": true
      },
      {
        "parts": [
          "His story is totally ",
          "."
        ],
        "full": "His story is totally CONSISTENT.",
        "jp": "彼の話は完全に一貫している。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to be ",
          " in our efforts."
        ],
        "full": "We need to be CONSISTENT in our efforts.",
        "jp": "私たちは努力において一貫している必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 129,
    "word": "CONSPICUOUS",
    "meaning_core": "目立つ",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SPIC",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NOTICEABLE": "目立つ",
      "PROMINENT": "顕著な",
      "OBVIOUS": "明らかな"
    },
    "distractors": [
      "OBSCURE",
      "HIDDEN",
      "INVISIBLE",
      "UNNOTICEABLE"
    ],
    "meanings_expanded": [
      "目立つ",
      "人目を引く",
      "著名な"
    ],
    "contexts": [
      {
        "parts": [
          "She felt",
          "in her bright dress."
        ],
        "full": "She felt CONSPICUOUS in her bright dress.",
        "jp": "彼女は明るいドレスを着て目立っていると感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "She wore a ",
          " red hat."
        ],
        "full": "She wore a CONSPICUOUS red hat.",
        "jp": "彼女は目立つ赤い帽子をかぶっていた。",
        "is_correct": true
      },
      {
        "parts": [
          "His error was ",
          "."
        ],
        "full": "His error was CONSPICUOUS.",
        "jp": "彼の誤りは明白だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 130,
    "word": "CONSPIRACY",
    "meaning_core": "陰謀",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SPIR",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "cy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PLOT": "企み",
      "SCHEME": "計画",
      "INTRIGUE": "陰謀"
    },
    "distractors": [
      "LOYALTY",
      "HONESTY",
      "TRUTH",
      "FACT"
    ],
    "meanings_expanded": [
      "陰謀",
      "共謀"
    ],
    "contexts": [
      {
        "parts": [
          "They uncovered a",
          "against the government."
        ],
        "full": "They uncovered a CONSPIRACY against the government.",
        "jp": "彼らは政府に対する陰謀を暴いた。",
        "is_correct": true
      },
      {
        "parts": [
          "They denied the ",
          "."
        ],
        "full": "They denied the CONSPIRACY.",
        "jp": "彼らはその陰謀を否定した。",
        "is_correct": true
      },
      {
        "parts": [
          "There is a theory of ",
          "."
        ],
        "full": "There is a theory of CONSPIRACY.",
        "jp": "陰謀論がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 131,
    "word": "CONSPIRE",
    "meaning_core": "共謀する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SPIRE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PLOT": "企む",
      "SCHEME": "画策する",
      "COLLUDE": "結託する"
    },
    "distractors": [
      "SUPPORT",
      "HELP",
      "AID",
      "ASSIST"
    ],
    "meanings_expanded": [
      "共謀する",
      "企む",
      "協力して作用する"
    ],
    "contexts": [
      {
        "parts": [
          "They",
          "to overthrow the king."
        ],
        "full": "They conspired to overthrow the king.",
        "jp": "彼らは王を退位させようと共謀した。",
        "is_correct": true
      },
      {
        "parts": [
          "Events seemed to",
          "against him."
        ],
        "full": "Events seemed to CONSPIRE against him.",
        "jp": "事態は彼に不利に作用しているようだった。",
        "is_correct": true
      },
      {
        "parts": [
          "The men will ",
          " against the king."
        ],
        "full": "The men will CONSPIRE against the king.",
        "jp": "男たちは王に対して共謀するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Everything seemed to ",
          " against me."
        ],
        "full": "Everything seemed to CONSPIRE against me.",
        "jp": "すべてが私に敵対しているように見えた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 132,
    "word": "CONSTANTLY",
    "meaning_core": "絶えず",
    "syllables": [
      {
        "text": "CON",
        "type": "strong"
      },
      {
        "text": "stant",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ALWAYS": "いつも",
      "CONTINUOUSLY": "連続して",
      "FREQUENTLY": "頻繁に"
    },
    "distractors": [
      "RARELY",
      "NEVER",
      "SELDOM",
      "SOMETIMES"
    ],
    "meanings_expanded": [
      "絶えず",
      "常に",
      "頻繁に"
    ],
    "contexts": [
      {
        "parts": [
          "She talks",
          "about her dog."
        ],
        "full": "She talks CONSTANTLY about her dog.",
        "jp": "彼女は絶えず自分の犬について話している。",
        "is_correct": true
      },
      {
        "parts": [
          "She is ",
          " checking her phone."
        ],
        "full": "She is CONSTANTLY checking her phone.",
        "jp": "彼女は絶えず携帯をチェックしている。",
        "is_correct": true
      },
      {
        "parts": [
          "The climate is ",
          " changing."
        ],
        "full": "The climate is CONSTANTLY changing.",
        "jp": "気候は絶えず変化している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 133,
    "word": "CONSULT",
    "meaning_core": "相談する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "SULT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ASK": "尋ねる",
      "CONFER": "協議する",
      "ADVISE": "助言を求める"
    },
    "distractors": [
      "IGNORE",
      "ORDER",
      "COMMAND",
      "DICTATE"
    ],
    "meanings_expanded": [
      "相談する",
      "（辞書などを）調べる",
      "診察を受ける"
    ],
    "contexts": [
      {
        "parts": [
          "You should",
          "a doctor."
        ],
        "full": "You should CONSULT a doctor.",
        "jp": "医者に相談すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Please",
          "the dictionary."
        ],
        "full": "Please CONSULT the dictionary.",
        "jp": "辞書を引いてください。",
        "is_correct": true
      },
      {
        "parts": [
          "You should ",
          " a doctor immediately."
        ],
        "full": "You should CONSULT a doctor immediately.",
        "jp": "すぐに医者に相談すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "I need to ",
          " the manual."
        ],
        "full": "I need to CONSULT the manual.",
        "jp": "私はマニュアルを参照する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 134,
    "word": "CONTAGIOUS",
    "meaning_core": "感染性の",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "TA",
        "type": "strong"
      },
      {
        "text": "gious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INFECTIOUS": "伝染性の",
      "CATCHING": "移りやすい",
      "SPREADING": "広まる"
    },
    "distractors": [
      "HARMLESS",
      "SAFE",
      "NONINFECTIOUS",
      "HEALTHY"
    ],
    "meanings_expanded": [
      "感染性の",
      "移りやすい"
    ],
    "contexts": [
      {
        "parts": [
          "The flu is highly",
          "."
        ],
        "full": "The flu is highly CONTAGIOUS.",
        "jp": "インフルエンザは非常に感染力が強い。",
        "is_correct": true
      },
      {
        "parts": [
          "Her laughter was",
          "."
        ],
        "full": "Her laughter was CONTAGIOUS.",
        "jp": "彼女の笑いは周りに伝染した。",
        "is_correct": true
      },
      {
        "parts": [
          "The disease is highly ",
          "."
        ],
        "full": "The disease is highly CONTAGIOUS.",
        "jp": "その病気は非常に伝染性が高い。",
        "is_correct": true
      },
      {
        "parts": [
          "Her laughter was ",
          "."
        ],
        "full": "Her laughter was CONTAGIOUS.",
        "jp": "彼女の笑い声は伝染した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 135,
    "word": "CONTEMPORARY",
    "meaning_core": "現代の",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "TEM",
        "type": "strong"
      },
      {
        "text": "po",
        "type": "weak"
      },
      {
        "text": "rar",
        "type": "weak"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MODERN": "近代の",
      "CURRENT": "現在の",
      "PRESENT-DAY": "今日の"
    },
    "distractors": [
      "ANCIENT",
      "OLD",
      "PAST",
      "CLASSIC"
    ],
    "meanings_expanded": [
      "現代の",
      "同時代の"
    ],
    "contexts": [
      {
        "parts": [
          "He is interested in",
          "art."
        ],
        "full": "He is interested in CONTEMPORARY art.",
        "jp": "彼は現代美術に興味がある。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a ",
          " artist."
        ],
        "full": "He is a CONTEMPORARY artist.",
        "jp": "彼は現代の芸術家だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The building has a ",
          " design."
        ],
        "full": "The building has a CONTEMPORARY design.",
        "jp": "その建物は現代的なデザインをしている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 136,
    "word": "CONTENTION",
    "meaning_core": "論争",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "TEN",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISPUTE": "紛争",
      "ARGUMENT": "議論",
      "CONFLICT": "対立"
    },
    "distractors": [
      "AGREEMENT",
      "HARMONY",
      "PEACE",
      "ACCORD"
    ],
    "meanings_expanded": [
      "論争",
      "主張",
      "競争"
    ],
    "contexts": [
      {
        "parts": [
          "This issue is a bone of",
          "."
        ],
        "full": "This issue is a bone of CONTENTION.",
        "jp": "この問題は論争の種だ。",
        "is_correct": true
      },
      {
        "parts": [
          "It is my",
          "that he is innocent."
        ],
        "full": "It is my CONTENTION that he is innocent.",
        "jp": "彼は無実であるというのが私の主張だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a point of ",
          "."
        ],
        "full": "This is a point of CONTENTION.",
        "jp": "これは論争の的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "That was his main ",
          "."
        ],
        "full": "That was his main CONTENTION.",
        "jp": "それが彼の主な主張だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 137,
    "word": "CONTRIBUTE",
    "meaning_core": "貢献する",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "TRIB",
        "type": "strong"
      },
      {
        "text": "ute",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DONATE": "寄付する",
      "SUPPLY": "供給する",
      "ADD": "加える"
    },
    "distractors": [
      "TAKE",
      "SUBTRACT",
      "REMOVE",
      "WITHHOLD"
    ],
    "meanings_expanded": [
      "貢献する",
      "寄付する",
      "（記事を）寄稿する"
    ],
    "contexts": [
      {
        "parts": [
          "Everyone should",
          "to the team."
        ],
        "full": "Everyone should CONTRIBUTE to the team.",
        "jp": "誰もがチームに貢献すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Smoking can",
          "to lung cancer."
        ],
        "full": "Smoking can CONTRIBUTE to lung cancer.",
        "jp": "喫煙は肺がんの一因となり得る。",
        "is_correct": true
      },
      {
        "parts": [
          "I want to ",
          " to the team."
        ],
        "full": "I want to CONTRIBUTE to the team.",
        "jp": "私はチームに貢献したい。",
        "is_correct": true
      },
      {
        "parts": [
          "Diet can ",
          " to good health."
        ],
        "full": "Diet can CONTRIBUTE to good health.",
        "jp": "食事は健康に貢献することができる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 138,
    "word": "CONTRIBUTION",
    "meaning_core": "貢献",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "tri",
        "type": "weak"
      },
      {
        "text": "BU",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DONATION": "寄付",
      "GIFT": "贈り物",
      "INPUT": "入力"
    },
    "distractors": [
      "LOSS",
      "DAMAGE",
      "DEBT",
      "COST"
    ],
    "meanings_expanded": [
      "貢献",
      "寄付金",
      "寄稿"
    ],
    "contexts": [
      {
        "parts": [
          "He made a significant",
          "to science."
        ],
        "full": "He made a significant CONTRIBUTION to science.",
        "jp": "彼は科学に多大な貢献をした。",
        "is_correct": true
      },
      {
        "parts": [
          "Thank you for your",
          "."
        ],
        "full": "Thank you for your donation.",
        "jp": "ご寄付ありがとうございます。",
        "is_correct": true
      },
      {
        "parts": [
          "Thank you for your ",
          "."
        ],
        "full": "Thank you for your CONTRIBUTION.",
        "jp": "あなたの貢献に感謝します。",
        "is_correct": true
      },
      {
        "parts": [
          "He made a huge ",
          " to science."
        ],
        "full": "He made a huge CONTRIBUTION to science.",
        "jp": "彼は科学に多大な貢献をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 139,
    "word": "CONTROVERSIAL",
    "meaning_core": "議論を呼ぶ",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "tro",
        "type": "weak"
      },
      {
        "text": "VER",
        "type": "strong"
      },
      {
        "text": "sial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEBATABLE": "議論の余地がある",
      "DISPUTED": "論争中の",
      "CONTENTIOUS": "争い好きな"
    },
    "distractors": [
      "CERTAIN",
      "UNDISPUTED",
      "AGREED",
      "SURE"
    ],
    "meanings_expanded": [
      "議論を呼ぶ",
      "物議を醸す"
    ],
    "contexts": [
      {
        "parts": [
          "The new policy is highly",
          "."
        ],
        "full": "The new policy is highly CONTROVERSIAL.",
        "jp": "新しい政策は非常に物議を醸している。",
        "is_correct": true
      },
      {
        "parts": [
          "It is a very ",
          " issue."
        ],
        "full": "It is a very CONTROVERSIAL issue.",
        "jp": "それは非常に議論を呼ぶ問題だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The article was highly ",
          "."
        ],
        "full": "The article was highly CONTROVERSIAL.",
        "jp": "その記事は非常に物議をかもした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 140,
    "word": "CONVENIENT",
    "meaning_core": "便利な",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "VEN",
        "type": "strong"
      },
      {
        "text": "ient",
        "type": "weak"
      }
    ],
    "synonyms": {
      "USEFUL": "役に立つ",
      "HANDY": "手軽な",
      "SUITABLE": "都合の良い"
    },
    "distractors": [
      "INCONVENIENT",
      "USELESS",
      "TROUBLESOME",
      "DIFFICULT"
    ],
    "meanings_expanded": [
      "便利な",
      "都合の良い"
    ],
    "contexts": [
      {
        "parts": [
          "When is a",
          "time for you?"
        ],
        "full": "When is a CONVENIENT time for you?",
        "jp": "ご都合の良い時間はいつですか？",
        "is_correct": true
      },
      {
        "parts": [
          "This tool is very",
          "."
        ],
        "full": "This tool is very useful.",
        "jp": "この道具はとても役に立つ。",
        "is_correct": true
      },
      {
        "parts": [
          "The store is very ",
          "."
        ],
        "full": "The store is very CONVENIENT.",
        "jp": "その店はとても便利だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Is this a ",
          " time to talk?"
        ],
        "full": "Is this a CONVENIENT time to talk?",
        "jp": "今は話すのに都合の良い時間ですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 141,
    "word": "CONVENTION",
    "meaning_core": "慣習",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "VEN",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CUSTOM": "習慣",
      "ASSEMBLY": "集会",
      "TRADITION": "伝統"
    },
    "distractors": [
      "INNOVATION",
      "EXCEPTION",
      "CHAOS",
      "DISORDER"
    ],
    "meanings_expanded": [
      "慣習",
      "しきたり",
      "大会"
    ],
    "contexts": [
      {
        "parts": [
          "Shaking hands is a social",
          "."
        ],
        "full": "Shaking hands is a social CONVENTION.",
        "jp": "握手は社会的な慣習だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He attended a comic",
          "."
        ],
        "full": "He attended a comic CONVENTION.",
        "jp": "彼はコミックの大会に参加した。",
        "is_correct": true
      },
      {
        "parts": [
          "They broke with ",
          "."
        ],
        "full": "They broke with CONVENTION.",
        "jp": "彼らは慣習を破った。",
        "is_correct": true
      },
      {
        "parts": [
          "We attended the national ",
          "."
        ],
        "full": "We attended the national CONVENTION.",
        "jp": "私たちは全国大会に出席した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 142,
    "word": "CONVENTIONAL",
    "meaning_core": "従来の",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "VEN",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TRADITIONAL": "伝統的な",
      "STANDARD": "標準的な",
      "ORTHODOX": "正統派の"
    },
    "distractors": [
      "UNUSUAL",
      "RADICAL",
      "MODERN",
      "NEW"
    ],
    "meanings_expanded": [
      "従来の",
      "型にはまった",
      "平凡な"
    ],
    "contexts": [
      {
        "parts": [
          "He prefers",
          "methods."
        ],
        "full": "He prefers CONVENTIONAL methods.",
        "jp": "彼は従来の方法を好む。",
        "is_correct": true
      },
      {
        "parts": [
          "He follows ",
          " wisdom."
        ],
        "full": "He follows CONVENTIONAL wisdom.",
        "jp": "彼は従来の知恵に従う。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a ",
          " approach."
        ],
        "full": "It was a CONVENTIONAL approach.",
        "jp": "それは従来の方法だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 143,
    "word": "CONVERSION",
    "meaning_core": "変換",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "VER",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TRANSFORMATION": "変形",
      "CHANGE": "変更",
      "ADAPTATION": "適応"
    },
    "distractors": [
      "CONSTANCY",
      "STABILITY",
      "MAINTENANCE",
      "KEEPING"
    ],
    "meanings_expanded": [
      "変換",
      "転換",
      "改宗"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "of water into steam requires heat."
        ],
        "full": "The CONVERSION of water into steam requires heat.",
        "jp": "水を蒸気に変換するには熱が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "His",
          "to Buddhism surprised us."
        ],
        "full": "His CONVERSION to Buddhism surprised us.",
        "jp": "彼が仏教に改宗したことは私たちを驚かせた。",
        "is_correct": true
      },
      {
        "parts": [
          "We need currency ",
          "."
        ],
        "full": "We need currency CONVERSION.",
        "jp": "私たちは通貨の交換が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " process is complex."
        ],
        "full": "The CONVERSION process is complex.",
        "jp": "その変換プロセスは複雑だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 144,
    "word": "CONVINCE",
    "meaning_core": "納得させる",
    "syllables": [
      {
        "text": "con",
        "type": "weak"
      },
      {
        "text": "VINCE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PERSUADE": "説得する",
      "SATISFY": "満足させる",
      "ASSURE": "確信させる"
    },
    "distractors": [
      "DISSUADE",
      "DOUBT",
      "CONFUSE",
      "PUZZLE"
    ],
    "meanings_expanded": [
      "納得させる",
      "確信させる"
    ],
    "contexts": [
      {
        "parts": [
          "I tried to",
          "him of my innocence."
        ],
        "full": "I tried to CONVINCE him of my innocence.",
        "jp": "私は彼に自分の無実を納得させようとした。",
        "is_correct": true
      },
      {
        "parts": [
          "I could not ",
          " her."
        ],
        "full": "I could not CONVINCE her.",
        "jp": "私は彼女を納得させることができなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to ",
          " them of your innocence."
        ],
        "full": "Try to CONVINCE them of your innocence.",
        "jp": "彼らにあなたの無実を信じさせなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 145,
    "word": "COOPERATE",
    "meaning_core": "協力する",
    "syllables": [
      {
        "text": "co",
        "type": "weak"
      },
      {
        "text": "OP",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COLLABORATE": "協同する",
      "WORK TOGETHER": "共に働く",
      "ASSIST": "助ける"
    },
    "distractors": [
      "OPPOSE",
      "COMPETE",
      "RESIST",
      "FIGHT"
    ],
    "meanings_expanded": [
      "協力する",
      "協同する"
    ],
    "contexts": [
      {
        "parts": [
          "We need to",
          "with each other."
        ],
        "full": "We need to COOPERATE with each other.",
        "jp": "私たちはお互いに協力する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " to finish this."
        ],
        "full": "We must COOPERATE to finish this.",
        "jp": "これを終えるために協力しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "They refused to ",
          " with the police."
        ],
        "full": "They refused to COOPERATE with the police.",
        "jp": "彼らは警察への協力を拒否した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 146,
    "word": "CORPORATION",
    "meaning_core": "企業",
    "syllables": [
      {
        "text": "cor",
        "type": "weak"
      },
      {
        "text": "po",
        "type": "weak"
      },
      {
        "text": "RA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPANY": "会社",
      "FIRM": "商社",
      "BUSINESS": "事業"
    },
    "distractors": [
      "INDIVIDUAL",
      "PERSON",
      "WORKER",
      "EMPLOYEE"
    ],
    "meanings_expanded": [
      "企業",
      "株式会社",
      "法人"
    ],
    "contexts": [
      {
        "parts": [
          "He works for a large multinational",
          "."
        ],
        "full": "He works for a large multinational CORPORATION.",
        "jp": "彼は巨大な多国籍企業で働いている。",
        "is_correct": true
      },
      {
        "parts": [
          "He works for a big ",
          "."
        ],
        "full": "He works for a big CORPORATION.",
        "jp": "彼は大企業で働いている。",
        "is_correct": true
      },
      {
        "parts": [
          "It is a global ",
          "."
        ],
        "full": "It is a global CORPORATION.",
        "jp": "それは国際的な企業だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 147,
    "word": "CRAFT",
    "meaning_core": "工芸",
    "syllables": [
      {
        "text": "CRAFT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SKILL": "技術",
      "ART": "芸術",
      "TRADE": "手仕事"
    },
    "distractors": [
      "LUCK",
      "CHANCE",
      "NATURE",
      "CHAOS"
    ],
    "meanings_expanded": [
      "工芸",
      "技術",
      "船"
    ],
    "contexts": [
      {
        "parts": [
          "She is skilled at arts and",
          "."
        ],
        "full": "She is skilled at arts and crafts.",
        "jp": "彼女は図画工作が得意だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The",
          "landed on the moon."
        ],
        "full": "The spacecraft landed on the moon.",
        "jp": "その宇宙船は月に着陸した。",
        "is_correct": true
      },
      {
        "parts": [
          "She mastered the ",
          "."
        ],
        "full": "She mastered the CRAFT.",
        "jp": "彼女はその技術を習得した。",
        "is_correct": true
      },
      {
        "parts": [
          "They sell local ",
          "."
        ],
        "full": "They sell local CRAFT.",
        "jp": "彼らは地元の工芸品を売っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 148,
    "word": "CREDIBILITY",
    "meaning_core": "信頼性",
    "syllables": [
      {
        "text": "cred",
        "type": "weak"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "BIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RELIABILITY": "信頼度",
      "TRUSTWORTHINESS": "信用性",
      "PLAUSIBILITY": "もっともらしさ"
    },
    "distractors": [
      "DOUBT",
      "DISTRUST",
      "LIE",
      "FALSEHOOD"
    ],
    "meanings_expanded": [
      "信頼性",
      "信憑性"
    ],
    "contexts": [
      {
        "parts": [
          "The scandal damaged his",
          "."
        ],
        "full": "The scandal damaged his CREDIBILITY.",
        "jp": "そのスキャンダルは彼の信頼性を傷つけた。",
        "is_correct": true
      },
      {
        "parts": [
          "His story lacks ",
          "."
        ],
        "full": "His story lacks CREDIBILITY.",
        "jp": "彼の話は信頼性に欠ける。",
        "is_correct": true
      },
      {
        "parts": [
          "You must protect your ",
          "."
        ],
        "full": "You must protect your CREDIBILITY.",
        "jp": "あなたは自分の信用を守らなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 149,
    "word": "CRISIS",
    "meaning_core": "危機",
    "syllables": [
      {
        "text": "CRI",
        "type": "strong"
      },
      {
        "text": "sis",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EMERGENCY": "緊急事態",
      "DISASTER": "災害",
      "CATASTROPHE": "大惨事"
    },
    "distractors": [
      "PEACE",
      "SAFETY",
      "STABILITY",
      "CALM"
    ],
    "meanings_expanded": [
      "危機",
      "重大局面"
    ],
    "contexts": [
      {
        "parts": [
          "The country is facing an economic",
          "."
        ],
        "full": "The country is facing an economic CRISIS.",
        "jp": "その国は経済危機に直面している。",
        "is_correct": true
      },
      {
        "parts": [
          "The country faces an economic ",
          "."
        ],
        "full": "The country faces an economic CRISIS.",
        "jp": "その国は経済危機に直面している。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a time of ",
          "."
        ],
        "full": "This is a time of CRISIS.",
        "jp": "今は危機の時だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 150,
    "word": "CRITICAL",
    "meaning_core": "批判的な",
    "syllables": [
      {
        "text": "CRIT",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CRUCIAL": "重大な",
      "VITAL": "不可欠な",
      "DISAPPROVING": "非難する"
    },
    "distractors": [
      "UNIMPORTANT",
      "TRIVIAL",
      "PRAISING",
      "SAFE"
    ],
    "meanings_expanded": [
      "批判的な",
      "重大な",
      "危機の"
    ],
    "contexts": [
      {
        "parts": [
          "It is",
          "to solve this problem now."
        ],
        "full": "It is CRITICAL to solve this problem now.",
        "jp": "今この問題を解決することが極めて重要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He was very",
          "of the plan."
        ],
        "full": "He was very CRITICAL of the plan.",
        "jp": "彼はその計画に対して非常に批判的だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave a ",
          " assessment."
        ],
        "full": "He gave a CRITICAL assessment.",
        "jp": "彼は批判的な評価を下した。",
        "is_correct": true
      },
      {
        "parts": [
          "Water is ",
          " for survival."
        ],
        "full": "Water is CRITICAL for survival.",
        "jp": "水は生存にとって極めて重要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 151,
    "word": "CRITICISM",
    "meaning_core": "批判",
    "syllables": [
      {
        "text": "CRIT",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cism",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISAPPROVAL": "不承認",
      "CENSURE": "非難",
      "REVIEW": "批評"
    },
    "distractors": [
      "PRAISE",
      "APPROVAL",
      "COMPLIMENT",
      "FLATTERY"
    ],
    "meanings_expanded": [
      "批判",
      "批評",
      "非難"
    ],
    "contexts": [
      {
        "parts": [
          "He accepted the",
          "gracefully."
        ],
        "full": "He accepted the CRITICISM gracefully.",
        "jp": "彼は批判を潔く受け入れた。",
        "is_correct": true
      },
      {
        "parts": [
          "She ignored the harsh ",
          "."
        ],
        "full": "She ignored the harsh CRITICISM.",
        "jp": "彼女は厳しい批判を無視した。",
        "is_correct": true
      },
      {
        "parts": [
          "The play received much ",
          "."
        ],
        "full": "The play received much CRITICISM.",
        "jp": "その劇は多くの批判を受けた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 152,
    "word": "CRUCIAL",
    "meaning_core": "極めて重要な",
    "syllables": [
      {
        "text": "CRU",
        "type": "strong"
      },
      {
        "text": "cial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ESSENTIAL": "不可欠な",
      "VITAL": "極めて重要な",
      "DECISIVE": "決定的な"
    },
    "distractors": [
      "TRIVIAL",
      "UNIMPORTANT",
      "MINOR",
      "INSIGNIFICANT"
    ],
    "meanings_expanded": [
      "極めて重要な",
      "決定的な",
      "厳しい"
    ],
    "contexts": [
      {
        "parts": [
          "Water is",
          "for survival."
        ],
        "full": "Water is CRUCIAL for survival.",
        "jp": "水は生存にとって極めて重要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This step is ",
          "."
        ],
        "full": "This step is CRUCIAL.",
        "jp": "このステップは極めて重要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Timing is ",
          " in this game."
        ],
        "full": "Timing is CRUCIAL in this game.",
        "jp": "このゲームではタイミングが非常に重要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 153,
    "word": "CRUELTY",
    "meaning_core": "残酷さ",
    "syllables": [
      {
        "text": "CRU",
        "type": "strong"
      },
      {
        "text": "el",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BRUTALITY": "残虐行為",
      "SAVAGERY": "野蛮",
      "HARSHNESS": "厳しさ"
    },
    "distractors": [
      "KINDNESS",
      "MERCY",
      "COMPASSION",
      "GENTLENESS"
    ],
    "meanings_expanded": [
      "残酷さ",
      "無慈悲",
      "虐待"
    ],
    "contexts": [
      {
        "parts": [
          "We must stop",
          "to animals."
        ],
        "full": "We must stop CRUELTY to animals.",
        "jp": "私たちは動物への虐待を止めなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "He reported animal ",
          "."
        ],
        "full": "He reported animal CRUELTY.",
        "jp": "彼は動物虐待を通報した。",
        "is_correct": true
      },
      {
        "parts": [
          "We oppose human ",
          "."
        ],
        "full": "We oppose human CRUELTY.",
        "jp": "私たちは人間の残酷さに反対する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 154,
    "word": "CULPRIT",
    "meaning_core": "犯人",
    "syllables": [
      {
        "text": "CUL",
        "type": "strong"
      },
      {
        "text": "prit",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OFFENDER": "違反者",
      "CRIMINAL": "犯罪者",
      "PERPETRATOR": "加害者"
    },
    "distractors": [
      "VICTIM",
      "HERO",
      "INNOCENT",
      "POLICE"
    ],
    "meanings_expanded": [
      "犯人",
      "容疑者",
      "原因となるもの"
    ],
    "contexts": [
      {
        "parts": [
          "Police caught the",
          "."
        ],
        "full": "Police caught the CULPRIT.",
        "jp": "警察は犯人を捕まえた。",
        "is_correct": true
      },
      {
        "parts": [
          "Sugar is the main",
          "of tooth decay."
        ],
        "full": "Sugar is the main CULPRIT of tooth decay.",
        "jp": "砂糖は虫歯の主な原因だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The police caught the ",
          "."
        ],
        "full": "The police caught the CULPRIT.",
        "jp": "警察は犯人を捕まえた。",
        "is_correct": true
      },
      {
        "parts": [
          "Who is the real ",
          " here?"
        ],
        "full": "Who is the real CULPRIT here?",
        "jp": "ここでの真犯人は誰ですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 155,
    "word": "CULTIVATE",
    "meaning_core": "耕す",
    "syllables": [
      {
        "text": "CUL",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "vate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FARM": "耕作する",
      "GROW": "育てる",
      "DEVELOP": "開発する"
    },
    "distractors": [
      "DESTROY",
      "NEGLECT",
      "ABANDON",
      "IGNORE"
    ],
    "meanings_expanded": [
      "耕す",
      "栽培する",
      "（才能などを）養う"
    ],
    "contexts": [
      {
        "parts": [
          "Farmers",
          "the land."
        ],
        "full": "Farmers CULTIVATE the land.",
        "jp": "農家は土地を耕す。",
        "is_correct": true
      },
      {
        "parts": [
          "He tries to",
          "friendships."
        ],
        "full": "He tries to CULTIVATE friendships.",
        "jp": "彼は友情を育もうとしている。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " good habits."
        ],
        "full": "We must CULTIVATE good habits.",
        "jp": "私たちは良い習慣を育まなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "Farmers ",
          " the land."
        ],
        "full": "Farmers CULTIVATE the land.",
        "jp": "農家は土地を耕作する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 156,
    "word": "CULTURE",
    "meaning_core": "文化",
    "syllables": [
      {
        "text": "CUL",
        "type": "strong"
      },
      {
        "text": "ture",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SOCIETY": "社会",
      "CUSTOMS": "慣習",
      "CIVILIZATION": "文明"
    },
    "distractors": [
      "NATURE",
      "WILDERNESS",
      "ANIMAL",
      "CHAOS"
    ],
    "meanings_expanded": [
      "文化",
      "教養",
      "培養"
    ],
    "contexts": [
      {
        "parts": [
          "We learned about Japanese",
          "."
        ],
        "full": "We learned about Japanese CULTURE.",
        "jp": "私たちは日本文化について学んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We learned about local ",
          "."
        ],
        "full": "We learned about local CULTURE.",
        "jp": "私たちは地元の文化について学んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is interested in Japanese ",
          "."
        ],
        "full": "He is interested in Japanese CULTURE.",
        "jp": "彼は日本文化に興味がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 157,
    "word": "CURRENTLY",
    "meaning_core": "現在は",
    "syllables": [
      {
        "text": "CUR",
        "type": "strong"
      },
      {
        "text": "rent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PRESENTLY": "現在",
      "NOW": "今",
      "AT PRESENT": "目下"
    },
    "distractors": [
      "FORMERLY",
      "PREVIOUSLY",
      "FUTURE",
      "PAST"
    ],
    "meanings_expanded": [
      "現在は",
      "目下"
    ],
    "contexts": [
      {
        "parts": [
          "He is",
          "working in Tokyo."
        ],
        "full": "He is CURRENTLY working in Tokyo.",
        "jp": "彼は現在東京で働いている。",
        "is_correct": true
      },
      {
        "parts": [
          "The office is ",
          " closed."
        ],
        "full": "The office is CURRENTLY closed.",
        "jp": "現在、オフィスは閉まっている。",
        "is_correct": true
      },
      {
        "parts": [
          "She is ",
          " working on a book."
        ],
        "full": "She is CURRENTLY working on a book.",
        "jp": "彼女は現在、本を執筆中だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 158,
    "word": "DEBATE",
    "meaning_core": "討論",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "BATE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ARGUMENT": "議論",
      "DISCUSSION": "話し合い",
      "DISPUTE": "論争"
    },
    "distractors": [
      "AGREEMENT",
      "ACCORD",
      "SILENCE",
      "PEACE"
    ],
    "meanings_expanded": [
      "討論",
      "論争",
      "議論する"
    ],
    "contexts": [
      {
        "parts": [
          "They held a",
          "on politics."
        ],
        "full": "They held a DEBATE on politics.",
        "jp": "彼らは政治について討論を行った。",
        "is_correct": true
      },
      {
        "parts": [
          "We had a lively ",
          "."
        ],
        "full": "We had a lively DEBATE.",
        "jp": "私たちは活発な討論をした。",
        "is_correct": true
      },
      {
        "parts": [
          "The topic is open to ",
          "."
        ],
        "full": "The topic is open to DEBATE.",
        "jp": "その話題は議論の余地がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 159,
    "word": "DEBT",
    "meaning_core": "借金",
    "syllables": [
      {
        "text": "DEBT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "LIABILITY": "負債",
      "DUE": "借り",
      "ARREARS": "滞納金"
    },
    "distractors": [
      "ASSET",
      "CREDIT",
      "PROFIT",
      "GAIN"
    ],
    "meanings_expanded": [
      "借金",
      "負債",
      "恩義"
    ],
    "contexts": [
      {
        "parts": [
          "He is deep in",
          "."
        ],
        "full": "He is deep in DEBT.",
        "jp": "彼は借金まみれだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The company is deep in ",
          "."
        ],
        "full": "The company is deep in DEBT.",
        "jp": "その会社は多額の借金を抱えている。",
        "is_correct": true
      },
      {
        "parts": [
          "I repaid the entire ",
          "."
        ],
        "full": "I repaid the entire DEBT.",
        "jp": "私は借金全額を返済した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 160,
    "word": "DECENT",
    "meaning_core": "礼儀にかなった",
    "syllables": [
      {
        "text": "DE",
        "type": "strong"
      },
      {
        "text": "cent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RESPECTABLE": "立派な",
      "PROPER": "適切な",
      "SUITABLE": "ふさわしい"
    },
    "distractors": [
      "INDECENT",
      "RUDE",
      "POOR",
      "BAD"
    ],
    "meanings_expanded": [
      "礼儀にかなった",
      "きちんとした",
      "かなりの"
    ],
    "contexts": [
      {
        "parts": [
          "He earns a",
          "salary."
        ],
        "full": "He earns a DECENT salary.",
        "jp": "彼はかなりの給料を稼いでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "He earns a ",
          " wage."
        ],
        "full": "He earns a DECENT wage.",
        "jp": "彼はまともな賃金を稼いでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "Show some ",
          " manners."
        ],
        "full": "Show some DECENT manners.",
        "jp": "ある程度の礼儀作法を見せなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 161,
    "word": "DECIPHER",
    "meaning_core": "解読する",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "CI",
        "type": "strong"
      },
      {
        "text": "pher",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DECODE": "解読する",
      "INTERPRET": "解釈する",
      "SOLVE": "解く"
    },
    "distractors": [
      "ENCODE",
      "HIDE",
      "CONCEAL",
      "BURY"
    ],
    "meanings_expanded": [
      "解読する",
      "判読する"
    ],
    "contexts": [
      {
        "parts": [
          "I couldn't",
          "his handwriting."
        ],
        "full": "I couldn't DECIPHER his handwriting.",
        "jp": "彼の筆跡を判読できなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " this old letter?"
        ],
        "full": "Can you DECIPHER this old letter?",
        "jp": "この古い手紙を解読できますか。",
        "is_correct": true
      },
      {
        "parts": [
          "Scientists will ",
          " the code."
        ],
        "full": "Scientists will DECIPHER the code.",
        "jp": "科学者たちはその暗号を解読するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 162,
    "word": "DEFECTIVE",
    "meaning_core": "欠陥のある",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "FEC",
        "type": "strong"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FAULTY": "欠点のある",
      "FLAWED": "不備のある",
      "BROKEN": "壊れた"
    },
    "distractors": [
      "PERFECT",
      "FLAWLESS",
      "INTACT",
      "WORKING"
    ],
    "meanings_expanded": [
      "欠陥のある",
      "不完全な"
    ],
    "contexts": [
      {
        "parts": [
          "This machine is",
          "."
        ],
        "full": "This machine is DEFECTIVE.",
        "jp": "この機械は欠陥がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The goods were ",
          "."
        ],
        "full": "The goods were DEFECTIVE.",
        "jp": "その商品は欠陥品だった。",
        "is_correct": true
      },
      {
        "parts": [
          "We returned the ",
          " part."
        ],
        "full": "We returned the DEFECTIVE part.",
        "jp": "私たちは欠陥のある部品を返品した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 163,
    "word": "DEFICIT",
    "meaning_core": "赤字",
    "syllables": [
      {
        "text": "DEF",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cit",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SHORTAGE": "不足",
      "LOSS": "損失",
      "DEBT": "借金"
    },
    "distractors": [
      "SURPLUS",
      "PROFIT",
      "EXCESS",
      "GAIN"
    ],
    "meanings_expanded": [
      "赤字",
      "不足額",
      "欠損"
    ],
    "contexts": [
      {
        "parts": [
          "The government faces a budget",
          "."
        ],
        "full": "The government faces a budget DEFICIT.",
        "jp": "政府は財政赤字に直面している。",
        "is_correct": true
      },
      {
        "parts": [
          "The budget has a large ",
          "."
        ],
        "full": "The budget has a large DEFICIT.",
        "jp": "その予算には大きな赤字がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They plan to reduce the ",
          "."
        ],
        "full": "They plan to reduce the DEFICIT.",
        "jp": "彼らは赤字を減らす計画だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 164,
    "word": "DEFINE",
    "meaning_core": "定義する",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "FINE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXPLAIN": "説明する",
      "DESCRIBE": "描写する",
      "OUTLINE": "概説する"
    },
    "distractors": [
      "CONFUSE",
      "OBSCURE",
      "HIDE",
      "MIX"
    ],
    "meanings_expanded": [
      "定義する",
      "明確にする",
      "規定する"
    ],
    "contexts": [
      {
        "parts": [
          "Can you",
          "the word?"
        ],
        "full": "Can you DEFINE the word?",
        "jp": "その単語を定義できますか？",
        "is_correct": true
      },
      {
        "parts": [
          "How would you ",
          " success?"
        ],
        "full": "How would you DEFINE success?",
        "jp": "あなたは成功をどのように定義しますか。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the term clearly."
        ],
        "full": "We must DEFINE the term clearly.",
        "jp": "私たちはその用語を明確に定義しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 165,
    "word": "DEFINITE",
    "meaning_core": "明確な",
    "syllables": [
      {
        "text": "DEF",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "nite",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CERTAIN": "確実な",
      "SURE": "確信している",
      "CLEAR": "はっきりした"
    },
    "distractors": [
      "VAGUE",
      "UNCERTAIN",
      "INDEFINITE",
      "DOUBTFUL"
    ],
    "meanings_expanded": [
      "明確な",
      "限定された",
      "確実な"
    ],
    "contexts": [
      {
        "parts": [
          "I need a",
          "answer."
        ],
        "full": "I need a DEFINITE answer.",
        "jp": "明確な答えが必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " plan."
        ],
        "full": "We need a DEFINITE plan.",
        "jp": "私たちは明確な計画が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I saw a ",
          " improvement."
        ],
        "full": "I saw a DEFINITE improvement.",
        "jp": "私は明確な改善を見た。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 166,
    "word": "DEFINITION",
    "meaning_core": "定義",
    "syllables": [
      {
        "text": "def",
        "type": "weak"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "NI",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MEANING": "意味",
      "EXPLANATION": "説明",
      "DESCRIPTION": "記述"
    },
    "distractors": [
      "AMBIGUITY",
      "CONFUSION",
      "MYSTERY",
      "PUZZLE"
    ],
    "meanings_expanded": [
      "定義",
      "解像度",
      "鮮明さ"
    ],
    "contexts": [
      {
        "parts": [
          "Look up the",
          "in the dictionary."
        ],
        "full": "Look up the DEFINITION in the dictionary.",
        "jp": "辞書で定義を調べなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "This TV has high",
          "."
        ],
        "full": "This TV has high DEFINITION.",
        "jp": "このテレビは高解像度だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " of the word is complex."
        ],
        "full": "The DEFINITION of the word is complex.",
        "jp": "その単語の定義は複雑だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I looked up the ",
          "."
        ],
        "full": "I looked up the DEFINITION.",
        "jp": "私は定義を調べた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 167,
    "word": "DELIBERATE",
    "meaning_core": "熟考する",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "LIB",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PONDER": "熟考する",
      "CONSIDER": "検討する",
      "REFLECT": "反省する"
    },
    "distractors": [
      "RUSH",
      "HURRY",
      "GUESS",
      "IGNORE"
    ],
    "meanings_expanded": [
      "熟考する",
      "審議する",
      "故意の（形容詞）"
    ],
    "contexts": [
      {
        "parts": [
          "The jury will",
          "tomorrow."
        ],
        "full": "The jury will DELIBERATE tomorrow.",
        "jp": "陪審員は明日審議を行う。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a",
          "act."
        ],
        "full": "It was a DELIBERATE act.",
        "jp": "それは故意の行為だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The jury will now ",
          "."
        ],
        "full": "The jury will now DELIBERATE.",
        "jp": "陪審は今から熟考する。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a ",
          " lie."
        ],
        "full": "It was a DELIBERATE lie.",
        "jp": "それは意図的な嘘だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 168,
    "word": "DEMOCRATIC",
    "meaning_core": "民主主義の",
    "syllables": [
      {
        "text": "dem",
        "type": "weak"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "CRAT",
        "type": "strong"
      },
      {
        "text": "ic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POPULAR": "大衆の",
      "REPRESENTATIVE": "代表制の",
      "EGALITARIAN": "平等主義の"
    },
    "distractors": [
      "DICTATORIAL",
      "AUTOCRATIC",
      "TYRANNICAL",
      "TOTALITARIAN"
    ],
    "meanings_expanded": [
      "民主主義の",
      "民主的な"
    ],
    "contexts": [
      {
        "parts": [
          "We live in a",
          "society."
        ],
        "full": "We live in a DEMOCRATIC society.",
        "jp": "私たちは民主主義社会に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "They held a ",
          " election."
        ],
        "full": "They held a DEMOCRATIC election.",
        "jp": "彼らは民主的な選挙を行った。",
        "is_correct": true
      },
      {
        "parts": [
          "We live in a ",
          " society."
        ],
        "full": "We live in a DEMOCRATIC society.",
        "jp": "私たちは民主的な社会に住んでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 169,
    "word": "DEPICT",
    "meaning_core": "描写する",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "PICT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PORTRAY": "描く",
      "DESCRIBE": "描写する",
      "ILLUSTRATE": "図解する"
    },
    "distractors": [
      "HIDE",
      "CONCEAL",
      "IGNORE",
      "DISTORT"
    ],
    "meanings_expanded": [
      "描写する",
      "描く"
    ],
    "contexts": [
      {
        "parts": [
          "The painting",
          "a rural scene."
        ],
        "full": "The painting depicts a rural scene.",
        "jp": "その絵は田園風景を描いている。",
        "is_correct": true
      },
      {
        "parts": [
          "The painting ",
          " a battle."
        ],
        "full": "The painting DEPICT a battle.",
        "jp": "その絵画は戦いを描写している。",
        "is_correct": true
      },
      {
        "parts": [
          "How does the book ",
          " the hero?"
        ],
        "full": "How does the book DEPICT the hero?",
        "jp": "その本はヒーローをどのように描いていますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 170,
    "word": "DEPOT",
    "meaning_core": "貯蔵庫",
    "syllables": [
      {
        "text": "DE",
        "type": "strong"
      },
      {
        "text": "pot",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WAREHOUSE": "倉庫",
      "STATION": "駅",
      "TERMINAL": "ターミナル"
    },
    "distractors": [
      "HOME",
      "OFFICE",
      "FIELD",
      "PARK"
    ],
    "meanings_expanded": [
      "貯蔵庫",
      "倉庫",
      "駅（米語）"
    ],
    "contexts": [
      {
        "parts": [
          "The bus",
          "is near here."
        ],
        "full": "The bus DEPOT is near here.",
        "jp": "バスの車庫（発着所）はこの近くだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We store goods in the",
          "."
        ],
        "full": "We store goods in the DEPOT.",
        "jp": "私たちは商品を倉庫に保管する。",
        "is_correct": true
      },
      {
        "parts": [
          "The bus pulled into the ",
          "."
        ],
        "full": "The bus pulled into the DEPOT.",
        "jp": "バスは車庫に入った。",
        "is_correct": true
      },
      {
        "parts": [
          "We store supplies at the ",
          "."
        ],
        "full": "We store supplies at the DEPOT.",
        "jp": "私たちは貯蔵庫に備蓄品を保管する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 171,
    "word": "DESERTED",
    "meaning_core": "人通りの絶えた",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "SERT",
        "type": "strong"
      },
      {
        "text": "ed",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ABANDONED": "見捨てられた",
      "EMPTY": "空の",
      "UNINHABITED": "無人の"
    },
    "distractors": [
      "CROWDED",
      "POPULATED",
      "BUSY",
      "FULL"
    ],
    "meanings_expanded": [
      "人通りの絶えた",
      "見捨てられた",
      "荒涼とした"
    ],
    "contexts": [
      {
        "parts": [
          "The streets were completely",
          "at night."
        ],
        "full": "The streets were completely DESERTED at night.",
        "jp": "夜、通りは完全に人通りが絶えていた。",
        "is_correct": true
      },
      {
        "parts": [
          "The streets were completely ",
          "."
        ],
        "full": "The streets were completely DESERTED.",
        "jp": "通りは完全に人通りの絶えていた。",
        "is_correct": true
      },
      {
        "parts": [
          "They found a ",
          " village."
        ],
        "full": "They found a DESERTED village.",
        "jp": "彼らは無人の村を見つけた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 172,
    "word": "DESERVE",
    "meaning_core": "～に値する",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "SERVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MERIT": "値する",
      "EARN": "（権利を）得る",
      "WARRANT": "正当化する"
    },
    "distractors": [
      "LOSE",
      "FAIL",
      "FORFEIT",
      "MISS"
    ],
    "meanings_expanded": [
      "～に値する",
      "～を受けるに足る"
    ],
    "contexts": [
      {
        "parts": [
          "You",
          "a break after working so hard."
        ],
        "full": "You DESERVE a break after working so hard.",
        "jp": "そんなに一生懸命働いたのだから、君は休憩するに値する。",
        "is_correct": true
      },
      {
        "parts": [
          "You ",
          " to win this prize."
        ],
        "full": "You DESERVE to win this prize.",
        "jp": "あなたはこの賞に値する。",
        "is_correct": true
      },
      {
        "parts": [
          "She did not ",
          " that treatment."
        ],
        "full": "She did not DESERVE that treatment.",
        "jp": "彼女はそのような扱いを受けるに値しなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 173,
    "word": "DESPERATE",
    "meaning_core": "必死の",
    "syllables": [
      {
        "text": "DES",
        "type": "strong"
      },
      {
        "text": "per",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HOPELESS": "絶望的な",
      "FRANTIC": "死に物狂いの",
      "URGENT": "緊急の"
    },
    "distractors": [
      "CALM",
      "HOPEFUL",
      "CONFIDENT",
      "SECURE"
    ],
    "meanings_expanded": [
      "必死の",
      "絶望的な",
      "自暴自棄の"
    ],
    "contexts": [
      {
        "parts": [
          "He made a",
          "attempt to escape."
        ],
        "full": "He made a DESPERATE attempt to escape.",
        "jp": "彼は逃げようと必死の試みをした。",
        "is_correct": true
      },
      {
        "parts": [
          "He made a ",
          " attempt to escape."
        ],
        "full": "He made a DESPERATE attempt to escape.",
        "jp": "彼は必死の脱出を試みた。",
        "is_correct": true
      },
      {
        "parts": [
          "The team is in ",
          " need of funds."
        ],
        "full": "The team is in DESPERATE need of funds.",
        "jp": "チームは資金を必死に必要としている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 174,
    "word": "DESPITE",
    "meaning_core": "～にもかかわらず",
    "syllables": [
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "SPITE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "IN SPITE OF": "～にもかかわらず",
      "REGARDLESS OF": "～にかかわらず",
      "NOTWITHSTANDING": "～それにもかかわらず"
    },
    "distractors": [
      "BECAUSE OF",
      "DUE TO",
      "THANKS TO",
      "OWING TO"
    ],
    "meanings_expanded": [
      "～にもかかわらず"
    ],
    "contexts": [
      {
        "parts": [
          "He went out",
          "the heavy rain."
        ],
        "full": "He went out DESPITE the heavy rain.",
        "jp": "大雨にもかかわらず彼は外出した。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          " the rain, we went out."
        ],
        "full": "DESPITE the rain, we went out.",
        "jp": "雨にもかかわらず、私たちは外出しました。",
        "is_correct": true
      },
      {
        "parts": [
          "She succeeded ",
          " the difficulty."
        ],
        "full": "She succeeded DESPITE the difficulty.",
        "jp": "困難にもかかわらず、彼女は成功した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 175,
    "word": "DEVASTATE",
    "meaning_core": "破壊する",
    "syllables": [
      {
        "text": "DEV",
        "type": "strong"
      },
      {
        "text": "as",
        "type": "weak"
      },
      {
        "text": "tate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DESTROY": "破壊する",
      "RUIN": "台無しにする",
      "RAVAGE": "荒らす"
    },
    "distractors": [
      "BUILD",
      "CREATE",
      "CONSTRUCT",
      "REPAIR"
    ],
    "meanings_expanded": [
      "破壊する",
      "（精神的に）打ちのめす",
      "荒廃させる"
    ],
    "contexts": [
      {
        "parts": [
          "The hurricane will",
          "the coast."
        ],
        "full": "The hurricane will DEVASTATE the coast.",
        "jp": "ハリケーンは海岸地帯を破壊するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The flood will ",
          " the town."
        ],
        "full": "The flood will DEVASTATE the town.",
        "jp": "洪水は町を破壊するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The news would ",
          " him."
        ],
        "full": "The news would DEVASTATE him.",
        "jp": "そのニュースは彼を打ちのめすだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 176,
    "word": "DEXTEROUS",
    "meaning_core": "器用な",
    "syllables": [
      {
        "text": "DEX",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SKILLFUL": "巧みな",
      "ADROIT": "機敏な",
      "HANDY": "器用な"
    },
    "distractors": [
      "CLUMSY",
      "AWKWARD",
      "UNSKILLED",
      "INEPT"
    ],
    "meanings_expanded": [
      "器用な",
      "機敏な",
      "巧妙な"
    ],
    "contexts": [
      {
        "parts": [
          "He is",
          "with his hands."
        ],
        "full": "He is DEXTEROUS with his hands.",
        "jp": "彼は手先が器用だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She is very ",
          " with her hands."
        ],
        "full": "She is very DEXTEROUS with her hands.",
        "jp": "彼女は手がとても器用だ。",
        "is_correct": true
      },
      {
        "parts": [
          "A good surgeon must be ",
          "."
        ],
        "full": "A good surgeon must be DEXTEROUS.",
        "jp": "優秀な外科医は器用でなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 177,
    "word": "DIAGNOSE",
    "meaning_core": "診断する",
    "syllables": [
      {
        "text": "di",
        "type": "weak"
      },
      {
        "text": "ag",
        "type": "weak"
      },
      {
        "text": "NOSE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "IDENTIFY": "特定する",
      "DETECT": "発見する",
      "DETERMINE": "判定する"
    },
    "distractors": [
      "IGNORE",
      "OVERLOOK",
      "GUESS",
      "MISS"
    ],
    "meanings_expanded": [
      "診断する",
      "原因を突き止める"
    ],
    "contexts": [
      {
        "parts": [
          "Doctors couldn't",
          "the disease."
        ],
        "full": "Doctors couldn't DIAGNOSE the disease.",
        "jp": "医師たちはその病気を診断できなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "The doctor will ",
          " the illness."
        ],
        "full": "The doctor will DIAGNOSE the illness.",
        "jp": "医者がその病気を診断するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "It is difficult to ",
          " the problem."
        ],
        "full": "It is difficult to DIAGNOSE the problem.",
        "jp": "その問題を診断するのは難しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 178,
    "word": "DICTATE",
    "meaning_core": "指図する",
    "syllables": [
      {
        "text": "DIC",
        "type": "strong"
      },
      {
        "text": "tate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMMAND": "命令する",
      "ORDER": "命じる",
      "IMPOSE": "課す"
    },
    "distractors": [
      "OBEY",
      "FOLLOW",
      "REQUEST",
      "ASK"
    ],
    "meanings_expanded": [
      "指図する",
      "書き取らせる",
      "規定する"
    ],
    "contexts": [
      {
        "parts": [
          "Don't let others",
          "your life."
        ],
        "full": "Don't let others DICTATE your life.",
        "jp": "他人に自分の人生を指図させてはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "You cannot ",
          " what I do."
        ],
        "full": "You cannot DICTATE what I do.",
        "jp": "あなたは私が何をすべきか指図できない。",
        "is_correct": true
      },
      {
        "parts": [
          "The terms of the treaty were ",
          "."
        ],
        "full": "The terms of the treaty were DICTATE.",
        "jp": "条約の条項が口述された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 179,
    "word": "DILIGENTLY",
    "meaning_core": "勤勉に",
    "syllables": [
      {
        "text": "DIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "gent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INDUSTRIOUSLY": "熱心に",
      "HARD": "一生懸命",
      "CAREFULLY": "入念に"
    },
    "distractors": [
      "LAZILY",
      "IDLY",
      "CARELESSLY",
      "SLOWLY"
    ],
    "meanings_expanded": [
      "勤勉に",
      "入念に",
      "こつこつと"
    ],
    "contexts": [
      {
        "parts": [
          "She studied",
          "for the exam."
        ],
        "full": "She studied DILIGENTLY for the exam.",
        "jp": "彼女は試験のために勤勉に勉強した。",
        "is_correct": true
      },
      {
        "parts": [
          "He worked ",
          " on the project."
        ],
        "full": "He worked DILIGENTLY on the project.",
        "jp": "彼はそのプロジェクトに勤勉に取り組んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "She studied ",
          " for the exam."
        ],
        "full": "She studied DILIGENTLY for the exam.",
        "jp": "彼女は試験のために熱心に勉強した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 180,
    "word": "DISCOMFORT",
    "meaning_core": "不快",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "COM",
        "type": "strong"
      },
      {
        "text": "fort",
        "type": "weak"
      }
    ],
    "synonyms": {
      "UNEASE": "不安",
      "PAIN": "痛み",
      "DISTRESS": "苦悩"
    },
    "distractors": [
      "COMFORT",
      "EASE",
      "RELIEF",
      "PLEASURE"
    ],
    "meanings_expanded": [
      "不快",
      "不便",
      "軽い痛み"
    ],
    "contexts": [
      {
        "parts": [
          "He felt some",
          "in his stomach."
        ],
        "full": "He felt some DISCOMFORT in his stomach.",
        "jp": "彼は胃に少し不快感を感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "The heat caused great ",
          "."
        ],
        "full": "The heat caused great DISCOMFORT.",
        "jp": "暑さは大きな不快感を引き起こした。",
        "is_correct": true
      },
      {
        "parts": [
          "He tried to hide his ",
          "."
        ],
        "full": "He tried to hide his DISCOMFORT.",
        "jp": "彼は不快感を隠そうとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 181,
    "word": "DISCREETLY",
    "meaning_core": "慎重に",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "CREET",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CAUTIOUSLY": "用心深く",
      "SECRETLY": "こっそりと",
      "TACTFULLY": "それとなく"
    },
    "distractors": [
      "OPENLY",
      "PUBLICLY",
      "LOUDLY",
      "OBVIOUSLY"
    ],
    "meanings_expanded": [
      "慎重に",
      "控えめに",
      "目立たないように"
    ],
    "contexts": [
      {
        "parts": [
          "He left the room",
          "."
        ],
        "full": "He left the room DISCREETLY.",
        "jp": "彼は慎重に部屋を出た。",
        "is_correct": true
      },
      {
        "parts": [
          "He left the room ",
          "."
        ],
        "full": "He left the room DISCREETLY.",
        "jp": "彼は慎重に部屋を去った。",
        "is_correct": true
      },
      {
        "parts": [
          "Please handle the matter ",
          "."
        ],
        "full": "Please handle the matter DISCREETLY.",
        "jp": "その問題を慎重に処理してください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 182,
    "word": "DISGUISE",
    "meaning_core": "変装",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "GUISE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MASK": "仮面",
      "CAMOUFLAGE": "カモフラージュ",
      "COSTUME": "衣装"
    },
    "distractors": [
      "REALITY",
      "TRUTH",
      "HONESTY",
      "OPENNESS"
    ],
    "meanings_expanded": [
      "変装",
      "見せかけ",
      "隠すこと"
    ],
    "contexts": [
      {
        "parts": [
          "He wore a",
          "to hide his identity."
        ],
        "full": "He wore a DISGUISE to hide his identity.",
        "jp": "彼は正体を隠すために変装をした。",
        "is_correct": true
      },
      {
        "parts": [
          "He wore a clever ",
          "."
        ],
        "full": "He wore a clever DISGUISE.",
        "jp": "彼は巧妙な変装をしていた。",
        "is_correct": true
      },
      {
        "parts": [
          "She tried to ",
          " her voice."
        ],
        "full": "She tried to DISGUISE her voice.",
        "jp": "彼女は声を隠そうとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 183,
    "word": "DISMISS",
    "meaning_core": "解雇する",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "MISS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FIRE": "クビにする",
      "REJECT": "却下する",
      "DISCHARGE": "免職する"
    },
    "distractors": [
      "HIRE",
      "EMPLOY",
      "ACCEPT",
      "ENGAGE"
    ],
    "meanings_expanded": [
      "解雇する",
      "（考えなどを）退ける",
      "解散させる"
    ],
    "contexts": [
      {
        "parts": [
          "The boss decided to",
          "him."
        ],
        "full": "The boss decided to DISMISS him.",
        "jp": "上司は彼を解雇することに決めた。",
        "is_correct": true
      },
      {
        "parts": [
          "The court will ",
          " the case."
        ],
        "full": "The court will DISMISS the case.",
        "jp": "裁判所はその訴訟を却下するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "He was ",
          " from his job."
        ],
        "full": "He was DISMISS from his job.",
        "jp": "彼は仕事を解雇された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 184,
    "word": "DISPERSE",
    "meaning_core": "分散させる",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "PERSE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SCATTER": "まき散らす",
      "SPREAD": "広げる",
      "DISSIPATE": "散らす"
    },
    "distractors": [
      "GATHER",
      "COLLECT",
      "ASSEMBLE",
      "CONCENTRATE"
    ],
    "meanings_expanded": [
      "分散させる",
      "散らばる",
      "消散させる"
    ],
    "contexts": [
      {
        "parts": [
          "The police used tear gas to",
          "the crowd."
        ],
        "full": "The police used tear gas to DISPERSE the crowd.",
        "jp": "警察は群衆を分散させるために催涙ガスを使用した。",
        "is_correct": true
      },
      {
        "parts": [
          "The crowd began to ",
          "."
        ],
        "full": "The crowd began to DISPERSE.",
        "jp": "群衆は分散し始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "Police used tear gas to ",
          " the mob."
        ],
        "full": "Police used tear gas to DISPERSE the mob.",
        "jp": "警察は暴徒を追い散らすために催涙ガスを使用した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 185,
    "word": "DISTINCTION",
    "meaning_core": "区別",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "TINC",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DIFFERENCE": "違い",
      "DIFFERENTIATION": "差別化",
      "EXCELLENCE": "優秀さ"
    },
    "distractors": [
      "SIMILARITY",
      "RESEMBLANCE",
      "EQUALITY",
      "SAMENESS"
    ],
    "meanings_expanded": [
      "区別",
      "卓越性",
      "特徴"
    ],
    "contexts": [
      {
        "parts": [
          "It is hard to make a",
          "between the two."
        ],
        "full": "It is hard to make a DISTINCTION between the two.",
        "jp": "その二つを区別するのは難しい。",
        "is_correct": true
      },
      {
        "parts": [
          "There is no clear ",
          " between them."
        ],
        "full": "There is no clear DISTINCTION between them.",
        "jp": "それらの間に明確な区別はない。",
        "is_correct": true
      },
      {
        "parts": [
          "He graduated with high ",
          "."
        ],
        "full": "He graduated with high DISTINCTION.",
        "jp": "彼は優秀な成績で卒業した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 186,
    "word": "DISTINGUISH",
    "meaning_core": "区別する",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "TIN",
        "type": "strong"
      },
      {
        "text": "guish",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DIFFERENTIATE": "識別する",
      "DISCRIMINATE": "区別する",
      "TELL APART": "見分ける"
    },
    "distractors": [
      "CONFUSE",
      "MIX",
      "BLEND",
      "IGNORE"
    ],
    "meanings_expanded": [
      "区別する",
      "見分ける",
      "目立たせる"
    ],
    "contexts": [
      {
        "parts": [
          "Can you",
          "between right and wrong?"
        ],
        "full": "Can you DISTINGUISH between right and wrong?",
        "jp": "善悪の区別がつきますか？",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " red from green?"
        ],
        "full": "Can you DISTINGUISH red from green?",
        "jp": "赤と緑を区別できますか。",
        "is_correct": true
      },
      {
        "parts": [
          "His work will ",
          " him from others."
        ],
        "full": "His work will DISTINGUISH him from others.",
        "jp": "彼の仕事は彼を他の人たちと区別するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 187,
    "word": "DISTRIBUTE",
    "meaning_core": "配布する",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "TRIB",
        "type": "strong"
      },
      {
        "text": "ute",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HAND OUT": "配る",
      "SPREAD": "広める",
      "ALLOCATE": "割り当てる"
    },
    "distractors": [
      "COLLECT",
      "GATHER",
      "KEEP",
      "WITHHOLD"
    ],
    "meanings_expanded": [
      "配布する",
      "分配する",
      "流通させる"
    ],
    "contexts": [
      {
        "parts": [
          "Volunteers will",
          "food to the homeless."
        ],
        "full": "Volunteers will DISTRIBUTE food to the homeless.",
        "jp": "ボランティアがホームレスに食料を配布する。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " the papers to everyone."
        ],
        "full": "Please DISTRIBUTE the papers to everyone.",
        "jp": "みんなにその書類を配ってください。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the wealth fairly."
        ],
        "full": "We need to DISTRIBUTE the wealth fairly.",
        "jp": "私たちは富を公平に分配する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 188,
    "word": "DISTURB",
    "meaning_core": "邪魔する",
    "syllables": [
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "TURB",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INTERRUPT": "中断させる",
      "BOTHER": "悩ませる",
      "UPSET": "動揺させる"
    },
    "distractors": [
      "CALM",
      "SOOTHE",
      "AID",
      "HELP"
    ],
    "meanings_expanded": [
      "邪魔する",
      "乱す",
      "不安にさせる"
    ],
    "contexts": [
      {
        "parts": [
          "Please do not",
          "him while he is working."
        ],
        "full": "Please do not DISTURB him while he is working.",
        "jp": "仕事中の彼の邪魔をしないでください。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " the sleeping baby."
        ],
        "full": "Do not DISTURB the sleeping baby.",
        "jp": "眠っている赤ちゃんを邪魔しないでください。",
        "is_correct": true
      },
      {
        "parts": [
          "The noise did not ",
          " me."
        ],
        "full": "The noise did not DISTURB me.",
        "jp": "その騒音は私を邪魔しなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 189,
    "word": "DOCILE",
    "meaning_core": "従順な",
    "syllables": [
      {
        "text": "DOC",
        "type": "strong"
      },
      {
        "text": "ile",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OBEDIENT": "従順な",
      "SUBMISSIVE": "服従的な",
      "TAME": "飼い慣らされた"
    },
    "distractors": [
      "AGGRESSIVE",
      "STUBBORN",
      "WILD",
      "REBELLIOUS"
    ],
    "meanings_expanded": [
      "従順な",
      "扱いやすい",
      "素直な"
    ],
    "contexts": [
      {
        "parts": [
          "The horse is very",
          "and easy to ride."
        ],
        "full": "The horse is very DOCILE and easy to ride.",
        "jp": "その馬はとても従順で乗りやすい。",
        "is_correct": true
      },
      {
        "parts": [
          "The horse was gentle and ",
          "."
        ],
        "full": "The horse was gentle and DOCILE.",
        "jp": "その馬は優しくて従順だった。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a quiet and ",
          " child."
        ],
        "full": "She is a quiet and DOCILE child.",
        "jp": "彼女は静かで従順な子供だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 190,
    "word": "DOWNFALL",
    "meaning_core": "没落",
    "syllables": [
      {
        "text": "DOWN",
        "type": "strong"
      },
      {
        "text": "fall",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RUIN": "破滅",
      "COLLAPSE": "崩壊",
      "DEFEAT": "敗北"
    },
    "distractors": [
      "SUCCESS",
      "RISE",
      "TRIUMPH",
      "VICTORY"
    ],
    "meanings_expanded": [
      "没落",
      "転落",
      "破滅の原因"
    ],
    "contexts": [
      {
        "parts": [
          "Greed was the cause of his",
          "."
        ],
        "full": "Greed was the cause of his DOWNFALL.",
        "jp": "強欲が彼の没落の原因だった。",
        "is_correct": true
      },
      {
        "parts": [
          "His arrogance caused his ",
          "."
        ],
        "full": "His arrogance caused his DOWNFALL.",
        "jp": "彼の傲慢さが彼の没落を引き起こした。",
        "is_correct": true
      },
      {
        "parts": [
          "The government's ",
          " was swift."
        ],
        "full": "The government's DOWNFALL was swift.",
        "jp": "政府の崩壊は速かった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 191,
    "word": "DOWNSIZE",
    "meaning_core": "小型化する",
    "syllables": [
      {
        "text": "DOWN",
        "type": "strong"
      },
      {
        "text": "size",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REDUCE": "減らす",
      "CUT": "削減する",
      "TRIM": "整理する"
    },
    "distractors": [
      "EXPAND",
      "GROW",
      "INCREASE",
      "ENLARGE"
    ],
    "meanings_expanded": [
      "（人員などを）削減する",
      "小型化する"
    ],
    "contexts": [
      {
        "parts": [
          "The company plans to",
          "its workforce."
        ],
        "full": "The company plans to DOWNSIZE its workforce.",
        "jp": "その会社は人員を削減する計画だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The company decided to ",
          "."
        ],
        "full": "The company decided to DOWNSIZE.",
        "jp": "その会社は規模を縮小することを決定した。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the car."
        ],
        "full": "We need to DOWNSIZE the car.",
        "jp": "私たちは車のサイズを小さくする必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 192,
    "word": "DRAMATIC",
    "meaning_core": "劇的な",
    "syllables": [
      {
        "text": "dra",
        "type": "weak"
      },
      {
        "text": "MAT",
        "type": "strong"
      },
      {
        "text": "ic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUDDEN": "突然の",
      "STRIKING": "印象的な",
      "THEATRICAL": "芝居がかった"
    },
    "distractors": [
      "BORING",
      "ORDINARY",
      "GRADUAL",
      "SUBTLE"
    ],
    "meanings_expanded": [
      "劇的な",
      "演劇の",
      "印象的な"
    ],
    "contexts": [
      {
        "parts": [
          "There was a",
          "change in the weather."
        ],
        "full": "There was a DRAMATIC change in the weather.",
        "jp": "天候に劇的な変化があった。",
        "is_correct": true
      },
      {
        "parts": [
          "There was a ",
          " change in policy."
        ],
        "full": "There was a DRAMATIC change in policy.",
        "jp": "政策に劇的な変更があった。",
        "is_correct": true
      },
      {
        "parts": [
          "He is prone to ",
          " gestures."
        ],
        "full": "He is prone to DRAMATIC gestures.",
        "jp": "彼は劇的なジェスチャーをしがちだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 193,
    "word": "DRASTIC",
    "meaning_core": "思い切った",
    "syllables": [
      {
        "text": "DRAS",
        "type": "strong"
      },
      {
        "text": "tic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXTREME": "極端な",
      "RADICAL": "抜本的な",
      "SEVERE": "厳しい"
    },
    "distractors": [
      "MILD",
      "MODERATE",
      "GENTLE",
      "SLIGHT"
    ],
    "meanings_expanded": [
      "思い切った",
      "徹底的な",
      "猛烈な"
    ],
    "contexts": [
      {
        "parts": [
          "We need to take",
          "measures."
        ],
        "full": "We need to take DRASTIC measures.",
        "jp": "我々は思い切った措置を講じる必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We must take ",
          " action now."
        ],
        "full": "We must take DRASTIC action now.",
        "jp": "今すぐ思い切った行動をとるべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The company implemented ",
          " cuts."
        ],
        "full": "The company implemented DRASTIC cuts.",
        "jp": "会社は思い切った削減を実施した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 194,
    "word": "DRASTICALLY",
    "meaning_core": "劇的に",
    "syllables": [
      {
        "text": "DRAS",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXTREMELY": "極端に",
      "SIGNIFICANTLY": "著しく",
      "RADICALLY": "根本的に"
    },
    "distractors": [
      "SLIGHTLY",
      "BARELY",
      "MODERATELY",
      "GENTLY"
    ],
    "meanings_expanded": [
      "劇的に",
      "徹底的に"
    ],
    "contexts": [
      {
        "parts": [
          "Prices have fallen",
          "."
        ],
        "full": "Prices have fallen DRASTICALLY.",
        "jp": "価格が劇的に下落した。",
        "is_correct": true
      },
      {
        "parts": [
          "The rules were changed ",
          "."
        ],
        "full": "The rules were changed DRASTICALLY.",
        "jp": "ルールは劇的に変更された。",
        "is_correct": true
      },
      {
        "parts": [
          "Sales have fallen ",
          "."
        ],
        "full": "Sales have fallen DRASTICALLY.",
        "jp": "売上が劇的に減少した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 195,
    "word": "DUBIOUS",
    "meaning_core": "疑わしい",
    "syllables": [
      {
        "text": "DU",
        "type": "strong"
      },
      {
        "text": "bi",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DOUBTFUL": "疑わしい",
      "SUSPICIOUS": "怪しい",
      "UNCERTAIN": "不確かな"
    },
    "distractors": [
      "CERTAIN",
      "SURE",
      "TRUSTWORTHY",
      "RELIABLE"
    ],
    "meanings_expanded": [
      "疑わしい",
      "怪しげな",
      "半信半疑の"
    ],
    "contexts": [
      {
        "parts": [
          "I am",
          "about his claims."
        ],
        "full": "I am DUBIOUS about his claims.",
        "jp": "私は彼の主張を疑わしく思っている。",
        "is_correct": true
      },
      {
        "parts": [
          "I have a ",
          " feeling about this."
        ],
        "full": "I have a DUBIOUS feeling about this.",
        "jp": "これについて疑わしい予感がする。",
        "is_correct": true
      },
      {
        "parts": [
          "His claims are highly ",
          "."
        ],
        "full": "His claims are highly DUBIOUS.",
        "jp": "彼の主張は非常に疑わしい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 196,
    "word": "DUE",
    "meaning_core": "支払期日の来た",
    "syllables": [
      {
        "text": "DUE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "OWED": "支払われるべき",
      "EXPECTED": "予定されている",
      "SCHEDULED": "予定の"
    },
    "distractors": [
      "PAID",
      "EARLY",
      "OPTIONAL",
      "FREE"
    ],
    "meanings_expanded": [
      "支払期日の来た",
      "到着予定で",
      "正当な"
    ],
    "contexts": [
      {
        "parts": [
          "The rent is",
          "tomorrow."
        ],
        "full": "The rent is DUE tomorrow.",
        "jp": "家賃は明日が支払期日だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The rent is ",
          " next week."
        ],
        "full": "The rent is DUE next week.",
        "jp": "家賃は来週が支払期日だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The delay was ",
          " to the storm."
        ],
        "full": "The delay was DUE to the storm.",
        "jp": "遅延は嵐が原因だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 198,
    "word": "DURING",
    "meaning_core": "～の間に",
    "syllables": [
      {
        "text": "DUR",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      }
    ],
    "synonyms": {
      "THROUGHOUT": "～の間中",
      "IN": "～の中に"
    },
    "distractors": [
      "BEFORE",
      "AFTER",
      "UNTIL",
      "SINCE"
    ],
    "meanings_expanded": [
      "～の間に",
      "～の間中"
    ],
    "contexts": [
      {
        "parts": [
          "I fell asleep",
          "the movie."
        ],
        "full": "I fell asleep DURING the movie.",
        "jp": "私は映画の間に眠ってしまった。",
        "is_correct": true
      },
      {
        "parts": [
          "She slept ",
          " the entire film."
        ],
        "full": "She slept DURING the entire film.",
        "jp": "彼女は映画全体の間眠っていた。",
        "is_correct": true
      },
      {
        "parts": [
          "We met ",
          " his stay in Tokyo."
        ],
        "full": "We met DURING his stay in Tokyo.",
        "jp": "私たちは彼が東京に滞在中に会った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 199,
    "word": "ECONOMY",
    "meaning_core": "経済",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "CON",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "my",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WEALTH": "富",
      "SYSTEM": "システム",
      "THRIFT": "節約"
    },
    "distractors": [
      "WASTE",
      "POVERTY",
      "CHAOS",
      "SPENDING"
    ],
    "meanings_expanded": [
      "経済",
      "景気",
      "節約"
    ],
    "contexts": [
      {
        "parts": [
          "The global",
          "is recovering."
        ],
        "full": "The global ECONOMY is recovering.",
        "jp": "世界経済は回復している。",
        "is_correct": true
      },
      {
        "parts": [
          "The nation's ",
          " is growing fast."
        ],
        "full": "The nation's ECONOMY is growing fast.",
        "jp": "その国の経済は急速に成長している。",
        "is_correct": true
      },
      {
        "parts": [
          "He prefers speed and ",
          "."
        ],
        "full": "He prefers speed and ECONOMY.",
        "jp": "彼はスピードと経済性を好む。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 200,
    "word": "EFFECTIVE",
    "meaning_core": "効果的な",
    "syllables": [
      {
        "text": "ef",
        "type": "weak"
      },
      {
        "text": "FEC",
        "type": "strong"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUCCESSFUL": "成功した",
      "POWERFUL": "強力な",
      "EFFICIENT": "効率的な"
    },
    "distractors": [
      "USELESS",
      "INEFFECTIVE",
      "WEAK",
      "POINTLESS"
    ],
    "meanings_expanded": [
      "効果的な",
      "有効な",
      "実際の"
    ],
    "contexts": [
      {
        "parts": [
          "This medicine is very",
          "."
        ],
        "full": "This medicine is very EFFECTIVE.",
        "jp": "この薬はとても効果的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is the most ",
          " method."
        ],
        "full": "This is the most EFFECTIVE method.",
        "jp": "これが最も効果的な方法だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The law becomes ",
          " tomorrow."
        ],
        "full": "The law becomes EFFECTIVE tomorrow.",
        "jp": "その法律は明日から有効になる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 201,
    "word": "EFFICIENT",
    "meaning_core": "効率的な",
    "syllables": [
      {
        "text": "ef",
        "type": "weak"
      },
      {
        "text": "FI",
        "type": "strong"
      },
      {
        "text": "cient",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EFFECTIVE": "効果的な",
      "PRODUCTIVE": "生産的な",
      "COMPETENT": "有能な"
    },
    "distractors": [
      "WASTEFUL",
      "INEFFICIENT",
      "SLOW",
      "LAZY"
    ],
    "meanings_expanded": [
      "効率的な",
      "有能な",
      "無駄のない"
    ],
    "contexts": [
      {
        "parts": [
          "This new engine is very",
          "."
        ],
        "full": "This new engine is very EFFICIENT.",
        "jp": "この新しいエンジンは非常に効率的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a more ",
          " process."
        ],
        "full": "We need a more EFFICIENT process.",
        "jp": "私たちにはより効率的なプロセスが必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a very ",
          " worker."
        ],
        "full": "She is a very EFFICIENT worker.",
        "jp": "彼女は非常に効率的な働き手だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 203,
    "word": "EJECT",
    "meaning_core": "外に出す",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "JECT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXPEL": "追放する",
      "THROW OUT": "投げ出す",
      "EMIT": "放出する"
    },
    "distractors": [
      "KEEP",
      "RETAIN",
      "ABSORB",
      "HOLD"
    ],
    "meanings_expanded": [
      "（ディスクなどを）取り出す",
      "噴出する",
      "脱出する"
    ],
    "contexts": [
      {
        "parts": [
          "Press the button to",
          "the CD."
        ],
        "full": "Press the button to EJECT the CD.",
        "jp": "ボタンを押してCDを取り出してください。",
        "is_correct": true
      },
      {
        "parts": [
          "Security guards will ",
          " the guest."
        ],
        "full": "Security guards will EJECT the guest.",
        "jp": "警備員がその客を追い出すだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Press this button to ",
          " the disk."
        ],
        "full": "Press this button to EJECT the disk.",
        "jp": "ディスクを取り出すにはこのボタンを押してください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 204,
    "word": "ELASTIC",
    "meaning_core": "弾力性の",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "LAS",
        "type": "strong"
      },
      {
        "text": "tic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FLEXIBLE": "柔軟な",
      "STRETCHY": "伸縮性のある",
      "RESILIENT": "弾力のある"
    },
    "distractors": [
      "RIGID",
      "STIFF",
      "HARD",
      "BRITTLE"
    ],
    "meanings_expanded": [
      "弾力性のある",
      "伸縮自在の",
      "融通の利く"
    ],
    "contexts": [
      {
        "parts": [
          "Rubber is an",
          "material."
        ],
        "full": "Rubber is an ELASTIC material.",
        "jp": "ゴムは弾力性のある素材だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The material is strong and ",
          "."
        ],
        "full": "The material is strong and ELASTIC.",
        "jp": "その素材は丈夫で弾力性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "This rope is highly ",
          "."
        ],
        "full": "This rope is highly ELASTIC.",
        "jp": "このロープは非常に伸縮性がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 205,
    "word": "ELECT",
    "meaning_core": "選出する",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "LECT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CHOOSE": "選ぶ",
      "VOTE": "投票する",
      "SELECT": "選択する"
    },
    "distractors": [
      "REJECT",
      "DISMISS",
      "IGNORE",
      "APPOINT"
    ],
    "meanings_expanded": [
      "選出する",
      "選挙する"
    ],
    "contexts": [
      {
        "parts": [
          "They voted to",
          "a new president."
        ],
        "full": "They voted to ELECT a new president.",
        "jp": "彼らは新しい大統領を選出するために投票した。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " a new leader soon."
        ],
        "full": "They will ELECT a new leader soon.",
        "jp": "彼らはすぐに新しいリーダーを選出するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " honest officials."
        ],
        "full": "We need to ELECT honest officials.",
        "jp": "私たちは正直な公務員を選出する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 206,
    "word": "ELIMINATE",
    "meaning_core": "排除する",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "LIM",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "nate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REMOVE": "取り除く",
      "GET RID OF": "処分する",
      "ERADICATE": "根絶する"
    },
    "distractors": [
      "ADD",
      "INCLUDE",
      "CREATE",
      "KEEP"
    ],
    "meanings_expanded": [
      "排除する",
      "削除する",
      "予選落ちさせる"
    ],
    "contexts": [
      {
        "parts": [
          "We must",
          "waste."
        ],
        "full": "We must ELIMINATE waste.",
        "jp": "私たちは無駄を排除しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " all possible errors."
        ],
        "full": "We must ELIMINATE all possible errors.",
        "jp": "私たちは考えられるすべての誤りを排除しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "This diet will ",
          " toxins."
        ],
        "full": "This diet will ELIMINATE toxins.",
        "jp": "この食事療法は毒素を排除するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 207,
    "word": "ELOQUENT",
    "meaning_core": "雄弁な",
    "syllables": [
      {
        "text": "EL",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "quent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ARTICULATE": "はっきりした",
      "EXPRESSIVE": "表現豊かな",
      "PERSUASIVE": "説得力のある"
    },
    "distractors": [
      "INARTICULATE",
      "SHY",
      "SILENT",
      "HESITANT"
    ],
    "meanings_expanded": [
      "雄弁な",
      "説得力のある"
    ],
    "contexts": [
      {
        "parts": [
          "He gave an",
          "speech."
        ],
        "full": "He gave an ELOQUENT speech.",
        "jp": "彼は雄弁なスピーチをした。",
        "is_correct": true
      },
      {
        "parts": [
          "She gave an ",
          " speech."
        ],
        "full": "She gave an ELOQUENT speech.",
        "jp": "彼女は雄弁な演説をした。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an ",
          " speaker."
        ],
        "full": "He is an ELOQUENT speaker.",
        "jp": "彼は雄弁な話し手だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 208,
    "word": "ELOQUENTLY",
    "meaning_core": "雄弁に",
    "syllables": [
      {
        "text": "EL",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "quent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FLUENTLY": "流暢に",
      "EXPRESSIVELY": "表情豊かに",
      "PERSUASIVELY": "説得力を持って"
    },
    "distractors": [
      "POORLY",
      "BADLY",
      "SILENTLY",
      "WEAKLY"
    ],
    "meanings_expanded": [
      "雄弁に",
      "感動的に"
    ],
    "contexts": [
      {
        "parts": [
          "She spoke",
          "about human rights."
        ],
        "full": "She spoke ELOQUENTLY about human rights.",
        "jp": "彼女は人権について雄弁に語った。",
        "is_correct": true
      },
      {
        "parts": [
          "He spoke very ",
          " about his plans."
        ],
        "full": "He spoke very ELOQUENTLY about his plans.",
        "jp": "彼は自分の計画について非常に雄弁に話した。",
        "is_correct": true
      },
      {
        "parts": [
          "She argued her point ",
          "."
        ],
        "full": "She argued her point ELOQUENTLY.",
        "jp": "彼女は自分の論点を雄弁に主張した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 209,
    "word": "EMBODY",
    "meaning_core": "体現する",
    "syllables": [
      {
        "text": "em",
        "type": "weak"
      },
      {
        "text": "BOD",
        "type": "strong"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REPRESENT": "代表する",
      "PERSONIFY": "擬人化する",
      "EXEMPLIFY": "実証する"
    },
    "distractors": [
      "HIDE",
      "CONCEAL",
      "DENY",
      "REJECT"
    ],
    "meanings_expanded": [
      "体現する",
      "具現化する",
      "具体的に表現する"
    ],
    "contexts": [
      {
        "parts": [
          "She seems to",
          "kindness."
        ],
        "full": "She seems to EMBODY kindness.",
        "jp": "彼女は親切心を体現しているようだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The structure will ",
          " modern design."
        ],
        "full": "The structure will EMBODY modern design.",
        "jp": "その構造はモダンデザインを体現するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "This act ",
          " his true feelings."
        ],
        "full": "This act EMBODY his true feelings.",
        "jp": "この行為は彼の本当の気持ちを具現化している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 210,
    "word": "EMERGE",
    "meaning_core": "現れる",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "MERGE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "APPEAR": "現れる",
      "ARISE": "生じる",
      "SURFACE": "浮上する"
    },
    "distractors": [
      "DISAPPEAR",
      "VANISH",
      "FADE",
      "HIDE"
    ],
    "meanings_expanded": [
      "現れる",
      "出現する",
      "明らかになる"
    ],
    "contexts": [
      {
        "parts": [
          "The sun began to",
          "from the clouds."
        ],
        "full": "The sun began to EMERGE from the clouds.",
        "jp": "太陽が雲から現れ始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "The sun will ",
          " from the clouds."
        ],
        "full": "The sun will EMERGE from the clouds.",
        "jp": "太陽が雲間から現れるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "New facts have begun to ",
          "."
        ],
        "full": "New facts have begun to EMERGE.",
        "jp": "新しい事実が現れ始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 211,
    "word": "EMOTION",
    "meaning_core": "感情",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "MO",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FEELING": "感情",
      "SENTIMENT": "情緒",
      "PASSION": "情熱"
    },
    "distractors": [
      "LOGIC",
      "REASON",
      "THOUGHT",
      "FACT"
    ],
    "meanings_expanded": [
      "感情",
      "情緒",
      "感動"
    ],
    "contexts": [
      {
        "parts": [
          "He showed no",
          "on his face."
        ],
        "full": "He showed no EMOTION on his face.",
        "jp": "彼は顔に感情を表さなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "She showed little ",
          "."
        ],
        "full": "She showed little EMOTION.",
        "jp": "彼女はほとんど感情を見せなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Anger is a strong ",
          "."
        ],
        "full": "Anger is a strong EMOTION.",
        "jp": "怒りは強い感情だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 212,
    "word": "EMPATHETIC",
    "meaning_core": "共感的な",
    "syllables": [
      {
        "text": "em",
        "type": "weak"
      },
      {
        "text": "pa",
        "type": "weak"
      },
      {
        "text": "THET",
        "type": "strong"
      },
      {
        "text": "ic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPASSIONATE": "思いやりのある",
      "UNDERSTANDING": "理解ある",
      "SYMPATHETIC": "同情的な"
    },
    "distractors": [
      "COLD",
      "INDIFFERENT",
      "CRUEL",
      "UNCARING"
    ],
    "meanings_expanded": [
      "共感的な",
      "親身な"
    ],
    "contexts": [
      {
        "parts": [
          "She is very",
          "towards others."
        ],
        "full": "She is very EMPATHETIC towards others.",
        "jp": "彼女は他人に対してとても共感的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "A nurse should be ",
          "."
        ],
        "full": "A nurse should be EMPATHETIC.",
        "jp": "看護師は共感的であるべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave an ",
          " response."
        ],
        "full": "He gave an EMPATHETIC response.",
        "jp": "彼は共感的な反応を示した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 213,
    "word": "EMPHASIZE",
    "meaning_core": "強調する",
    "syllables": [
      {
        "text": "EM",
        "type": "strong"
      },
      {
        "text": "pha",
        "type": "weak"
      },
      {
        "text": "size",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STRESS": "強調する",
      "HIGHLIGHT": "目立たせる",
      "ACCENTUATE": "際立たせる"
    },
    "distractors": [
      "IGNORE",
      "DOWNPLAY",
      "NEGLECT",
      "HIDE"
    ],
    "meanings_expanded": [
      "強調する",
      "重視する"
    ],
    "contexts": [
      {
        "parts": [
          "I want to",
          "the importance of this rule."
        ],
        "full": "I want to EMPHASIZE the importance of this rule.",
        "jp": "私はこのルールの重要性を強調したい。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the importance of safety."
        ],
        "full": "We must EMPHASIZE the importance of safety.",
        "jp": "私たちは安全の重要性を強調しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The report needs to ",
          " profits."
        ],
        "full": "The report needs to EMPHASIZE profits.",
        "jp": "報告書は利益を強調する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 214,
    "word": "EMPHATICALLY",
    "meaning_core": "断固として",
    "syllables": [
      {
        "text": "em",
        "type": "weak"
      },
      {
        "text": "PHAT",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STRONGLY": "強く",
      "FIRMLY": "断固として",
      "CATEGORICALLY": "絶対的に"
    },
    "distractors": [
      "WEAKLY",
      "HESITANTLY",
      "UNCERTAINLY",
      "QUIETLY"
    ],
    "meanings_expanded": [
      "断固として",
      "力強く",
      "強調して"
    ],
    "contexts": [
      {
        "parts": [
          "He",
          "denied the accusations."
        ],
        "full": "He EMPHATICALLY denied the accusations.",
        "jp": "彼はその告発を断固として否定した。",
        "is_correct": true
      },
      {
        "parts": [
          "He stated his opinion ",
          "."
        ],
        "full": "He stated his opinion EMPHATICALLY.",
        "jp": "彼は自分の意見を断固として述べた。",
        "is_correct": true
      },
      {
        "parts": [
          "She denied the charge ",
          "."
        ],
        "full": "She denied the charge EMPHATICALLY.",
        "jp": "彼女はその告発を断固として否定した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 215,
    "word": "ENCOUNTER",
    "meaning_core": "遭遇する",
    "syllables": [
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "COUN",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MEET": "会う",
      "FACE": "直面する",
      "COME ACROSS": "出くわす"
    },
    "distractors": [
      "AVOID",
      "MISS",
      "ESCAPE",
      "EVADE"
    ],
    "meanings_expanded": [
      "遭遇する",
      "出くわす",
      "直面する"
    ],
    "contexts": [
      {
        "parts": [
          "We might",
          "problems along the way."
        ],
        "full": "We might ENCOUNTER problems along the way.",
        "jp": "途中で問題に遭遇するかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "I had an unusual ",
          " today."
        ],
        "full": "I had an unusual ENCOUNTER today.",
        "jp": "私は今日珍しい遭遇をした。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " strong opposition."
        ],
        "full": "We will ENCOUNTER strong opposition.",
        "jp": "私たちは強い反対に直面するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 216,
    "word": "ENDORSEMENT",
    "meaning_core": "支持",
    "syllables": [
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "DORSE",
        "type": "strong"
      },
      {
        "text": "ment",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUPPORT": "支持",
      "APPROVAL": "承認",
      "BACKING": "後援"
    },
    "distractors": [
      "OPPOSITION",
      "REJECTION",
      "DISAPPROVAL",
      "CRITICISM"
    ],
    "meanings_expanded": [
      "支持",
      "承認",
      "推奨"
    ],
    "contexts": [
      {
        "parts": [
          "The candidate received the",
          "of the mayor."
        ],
        "full": "The candidate received the ENDORSEMENT of the mayor.",
        "jp": "その候補者は市長の支持を受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "The product received a celebrity ",
          "."
        ],
        "full": "The product received a celebrity ENDORSEMENT.",
        "jp": "その製品は有名人の支持を受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "I need your ",
          " on this form."
        ],
        "full": "I need your ENDORSEMENT on this form.",
        "jp": "このフォームにあなたの承認が必要です。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 217,
    "word": "ENERGY",
    "meaning_core": "エネルギー",
    "syllables": [
      {
        "text": "EN",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "gy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POWER": "力",
      "VITALITY": "活力",
      "STRENGTH": "強さ"
    },
    "distractors": [
      "LETHARGY",
      "WEAKNESS",
      "FATIGUE",
      "TIREDNESS"
    ],
    "meanings_expanded": [
      "エネルギー",
      "活力",
      "精力"
    ],
    "contexts": [
      {
        "parts": [
          "Solar power is a renewable",
          "source."
        ],
        "full": "Solar power is a renewable ENERGY source.",
        "jp": "太陽光は再生可能エネルギー源だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We conserve solar ",
          "."
        ],
        "full": "We conserve solar ENERGY.",
        "jp": "私たちは太陽エネルギーを節約する。",
        "is_correct": true
      },
      {
        "parts": [
          "She put a lot of ",
          " into the work."
        ],
        "full": "She put a lot of ENERGY into the work.",
        "jp": "彼女はその仕事に多くの活力を注いだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 218,
    "word": "ENHANCE",
    "meaning_core": "高める",
    "syllables": [
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "HANCE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "IMPROVE": "改善する",
      "BOOST": "高める",
      "INCREASE": "増やす"
    },
    "distractors": [
      "DECREASE",
      "DIMINISH",
      "WORSEN",
      "REDUCE"
    ],
    "meanings_expanded": [
      "高める",
      "強化する",
      "増す"
    ],
    "contexts": [
      {
        "parts": [
          "This sauce will",
          "the flavor of the meat."
        ],
        "full": "This sauce will ENHANCE the flavor of the meat.",
        "jp": "このソースは肉の風味を引き立てる（高める）だろう。",
        "is_correct": true
      },
      {
        "parts": [
          "This will ",
          " the flavor."
        ],
        "full": "This will ENHANCE the flavor.",
        "jp": "これは風味を高めるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " security measures."
        ],
        "full": "We must ENHANCE security measures.",
        "jp": "私たちは安全対策を強化しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 219,
    "word": "ENLIGHTENED",
    "meaning_core": "啓発された",
    "syllables": [
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "LIGHT",
        "type": "strong"
      },
      {
        "text": "ened",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INFORMED": "知識のある",
      "EDUCATED": "教養のある",
      "AWARE": "認識している"
    },
    "distractors": [
      "IGNORANT",
      "CONFUSED",
      "DARK",
      "UNAWARE"
    ],
    "meanings_expanded": [
      "啓発された",
      "進歩的な",
      "見識のある"
    ],
    "contexts": [
      {
        "parts": [
          "He has an",
          "view of education."
        ],
        "full": "He has an ENLIGHTENED view of education.",
        "jp": "彼は教育に関して進歩的な考えを持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "She has an ",
          " viewpoint."
        ],
        "full": "She has an ENLIGHTENED viewpoint.",
        "jp": "彼女は啓発された見解を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "We seek an ",
          " solution."
        ],
        "full": "We seek an ENLIGHTENED solution.",
        "jp": "私たちは啓発された解決策を求めている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 220,
    "word": "ENORMOUS",
    "meaning_core": "巨大な",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "NOR",
        "type": "strong"
      },
      {
        "text": "mous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HUGE": "巨大な",
      "MASSIVE": "大規模な",
      "VAST": "広大な"
    },
    "distractors": [
      "TINY",
      "SMALL",
      "LITTLE",
      "MINUTE"
    ],
    "meanings_expanded": [
      "巨大な",
      "莫大な"
    ],
    "contexts": [
      {
        "parts": [
          "The project requires an",
          "amount of money."
        ],
        "full": "The project requires an ENORMOUS amount of money.",
        "jp": "そのプロジェクトには莫大な資金が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The company made an ",
          " profit."
        ],
        "full": "The company made an ENORMOUS profit.",
        "jp": "会社は莫大な利益を上げた。",
        "is_correct": true
      },
      {
        "parts": [
          "We saw an ",
          " crowd."
        ],
        "full": "We saw an ENORMOUS crowd.",
        "jp": "私たちは巨大な群衆を見た。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 221,
    "word": "ENROLL",
    "meaning_core": "入学する",
    "syllables": [
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "ROLL",
        "type": "strong"
      }
    ],
    "synonyms": {
      "REGISTER": "登録する",
      "JOIN": "参加する",
      "SIGN UP": "申し込む"
    },
    "distractors": [
      "QUIT",
      "LEAVE",
      "DROP OUT",
      "WITHDRAW"
    ],
    "meanings_expanded": [
      "入学する",
      "登録する",
      "入会する"
    ],
    "contexts": [
      {
        "parts": [
          "I decided to",
          "in the art course."
        ],
        "full": "I decided to ENROLL in the art course.",
        "jp": "私はアートコースに登録することに決めた。",
        "is_correct": true
      },
      {
        "parts": [
          "I plan to ",
          " in college."
        ],
        "full": "I plan to ENROLL in college.",
        "jp": "私は大学に入学するつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "You can ",
          " online today."
        ],
        "full": "You can ENROLL online today.",
        "jp": "今日オンラインで登録できます。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 222,
    "word": "ENTANGLE",
    "meaning_core": "絡まる",
    "syllables": [
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "TAN",
        "type": "strong"
      },
      {
        "text": "gle",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TWIST": "ねじる",
      "TRAP": "罠にかける",
      "INVOLVE": "巻き込む"
    },
    "distractors": [
      "UNTANGLE",
      "FREE",
      "RELEASE",
      "SEPARATE"
    ],
    "meanings_expanded": [
      "～に絡まる",
      "巻き込む"
    ],
    "contexts": [
      {
        "parts": [
          "The dolphin became",
          "in the net."
        ],
        "full": "The dolphin became entangled in the net.",
        "jp": "イルカは網に絡まってしまった。",
        "is_correct": true
      },
      {
        "parts": [
          "The rope began to ",
          " the boat."
        ],
        "full": "The rope began to ENTANGLE the boat.",
        "jp": "ロープがボートに絡まり始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't ",
          " yourself in their conflict."
        ],
        "full": "Don't ENTANGLE yourself in their conflict.",
        "jp": "彼らの対立に巻き込まれないで。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 223,
    "word": "ENTERPRISE",
    "meaning_core": "事業",
    "syllables": [
      {
        "text": "EN",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      },
      {
        "text": "prise",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BUSINESS": "ビジネス",
      "VENTURE": "ベンチャー",
      "COMPANY": "会社"
    },
    "distractors": [
      "IDLENESS",
      "INACTIVITY",
      "SAFETY",
      "CAUTION"
    ],
    "meanings_expanded": [
      "事業",
      "企業",
      "冒険心"
    ],
    "contexts": [
      {
        "parts": [
          "This is a risky",
          "."
        ],
        "full": "This is a risky ENTERPRISE.",
        "jp": "これはリスクのある事業だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He started a new business ",
          "."
        ],
        "full": "He started a new business ENTERPRISE.",
        "jp": "彼は新しい事業を始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a government ",
          "."
        ],
        "full": "This is a government ENTERPRISE.",
        "jp": "これは政府の事業だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 224,
    "word": "EQUITY",
    "meaning_core": "公平",
    "syllables": [
      {
        "text": "EQ",
        "type": "strong"
      },
      {
        "text": "ui",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FAIRNESS": "公正",
      "JUSTICE": "正義",
      "IMPARTIALITY": "公平無私"
    },
    "distractors": [
      "BIAS",
      "UNFAIRNESS",
      "INJUSTICE",
      "PARTIALITY"
    ],
    "meanings_expanded": [
      "公平",
      "公正",
      "（株主）資本"
    ],
    "contexts": [
      {
        "parts": [
          "We must ensure",
          "in education."
        ],
        "full": "We must ensure EQUITY in education.",
        "jp": "教育における公平性を確保しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We strive for social ",
          "."
        ],
        "full": "We strive for social EQUITY.",
        "jp": "私たちは社会の公平を目指す。",
        "is_correct": true
      },
      {
        "parts": [
          "The judge ruled with ",
          "."
        ],
        "full": "The judge ruled with EQUITY.",
        "jp": "裁判官は公平に基づいて裁決した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 225,
    "word": "ERRONEOUSLY",
    "meaning_core": "誤って",
    "syllables": [
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "RO",
        "type": "strong"
      },
      {
        "text": "ne",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WRONGLY": "間違って",
      "INCORRECTLY": "不正確に",
      "MISTAKENLY": "誤って"
    },
    "distractors": [
      "CORRECTLY",
      "RIGHTLY",
      "ACCURATELY",
      "TRULY"
    ],
    "meanings_expanded": [
      "誤って",
      "間違って"
    ],
    "contexts": [
      {
        "parts": [
          "The letter was",
          "delivered."
        ],
        "full": "The letter was ERRONEOUSLY delivered.",
        "jp": "その手紙は誤って配達された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 226,
    "word": "ESTABLISH",
    "meaning_core": "設立する",
    "syllables": [
      {
        "text": "es",
        "type": "weak"
      },
      {
        "text": "TAB",
        "type": "strong"
      },
      {
        "text": "lish",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FOUND": "創設する",
      "SET UP": "立ち上げる",
      "CREATE": "作る"
    },
    "distractors": [
      "DESTROY",
      "ABOLISH",
      "RUIN",
      "CLOSE"
    ],
    "meanings_expanded": [
      "設立する",
      "確立する",
      "立証する"
    ],
    "contexts": [
      {
        "parts": [
          "They plan to",
          "a new branch."
        ],
        "full": "They plan to ESTABLISH a new branch.",
        "jp": "彼らは新しい支店を設立する計画だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " a new office."
        ],
        "full": "We need to ESTABLISH a new office.",
        "jp": "私たちは新しい事務所を設立する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Scientists will ",
          " the cause."
        ],
        "full": "Scientists will ESTABLISH the cause.",
        "jp": "科学者たちが原因を究明するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 227,
    "word": "ESTIMATE",
    "meaning_core": "見積もる",
    "syllables": [
      {
        "text": "ES",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "mate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CALCULATE": "計算する",
      "GUESS": "推測する",
      "ASSESS": "評価する"
    },
    "distractors": [
      "MEASURE",
      "KNOW",
      "PROVE",
      "VERIFY"
    ],
    "meanings_expanded": [
      "見積もる",
      "推定する",
      "見積もり"
    ],
    "contexts": [
      {
        "parts": [
          "Can you",
          "the cost?"
        ],
        "full": "Can you ESTIMATE the cost?",
        "jp": "費用を見積もれますか？",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " the total cost?"
        ],
        "full": "Can you ESTIMATE the total cost?",
        "jp": "総費用を見積もることができますか。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a rough ",
          "."
        ],
        "full": "This is a rough ESTIMATE.",
        "jp": "これは概算の見積もりだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 228,
    "word": "ETHNIC",
    "meaning_core": "民族の",
    "syllables": [
      {
        "text": "ETH",
        "type": "strong"
      },
      {
        "text": "nic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CULTURAL": "文化の",
      "RACIAL": "人種の",
      "TRIBAL": "部族の"
    },
    "distractors": [
      "GLOBAL",
      "UNIVERSAL",
      "INTERNATIONAL",
      "MODERN"
    ],
    "meanings_expanded": [
      "民族の",
      "人種の"
    ],
    "contexts": [
      {
        "parts": [
          "We enjoy",
          "food."
        ],
        "full": "We enjoy ETHNIC food.",
        "jp": "私たちはエスニック料理（民族料理）を楽しむ。",
        "is_correct": true
      },
      {
        "parts": [
          "The city has great ",
          " diversity."
        ],
        "full": "The city has great ETHNIC diversity.",
        "jp": "その都市には大きな民族の多様性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They discussed ",
          " conflicts."
        ],
        "full": "They discussed ETHNIC conflicts.",
        "jp": "彼らは民族紛争について議論した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 229,
    "word": "EVACUATE",
    "meaning_core": "避難する",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "VAC",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LEAVE": "去る",
      "ESCAPE": "逃げる",
      "ABANDON": "捨てる"
    },
    "distractors": [
      "ENTER",
      "STAY",
      "REMAIN",
      "OCCUPY"
    ],
    "meanings_expanded": [
      "避難する",
      "立ち退く"
    ],
    "contexts": [
      {
        "parts": [
          "Residents were told to",
          "the area."
        ],
        "full": "Residents were told to EVACUATE the area.",
        "jp": "住民はその地域から避難するように言われた。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the building now."
        ],
        "full": "We must EVACUATE the building now.",
        "jp": "私たちは今すぐ建物を避難させなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "Firefighters helped to ",
          " the area."
        ],
        "full": "Firefighters helped to EVACUATE the area.",
        "jp": "消防士は地域の避難を手伝った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 230,
    "word": "EVALUATE",
    "meaning_core": "評価する",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "VAL",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ASSESS": "査定する",
      "JUDGE": "判断する",
      "RATE": "格付けする"
    },
    "distractors": [
      "GUESS",
      "IGNORE",
      "NEGLECT",
      "OVERLOOK"
    ],
    "meanings_expanded": [
      "評価する",
      "査定する"
    ],
    "contexts": [
      {
        "parts": [
          "Teachers",
          "student performance."
        ],
        "full": "Teachers EVALUATE student performance.",
        "jp": "教師は生徒の成績を評価する。",
        "is_correct": true
      },
      {
        "parts": [
          "The manager will ",
          " his work."
        ],
        "full": "The manager will EVALUATE his work.",
        "jp": "マネージャーが彼の仕事を評価するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the risks involved."
        ],
        "full": "We need to EVALUATE the risks involved.",
        "jp": "私たちは関わるリスクを評価する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 231,
    "word": "EVAPORATE",
    "meaning_core": "蒸発する",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "VAP",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "rate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VAPORIZE": "気化する",
      "DRY UP": "干上がる",
      "VANISH": "消える"
    },
    "distractors": [
      "FREEZE",
      "SOLIDIFY",
      "CONDENSE",
      "LIQUEFY"
    ],
    "meanings_expanded": [
      "蒸発する",
      "消滅する"
    ],
    "contexts": [
      {
        "parts": [
          "Water will",
          "in the sun."
        ],
        "full": "Water will EVAPORATE in the sun.",
        "jp": "水は太陽の下で蒸発するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The water will quickly ",
          " in the heat."
        ],
        "full": "The water will quickly EVAPORATE in the heat.",
        "jp": "熱で水はすぐに蒸発するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Our hope began to ",
          "."
        ],
        "full": "Our hope began to EVAPORATE.",
        "jp": "私たちの希望は消え始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 232,
    "word": "EVASION",
    "meaning_core": "回避",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "VA",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AVOIDANCE": "忌避",
      "DODGING": "かわすこと",
      "ESCAPE": "逃亡"
    },
    "distractors": [
      "CONFRONTATION",
      "MEETING",
      "FACING",
      "HONESTY"
    ],
    "meanings_expanded": [
      "回避",
      "脱税"
    ],
    "contexts": [
      {
        "parts": [
          "He was charged with tax",
          "."
        ],
        "full": "He was charged with tax EVASION.",
        "jp": "彼は脱税で告発された。",
        "is_correct": true
      },
      {
        "parts": [
          "Tax ",
          " is a serious crime."
        ],
        "full": "Tax EVASION is a serious crime.",
        "jp": "脱税は重大な犯罪だ。",
        "is_correct": true
      },
      {
        "parts": [
          "His answer was mere ",
          "."
        ],
        "full": "His answer was mere EVASION.",
        "jp": "彼の答えは単なる回避だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 235,
    "word": "EVENTUALLY",
    "meaning_core": "最終的に",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "VEN",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FINALLY": "ついに",
      "ULTIMATELY": "結局",
      "IN THE END": "最後には"
    },
    "distractors": [
      "INITIALLY",
      "FIRST",
      "NEVER",
      "IMMEDIATELY"
    ],
    "meanings_expanded": [
      "最終的に",
      "結局は"
    ],
    "contexts": [
      {
        "parts": [
          "He",
          "became a doctor."
        ],
        "full": "He EVENTUALLY became a doctor.",
        "jp": "彼は最終的に医者になった。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " find a solution."
        ],
        "full": "We will EVENTUALLY find a solution.",
        "jp": "私たちは最終的に解決策を見つけるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "She ",
          " confessed the truth."
        ],
        "full": "She EVENTUALLY confessed the truth.",
        "jp": "彼女は最終的に真実を告白した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 236,
    "word": "EVIDENT",
    "meaning_core": "明白な",
    "syllables": [
      {
        "text": "EV",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "dent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OBVIOUS": "明らかな",
      "CLEAR": "明確な",
      "APPARENT": "明白な"
    },
    "distractors": [
      "UNCLEAR",
      "OBSCURE",
      "HIDDEN",
      "VAGUE"
    ],
    "meanings_expanded": [
      "明白な",
      "明らかな"
    ],
    "contexts": [
      {
        "parts": [
          "It was",
          "that she was unhappy."
        ],
        "full": "It was EVIDENT that she was unhappy.",
        "jp": "彼女が不幸であることは明白だった。",
        "is_correct": true
      },
      {
        "parts": [
          "It was ",
          " that he lied."
        ],
        "full": "It was EVIDENT that he lied.",
        "jp": "彼が嘘をついたのは明白だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The strain on his face was ",
          "."
        ],
        "full": "The strain on his face was EVIDENT.",
        "jp": "彼の顔の緊張は明らかだった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 237,
    "word": "EVIDENTLY",
    "meaning_core": "明らかに",
    "syllables": [
      {
        "text": "EV",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "dent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OBVIOUSLY": "明らかに",
      "CLEARLY": "はっきりと",
      "APPARENTLY": "見たところ"
    },
    "distractors": [
      "DOUBTFULLY",
      "UNCERTAINLY",
      "VAGUELY",
      "SECRETLY"
    ],
    "meanings_expanded": [
      "明らかに",
      "見たところ"
    ],
    "contexts": [
      {
        "parts": [
          "He is",
          "upset about the news."
        ],
        "full": "He is EVIDENTLY upset about the news.",
        "jp": "彼はそのニュースに明らかに動揺している。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          ", he is not interested."
        ],
        "full": "EVIDENTLY, he is not interested.",
        "jp": "明らかに、彼は興味がない。",
        "is_correct": true
      },
      {
        "parts": [
          "The plan was ",
          ", a failure."
        ],
        "full": "The plan was EVIDENTLY, a failure.",
        "jp": "その計画は明らかに失敗だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 238,
    "word": "EVOLUTION",
    "meaning_core": "進化",
    "syllables": [
      {
        "text": "ev",
        "type": "weak"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "LU",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEVELOPMENT": "発展",
      "PROGRESS": "進歩",
      "GROWTH": "成長"
    },
    "distractors": [
      "REGRESSION",
      "DECLINE",
      "STAGNATION",
      "STOP"
    ],
    "meanings_expanded": [
      "進化",
      "発展",
      "展開"
    ],
    "contexts": [
      {
        "parts": [
          "Darwin studied the",
          "of species."
        ],
        "full": "Darwin studied the EVOLUTION of species.",
        "jp": "ダーウィンは種の進化を研究した。",
        "is_correct": true
      },
      {
        "parts": [
          "We studied the theory of ",
          "."
        ],
        "full": "We studied the theory of EVOLUTION.",
        "jp": "私たちは進化論を研究した。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " of the internet is fast."
        ],
        "full": "The EVOLUTION of the internet is fast.",
        "jp": "インターネットの進化は速い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 239,
    "word": "EVOLVE",
    "meaning_core": "進化する",
    "syllables": [
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "VOLVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DEVELOP": "発展する",
      "ADVANCE": "進歩する",
      "CHANGE": "変化する"
    },
    "distractors": [
      "REGRESS",
      "REMAIN",
      "STAY",
      "STOP"
    ],
    "meanings_expanded": [
      "進化する",
      "発展する"
    ],
    "contexts": [
      {
        "parts": [
          "Animals must",
          "to survive."
        ],
        "full": "Animals must EVOLVE to survive.",
        "jp": "動物は生き残るために進化しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "Birds ",
          " from dinosaurs."
        ],
        "full": "Birds EVOLVE from dinosaurs.",
        "jp": "鳥は恐竜から進化した。",
        "is_correct": true
      },
      {
        "parts": [
          "The process will continue to ",
          "."
        ],
        "full": "The process will continue to EVOLVE.",
        "jp": "そのプロセスは進化し続けるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 240,
    "word": "EXAGGERATE",
    "meaning_core": "誇張する",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "AG",
        "type": "strong"
      },
      {
        "text": "ger",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OVERSTATE": "大げさに言う",
      "MAGNIFY": "拡大する",
      "EMBELLISH": "脚色する"
    },
    "distractors": [
      "UNDERSTATE",
      "MINIMIZE",
      "IGNORE",
      "HIDE"
    ],
    "meanings_expanded": [
      "誇張する",
      "大げさに言う"
    ],
    "contexts": [
      {
        "parts": [
          "Don't",
          "the size of the fish."
        ],
        "full": "Don't EXAGGERATE the size of the fish.",
        "jp": "魚の大きさを誇張してはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "Try not to ",
          " the dangers."
        ],
        "full": "Try not to EXAGGERATE the dangers.",
        "jp": "危険を誇張しないようにしなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "He tends to ",
          " his success."
        ],
        "full": "He tends to EXAGGERATE his success.",
        "jp": "彼は自分の成功を誇張しがちだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 241,
    "word": "EXCEED",
    "meaning_core": "上回る",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "CEED",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SURPASS": "超える",
      "OUTDO": "勝る",
      "GO BEYOND": "越える"
    },
    "distractors": [
      "FAIL",
      "FALL BEHIND",
      "LOSE",
      "TRAIL"
    ],
    "meanings_expanded": [
      "上回る",
      "超える",
      "（限度を）越える"
    ],
    "contexts": [
      {
        "parts": [
          "The cost should not",
          "the budget."
        ],
        "full": "The cost should not EXCEED the budget.",
        "jp": "費用は予算を超えてはならない。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " the speed limit."
        ],
        "full": "Do not EXCEED the speed limit.",
        "jp": "制限速度を超過してはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "Her performance will ",
          " expectations."
        ],
        "full": "Her performance will EXCEED expectations.",
        "jp": "彼女の業績は期待を上回るだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 242,
    "word": "EXCEPT",
    "meaning_core": "～を除いて",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "CEPT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXCLUDING": "除いて",
      "BUT": "～以外",
      "APART FROM": "～は別として"
    },
    "distractors": [
      "INCLUDING",
      "PLUS",
      "WITH",
      "AND"
    ],
    "meanings_expanded": [
      "～を除いて",
      "～以外は"
    ],
    "contexts": [
      {
        "parts": [
          "Everyone went",
          "John."
        ],
        "full": "Everyone went EXCEPT John.",
        "jp": "ジョン以外はみんな行った。",
        "is_correct": true
      },
      {
        "parts": [
          "Everyone was present ",
          " John."
        ],
        "full": "Everyone was present EXCEPT John.",
        "jp": "ジョンを除いて全員が出席していた。",
        "is_correct": true
      },
      {
        "parts": [
          "We work every day ",
          " Sunday."
        ],
        "full": "We work every day EXCEPT Sunday.",
        "jp": "私たちは日曜日を除いて毎日働く。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 243,
    "word": "EXCESSIVE",
    "meaning_core": "過度の",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "CES",
        "type": "strong"
      },
      {
        "text": "sive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXTREME": "極端な",
      "IMMODERATE": "節度のない",
      "TOO MUCH": "多すぎる"
    },
    "distractors": [
      "MODERATE",
      "INSUFFICIENT",
      "LITTLE",
      "REASONABLE"
    ],
    "meanings_expanded": [
      "過度の",
      "過剰な",
      "法外な"
    ],
    "contexts": [
      {
        "parts": [
          "Avoid",
          "drinking."
        ],
        "full": "Avoid EXCESSIVE drinking.",
        "jp": "過度の飲酒は避けなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Avoid ",
          " use of salt."
        ],
        "full": "Avoid EXCESSIVE use of salt.",
        "jp": "過度の塩の使用は避けなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "He charges ",
          " fees."
        ],
        "full": "He charges EXCESSIVE fees.",
        "jp": "彼は法外な料金を請求する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 244,
    "word": "EXHAUSTION",
    "meaning_core": "過度の疲労",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "HAUS",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FATIGUE": "疲労",
      "TIREDNESS": "疲れ",
      "WEARINESS": "倦怠"
    },
    "distractors": [
      "ENERGY",
      "VIGOR",
      "STRENGTH",
      "LIVELINESS"
    ],
    "meanings_expanded": [
      "極度の疲労",
      "消耗",
      "枯渇"
    ],
    "contexts": [
      {
        "parts": [
          "He collapsed from",
          "."
        ],
        "full": "He collapsed from EXHAUSTION.",
        "jp": "彼は過労で倒れた。",
        "is_correct": true
      },
      {
        "parts": [
          "She suffered from mental ",
          "."
        ],
        "full": "She suffered from mental EXHAUSTION.",
        "jp": "彼女は精神的な疲労に苦しんだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The hikers collapsed from ",
          "."
        ],
        "full": "The hikers collapsed from EXHAUSTION.",
        "jp": "ハイカーたちは極度の疲労で倒れた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 245,
    "word": "EXPAND",
    "meaning_core": "拡大する",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "PAND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ENLARGE": "大きくする",
      "EXTEND": "広げる",
      "GROW": "成長する"
    },
    "distractors": [
      "SHRINK",
      "CONTRACT",
      "REDUCE",
      "DECREASE"
    ],
    "meanings_expanded": [
      "拡大する",
      "膨張する",
      "広げる"
    ],
    "contexts": [
      {
        "parts": [
          "Heat makes metal",
          "."
        ],
        "full": "Heat makes metal EXPAND.",
        "jp": "熱は金属を膨張させる。",
        "is_correct": true
      },
      {
        "parts": [
          "The company plans to ",
          " overseas."
        ],
        "full": "The company plans to EXPAND overseas.",
        "jp": "会社は海外に拡大する計画だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Hot air will ",
          "."
        ],
        "full": "Hot air will EXPAND.",
        "jp": "熱い空気は膨張するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 246,
    "word": "EXPEDITION",
    "meaning_core": "遠征",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "pe",
        "type": "weak"
      },
      {
        "text": "DI",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "JOURNEY": "旅",
      "VOYAGE": "航海",
      "MISSION": "任務"
    },
    "distractors": [
      "STAY",
      "VACATION",
      "REST",
      "HALT"
    ],
    "meanings_expanded": [
      "遠征",
      "探検",
      "迅速さ"
    ],
    "contexts": [
      {
        "parts": [
          "They went on an",
          "to the North Pole."
        ],
        "full": "They went on an EXPEDITION to the North Pole.",
        "jp": "彼らは北極への遠征に出かけた。",
        "is_correct": true
      },
      {
        "parts": [
          "They organized a research ",
          "."
        ],
        "full": "They organized a research EXPEDITION.",
        "jp": "彼らは調査遠征を組織した。",
        "is_correct": true
      },
      {
        "parts": [
          "The jungle ",
          " was dangerous."
        ],
        "full": "The jungle EXPEDITION was dangerous.",
        "jp": "ジャングルの探検は危険だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 247,
    "word": "EXPENDITURE",
    "meaning_core": "支出",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "PEN",
        "type": "strong"
      },
      {
        "text": "di",
        "type": "weak"
      },
      {
        "text": "ture",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SPENDING": "出費",
      "COST": "費用",
      "EXPENSE": "経費"
    },
    "distractors": [
      "INCOME",
      "REVENUE",
      "PROFIT",
      "SAVINGS"
    ],
    "meanings_expanded": [
      "支出",
      "経費",
      "消費"
    ],
    "contexts": [
      {
        "parts": [
          "We need to cut",
          "on advertising."
        ],
        "full": "We need to cut EXPENDITURE on advertising.",
        "jp": "私たちは広告への支出を削減する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to reduce unnecessary ",
          "."
        ],
        "full": "We need to reduce unnecessary EXPENDITURE.",
        "jp": "私たちは不必要な支出を減らす必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The government increased military ",
          "."
        ],
        "full": "The government increased military EXPENDITURE.",
        "jp": "政府は軍事支出を増やした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 248,
    "word": "EXPERTISE",
    "meaning_core": "専門知識",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "per",
        "type": "weak"
      },
      {
        "text": "TISE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SKILL": "技能",
      "KNOWLEDGE": "知識",
      "PROFICIENCY": "熟達"
    },
    "distractors": [
      "IGNORANCE",
      "INCOMPETENCE",
      "AMATEURISM",
      "CLUMSINESS"
    ],
    "meanings_expanded": [
      "専門知識",
      "専門的技術"
    ],
    "contexts": [
      {
        "parts": [
          "We need someone with",
          "in coding."
        ],
        "full": "We need someone with EXPERTISE in coding.",
        "jp": "コーディングの専門知識を持つ人が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She has great ",
          " in coding."
        ],
        "full": "She has great EXPERTISE in coding.",
        "jp": "彼女はコーディングに優れた専門知識を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "We rely on his ",
          "."
        ],
        "full": "We rely on his EXPERTISE.",
        "jp": "私たちは彼の専門知識に頼っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 249,
    "word": "EXPIRE",
    "meaning_core": "期限が切れる",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "PIRE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "RUN OUT": "切れる",
      "END": "終わる",
      "TERMINATE": "終了する"
    },
    "distractors": [
      "START",
      "BEGIN",
      "RENEW",
      "CONTINUE"
    ],
    "meanings_expanded": [
      "期限が切れる",
      "満了する",
      "息を引き取る"
    ],
    "contexts": [
      {
        "parts": [
          "My passport will",
          "next month."
        ],
        "full": "My passport will EXPIRE next month.",
        "jp": "私のパスポートは来月期限が切れる。",
        "is_correct": true
      },
      {
        "parts": [
          "My passport will ",
          " soon."
        ],
        "full": "My passport will EXPIRE soon.",
        "jp": "私のパスポートは間もなく期限が切れる。",
        "is_correct": true
      },
      {
        "parts": [
          "The contract will ",
          " next month."
        ],
        "full": "The contract will EXPIRE next month.",
        "jp": "その契約は来月失効する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 250,
    "word": "EXPLICIT",
    "meaning_core": "明確な",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "PLIC",
        "type": "strong"
      },
      {
        "text": "it",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CLEAR": "明らかな",
      "DIRECT": "直接的な",
      "PRECISE": "正確な"
    },
    "distractors": [
      "IMPLICIT",
      "VAGUE",
      "AMBIGUOUS",
      "UNCLEAR"
    ],
    "meanings_expanded": [
      "明確な",
      "あからさまな",
      "率直な"
    ],
    "contexts": [
      {
        "parts": [
          "He gave",
          "instructions."
        ],
        "full": "He gave EXPLICIT instructions.",
        "jp": "彼は明確な指示を与えた。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave ",
          " instructions."
        ],
        "full": "He gave EXPLICIT instructions.",
        "jp": "彼は明確な指示を与えた。",
        "is_correct": true
      },
      {
        "parts": [
          "The warning was quite ",
          "."
        ],
        "full": "The warning was quite EXPLICIT.",
        "jp": "その警告は非常に露骨だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 251,
    "word": "EXPLICITLY",
    "meaning_core": "明示的に",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "PLIC",
        "type": "strong"
      },
      {
        "text": "it",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CLEARLY": "明確に",
      "DIRECTLY": "直接的に",
      "PLAINLY": "はっきりと"
    },
    "distractors": [
      "IMPLICITLY",
      "VAGUELY",
      "SECRETLY",
      "OBSCURELY"
    ],
    "meanings_expanded": [
      "明示的に",
      "はっきりと",
      "露骨に"
    ],
    "contexts": [
      {
        "parts": [
          "The rules were",
          "stated."
        ],
        "full": "The rules were EXPLICITLY stated.",
        "jp": "ルールは明示的に述べられていた。",
        "is_correct": true
      },
      {
        "parts": [
          "He was told ",
          " not to go."
        ],
        "full": "He was told EXPLICITLY not to go.",
        "jp": "彼は行かないようにと明示的に言われた。",
        "is_correct": true
      },
      {
        "parts": [
          "The rules ",
          " forbid smoking."
        ],
        "full": "The rules EXPLICITLY forbid smoking.",
        "jp": "ルールは喫煙を明示的に禁止している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 252,
    "word": "EXTENSIVE",
    "meaning_core": "広範囲にわたる",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "TEN",
        "type": "strong"
      },
      {
        "text": "sive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VAST": "広大な",
      "WIDE": "広い",
      "COMPREHENSIVE": "包括的な"
    },
    "distractors": [
      "LIMITED",
      "NARROW",
      "SMALL",
      "RESTRICTED"
    ],
    "meanings_expanded": [
      "広範囲にわたる",
      "大規模な",
      "広大な"
    ],
    "contexts": [
      {
        "parts": [
          "The fire caused",
          "damage."
        ],
        "full": "The fire caused EXTENSIVE damage.",
        "jp": "火事は広範囲にわたる被害をもたらした。",
        "is_correct": true
      },
      {
        "parts": [
          "She has ",
          " knowledge of history."
        ],
        "full": "She has EXTENSIVE knowledge of history.",
        "jp": "彼女は歴史について広範な知識を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The damage was ",
          "."
        ],
        "full": "The damage was EXTENSIVE.",
        "jp": "損害は広範囲にわたった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 253,
    "word": "EXTENSIVELY",
    "meaning_core": "広範囲に",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "TEN",
        "type": "strong"
      },
      {
        "text": "sive",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WIDELY": "広く",
      "BROADLY": "広範に",
      "GREATLY": "大いに"
    },
    "distractors": [
      "SLIGHTLY",
      "BARELY",
      "LITTLE",
      "NARROWLY"
    ],
    "meanings_expanded": [
      "広範囲に",
      "詳細に"
    ],
    "contexts": [
      {
        "parts": [
          "She has traveled",
          "in Europe."
        ],
        "full": "She has traveled EXTENSIVELY in Europe.",
        "jp": "彼女はヨーロッパを広範囲に旅行した。",
        "is_correct": true
      },
      {
        "parts": [
          "They traveled ",
          " in Asia."
        ],
        "full": "They traveled EXTENSIVELY in Asia.",
        "jp": "彼らはアジアを広範囲に旅行した。",
        "is_correct": true
      },
      {
        "parts": [
          "He researched the topic ",
          "."
        ],
        "full": "He researched the topic EXTENSIVELY.",
        "jp": "彼はそのトピックを広範囲に調査した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 254,
    "word": "EXTENT",
    "meaning_core": "範囲",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "TENT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DEGREE": "程度",
      "SCOPE": "範囲",
      "SCALE": "規模"
    },
    "distractors": [
      "NOTHING",
      "ZERO",
      "LACK",
      "NONE"
    ],
    "meanings_expanded": [
      "範囲",
      "程度",
      "広がり"
    ],
    "contexts": [
      {
        "parts": [
          "I agree with you to some",
          "."
        ],
        "full": "I agree with you to some EXTENT.",
        "jp": "ある程度までは君に同意する。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to know the full ",
          "."
        ],
        "full": "We need to know the full EXTENT.",
        "jp": "私たちは全容を知る必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "To some ",
          ", I agree."
        ],
        "full": "To some EXTENT, I agree.",
        "jp": "ある程度は、私も同意する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 255,
    "word": "EXTINCTION",
    "meaning_core": "絶滅",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "TINC",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISAPPEARANCE": "消滅",
      "DESTRUCTION": "破壊",
      "ELIMINATION": "排除"
    },
    "distractors": [
      "SURVIVAL",
      "EXISTENCE",
      "BIRTH",
      "CREATION"
    ],
    "meanings_expanded": [
      "絶滅",
      "消滅",
      "鎮火"
    ],
    "contexts": [
      {
        "parts": [
          "Many species face",
          "due to climate change."
        ],
        "full": "Many species face EXTINCTION due to climate change.",
        "jp": "多くの種が気候変動により絶滅の危機に瀕している。",
        "is_correct": true
      },
      {
        "parts": [
          "The species faces ",
          "."
        ],
        "full": "The species faces EXTINCTION.",
        "jp": "その種は絶滅に直面している。",
        "is_correct": true
      },
      {
        "parts": [
          "Human actions cause mass ",
          "."
        ],
        "full": "Human actions cause mass EXTINCTION.",
        "jp": "人間の行動が大量絶滅を引き起こす。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 256,
    "word": "EXTREMELY",
    "meaning_core": "極めて",
    "syllables": [
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "TREME",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VERY": "とても",
      "HIGHLY": "大いに",
      "EXCEEDINGLY": "非常に"
    },
    "distractors": [
      "SLIGHTLY",
      "A BIT",
      "FAIRLY",
      "MODERATELY"
    ],
    "meanings_expanded": [
      "極めて",
      "極端に",
      "非常に"
    ],
    "contexts": [
      {
        "parts": [
          "It is",
          "dangerous to swim here."
        ],
        "full": "It is EXTREMELY dangerous to swim here.",
        "jp": "ここで泳ぐのは極めて危険だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The weather is ",
          " cold today."
        ],
        "full": "The weather is EXTREMELY cold today.",
        "jp": "今日の天気は極めて寒い。",
        "is_correct": true
      },
      {
        "parts": [
          "She is ",
          " talented."
        ],
        "full": "She is EXTREMELY talented.",
        "jp": "彼女は非常に才能がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 257,
    "word": "FACILITY",
    "meaning_core": "施設",
    "syllables": [
      {
        "text": "fa",
        "type": "weak"
      },
      {
        "text": "CIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AMENITY": "設備",
      "ESTABLISHMENT": "施設",
      "EQUIPMENT": "備品"
    },
    "distractors": [
      "DIFFICULTY",
      "BARRIER",
      "PROBLEM",
      "OBSTACLE"
    ],
    "meanings_expanded": [
      "施設",
      "設備",
      "才能"
    ],
    "contexts": [
      {
        "parts": [
          "The new sports",
          "is open."
        ],
        "full": "The new sports FACILITY is open.",
        "jp": "新しいスポーツ施設がオープンした。",
        "is_correct": true
      },
      {
        "parts": [
          "She has a",
          "for languages."
        ],
        "full": "She has a talent for languages.",
        "jp": "彼女には語学の才能がある。（※facilityは才能という意味も持つが文脈としてはtalentが一般的）",
        "is_correct": true
      },
      {
        "parts": [
          "The school built a new ",
          "."
        ],
        "full": "The school built a new FACILITY.",
        "jp": "学校は新しい施設を建設した。",
        "is_correct": true
      },
      {
        "parts": [
          "They have a great manufacturing ",
          "."
        ],
        "full": "They have a great manufacturing FACILITY.",
        "jp": "彼らは素晴らしい製造施設を持っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 258,
    "word": "FAMINE",
    "meaning_core": "飢饉",
    "syllables": [
      {
        "text": "FAM",
        "type": "strong"
      },
      {
        "text": "ine",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STARVATION": "飢餓",
      "HUNGER": "飢え",
      "SCARCITY": "不足"
    },
    "distractors": [
      "FEAST",
      "PLENTY",
      "ABUNDANCE",
      "SURPLUS"
    ],
    "meanings_expanded": [
      "飢饉",
      "深刻な欠乏",
      "飢餓"
    ],
    "contexts": [
      {
        "parts": [
          "The war caused widespread",
          "."
        ],
        "full": "The war caused widespread FAMINE.",
        "jp": "戦争は広範囲にわたる飢饉を引き起こした。",
        "is_correct": true
      },
      {
        "parts": [
          "The country suffered a severe ",
          "."
        ],
        "full": "The country suffered a severe FAMINE.",
        "jp": "その国は深刻な飢饉に苦しんだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Aid was sent to the ",
          " area."
        ],
        "full": "Aid was sent to the FAMINE area.",
        "jp": "援助が飢饉地域に送られた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 259,
    "word": "FASCINATION",
    "meaning_core": "魅力",
    "syllables": [
      {
        "text": "fas",
        "type": "weak"
      },
      {
        "text": "ci",
        "type": "weak"
      },
      {
        "text": "NA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INTEREST": "興味",
      "ATTRACTION": "魅力",
      "CHARM": "魅力"
    },
    "distractors": [
      "BOREDOM",
      "DISINTEREST",
      "APATHY",
      "DISGUST"
    ],
    "meanings_expanded": [
      "魅力",
      "興味",
      "うっとりさせる状態"
    ],
    "contexts": [
      {
        "parts": [
          "She has a",
          "with ancient history."
        ],
        "full": "She has a FASCINATION with ancient history.",
        "jp": "彼女は古代史に魅了されている。",
        "is_correct": true
      },
      {
        "parts": [
          "The ocean holds a deep ",
          "."
        ],
        "full": "The ocean holds a deep FASCINATION.",
        "jp": "海は深い魅力を保持している。",
        "is_correct": true
      },
      {
        "parts": [
          "She has a lifelong ",
          " with space."
        ],
        "full": "She has a lifelong FASCINATION with space.",
        "jp": "彼女は宇宙に生涯の魅了を抱いている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 260,
    "word": "FATAL",
    "meaning_core": "致命的な",
    "syllables": [
      {
        "text": "FA",
        "type": "strong"
      },
      {
        "text": "tal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEADLY": "致命的な",
      "LETHAL": "致死の",
      "MORTAL": "死に至る"
    },
    "distractors": [
      "HARMLESS",
      "SAFE",
      "MINOR",
      "TRIVIAL"
    ],
    "meanings_expanded": [
      "致命的な",
      "命に関わる",
      "運命の"
    ],
    "contexts": [
      {
        "parts": [
          "It was a",
          "mistake."
        ],
        "full": "It was a FATAL mistake.",
        "jp": "それは致命的な間違いだった。",
        "is_correct": true
      },
      {
        "parts": [
          "The wound was ",
          "."
        ],
        "full": "The wound was FATAL.",
        "jp": "その傷は致命的だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He made a ",
          " mistake."
        ],
        "full": "He made a FATAL mistake.",
        "jp": "彼は致命的な間違いを犯した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 261,
    "word": "FEASIBLE",
    "meaning_core": "実現可能な",
    "syllables": [
      {
        "text": "FEA",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POSSIBLE": "可能な",
      "PRACTICAL": "実用的な",
      "VIABLE": "実行可能な"
    },
    "distractors": [
      "IMPOSSIBLE",
      "IMPRACTICAL",
      "UNLIKELY",
      "HOPELESS"
    ],
    "meanings_expanded": [
      "実現可能な",
      "実行できる",
      "もっともらしい"
    ],
    "contexts": [
      {
        "parts": [
          "The plan seems",
          "."
        ],
        "full": "The plan seems FEASIBLE.",
        "jp": "その計画は実現可能に見える。",
        "is_correct": true
      },
      {
        "parts": [
          "The plan is technically ",
          "."
        ],
        "full": "The plan is technically FEASIBLE.",
        "jp": "その計画は技術的に実現可能だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We seek a ",
          " solution."
        ],
        "full": "We seek a FEASIBLE solution.",
        "jp": "私たちは実行可能な解決策を探している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 262,
    "word": "FEATURE",
    "meaning_core": "特徴",
    "syllables": [
      {
        "text": "FEA",
        "type": "strong"
      },
      {
        "text": "ture",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CHARACTERISTIC": "特徴",
      "TRAIT": "特性",
      "ASPECT": "側面"
    },
    "distractors": [
      "WHOLE",
      "TOTALITY",
      "EXCEPTION",
      "LACK"
    ],
    "meanings_expanded": [
      "特徴",
      "顔立ち",
      "特集記事"
    ],
    "contexts": [
      {
        "parts": [
          "The camera has a zoom",
          "."
        ],
        "full": "The camera has a zoom FEATURE.",
        "jp": "そのカメラにはズーム機能がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The magazine will",
          "an interview with him."
        ],
        "full": "The magazine will FEATURE an interview with him.",
        "jp": "その雑誌は彼のインタビューを特集するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a unique ",
          " of the product."
        ],
        "full": "This is a unique FEATURE of the product.",
        "jp": "これはその製品のユニークな特徴だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The movie will ",
          " two famous actors."
        ],
        "full": "The movie will FEATURE two famous actors.",
        "jp": "その映画は2人の有名俳優を主演させるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 263,
    "word": "FIRM",
    "meaning_core": "固い",
    "syllables": [
      {
        "text": "FIRM",
        "type": "strong"
      }
    ],
    "synonyms": {
      "HARD": "固い",
      "SOLID": "堅固な",
      "STRICT": "厳しい"
    },
    "distractors": [
      "SOFT",
      "WEAK",
      "FLEXIBLE",
      "LOOSE"
    ],
    "meanings_expanded": [
      "固い",
      "断固とした",
      "会社"
    ],
    "contexts": [
      {
        "parts": [
          "He gave me a",
          "handshake."
        ],
        "full": "He gave me a FIRM handshake.",
        "jp": "彼は私と固い握手を交わした。",
        "is_correct": true
      },
      {
        "parts": [
          "She stood on ",
          " ground."
        ],
        "full": "She stood on FIRM ground.",
        "jp": "彼女は固い地面に立っていた。",
        "is_correct": true
      },
      {
        "parts": [
          "We maintain a ",
          " position."
        ],
        "full": "We maintain a FIRM position.",
        "jp": "私たちは断固とした立場を維持する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 264,
    "word": "FLATTER",
    "meaning_core": "お世辞を言う",
    "syllables": [
      {
        "text": "FLAT",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PRAISE": "褒める",
      "COMPLIMENT": "賛辞を贈る",
      "BUTTER UP": "ご機嫌をとる"
    },
    "distractors": [
      "INSULT",
      "CRITICIZE",
      "OFFEND",
      "MOCK"
    ],
    "meanings_expanded": [
      "お世辞を言う",
      "実物より良く見せる",
      "うれしがらせる"
    ],
    "contexts": [
      {
        "parts": [
          "Don't try to",
          "me."
        ],
        "full": "Don't try to FLATTER me.",
        "jp": "私にお世辞を言おうとしないで。",
        "is_correct": true
      },
      {
        "parts": [
          "That photo really",
          "you."
        ],
        "full": "That photo really flatters you.",
        "jp": "その写真は君を実物より良く見せている（写りがいい）。",
        "is_correct": true
      },
      {
        "parts": [
          "He tried to ",
          " his boss."
        ],
        "full": "He tried to FLATTER his boss.",
        "jp": "彼は上司にお世辞を言おうとした。",
        "is_correct": true
      },
      {
        "parts": [
          "Her words did not ",
          " me."
        ],
        "full": "Her words did not FLATTER me.",
        "jp": "彼女の言葉は私にお世辞を言わなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 265,
    "word": "FLEXIBLE",
    "meaning_core": "柔軟な",
    "syllables": [
      {
        "text": "FLEX",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ADAPTABLE": "適応できる",
      "PLIABLE": "曲げやすい",
      "ELASTIC": "弾力のある"
    },
    "distractors": [
      "RIGID",
      "STIFF",
      "STUBBORN",
      "FIXED"
    ],
    "meanings_expanded": [
      "柔軟な",
      "融通の利く",
      "曲げやすい"
    ],
    "contexts": [
      {
        "parts": [
          "My schedule is quite",
          "."
        ],
        "full": "My schedule is quite FLEXIBLE.",
        "jp": "私のスケジュールはかなり融通が利く。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " working schedule."
        ],
        "full": "We need a FLEXIBLE working schedule.",
        "jp": "私たちは柔軟な勤務スケジュールが必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The material is strong yet ",
          "."
        ],
        "full": "The material is strong yet FLEXIBLE.",
        "jp": "その素材は丈夫だが柔軟性がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 266,
    "word": "FLOCK",
    "meaning_core": "群れ",
    "syllables": [
      {
        "text": "FLOCK",
        "type": "strong"
      }
    ],
    "synonyms": {
      "GROUP": "集団",
      "HERD": "（家畜の）群れ",
      "CROWD": "群衆"
    },
    "distractors": [
      "INDIVIDUAL",
      "ONE",
      "SINGLE",
      "SOLO"
    ],
    "meanings_expanded": [
      "（鳥・羊などの）群れ",
      "群衆",
      "集まる"
    ],
    "contexts": [
      {
        "parts": [
          "A",
          "of birds flew over the lake."
        ],
        "full": "A FLOCK of birds flew over the lake.",
        "jp": "鳥の群れが湖の上を飛んでいった。",
        "is_correct": true
      },
      {
        "parts": [
          "People",
          "to the beach in summer."
        ],
        "full": "People FLOCK to the beach in summer.",
        "jp": "夏には人々がビーチに押し寄せる。",
        "is_correct": true
      },
      {
        "parts": [
          "A ",
          " of birds flew over."
        ],
        "full": "A FLOCK of birds flew over.",
        "jp": "鳥の群れが上空を飛んでいった。",
        "is_correct": true
      },
      {
        "parts": [
          "Tourists ",
          " to the city."
        ],
        "full": "Tourists FLOCK to the city.",
        "jp": "観光客がその都市に群がる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 267,
    "word": "FLUCTUATE",
    "meaning_core": "変動する",
    "syllables": [
      {
        "text": "FLUC",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VARY": "変わる",
      "CHANGE": "変化する",
      "SHIFT": "移行する"
    },
    "distractors": [
      "STABILIZE",
      "REMAIN",
      "STAY",
      "FIX"
    ],
    "meanings_expanded": [
      "変動する",
      "上下する",
      "動揺する"
    ],
    "contexts": [
      {
        "parts": [
          "Oil prices",
          "daily."
        ],
        "full": "Oil prices FLUCTUATE daily.",
        "jp": "石油価格は毎日変動する。",
        "is_correct": true
      },
      {
        "parts": [
          "Stock prices often ",
          "."
        ],
        "full": "Stock prices often FLUCTUATE.",
        "jp": "株価はしばしば変動する。",
        "is_correct": true
      },
      {
        "parts": [
          "Temperature levels can ",
          "."
        ],
        "full": "Temperature levels can FLUCTUATE.",
        "jp": "温度レベルは変動する可能性がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 268,
    "word": "FORESEE",
    "meaning_core": "予見する",
    "syllables": [
      {
        "text": "fore",
        "type": "weak"
      },
      {
        "text": "SEE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PREDICT": "予測する",
      "ANTICIPATE": "予期する",
      "EXPECT": "期待する"
    },
    "distractors": [
      "IGNORE",
      "MISS",
      "DOUBT",
      "FORGET"
    ],
    "meanings_expanded": [
      "予見する",
      "見越す"
    ],
    "contexts": [
      {
        "parts": [
          "I didn't",
          "any problems."
        ],
        "full": "I didn't FORESEE any problems.",
        "jp": "私は何の問題も予見していなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you",
          "the future?"
        ],
        "full": "Can you predict the future?",
        "jp": "未来を予測できますか？",
        "is_correct": true
      },
      {
        "parts": [
          "We did not ",
          " this problem."
        ],
        "full": "We did not FORESEE this problem.",
        "jp": "私たちはこの問題を予見しなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " the consequences?"
        ],
        "full": "Can you FORESEE the consequences?",
        "jp": "あなたはその結果を予見できますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 269,
    "word": "FORGE",
    "meaning_core": "築き上げる",
    "syllables": [
      {
        "text": "FORGE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "BUILD": "築く",
      "CREATE": "作る",
      "FAKE": "偽造する"
    },
    "distractors": [
      "DESTROY",
      "BREAK",
      "RUIN",
      "DEMOLISH"
    ],
    "meanings_expanded": [
      "築き上げる",
      "偽造する",
      "鍛造する"
    ],
    "contexts": [
      {
        "parts": [
          "They managed to",
          "a strong alliance."
        ],
        "full": "They managed to FORGE a strong alliance.",
        "jp": "彼らは強力な同盟を築き上げることができた。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "my signature."
        ],
        "full": "Don't FORGE my signature.",
        "jp": "私の署名を偽造しないで。",
        "is_correct": true
      },
      {
        "parts": [
          "They worked to ",
          " a new alliance."
        ],
        "full": "They worked to FORGE a new alliance.",
        "jp": "彼らは新しい同盟を築き上げるために働いた。",
        "is_correct": true
      },
      {
        "parts": [
          "He tried to ",
          " a signature."
        ],
        "full": "He tried to FORGE a signature.",
        "jp": "彼は署名を偽造しようとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 270,
    "word": "FORMIDABLE",
    "meaning_core": "恐るべき",
    "syllables": [
      {
        "text": "FOR",
        "type": "strong"
      },
      {
        "text": "mi",
        "type": "weak"
      },
      {
        "text": "da",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INTIMIDATING": "威圧的な",
      "IMPRESSIVE": "印象的な",
      "POWERFUL": "強力な"
    },
    "distractors": [
      "WEAK",
      "EASY",
      "HARMLESS",
      "TINY"
    ],
    "meanings_expanded": [
      "恐るべき",
      "手強い",
      "畏敬の念を起こさせる"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "opponent."
        ],
        "full": "He is a FORMIDABLE opponent.",
        "jp": "彼は手強い相手だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a ",
          " opponent."
        ],
        "full": "She is a FORMIDABLE opponent.",
        "jp": "彼女は恐るべき敵だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They faced a ",
          " challenge."
        ],
        "full": "They faced a FORMIDABLE challenge.",
        "jp": "彼らは手ごわい課題に直面した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 271,
    "word": "FORTUNATE",
    "meaning_core": "幸運な",
    "syllables": [
      {
        "text": "FOR",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "nate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LUCKY": "運が良い",
      "BLESSED": "恵まれた",
      "FAVORABLE": "好都合な"
    },
    "distractors": [
      "UNLUCKY",
      "TRAGIC",
      "SAD",
      "POOR"
    ],
    "meanings_expanded": [
      "幸運な",
      "運が良い"
    ],
    "contexts": [
      {
        "parts": [
          "We were",
          "to escape unhurt."
        ],
        "full": "We were FORTUNATE to escape unhurt.",
        "jp": "私たちは幸運にも無傷で逃げることができた。",
        "is_correct": true
      },
      {
        "parts": [
          "I feel ",
          " to have your help."
        ],
        "full": "I feel FORTUNATE to have your help.",
        "jp": "あなたの助けがあって幸運だと感じる。",
        "is_correct": true
      },
      {
        "parts": [
          "You are ",
          " to be here."
        ],
        "full": "You are FORTUNATE to be here.",
        "jp": "あなたはここにいられて幸運だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 272,
    "word": "FOSTER",
    "meaning_core": "育成する",
    "syllables": [
      {
        "text": "FOS",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NURTURE": "育てる",
      "PROMOTE": "促進する",
      "ENCOURAGE": "助長する"
    },
    "distractors": [
      "NEGLECT",
      "IGNORE",
      "HINDER",
      "HALT"
    ],
    "meanings_expanded": [
      "育成する",
      "促進する",
      "養育する"
    ],
    "contexts": [
      {
        "parts": [
          "We want to",
          "innovation."
        ],
        "full": "We want to FOSTER innovation.",
        "jp": "私たちはイノベーションを育成したい。",
        "is_correct": true
      },
      {
        "parts": [
          "We try to ",
          " creativity."
        ],
        "full": "We try to FOSTER creativity.",
        "jp": "私たちは創造性を育成しようとしている。",
        "is_correct": true
      },
      {
        "parts": [
          "She wants to ",
          " a child."
        ],
        "full": "She wants to FOSTER a child.",
        "jp": "彼女は子供を里子として育てることを望んでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 273,
    "word": "FRACTURE",
    "meaning_core": "骨折",
    "syllables": [
      {
        "text": "FRAC",
        "type": "strong"
      },
      {
        "text": "ture",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BREAK": "破損",
      "CRACK": "ひび",
      "SPLIT": "裂け目"
    },
    "distractors": [
      "HEALING",
      "CURE",
      "WHOLE",
      "REPAIR"
    ],
    "meanings_expanded": [
      "骨折",
      "割れ目",
      "破砕"
    ],
    "contexts": [
      {
        "parts": [
          "He suffered a leg",
          "."
        ],
        "full": "He suffered a leg FRACTURE.",
        "jp": "彼は足を骨折した。",
        "is_correct": true
      },
      {
        "parts": [
          "He suffered a slight leg ",
          "."
        ],
        "full": "He suffered a slight leg FRACTURE.",
        "jp": "彼は軽度の脚の骨折を負った。",
        "is_correct": true
      },
      {
        "parts": [
          "The bone will easily ",
          "."
        ],
        "full": "The bone will easily FRACTURE.",
        "jp": "その骨は簡単に折れるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 274,
    "word": "FRAGILE",
    "meaning_core": "こわれやすい",
    "syllables": [
      {
        "text": "FRAG",
        "type": "strong"
      },
      {
        "text": "ile",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DELICATE": "繊細な",
      "BREAKABLE": "壊れやすい",
      "WEAK": "弱い"
    },
    "distractors": [
      "STRONG",
      "TOUGH",
      "DURABLE",
      "ROBUST"
    ],
    "meanings_expanded": [
      "こわれやすい",
      "もろい",
      "虚弱な"
    ],
    "contexts": [
      {
        "parts": [
          "Handle with care; it is",
          "."
        ],
        "full": "Handle with care; it is FRAGILE.",
        "jp": "取扱注意、それは壊れやすい。",
        "is_correct": true
      },
      {
        "parts": [
          "Handle the glass, it is ",
          "."
        ],
        "full": "Handle the glass, it is FRAGILE.",
        "jp": "ガラスを扱ってください、それは壊れやすいです。",
        "is_correct": true
      },
      {
        "parts": [
          "The whole agreement is very ",
          "."
        ],
        "full": "The whole agreement is very FRAGILE.",
        "jp": "その合意全体は非常に不安定だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 275,
    "word": "FRICTION",
    "meaning_core": "摩擦",
    "syllables": [
      {
        "text": "FRIC",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RUBBING": "擦れ",
      "CONFLICT": "対立",
      "RESISTANCE": "抵抗"
    },
    "distractors": [
      "HARMONY",
      "PEACE",
      "SMOOTHNESS",
      "SLIP"
    ],
    "meanings_expanded": [
      "摩擦",
      "不和",
      "軋轢"
    ],
    "contexts": [
      {
        "parts": [
          "Oil reduces",
          "in the engine."
        ],
        "full": "Oil reduces FRICTION in the engine.",
        "jp": "油はエンジンの摩擦を減らす。",
        "is_correct": true
      },
      {
        "parts": [
          "There was a lot of ",
          " between them."
        ],
        "full": "There was a lot of FRICTION between them.",
        "jp": "彼らの間には多くの摩擦があった。",
        "is_correct": true
      },
      {
        "parts": [
          "Reducing ",
          " saves energy."
        ],
        "full": "Reducing FRICTION saves energy.",
        "jp": "摩擦を減らすことはエネルギーを節約する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 276,
    "word": "FRUSTRATION",
    "meaning_core": "欲求不満",
    "syllables": [
      {
        "text": "frus",
        "type": "weak"
      },
      {
        "text": "TRA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANNOYANCE": "いらだち",
      "IRRITATION": "焦燥",
      "DISAPPOINTMENT": "失望"
    },
    "distractors": [
      "SATISFACTION",
      "JOY",
      "PLEASURE",
      "CONTENTMENT"
    ],
    "meanings_expanded": [
      "欲求不満",
      "挫折",
      "イライラ"
    ],
    "contexts": [
      {
        "parts": [
          "He shouted in",
          "."
        ],
        "full": "He shouted in FRUSTRATION.",
        "jp": "彼は欲求不満で叫んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "She felt deep ",
          " with the work."
        ],
        "full": "She felt deep FRUSTRATION with the work.",
        "jp": "彼女はその仕事に深い欲求不満を感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "We shared our sense of ",
          "."
        ],
        "full": "We shared our sense of FRUSTRATION.",
        "jp": "私たちは欲求不満の感覚を共有した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 277,
    "word": "FUND",
    "meaning_core": "資金提供する",
    "syllables": [
      {
        "text": "FUND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FINANCE": "融資する",
      "SUPPORT": "支援する",
      "SUBSIDIZE": "助成する"
    },
    "distractors": [
      "DEFUND",
      "WITHDRAW",
      "DEBT",
      "OWE"
    ],
    "meanings_expanded": [
      "資金提供する",
      "資金",
      "基金"
    ],
    "contexts": [
      {
        "parts": [
          "The government will",
          "the project."
        ],
        "full": "The government will FUND the project.",
        "jp": "政府はそのプロジェクトに資金を提供するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the research."
        ],
        "full": "We need to FUND the research.",
        "jp": "私たちはその研究に資金提供する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The government cut the school ",
          "."
        ],
        "full": "The government cut the school FUND.",
        "jp": "政府は学校の資金を削減した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 278,
    "word": "FUSS",
    "meaning_core": "大騒ぎ",
    "syllables": [
      {
        "text": "FUSS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "COMMOTION": "騒動",
      "BOTHER": "面倒",
      "STIR": "騒ぎ"
    },
    "distractors": [
      "CALM",
      "PEACE",
      "SILENCE",
      "QUIET"
    ],
    "meanings_expanded": [
      "大騒ぎ",
      "空騒ぎ",
      "やきもきすること"
    ],
    "contexts": [
      {
        "parts": [
          "Don't make a",
          "over nothing."
        ],
        "full": "Don't make a FUSS over nothing.",
        "jp": "何でもないことで大騒ぎするな。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't make such a big ",
          " over it."
        ],
        "full": "Don't make such a big FUSS over it.",
        "jp": "そのことでそんなに大騒ぎしないで。",
        "is_correct": true
      },
      {
        "parts": [
          "There was a lot of ",
          " before the party."
        ],
        "full": "There was a lot of FUSS before the party.",
        "jp": "パーティーの前に多くの騒ぎがあった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 279,
    "word": "GENDER",
    "meaning_core": "性別",
    "syllables": [
      {
        "text": "GEN",
        "type": "strong"
      },
      {
        "text": "der",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SEX": "性",
      "TYPE": "種類",
      "KIND": "種"
    },
    "distractors": [
      "AGE",
      "HEIGHT",
      "WEIGHT",
      "COLOR"
    ],
    "meanings_expanded": [
      "ジェンダー",
      "性別"
    ],
    "contexts": [
      {
        "parts": [
          "Discrimination based on",
          "is illegal."
        ],
        "full": "Discrimination based on GENDER is illegal.",
        "jp": "性別に基づく差別は違法だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We strive for ",
          " equality."
        ],
        "full": "We strive for GENDER equality.",
        "jp": "私たちは男女平等をめざす。",
        "is_correct": true
      },
      {
        "parts": [
          "Please state your name and ",
          "."
        ],
        "full": "Please state your name and GENDER.",
        "jp": "あなたの名前と性別を述べてください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 280,
    "word": "GENERATE",
    "meaning_core": "生み出す",
    "syllables": [
      {
        "text": "GEN",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PRODUCE": "生産する",
      "CREATE": "創造する",
      "MAKE": "作る"
    },
    "distractors": [
      "DESTROY",
      "STOP",
      "END",
      "KILL"
    ],
    "meanings_expanded": [
      "生み出す",
      "発生させる",
      "引き起こす"
    ],
    "contexts": [
      {
        "parts": [
          "Solar panels",
          "electricity."
        ],
        "full": "Solar panels GENERATE electricity.",
        "jp": "ソーラーパネルは電気を生み出す。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " more ideas."
        ],
        "full": "We need to GENERATE more ideas.",
        "jp": "私たちはもっとアイデアを生み出す必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "This process can ",
          " electricity."
        ],
        "full": "This process can GENERATE electricity.",
        "jp": "このプロセスは電気を生成できる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 281,
    "word": "GENEROUS",
    "meaning_core": "気前のよい",
    "syllables": [
      {
        "text": "GEN",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LIBERAL": "気前のよい",
      "KIND": "親切な",
      "CHARITABLE": "慈悲深い"
    },
    "distractors": [
      "STINGY",
      "SELFISH",
      "MEAN",
      "GREEDY"
    ],
    "meanings_expanded": [
      "気前のよい",
      "寛大な",
      "たくさんの"
    ],
    "contexts": [
      {
        "parts": [
          "He made a",
          "donation."
        ],
        "full": "He made a GENEROUS donation.",
        "jp": "彼は気前のよい寄付をした。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a very ",
          " person."
        ],
        "full": "He is a very GENEROUS person.",
        "jp": "彼​​はとても気前の良い人だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She made a ",
          " donation."
        ],
        "full": "She made a GENEROUS donation.",
        "jp": "彼女は気前の良い寄付をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 282,
    "word": "GLORIOUS",
    "meaning_core": "栄光の",
    "syllables": [
      {
        "text": "GLO",
        "type": "strong"
      },
      {
        "text": "ri",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MAGNIFICENT": "壮大な",
      "SPLENDID": "素晴らしい",
      "GRAND": "雄大な"
    },
    "distractors": [
      "SHAMEFUL",
      "TERRIBLE",
      "BAD",
      "AWFUL"
    ],
    "meanings_expanded": [
      "栄光の",
      "素晴らしい",
      "輝かしい"
    ],
    "contexts": [
      {
        "parts": [
          "It was a",
          "victory."
        ],
        "full": "It was a GLORIOUS victory.",
        "jp": "それは栄光の勝利だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The victory was ",
          "."
        ],
        "full": "The victory was GLORIOUS.",
        "jp": "その勝利は栄光に満ちていた。",
        "is_correct": true
      },
      {
        "parts": [
          "We remember the ",
          " past."
        ],
        "full": "We remember the GLORIOUS past.",
        "jp": "私たちは栄光ある過去を覚えている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 283,
    "word": "GOVERN",
    "meaning_core": "統治する",
    "syllables": [
      {
        "text": "GOV",
        "type": "strong"
      },
      {
        "text": "ern",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RULE": "支配する",
      "CONTROL": "管理する",
      "LEAD": "導く"
    },
    "distractors": [
      "OBEY",
      "FOLLOW",
      "SERVE",
      "SUBMIT"
    ],
    "meanings_expanded": [
      "統治する",
      "治める",
      "左右する"
    ],
    "contexts": [
      {
        "parts": [
          "The president will",
          "the country."
        ],
        "full": "The president will GOVERN the country.",
        "jp": "大統領が国を統治するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Who will ",
          " the country next?"
        ],
        "full": "Who will GOVERN the country next?",
        "jp": "次に誰がその国を統治するのか。",
        "is_correct": true
      },
      {
        "parts": [
          "Rules must ",
          " your actions."
        ],
        "full": "Rules must GOVERN your actions.",
        "jp": "ルールがあなたの行動を支配しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 284,
    "word": "GRACE",
    "meaning_core": "優雅さ",
    "syllables": [
      {
        "text": "GRACE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ELEGANCE": "優雅",
      "CHARM": "魅力",
      "POISE": "釣り合い"
    },
    "distractors": [
      "CLUMSINESS",
      "AWKWARDNESS",
      "RUDENESS",
      "UGLINESS"
    ],
    "meanings_expanded": [
      "優雅さ",
      "気品",
      "恩寵"
    ],
    "contexts": [
      {
        "parts": [
          "She danced with",
          "."
        ],
        "full": "She danced with GRACE.",
        "jp": "彼女は優雅に踊った。",
        "is_correct": true
      },
      {
        "parts": [
          "She accepted the award with ",
          "."
        ],
        "full": "She accepted the award with GRACE.",
        "jp": "彼女は優雅に賞を受け取った。",
        "is_correct": true
      },
      {
        "parts": [
          "He fell from ",
          "."
        ],
        "full": "He fell from GRACE.",
        "jp": "彼は失脚した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 285,
    "word": "GRACIOUS",
    "meaning_core": "礼儀正しい",
    "syllables": [
      {
        "text": "GRA",
        "type": "strong"
      },
      {
        "text": "cious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POLITE": "礼儀正しい",
      "COURTEOUS": "丁寧な",
      "KIND": "親切な"
    },
    "distractors": [
      "RUDE",
      "IMPOLITE",
      "MEAN",
      "UNKIND"
    ],
    "meanings_expanded": [
      "礼儀正しい",
      "親切な",
      "優雅な"
    ],
    "contexts": [
      {
        "parts": [
          "She was a",
          "host."
        ],
        "full": "She was a GRACIOUS host.",
        "jp": "彼女は礼儀正しいホストだった。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave a ",
          " reply."
        ],
        "full": "He gave a GRACIOUS reply.",
        "jp": "彼は丁寧な返事をした。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a very ",
          " host."
        ],
        "full": "She is a very GRACIOUS host.",
        "jp": "彼女はとても礼儀正しいホストだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 286,
    "word": "GRADUALLY",
    "meaning_core": "徐々に",
    "syllables": [
      {
        "text": "GRAD",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SLOWLY": "ゆっくりと",
      "STEADILY": "着実に",
      "LITTLE BY LITTLE": "少しずつ"
    },
    "distractors": [
      "SUDDENLY",
      "QUICKLY",
      "INSTANTLY",
      "IMMEDIATELY"
    ],
    "meanings_expanded": [
      "徐々に",
      "次第に"
    ],
    "contexts": [
      {
        "parts": [
          "The weather is",
          "getting warmer."
        ],
        "full": "The weather is GRADUALLY getting warmer.",
        "jp": "天気は徐々に暖かくなっている。",
        "is_correct": true
      },
      {
        "parts": [
          "The temperature dropped ",
          "."
        ],
        "full": "The temperature dropped GRADUALLY.",
        "jp": "気温は徐々に下がった。",
        "is_correct": true
      },
      {
        "parts": [
          "He will ",
          " recover his health."
        ],
        "full": "He will GRADUALLY recover his health.",
        "jp": "彼は徐々に健康を回復するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 287,
    "word": "GREGARIOUS",
    "meaning_core": "社交的な",
    "syllables": [
      {
        "text": "gre",
        "type": "weak"
      },
      {
        "text": "GAR",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SOCIABLE": "社交的な",
      "OUTGOING": "外向的な",
      "FRIENDLY": "友好的な"
    },
    "distractors": [
      "SHY",
      "INTROVERTED",
      "LONELY",
      "RESERVED"
    ],
    "meanings_expanded": [
      "社交的な",
      "群居する"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "person who loves parties."
        ],
        "full": "He is a GREGARIOUS person who loves parties.",
        "jp": "彼はパーティー好きの社交的な人だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Lions are ",
          " animals."
        ],
        "full": "Lions are GREGARIOUS animals.",
        "jp": "ライオンは群居性の動物だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a very ",
          " person."
        ],
        "full": "He is a very GREGARIOUS person.",
        "jp": "彼は非常に社交的な人だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 288,
    "word": "GRIEVANCE",
    "meaning_core": "不平",
    "syllables": [
      {
        "text": "GRIEV",
        "type": "strong"
      },
      {
        "text": "ance",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLAINT": "不満",
      "INJUSTICE": "不正",
      "GRUDGE": "恨み"
    },
    "distractors": [
      "PRAISE",
      "COMPLIMENT",
      "JOY",
      "SATISFACTION"
    ],
    "meanings_expanded": [
      "不平",
      "苦情",
      "不当な扱い"
    ],
    "contexts": [
      {
        "parts": [
          "Employees filed a",
          "against the company."
        ],
        "full": "Employees filed a GRIEVANCE against the company.",
        "jp": "従業員たちは会社に対して苦情を申し立てた。",
        "is_correct": true
      },
      {
        "parts": [
          "She filed a formal ",
          "."
        ],
        "full": "She filed a formal GRIEVANCE.",
        "jp": "彼女は正式な不満を申し立てた。",
        "is_correct": true
      },
      {
        "parts": [
          "The workers aired their ",
          "."
        ],
        "full": "The workers aired their GRIEVANCE.",
        "jp": "労働者たちは不平を表明した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 289,
    "word": "GRIEVE",
    "meaning_core": "悲しむ",
    "syllables": [
      {
        "text": "GRIEVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MOURN": "喪に服す",
      "SORROW": "悲しむ",
      "LAMENT": "嘆く"
    },
    "distractors": [
      "REJOICE",
      "CELEBRATE",
      "LAUGH",
      "SMILE"
    ],
    "meanings_expanded": [
      "深く悲しむ",
      "嘆き悲しむ"
    ],
    "contexts": [
      {
        "parts": [
          "We",
          "for the loss of our friend."
        ],
        "full": "We GRIEVE for the loss of our friend.",
        "jp": "私たちは友人を失ったことを悲しんでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "People still ",
          " the loss."
        ],
        "full": "People still GRIEVE the loss.",
        "jp": "人々はまだその喪失を悲しんでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "She will ",
          " for her friend."
        ],
        "full": "She will GRIEVE for her friend.",
        "jp": "彼女は友人を悼むだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 290,
    "word": "GUILT",
    "meaning_core": "罪悪感",
    "syllables": [
      {
        "text": "GUILT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SHAME": "恥",
      "REMORSE": "後悔",
      "REGRET": "遺憾"
    },
    "distractors": [
      "INNOCENCE",
      "PRIDE",
      "JOY",
      "HAPPINESS"
    ],
    "meanings_expanded": [
      "罪悪感",
      "有罪",
      "罪"
    ],
    "contexts": [
      {
        "parts": [
          "He felt",
          "about lying."
        ],
        "full": "He felt GUILT about lying.",
        "jp": "彼は嘘をついたことに罪悪感を感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "He felt a strong sense of ",
          "."
        ],
        "full": "He felt a strong sense of GUILT.",
        "jp": "彼は強い罪悪感を感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "The jury debated his ",
          "."
        ],
        "full": "The jury debated his GUILT.",
        "jp": "陪審員は彼の有罪について討論した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 291,
    "word": "HAPHAZARDLY",
    "meaning_core": "でたらめに",
    "syllables": [
      {
        "text": "hap",
        "type": "weak"
      },
      {
        "text": "HAZ",
        "type": "strong"
      },
      {
        "text": "ard",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RANDOMLY": "無作為に",
      "CARELESSLY": "不注意に",
      "AIMLESSLY": "目的なく"
    },
    "distractors": [
      "CAREFULLY",
      "METHODICALLY",
      "SYSTEMATICALLY",
      "ORDERLY"
    ],
    "meanings_expanded": [
      "でたらめに",
      "無計画に",
      "偶然に"
    ],
    "contexts": [
      {
        "parts": [
          "Books were piled",
          "on the floor."
        ],
        "full": "Books were piled HAPHAZARDLY on the floor.",
        "jp": "本が床にでたらめに積み上げられていた。",
        "is_correct": true
      },
      {
        "parts": [
          "Books were piled ",
          " on the floor."
        ],
        "full": "Books were piled HAPHAZARDLY on the floor.",
        "jp": "本は床にでたらめに積まれていた。",
        "is_correct": true
      },
      {
        "parts": [
          "The work was done ",
          "."
        ],
        "full": "The work was done HAPHAZARDLY.",
        "jp": "その作業は無計画に行われた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 292,
    "word": "HARMFUL",
    "meaning_core": "有害な",
    "syllables": [
      {
        "text": "HARM",
        "type": "strong"
      },
      {
        "text": "ful",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DAMAGING": "損害を与える",
      "DANGEROUS": "危険な",
      "INJURIOUS": "有害な"
    },
    "distractors": [
      "BENEFICIAL",
      "SAFE",
      "HELPFUL",
      "GOOD"
    ],
    "meanings_expanded": [
      "有害な",
      "危険な"
    ],
    "contexts": [
      {
        "parts": [
          "Smoking is",
          "to your health."
        ],
        "full": "Smoking is HARMFUL to your health.",
        "jp": "喫煙は健康に有害だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Smoking is ",
          " to health."
        ],
        "full": "Smoking is HARMFUL to health.",
        "jp": "喫煙は健康に有害だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The substance is highly ",
          "."
        ],
        "full": "The substance is highly HARMFUL.",
        "jp": "その物質は非常に有害だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 293,
    "word": "HARSH",
    "meaning_core": "厳しい",
    "syllables": [
      {
        "text": "HARSH",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SEVERE": "深刻な",
      "STRICT": "厳格な",
      "CRUEL": "残酷な"
    },
    "distractors": [
      "GENTLE",
      "MILD",
      "SOFT",
      "KIND"
    ],
    "meanings_expanded": [
      "厳しい",
      "不快な",
      "粗い"
    ],
    "contexts": [
      {
        "parts": [
          "The punishment was too",
          "."
        ],
        "full": "The punishment was too HARSH.",
        "jp": "その罰は厳しすぎた。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave a ",
          " judgment."
        ],
        "full": "He gave a HARSH judgment.",
        "jp": "彼は厳しい判決を下した。",
        "is_correct": true
      },
      {
        "parts": [
          "The climate is extremely ",
          "."
        ],
        "full": "The climate is extremely HARSH.",
        "jp": "その気候は極めて厳しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 294,
    "word": "HARSHLY",
    "meaning_core": "激しく",
    "syllables": [
      {
        "text": "HARSH",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SEVERELY": "厳しく",
      "STRICTLY": "厳格に",
      "CRUELLY": "残酷に"
    },
    "distractors": [
      "GENTLY",
      "KINDLY",
      "SOFTLY",
      "MILDLY"
    ],
    "meanings_expanded": [
      "厳しく",
      "激しく",
      "耳障りに"
    ],
    "contexts": [
      {
        "parts": [
          "He was criticized",
          "for his mistake."
        ],
        "full": "He was criticized HARSHLY for his mistake.",
        "jp": "彼は間違いを厳しく批判された。",
        "is_correct": true
      },
      {
        "parts": [
          "The critics judged the movie ",
          "."
        ],
        "full": "The critics judged the movie HARSHLY.",
        "jp": "批評家たちはその映画を激しく批判した。",
        "is_correct": true
      },
      {
        "parts": [
          "He spoke to the child ",
          "."
        ],
        "full": "He spoke to the child HARSHLY.",
        "jp": "彼はその子供に厳しく話した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 295,
    "word": "HAUNT",
    "meaning_core": "出没する",
    "syllables": [
      {
        "text": "HAUNT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "TORMENT": "苦しめる",
      "PLAGUE": "悩ます",
      "VISIT": "訪れる"
    },
    "distractors": [
      "COMFORT",
      "SOOTHE",
      "LEAVE",
      "PLEASE"
    ],
    "meanings_expanded": [
      "（幽霊が）出没する",
      "（考えなどが）つきまとう"
    ],
    "contexts": [
      {
        "parts": [
          "The memory will",
          "him forever."
        ],
        "full": "The memory will HAUNT him forever.",
        "jp": "その記憶は彼に永遠につきまとうだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The ghost is said to ",
          " the old house."
        ],
        "full": "The ghost is said to HAUNT the old house.",
        "jp": "その幽霊は古い家に出没すると言われている。",
        "is_correct": true
      },
      {
        "parts": [
          "Old memories still ",
          " her."
        ],
        "full": "Old memories still HAUNT her.",
        "jp": "古い記憶がまだ彼女に取り憑いている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 296,
    "word": "HAZARD",
    "meaning_core": "危険要因",
    "syllables": [
      {
        "text": "HAZ",
        "type": "strong"
      },
      {
        "text": "ard",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DANGER": "危険",
      "RISK": "リスク",
      "PERIL": "危難"
    },
    "distractors": [
      "SAFETY",
      "SECURITY",
      "PROTECTION",
      "SHELTER"
    ],
    "meanings_expanded": [
      "危険要因",
      "危険",
      "偶然"
    ],
    "contexts": [
      {
        "parts": [
          "Smoking is a health",
          "."
        ],
        "full": "Smoking is a health HAZARD.",
        "jp": "喫煙は健康への危険要因だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Smoking is a health ",
          "."
        ],
        "full": "Smoking is a health HAZARD.",
        "jp": "喫煙は健康上の危険要因だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Watch out for the traffic ",
          "."
        ],
        "full": "Watch out for the traffic HAZARD.",
        "jp": "交通の危険に気を付けて。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 297,
    "word": "HEED",
    "meaning_core": "気を付ける",
    "syllables": [
      {
        "text": "HEED",
        "type": "strong"
      }
    ],
    "synonyms": {
      "LISTEN TO": "聞く",
      "MIND": "気にする",
      "PAY ATTENTION TO": "注意を払う"
    },
    "distractors": [
      "IGNORE",
      "DISREGARD",
      "NEGLECT",
      "OVERLOOK"
    ],
    "meanings_expanded": [
      "（忠告などを）心に留める",
      "注意する"
    ],
    "contexts": [
      {
        "parts": [
          "You should",
          "my advice."
        ],
        "full": "You should HEED my advice.",
        "jp": "私の忠告を心に留めるべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "You should ",
          " her warning."
        ],
        "full": "You should HEED her warning.",
        "jp": "あなたは彼女の警告に注意を払うべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "They failed to ",
          " the safety advice."
        ],
        "full": "They failed to HEED the safety advice.",
        "jp": "彼らは安全に関する助言に気を付けなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 298,
    "word": "HERITAGE",
    "meaning_core": "遺産",
    "syllables": [
      {
        "text": "HER",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "tage",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LEGACY": "遺産",
      "TRADITION": "伝統",
      "INHERITANCE": "相続財産"
    },
    "distractors": [
      "FUTURE",
      "NOVELTY",
      "INNOVATION",
      "NEWNESS"
    ],
    "meanings_expanded": [
      "遺産",
      "伝統",
      "継承物"
    ],
    "contexts": [
      {
        "parts": [
          "We must preserve our cultural",
          "."
        ],
        "full": "We must preserve our cultural HERITAGE.",
        "jp": "私たちは文化遺産を保存しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We must protect our cultural ",
          "."
        ],
        "full": "We must protect our cultural HERITAGE.",
        "jp": "私たちは文化遺産を保護しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The town's ",
          " dates back centuries."
        ],
        "full": "The town's HERITAGE dates back centuries.",
        "jp": "その町の遺産は何世紀も前に遡る。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 299,
    "word": "HILARIOUS",
    "meaning_core": "大変陽気な",
    "syllables": [
      {
        "text": "hi",
        "type": "weak"
      },
      {
        "text": "LAR",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FUNNY": "面白い",
      "AMUSING": "楽しい",
      "COMICAL": "滑稽な"
    },
    "distractors": [
      "SAD",
      "SERIOUS",
      "BORING",
      "GRAVE"
    ],
    "meanings_expanded": [
      "大変陽気な",
      "大笑いさせる",
      "滑稽な"
    ],
    "contexts": [
      {
        "parts": [
          "The movie was absolutely",
          "."
        ],
        "full": "The movie was absolutely HILARIOUS.",
        "jp": "その映画は最高に面白かった。",
        "is_correct": true
      },
      {
        "parts": [
          "The joke was absolutely ",
          "."
        ],
        "full": "The joke was absolutely HILARIOUS.",
        "jp": "その冗談はとても面白かった。",
        "is_correct": true
      },
      {
        "parts": [
          "She told a ",
          " story."
        ],
        "full": "She told a HILARIOUS story.",
        "jp": "彼女は大変陽気な話をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 300,
    "word": "HOSPITALITY",
    "meaning_core": "もてなし",
    "syllables": [
      {
        "text": "hos",
        "type": "weak"
      },
      {
        "text": "pi",
        "type": "weak"
      },
      {
        "text": "TAL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WELCOME": "歓迎",
      "FRIENDLINESS": "親切",
      "WARMTH": "温かさ"
    },
    "distractors": [
      "HOSTILITY",
      "UNFRIENDLINESS",
      "COLDNESS",
      "RUDENESS"
    ],
    "meanings_expanded": [
      "もてなし",
      "歓待",
      "親切"
    ],
    "contexts": [
      {
        "parts": [
          "Thank you for your kind",
          "."
        ],
        "full": "Thank you for your kind HOSPITALITY.",
        "jp": "ご親切なもてなしをありがとう。",
        "is_correct": true
      },
      {
        "parts": [
          "Thank you for your warm ",
          "."
        ],
        "full": "Thank you for your warm HOSPITALITY.",
        "jp": "温かいもてなしをありがとう。",
        "is_correct": true
      },
      {
        "parts": [
          "They are famous for their ",
          "."
        ],
        "full": "They are famous for their HOSPITALITY.",
        "jp": "彼らはもてなしで有名だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 301,
    "word": "HUMILIATE",
    "meaning_core": "恥をかかせる",
    "syllables": [
      {
        "text": "hu",
        "type": "weak"
      },
      {
        "text": "MIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EMBARRASS": "当惑させる",
      "SHAME": "恥じ入らせる",
      "DISGRACE": "面目を失わせる"
    },
    "distractors": [
      "HONOR",
      "PRAISE",
      "RESPECT",
      "ELEVATE"
    ],
    "meanings_expanded": [
      "恥をかかせる",
      "屈辱を与える"
    ],
    "contexts": [
      {
        "parts": [
          "He tried to",
          "me in public."
        ],
        "full": "He tried to HUMILIATE me in public.",
        "jp": "彼は人前で私に恥をかかせようとした。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't ",
          " your younger sister."
        ],
        "full": "Don't HUMILIATE your younger sister.",
        "jp": "あなたの妹に恥をかかせてはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "The defeat will ",
          " the team."
        ],
        "full": "The defeat will HUMILIATE the team.",
        "jp": "その敗北はチームに恥をかかせるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 302,
    "word": "HYBRID",
    "meaning_core": "雑種",
    "syllables": [
      {
        "text": "HY",
        "type": "strong"
      },
      {
        "text": "brid",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MIXTURE": "混合物",
      "CROSS": "交配種",
      "BLEND": "混合"
    },
    "distractors": [
      "PURE",
      "ORIGINAL",
      "SINGLE",
      "SIMPLE"
    ],
    "meanings_expanded": [
      "雑種",
      "ハイブリッド",
      "混合物"
    ],
    "contexts": [
      {
        "parts": [
          "This car is a",
          "model."
        ],
        "full": "This car is a HYBRID model.",
        "jp": "この車はハイブリッドモデルだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The car has a ",
          " engine."
        ],
        "full": "The car has a HYBRID engine.",
        "jp": "その車はハイブリッドエンジンを搭載している。",
        "is_correct": true
      },
      {
        "parts": [
          "This plant is a ",
          "."
        ],
        "full": "This plant is a HYBRID.",
        "jp": "この植物は雑種だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 303,
    "word": "IDENTIFY",
    "meaning_core": "特定する",
    "syllables": [
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "DEN",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "fy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RECOGNIZE": "認識する",
      "PINPOINT": "正確に示す",
      "DISTINGUISH": "区別する"
    },
    "distractors": [
      "CONFUSE",
      "IGNORE",
      "OVERLOOK",
      "MISS"
    ],
    "meanings_expanded": [
      "特定する",
      "確認する",
      "同一視する"
    ],
    "contexts": [
      {
        "parts": [
          "Can you",
          "the suspect?"
        ],
        "full": "Can you IDENTIFY the suspect?",
        "jp": "容疑者を特定できますか？",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " the owner?"
        ],
        "full": "Can you IDENTIFY the owner?",
        "jp": "所有者を特定できますか。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the key issues."
        ],
        "full": "We must IDENTIFY the key issues.",
        "jp": "私たちは主要な問題を特定しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 304,
    "word": "IDEOLOGY",
    "meaning_core": "イデオロギー",
    "syllables": [
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "de",
        "type": "weak"
      },
      {
        "text": "OL",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "gy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BELIEF": "信念",
      "DOCTRINE": "教義",
      "PHILOSOPHY": "哲学"
    },
    "distractors": [
      "FACT",
      "REALITY",
      "TRUTH",
      "SCIENCE"
    ],
    "meanings_expanded": [
      "イデオロギー",
      "思想傾向",
      "観念形態"
    ],
    "contexts": [
      {
        "parts": [
          "Political",
          "can divide people."
        ],
        "full": "Political IDEOLOGY can divide people.",
        "jp": "政治的イデオロギーは人々を分断しうる。",
        "is_correct": true
      },
      {
        "parts": [
          "He follows a specific political ",
          "."
        ],
        "full": "He follows a specific political IDEOLOGY.",
        "jp": "彼は特定の政治的イデオロギーに従っている。",
        "is_correct": true
      },
      {
        "parts": [
          "This book discusses communist ",
          "."
        ],
        "full": "This book discusses communist IDEOLOGY.",
        "jp": "この本は共産主義のイデオロギーについて論じている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 305,
    "word": "IGNORE",
    "meaning_core": "無視する",
    "syllables": [
      {
        "text": "ig",
        "type": "weak"
      },
      {
        "text": "NORE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DISREGARD": "軽視する",
      "OVERLOOK": "見落とす",
      "NEGLECT": "怠る"
    },
    "distractors": [
      "NOTICE",
      "HEED",
      "OBSERVE",
      "LISTEN"
    ],
    "meanings_expanded": [
      "無視する",
      "知らないふりをする"
    ],
    "contexts": [
      {
        "parts": [
          "Don't",
          "the warning signs."
        ],
        "full": "Don't IGNORE the warning signs.",
        "jp": "警告のサインを無視するな。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't ",
          " the warning signs."
        ],
        "full": "Don't IGNORE the warning signs.",
        "jp": "警告のサインを無視してはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "She chose to ",
          " his calls."
        ],
        "full": "She chose to IGNORE his calls.",
        "jp": "彼女は彼の電話を無視することを選んだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 306,
    "word": "ILLUSION",
    "meaning_core": "幻想",
    "syllables": [
      {
        "text": "il",
        "type": "weak"
      },
      {
        "text": "LU",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DELUSION": "妄想",
      "FANTASY": "空想",
      "HALLUCINATION": "幻覚"
    },
    "distractors": [
      "REALITY",
      "FACT",
      "TRUTH",
      "ACTUALITY"
    ],
    "meanings_expanded": [
      "幻想",
      "錯覚",
      "幻影"
    ],
    "contexts": [
      {
        "parts": [
          "The magician created an",
          "."
        ],
        "full": "The magician created an ILLUSION.",
        "jp": "手品師は錯覚を作り出した。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a trick of ",
          "."
        ],
        "full": "It was a trick of ILLUSION.",
        "jp": "それは目の錯覚だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He suffered from the ",
          " of greatness."
        ],
        "full": "He suffered from the ILLUSION of greatness.",
        "jp": "彼は偉大さの幻想に苦しんだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 307,
    "word": "ILLUSTRATE",
    "meaning_core": "例証する",
    "syllables": [
      {
        "text": "IL",
        "type": "strong"
      },
      {
        "text": "lus",
        "type": "weak"
      },
      {
        "text": "trate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEMONSTRATE": "実証する",
      "EXPLAIN": "説明する",
      "DEPICT": "描く"
    },
    "distractors": [
      "CONFUSE",
      "OBSCURE",
      "HIDE",
      "COMPLICATE"
    ],
    "meanings_expanded": [
      "例証する",
      "説明する",
      "挿絵を入れる"
    ],
    "contexts": [
      {
        "parts": [
          "Let me",
          "this point with a story."
        ],
        "full": "Let me ILLUSTRATE this point with a story.",
        "jp": "ある話でこの点を説明させてください。",
        "is_correct": true
      },
      {
        "parts": [
          "This graph will ",
          " the trend."
        ],
        "full": "This graph will ILLUSTRATE the trend.",
        "jp": "このグラフはその傾向を例証するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "She used a story to ",
          " her point."
        ],
        "full": "She used a story to ILLUSTRATE her point.",
        "jp": "彼女は自分の論点を説明するために話を使った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 308,
    "word": "IMMEDIATE",
    "meaning_core": "即座の",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "ME",
        "type": "strong"
      },
      {
        "text": "di",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INSTANT": "瞬時の",
      "PROMPT": "迅速な",
      "DIRECT": "直接の"
    },
    "distractors": [
      "DELAYED",
      "DISTANT",
      "SLOW",
      "LATER"
    ],
    "meanings_expanded": [
      "即座の",
      "直接の",
      "当面の"
    ],
    "contexts": [
      {
        "parts": [
          "We need an",
          "response."
        ],
        "full": "We need an IMMEDIATE response.",
        "jp": "即座の返答が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need an ",
          " response."
        ],
        "full": "We need an IMMEDIATE response.",
        "jp": "私たちには即座の対応が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is my ",
          " supervisor."
        ],
        "full": "He is my IMMEDIATE supervisor.",
        "jp": "彼は私の直属の上司だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 309,
    "word": "IMPENDING",
    "meaning_core": "差し迫った",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "PEND",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IMMINENT": "切迫した",
      "APPROACHING": "近づいている",
      "LOOMING": "迫りくる"
    },
    "distractors": [
      "DISTANT",
      "REMOTE",
      "PAST",
      "GONE"
    ],
    "meanings_expanded": [
      "差し迫った",
      "切迫した"
    ],
    "contexts": [
      {
        "parts": [
          "They warned of",
          "danger."
        ],
        "full": "They warned of IMPENDING danger.",
        "jp": "彼らは差し迫った危険について警告した。",
        "is_correct": true
      },
      {
        "parts": [
          "They prepared for the ",
          " storm."
        ],
        "full": "They prepared for the IMPENDING storm.",
        "jp": "彼らは差し迫った嵐に備えた。",
        "is_correct": true
      },
      {
        "parts": [
          "We feared an ",
          " disaster."
        ],
        "full": "We feared an IMPENDING disaster.",
        "jp": "私たちは差し迫った災害を恐れた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 310,
    "word": "IMPLEMENT",
    "meaning_core": "実行する",
    "syllables": [
      {
        "text": "IM",
        "type": "strong"
      },
      {
        "text": "ple",
        "type": "weak"
      },
      {
        "text": "ment",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXECUTE": "遂行する",
      "CARRY OUT": "実行する",
      "APPLY": "適用する"
    },
    "distractors": [
      "CANCEL",
      "DELAY",
      "STOP",
      "IGNORE"
    ],
    "meanings_expanded": [
      "実行する",
      "履行する",
      "道具"
    ],
    "contexts": [
      {
        "parts": [
          "We plan to",
          "the new rules soon."
        ],
        "full": "We plan to IMPLEMENT the new rules soon.",
        "jp": "私たちはまもなく新しいルールを実行する予定だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the new policy."
        ],
        "full": "We must IMPLEMENT the new policy.",
        "jp": "私たちは新しい政策を実行しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " the plan next year."
        ],
        "full": "They will IMPLEMENT the plan next year.",
        "jp": "彼らは来年その計画を実行するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 311,
    "word": "IMPLICATION",
    "meaning_core": "言外の意味",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "pli",
        "type": "weak"
      },
      {
        "text": "CA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUGGESTION": "暗示",
      "INFERENCE": "推論",
      "CONSEQUENCE": "結果"
    },
    "distractors": [
      "STATEMENT",
      "FACT",
      "PROOF",
      "REALITY"
    ],
    "meanings_expanded": [
      "言外の意味",
      "暗示",
      "影響"
    ],
    "contexts": [
      {
        "parts": [
          "What is the",
          "of his statement?"
        ],
        "full": "What is the IMPLICATION of his statement?",
        "jp": "彼の発言の言外の意味は何ですか？",
        "is_correct": true
      },
      {
        "parts": [
          "What is the political ",
          "?"
        ],
        "full": "What is the political IMPLICATION?",
        "jp": "政治的な言外の意味は何ですか。",
        "is_correct": true
      },
      {
        "parts": [
          "The findings have huge ",
          "."
        ],
        "full": "The findings have huge IMPLICATION.",
        "jp": "その調査結果は大きな影響（言外の意味）を持つ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 312,
    "word": "IMPLICITLY",
    "meaning_core": "暗黙のうちに",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "PLIC",
        "type": "strong"
      },
      {
        "text": "it",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TACITLY": "それとなく",
      "SILENTLY": "静かに",
      "INDIRECTLY": "間接的に"
    },
    "distractors": [
      "EXPLICITLY",
      "OPENLY",
      "DIRECTLY",
      "CLEARLY"
    ],
    "meanings_expanded": [
      "暗黙のうちに",
      "絶対的に"
    ],
    "contexts": [
      {
        "parts": [
          "She",
          "agreed to the plan."
        ],
        "full": "She IMPLICITLY agreed to the plan.",
        "jp": "彼女は暗黙のうちにその計画に同意した。",
        "is_correct": true
      },
      {
        "parts": [
          "He ",
          " agreed to the terms."
        ],
        "full": "He IMPLICITLY agreed to the terms.",
        "jp": "彼は暗黙のうちにその条件に同意した。",
        "is_correct": true
      },
      {
        "parts": [
          "The message was ",
          " clear."
        ],
        "full": "The message was IMPLICITLY clear.",
        "jp": "そのメッセージは暗黙のうちに明確だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 313,
    "word": "IMPOSING",
    "meaning_core": "堂々とした",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "POS",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IMPRESSIVE": "印象的な",
      "GRAND": "壮大な",
      "MAJESTIC": "威厳のある"
    },
    "distractors": [
      "SMALL",
      "MODEST",
      "HUMBLE",
      "TINY"
    ],
    "meanings_expanded": [
      "堂々とした",
      "印象的な"
    ],
    "contexts": [
      {
        "parts": [
          "The castle is an",
          "structure."
        ],
        "full": "The castle is an IMPOSING structure.",
        "jp": "その城は堂々とした建造物だ。",
        "is_correct": true
      },
      {
        "parts": [
          "It was an ",
          " sight."
        ],
        "full": "It was an IMPOSING sight.",
        "jp": "それは堂々とした光景だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The building looked very ",
          "."
        ],
        "full": "The building looked very IMPOSING.",
        "jp": "その建物は非常に威風堂々として見えた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 314,
    "word": "IMPRACTICAL",
    "meaning_core": "非実用的な",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "PRAC",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "UNREALISTIC": "非現実的な",
      "USELESS": "役に立たない",
      "IDEALISTIC": "理想主義的な"
    },
    "distractors": [
      "PRACTICAL",
      "USEFUL",
      "REALISTIC",
      "SENSIBLE"
    ],
    "meanings_expanded": [
      "非実用的な",
      "実践的でない"
    ],
    "contexts": [
      {
        "parts": [
          "Your idea sounds",
          "."
        ],
        "full": "Your idea sounds IMPRACTICAL.",
        "jp": "君のアイデアは非実用的に聞こえる。",
        "is_correct": true
      },
      {
        "parts": [
          "The idea is totally ",
          "."
        ],
        "full": "The idea is totally IMPRACTICAL.",
        "jp": "そのアイデアは完全に非実用的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This plan is too ",
          " to work."
        ],
        "full": "This plan is too IMPRACTICAL to work.",
        "jp": "この計画は非実用的すぎて機能しない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 315,
    "word": "IMPRESSIVE",
    "meaning_core": "印象的な",
    "syllables": [
      {
        "text": "im",
        "type": "weak"
      },
      {
        "text": "PRES",
        "type": "strong"
      },
      {
        "text": "sive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REMARKABLE": "注目すべき",
      "STRIKING": "際立った",
      "AWESOME": "素晴らしい"
    },
    "distractors": [
      "ORDINARY",
      "UNIMPRESSIVE",
      "BORING",
      "DULL"
    ],
    "meanings_expanded": [
      "印象的な",
      "感動的な"
    ],
    "contexts": [
      {
        "parts": [
          "She gave an",
          "performance."
        ],
        "full": "She gave an IMPRESSIVE performance.",
        "jp": "彼女は印象的な演技をした。",
        "is_correct": true
      },
      {
        "parts": [
          "She gave an ",
          " presentation."
        ],
        "full": "She gave an IMPRESSIVE presentation.",
        "jp": "彼女は印象的なプレゼンテーションを行った。",
        "is_correct": true
      },
      {
        "parts": [
          "The results were quite ",
          "."
        ],
        "full": "The results were quite IMPRESSIVE.",
        "jp": "その結果は非常に感銘を与えるものだった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 323,
    "word": "INCENTIVE",
    "meaning_core": "動機",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "CEN",
        "type": "strong"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MOTIVATION": "動機付け",
      "STIMULUS": "刺激",
      "REWARD": "報酬"
    },
    "distractors": [
      "PUNISHMENT",
      "PENALTY",
      "DETERRENT",
      "OBSTACLE"
    ],
    "meanings_expanded": [
      "動機",
      "誘因",
      "奨励金"
    ],
    "contexts": [
      {
        "parts": [
          "Money is a strong",
          "to work."
        ],
        "full": "Money is a strong INCENTIVE to work.",
        "jp": "お金は働くための強い動機となる。",
        "is_correct": true
      },
      {
        "parts": [
          "He lacked the",
          "to study."
        ],
        "full": "He lacked the INCENTIVE to study.",
        "jp": "彼には勉強する動機が欠けていた。",
        "is_correct": true
      },
      {
        "parts": [
          "The bonus is an extra ",
          "."
        ],
        "full": "The bonus is an extra INCENTIVE.",
        "jp": "ボーナスは追加の動機だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We offer staff a great ",
          "."
        ],
        "full": "We offer staff a great INCENTIVE.",
        "jp": "私たちはスタッフに大きな動機付けを提供する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 324,
    "word": "INCESSANTLY",
    "meaning_core": "絶え間なく",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "CES",
        "type": "strong"
      },
      {
        "text": "sant",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONSTANTLY": "絶えず",
      "CONTINUOUSLY": "連続して",
      "ENDLESSLY": "果てしなく"
    },
    "distractors": [
      "RARELY",
      "OCCASIONALLY",
      "SELDOM",
      "SPORADICALLY"
    ],
    "meanings_expanded": [
      "絶え間なく",
      "ひっきりなしに"
    ],
    "contexts": [
      {
        "parts": [
          "It rained",
          "for three days."
        ],
        "full": "It rained INCESSANTLY for three days.",
        "jp": "3日間、絶え間なく雨が降った。",
        "is_correct": true
      },
      {
        "parts": [
          "He talked",
          "during the movie."
        ],
        "full": "He talked INCESSANTLY during the movie.",
        "jp": "彼は映画の間中、ひっきりなしに話していた。",
        "is_correct": true
      },
      {
        "parts": [
          "The phone rang ",
          "."
        ],
        "full": "The phone rang INCESSANTLY.",
        "jp": "電話が絶え間なく鳴った。",
        "is_correct": true
      },
      {
        "parts": [
          "He complained ",
          " about the food."
        ],
        "full": "He complained INCESSANTLY about the food.",
        "jp": "彼は食事について絶えず不平を言った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 325,
    "word": "INCREASINGLY",
    "meaning_core": "ますます",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "CREAS",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MORE AND MORE": "ますます",
      "PROGRESSIVELY": "徐々に",
      "STEADILY": "着実に"
    },
    "distractors": [
      "LESS",
      "DECREASINGLY",
      "RARELY",
      "SELDOM"
    ],
    "meanings_expanded": [
      "ますます",
      "いよいよ",
      "さらに"
    ],
    "contexts": [
      {
        "parts": [
          "It is becoming",
          "difficult."
        ],
        "full": "It is becoming INCREASINGLY difficult.",
        "jp": "それはますます難しくなっている。",
        "is_correct": true
      },
      {
        "parts": [
          "He became",
          "popular."
        ],
        "full": "He became INCREASINGLY popular.",
        "jp": "彼はますます人気が出た。",
        "is_correct": true
      },
      {
        "parts": [
          "The work is ",
          " difficult."
        ],
        "full": "The work is INCREASINGLY difficult.",
        "jp": "その仕事はますます難しくなっている。",
        "is_correct": true
      },
      {
        "parts": [
          "It is becoming ",
          " clear."
        ],
        "full": "It is becoming INCREASINGLY clear.",
        "jp": "それはますます明らかになってきている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 326,
    "word": "INDEFINITELY",
    "meaning_core": "無期限に",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "DEF",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "nite",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENDLESSLY": "果てしなく",
      "FOREVER": "永遠に",
      "PERMANENTLY": "永続的に"
    },
    "distractors": [
      "TEMPORARILY",
      "BRIEFLY",
      "MOMENTARILY",
      "SHORTLY"
    ],
    "meanings_expanded": [
      "無期限に",
      "いつまでも"
    ],
    "contexts": [
      {
        "parts": [
          "The meeting was postponed",
          "."
        ],
        "full": "The meeting was postponed INDEFINITELY.",
        "jp": "会議は無期限に延期された。",
        "is_correct": true
      },
      {
        "parts": [
          "The meeting was postponed ",
          "."
        ],
        "full": "The meeting was postponed INDEFINITELY.",
        "jp": "会議は無期限に延期された。",
        "is_correct": true
      },
      {
        "parts": [
          "They stopped production ",
          "."
        ],
        "full": "They stopped production INDEFINITELY.",
        "jp": "彼らは生産を無期限に停止した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 327,
    "word": "INDIGENOUS",
    "meaning_core": "原産の",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "DIG",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "nous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NATIVE": "原産の",
      "LOCAL": "地元の",
      "ABORIGINAL": "先住の"
    },
    "distractors": [
      "FOREIGN",
      "ALIEN",
      "EXOTIC",
      "IMPORTED"
    ],
    "meanings_expanded": [
      "原産の",
      "先住の",
      "固有の"
    ],
    "contexts": [
      {
        "parts": [
          "These plants are",
          "to this region."
        ],
        "full": "These plants are INDIGENOUS to this region.",
        "jp": "これらの植物はこの地域の原産だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The kangaroo is",
          "to Australia."
        ],
        "full": "The kangaroo is INDIGENOUS to Australia.",
        "jp": "カンガルーはオーストラリア固有の動物だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is an ",
          " plant species."
        ],
        "full": "This is an INDIGENOUS plant species.",
        "jp": "これは原産の植物種だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We study the ",
          " people's culture."
        ],
        "full": "We study the INDIGENOUS people's culture.",
        "jp": "私たちは先住民の文化を研究する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 328,
    "word": "INDIGNANT",
    "meaning_core": "憤慨した",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "DIG",
        "type": "strong"
      },
      {
        "text": "nant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANGRY": "怒った",
      "OFFENDED": "気分を害した",
      "FURIOUS": "激怒した"
    },
    "distractors": [
      "HAPPY",
      "PLEASED",
      "CONTENT",
      "CALM"
    ],
    "meanings_expanded": [
      "憤慨した",
      "怒った"
    ],
    "contexts": [
      {
        "parts": [
          "She was",
          "about the insult."
        ],
        "full": "She was INDIGNANT about the insult.",
        "jp": "彼女はその侮辱に憤慨した。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave an",
          "reply."
        ],
        "full": "He gave an INDIGNANT reply.",
        "jp": "彼は憤然とした返事をした。",
        "is_correct": true
      },
      {
        "parts": [
          "She was ",
          " at the unfairness."
        ],
        "full": "She was INDIGNANT at the unfairness.",
        "jp": "彼女はその不公平さに憤慨した。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave an ",
          " reply."
        ],
        "full": "He gave an INDIGNANT reply.",
        "jp": "彼は憤慨した返答をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 329,
    "word": "INDIGNANTLY",
    "meaning_core": "憤慨して",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "DIG",
        "type": "strong"
      },
      {
        "text": "nant",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANGRILY": "怒って",
      "FURIOUSLY": "激怒して"
    },
    "distractors": [
      "HAPPILY",
      "CALMLY",
      "GENTLY",
      "SOFTLY"
    ],
    "meanings_expanded": [
      "憤慨して",
      "怒って"
    ],
    "contexts": [
      {
        "parts": [
          "'It's not fair!' she said",
          "."
        ],
        "full": "'It's not fair!' she said INDIGNANTLY.",
        "jp": "「不公平だ！」と彼女は憤慨して言った。",
        "is_correct": true
      },
      {
        "parts": [
          "He shouted",
          "at the referee."
        ],
        "full": "He shouted INDIGNANTLY at the referee.",
        "jp": "彼は審判に対して憤然と叫んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "She replied ",
          " to the accusation."
        ],
        "full": "She replied INDIGNANTLY to the accusation.",
        "jp": "彼女はその告発に憤慨して答えた。",
        "is_correct": true
      },
      {
        "parts": [
          "He walked out ",
          "."
        ],
        "full": "He walked out INDIGNANTLY.",
        "jp": "彼は憤慨して立ち去った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 330,
    "word": "INDISPENSABLE",
    "meaning_core": "不可欠な",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "dis",
        "type": "weak"
      },
      {
        "text": "PEN",
        "type": "strong"
      },
      {
        "text": "sa",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ESSENTIAL": "不可欠な",
      "CRUCIAL": "決定的な",
      "NECESSARY": "必要な"
    },
    "distractors": [
      "USELESS",
      "UNNECESSARY",
      "OPTIONAL",
      "DISPENSABLE"
    ],
    "meanings_expanded": [
      "不可欠な",
      "絶対必要な"
    ],
    "contexts": [
      {
        "parts": [
          "Water is",
          "to life."
        ],
        "full": "Water is INDISPENSABLE to life.",
        "jp": "水は生命にとって不可欠だ。",
        "is_correct": true
      },
      {
        "parts": [
          "His help was",
          "."
        ],
        "full": "His help was INDISPENSABLE.",
        "jp": "彼の助けは不可欠だった。",
        "is_correct": true
      },
      {
        "parts": [
          "Water is ",
          " for life."
        ],
        "full": "Water is INDISPENSABLE for life.",
        "jp": "水は生命にとって不可欠だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This tool is absolutely ",
          "."
        ],
        "full": "This tool is absolutely INDISPENSABLE.",
        "jp": "この道具は絶対的に不可欠だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 331,
    "word": "INDUCE",
    "meaning_core": "誘発する",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "DUCE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CAUSE": "引き起こす",
      "PROVOKE": "誘発する",
      "PERSUADE": "説得する"
    },
    "distractors": [
      "PREVENT",
      "STOP",
      "HALT",
      "DISCOURAGE"
    ],
    "meanings_expanded": [
      "誘発する",
      "引き起こす",
      "勧誘する"
    ],
    "contexts": [
      {
        "parts": [
          "The drug may",
          "sleep."
        ],
        "full": "The drug may INDUCE sleep.",
        "jp": "その薬は眠気を誘発するかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "Nothing could",
          "him to stay."
        ],
        "full": "Nothing could INDUCE him to stay.",
        "jp": "何があっても彼を引き留めることはできなかった（彼を説得して留まらせることはできなかった）。",
        "is_correct": true
      },
      {
        "parts": [
          "The medicine might ",
          " sleep."
        ],
        "full": "The medicine might INDUCE sleep.",
        "jp": "その薬は眠気を誘発するかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "Fear can ",
          " panic."
        ],
        "full": "Fear can INDUCE panic.",
        "jp": "恐怖はパニックを引き起こす可能性がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 332,
    "word": "INFECTIOUS",
    "meaning_core": "伝染性の",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "FEC",
        "type": "strong"
      },
      {
        "text": "tious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTAGIOUS": "感染性の",
      "CATCHING": "移りやすい",
      "SPREADING": "広がる"
    },
    "distractors": [
      "HARMLESS",
      "NONINFECTIOUS",
      "SAFE",
      "HEALTHY"
    ],
    "meanings_expanded": [
      "伝染性の",
      "感染症の"
    ],
    "contexts": [
      {
        "parts": [
          "The flu is highly",
          "."
        ],
        "full": "The flu is highly INFECTIOUS.",
        "jp": "インフルエンザは非常に伝染性が高い。",
        "is_correct": true
      },
      {
        "parts": [
          "His enthusiasm was",
          "."
        ],
        "full": "His enthusiasm was INFECTIOUS.",
        "jp": "彼の熱意は周りに伝染した。",
        "is_correct": true
      },
      {
        "parts": [
          "The disease is highly ",
          "."
        ],
        "full": "The disease is highly INFECTIOUS.",
        "jp": "その病気は非常に感染性が高い。",
        "is_correct": true
      },
      {
        "parts": [
          "She has an ",
          " laugh."
        ],
        "full": "She has an INFECTIOUS laugh.",
        "jp": "彼女は伝染性の笑い方をする。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 333,
    "word": "INFINITELY",
    "meaning_core": "無限に",
    "syllables": [
      {
        "text": "IN",
        "type": "strong"
      },
      {
        "text": "fi",
        "type": "weak"
      },
      {
        "text": "nite",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENDLESSLY": "果てしなく",
      "BOUNDLESSLY": "限りなく",
      "VASTLY": "広大に"
    },
    "distractors": [
      "LIMITEDLY",
      "FINITELY",
      "SLIGHTLY",
      "LITTLE"
    ],
    "meanings_expanded": [
      "無限に",
      "はるかに"
    ],
    "contexts": [
      {
        "parts": [
          "The universe is",
          "large."
        ],
        "full": "The universe is INFINITELY large.",
        "jp": "宇宙は無限に大きい。",
        "is_correct": true
      },
      {
        "parts": [
          "This is",
          "better."
        ],
        "full": "This is INFINITELY better.",
        "jp": "これのほうがはるかに良い。",
        "is_correct": true
      },
      {
        "parts": [
          "The possibilities are ",
          "."
        ],
        "full": "The possibilities are INFINITELY.",
        "jp": "可能性は無限だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is ",
          " better than me."
        ],
        "full": "He is INFINITELY better than me.",
        "jp": "彼は私より無限に優れている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 334,
    "word": "INFLUENTIAL",
    "meaning_core": "影響力のある",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "flu",
        "type": "weak"
      },
      {
        "text": "EN",
        "type": "strong"
      },
      {
        "text": "tial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POWERFUL": "強力な",
      "IMPORTANT": "重要な",
      "DOMINANT": "支配的な"
    },
    "distractors": [
      "WEAK",
      "INSIGNIFICANT",
      "POWERLESS",
      "MINOR"
    ],
    "meanings_expanded": [
      "影響力のある",
      "有力な"
    ],
    "contexts": [
      {
        "parts": [
          "He is an",
          "politician."
        ],
        "full": "He is an INFLUENTIAL politician.",
        "jp": "彼は有力な政治家だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She played an",
          "role."
        ],
        "full": "She played an INFLUENTIAL role.",
        "jp": "彼女は影響力のある役割を果たした。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an ",
          " figure in politics."
        ],
        "full": "He is an INFLUENTIAL figure in politics.",
        "jp": "彼は政治において影響力のある人物だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Her work was highly ",
          "."
        ],
        "full": "Her work was highly INFLUENTIAL.",
        "jp": "彼女の作品は非常に影響力があった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 335,
    "word": "INFRASTRUCTURE",
    "meaning_core": "社会基盤",
    "syllables": [
      {
        "text": "IN",
        "type": "strong"
      },
      {
        "text": "fra",
        "type": "weak"
      },
      {
        "text": "struc",
        "type": "weak"
      },
      {
        "text": "ture",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FOUNDATION": "基盤",
      "BASE": "土台",
      "FRAMEWORK": "枠組み"
    },
    "distractors": [
      "DECORATION",
      "ORNAMENT",
      "ACCESSORY",
      "DETAIL"
    ],
    "meanings_expanded": [
      "インフラ",
      "社会基盤",
      "下部構造"
    ],
    "contexts": [
      {
        "parts": [
          "The country needs to improve its",
          "."
        ],
        "full": "The country needs to improve its INFRASTRUCTURE.",
        "jp": "その国はインフラを改善する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Roads and bridges are part of the",
          "."
        ],
        "full": "Roads and bridges are part of the INFRASTRUCTURE.",
        "jp": "道路や橋は社会基盤の一部だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The city needs better ",
          "."
        ],
        "full": "The city needs better INFRASTRUCTURE.",
        "jp": "その都市はより良い社会基盤を必要としている。",
        "is_correct": true
      },
      {
        "parts": [
          "We invest in digital ",
          "."
        ],
        "full": "We invest in digital INFRASTRUCTURE.",
        "jp": "私たちはデジタルインフラに投資する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 336,
    "word": "INHERENT",
    "meaning_core": "本来備わっている",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "HER",
        "type": "strong"
      },
      {
        "text": "ent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INTRINSIC": "本来の",
      "NATIVE": "生来の",
      "BUILT-IN": "組み込みの"
    },
    "distractors": [
      "ACQUIRED",
      "EXTERNAL",
      "ALIEN",
      "FOREIGN"
    ],
    "meanings_expanded": [
      "本来備わっている",
      "固有の",
      "生来の"
    ],
    "contexts": [
      {
        "parts": [
          "There are risks",
          "in this plan."
        ],
        "full": "There are risks INHERENT in this plan.",
        "jp": "この計画には固有のリスクがある。",
        "is_correct": true
      },
      {
        "parts": [
          "Freedom is an",
          "right."
        ],
        "full": "Freedom is an INHERENT right.",
        "jp": "自由は天賦の権利だ。",
        "is_correct": true
      },
      {
        "parts": [
          "There is an ",
          " risk in this job."
        ],
        "full": "There is an INHERENT risk in this job.",
        "jp": "この仕事には本来備わっているリスクがある。",
        "is_correct": true
      },
      {
        "parts": [
          "The problem is ",
          " in the system."
        ],
        "full": "The problem is INHERENT in the system.",
        "jp": "その問題はシステムに内在している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 337,
    "word": "INITIATE",
    "meaning_core": "開始する",
    "syllables": [
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "NI",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "START": "始める",
      "BEGIN": "開始する",
      "LAUNCH": "着手する"
    },
    "distractors": [
      "STOP",
      "END",
      "FINISH",
      "HALT"
    ],
    "meanings_expanded": [
      "開始する",
      "着手する",
      "手ほどきをする"
    ],
    "contexts": [
      {
        "parts": [
          "They plan to",
          "a new project."
        ],
        "full": "They plan to INITIATE a new project.",
        "jp": "彼らは新しいプロジェクトを開始する計画だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He was",
          "into the club."
        ],
        "full": "He was initiated into the club.",
        "jp": "彼はクラブに入会させられた。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " the plan tomorrow."
        ],
        "full": "We will INITIATE the plan tomorrow.",
        "jp": "私たちは明日その計画を開始する。",
        "is_correct": true
      },
      {
        "parts": [
          "Who will ",
          " the discussion?"
        ],
        "full": "Who will INITIATE the discussion?",
        "jp": "誰が議論を始めるのか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 338,
    "word": "INITIATIVE",
    "meaning_core": "主導権",
    "syllables": [
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "NI",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LEADERSHIP": "指導力",
      "PLAN": "計画",
      "ACTION": "行動"
    },
    "distractors": [
      "APATHY",
      "LAZINESS",
      "INACTION",
      "PASSIVITY"
    ],
    "meanings_expanded": [
      "主導権",
      "自発性",
      "新しい取り組み"
    ],
    "contexts": [
      {
        "parts": [
          "He took the",
          "to solve the problem."
        ],
        "full": "He took the INITIATIVE to solve the problem.",
        "jp": "彼は率先して（主導権を取って）問題を解決した。",
        "is_correct": true
      },
      {
        "parts": [
          "The government launched a new",
          "."
        ],
        "full": "The government launched a new INITIATIVE.",
        "jp": "政府は新しい取り組みを開始した。",
        "is_correct": true
      },
      {
        "parts": [
          "She took the ",
          "."
        ],
        "full": "She took the INITIATIVE.",
        "jp": "彼女が主導権を握った。",
        "is_correct": true
      },
      {
        "parts": [
          "We launched a new sales ",
          "."
        ],
        "full": "We launched a new sales INITIATIVE.",
        "jp": "私たちは新しい販売戦略（主導権）を開始した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 339,
    "word": "INNATE",
    "meaning_core": "生まれつきの",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "NATE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "NATURAL": "生まれつきの",
      "INBORN": "先天的な",
      "INHERENT": "本来の"
    },
    "distractors": [
      "ACQUIRED",
      "LEARNED",
      "FOREIGN",
      "ARTIFICIAL"
    ],
    "meanings_expanded": [
      "生まれつきの",
      "先天的な"
    ],
    "contexts": [
      {
        "parts": [
          "She has an",
          "talent for music."
        ],
        "full": "She has an INNATE talent for music.",
        "jp": "彼女には音楽の天賦の才がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Language ability is",
          "."
        ],
        "full": "Language ability is INNATE.",
        "jp": "言語能力は生まれつきのものだ（という説がある）。",
        "is_correct": true
      },
      {
        "parts": [
          "She has an ",
          " musical talent."
        ],
        "full": "She has an INNATE musical talent.",
        "jp": "彼女は生まれつきの音楽の才能を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "Courage is an ",
          " quality."
        ],
        "full": "Courage is an INNATE quality.",
        "jp": "勇気は生まれつき備わっている資質だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 340,
    "word": "INNOVATION",
    "meaning_core": "革新",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "no",
        "type": "weak"
      },
      {
        "text": "VA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INVENTION": "発明",
      "CHANGE": "変革",
      "NOVELTY": "新しさ"
    },
    "distractors": [
      "TRADITION",
      "ROUTINE",
      "HABIT",
      "STAGNATION"
    ],
    "meanings_expanded": [
      "革新",
      "技術革新",
      "新機軸"
    ],
    "contexts": [
      {
        "parts": [
          "Technological",
          "changes our lives."
        ],
        "full": "Technological INNOVATION changes our lives.",
        "jp": "技術革新は私たちの生活を変える。",
        "is_correct": true
      },
      {
        "parts": [
          "We need",
          "in design."
        ],
        "full": "We need INNOVATION in design.",
        "jp": "デザインにおける革新が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We encourage technical ",
          "."
        ],
        "full": "We encourage technical INNOVATION.",
        "jp": "私たちは技術革新を奨励する。",
        "is_correct": true
      },
      {
        "parts": [
          "The product shows great ",
          "."
        ],
        "full": "The product shows great INNOVATION.",
        "jp": "その製品は大きな革新を示している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 341,
    "word": "INQUIRY",
    "meaning_core": "調査",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "QUIR",
        "type": "strong"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INVESTIGATION": "調査",
      "QUESTION": "質問",
      "QUERY": "問い合わせ"
    },
    "distractors": [
      "ANSWER",
      "REPLY",
      "RESPONSE",
      "STATEMENT"
    ],
    "meanings_expanded": [
      "調査",
      "問い合わせ",
      "探求"
    ],
    "contexts": [
      {
        "parts": [
          "The police launched an",
          "into the case."
        ],
        "full": "The police launched an INQUIRY into the case.",
        "jp": "警察はその事件の調査を開始した。",
        "is_correct": true
      },
      {
        "parts": [
          "We received an",
          "about the product."
        ],
        "full": "We received an INQUIRY about the product.",
        "jp": "その製品についての問い合わせを受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "We received an ",
          " about the job."
        ],
        "full": "We received an INQUIRY about the job.",
        "jp": "私たちはその仕事についての問い合わせを受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "The police opened a serious ",
          "."
        ],
        "full": "The police opened a serious INQUIRY.",
        "jp": "警察は深刻な調査を開始した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 342,
    "word": "INSIDE",
    "meaning_core": "～の内側に",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "SIDE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "WITHIN": "内部に",
      "IN": "中に"
    },
    "distractors": [
      "OUTSIDE",
      "WITHOUT",
      "EXTERIOR"
    ],
    "meanings_expanded": [
      "～の内側に",
      "～の中に"
    ],
    "contexts": [
      {
        "parts": [
          "He stayed",
          "the house."
        ],
        "full": "He stayed INSIDE the house.",
        "jp": "彼は家の中にいた。",
        "is_correct": true
      },
      {
        "parts": [
          "The toy was",
          "the box."
        ],
        "full": "The toy was INSIDE the box.",
        "jp": "おもちゃは箱の中にあった。",
        "is_correct": true
      },
      {
        "parts": [
          "Leave your shoes ",
          " the door."
        ],
        "full": "Leave your shoes INSIDE the door.",
        "jp": "靴をドアの内側に置いてください。",
        "is_correct": true
      },
      {
        "parts": [
          "The secret is hidden deep ",
          "."
        ],
        "full": "The secret is hidden deep INSIDE.",
        "jp": "その秘密は奥深くに隠されている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 343,
    "word": "INSIST",
    "meaning_core": "主張する",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "SIST",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DEMAND": "要求する",
      "ASSERT": "断言する",
      "PERSIST": "固執する"
    },
    "distractors": [
      "GIVE UP",
      "YIELD",
      "AGREE",
      "COMPLY"
    ],
    "meanings_expanded": [
      "主張する",
      "言い張る",
      "強く要求する"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "on paying for dinner."
        ],
        "full": "I INSIST on paying for dinner.",
        "jp": "夕食代は私が払うと言い張ります。",
        "is_correct": true
      },
      {
        "parts": [
          "He",
          "that he was innocent."
        ],
        "full": "He insisted that he was innocent.",
        "jp": "彼は自分が無実だと主張した。",
        "is_correct": true
      },
      {
        "parts": [
          "She will ",
          " on a refund."
        ],
        "full": "She will INSIST on a refund.",
        "jp": "彼女は払い戻しを強く要求するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "They ",
          " that he attend."
        ],
        "full": "They INSIST that he attend.",
        "jp": "彼らは彼が出席することを主張する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 344,
    "word": "INSTANTANEOUSLY",
    "meaning_core": "すぐに",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "stan",
        "type": "weak"
      },
      {
        "text": "TA",
        "type": "strong"
      },
      {
        "text": "neous",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IMMEDIATELY": "即座に",
      "INSTANTLY": "瞬時に",
      "AT ONCE": "直ちに"
    },
    "distractors": [
      "SLOWLY",
      "GRADUALLY",
      "LATER",
      "EVENTUALLY"
    ],
    "meanings_expanded": [
      "即座に",
      "瞬時に"
    ],
    "contexts": [
      {
        "parts": [
          "The bomb exploded",
          "."
        ],
        "full": "The bomb exploded INSTANTANEOUSLY.",
        "jp": "爆弾は瞬時に爆発した。",
        "is_correct": true
      },
      {
        "parts": [
          "The message was sent",
          "."
        ],
        "full": "The message was sent INSTANTANEOUSLY.",
        "jp": "メッセージは即座に送信された。",
        "is_correct": true
      },
      {
        "parts": [
          "The light went out ",
          "."
        ],
        "full": "The light went out INSTANTANEOUSLY.",
        "jp": "明かりはすぐに消えた。",
        "is_correct": true
      },
      {
        "parts": [
          "The signal was sent ",
          "."
        ],
        "full": "The signal was sent INSTANTANEOUSLY.",
        "jp": "その信号は瞬時に送信された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 345,
    "word": "INTEGRITY",
    "meaning_core": "誠実さ",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "TEG",
        "type": "strong"
      },
      {
        "text": "ri",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HONESTY": "正直",
      "MORALITY": "道徳性",
      "UPRIGHTNESS": "高潔"
    },
    "distractors": [
      "DISHONESTY",
      "CORRUPTION",
      "DECEIT",
      "FRAUD"
    ],
    "meanings_expanded": [
      "誠実さ",
      "高潔",
      "完全性"
    ],
    "contexts": [
      {
        "parts": [
          "He is a man of",
          "."
        ],
        "full": "He is a man of INTEGRITY.",
        "jp": "彼は誠実な人だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The engineer checked the structural",
          "."
        ],
        "full": "The engineer checked the structural INTEGRITY.",
        "jp": "技術者は構造の完全性をチェックした。",
        "is_correct": true
      },
      {
        "parts": [
          "He is known for his ",
          "."
        ],
        "full": "He is known for his INTEGRITY.",
        "jp": "彼は誠実さで知られている。",
        "is_correct": true
      },
      {
        "parts": [
          "We doubt the system's ",
          "."
        ],
        "full": "We doubt the system's INTEGRITY.",
        "jp": "私たちはシステムの完全性を疑う。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 346,
    "word": "INTELLECTUAL",
    "meaning_core": "知的な",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "tel",
        "type": "weak"
      },
      {
        "text": "LEC",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MENTAL": "精神の",
      "ACADEMIC": "学問的な",
      "SMART": "賢い"
    },
    "distractors": [
      "PHYSICAL",
      "EMOTIONAL",
      "FOOLISH",
      "STUPID"
    ],
    "meanings_expanded": [
      "知的な",
      "知性の",
      "知識人"
    ],
    "contexts": [
      {
        "parts": [
          "She has great",
          "curiosity."
        ],
        "full": "She has great INTELLECTUAL curiosity.",
        "jp": "彼女は旺盛な知的好奇心を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "Protect your",
          "property."
        ],
        "full": "Protect your INTELLECTUAL property.",
        "jp": "知的財産を守りなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "She has vast ",
          " potential."
        ],
        "full": "She has vast INTELLECTUAL potential.",
        "jp": "彼女は広大な知的潜在能力を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The problem is purely ",
          "."
        ],
        "full": "The problem is purely INTELLECTUAL.",
        "jp": "その問題は純粋に知的なものだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 347,
    "word": "INTERFERE",
    "meaning_core": "干渉する",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "ter",
        "type": "weak"
      },
      {
        "text": "FERE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MEDDLE": "おせっかいをする",
      "HINDER": "妨げる",
      "OBSTRUCT": "邪魔する"
    },
    "distractors": [
      "HELP",
      "ASSIST",
      "SUPPORT",
      "AID"
    ],
    "meanings_expanded": [
      "干渉する",
      "邪魔する",
      "介入する"
    ],
    "contexts": [
      {
        "parts": [
          "Don't",
          "in my business."
        ],
        "full": "Don't INTERFERE in my business.",
        "jp": "私のことに干渉しないで。",
        "is_correct": true
      },
      {
        "parts": [
          "Noise can",
          "with sleep."
        ],
        "full": "Noise can INTERFERE with sleep.",
        "jp": "騒音は睡眠を妨げることがある。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " with my work."
        ],
        "full": "Do not INTERFERE with my work.",
        "jp": "私の仕事に干渉しないでください。",
        "is_correct": true
      },
      {
        "parts": [
          "His illness will ",
          " with his studies."
        ],
        "full": "His illness will INTERFERE with his studies.",
        "jp": "彼の病気が彼の勉強を妨げるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 348,
    "word": "INTERVENE",
    "meaning_core": "介入する",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "ter",
        "type": "weak"
      },
      {
        "text": "VENE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "STEP IN": "介入する",
      "MEDIATE": "調停する",
      "INTERFERE": "干渉する"
    },
    "distractors": [
      "IGNORE",
      "WITHDRAW",
      "LEAVE",
      "NEGLECT"
    ],
    "meanings_expanded": [
      "介入する",
      "仲裁する",
      "介在する"
    ],
    "contexts": [
      {
        "parts": [
          "The police had to",
          "to stop the fight."
        ],
        "full": "The police had to INTERVENE to stop the fight.",
        "jp": "喧嘩を止めるために警察が介入しなければならなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "The government refused to",
          "."
        ],
        "full": "The government refused to INTERVENE.",
        "jp": "政府は介入を拒否した。",
        "is_correct": true
      },
      {
        "parts": [
          "The UN decided to ",
          "."
        ],
        "full": "The UN decided to INTERVENE.",
        "jp": "国連は介入することを決定した。",
        "is_correct": true
      },
      {
        "parts": [
          "I had to ",
          " in the argument."
        ],
        "full": "I had to INTERVENE in the argument.",
        "jp": "私はその議論に介入しなければならなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 349,
    "word": "INTRICATE",
    "meaning_core": "複雑な",
    "syllables": [
      {
        "text": "IN",
        "type": "strong"
      },
      {
        "text": "tri",
        "type": "weak"
      },
      {
        "text": "cate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLEX": "複雑な",
      "COMPLICATED": "込み入った",
      "ELABORATE": "精巧な"
    },
    "distractors": [
      "SIMPLE",
      "PLAIN",
      "EASY",
      "BASIC"
    ],
    "meanings_expanded": [
      "入り組んだ",
      "複雑な",
      "難解な"
    ],
    "contexts": [
      {
        "parts": [
          "The watch has an",
          "mechanism."
        ],
        "full": "The watch has an INTRICATE mechanism.",
        "jp": "その時計は複雑な機構を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "This is an",
          "design."
        ],
        "full": "This is an INTRICATE design.",
        "jp": "これは入り組んだデザインだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The design was ",
          "."
        ],
        "full": "The design was INTRICATE.",
        "jp": "そのデザインは複雑だった。",
        "is_correct": true
      },
      {
        "parts": [
          "She wore an ",
          " pattern dress."
        ],
        "full": "She wore an INTRICATE pattern dress.",
        "jp": "彼女は複雑な模様のドレスを着ていた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 350,
    "word": "INTRICATELY",
    "meaning_core": "複雑に",
    "syllables": [
      {
        "text": "IN",
        "type": "strong"
      },
      {
        "text": "tri",
        "type": "weak"
      },
      {
        "text": "cate",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLEXLY": "複雑に",
      "ELABORATELY": "精巧に"
    },
    "distractors": [
      "SIMPLY",
      "PLAINLY",
      "EASILY",
      "CLEARLY"
    ],
    "meanings_expanded": [
      "複雑に",
      "入り組んで"
    ],
    "contexts": [
      {
        "parts": [
          "The rug is",
          "woven."
        ],
        "full": "The rug is INTRICATELY woven.",
        "jp": "その敷物は複雑に織られている。",
        "is_correct": true
      },
      {
        "parts": [
          "The plot is",
          "constructed."
        ],
        "full": "The plot is INTRICATELY constructed.",
        "jp": "その筋書きは複雑に構成されている。",
        "is_correct": true
      },
      {
        "parts": [
          "The parts are ",
          " connected."
        ],
        "full": "The parts are INTRICATELY connected.",
        "jp": "部品は複雑に接続されている。",
        "is_correct": true
      },
      {
        "parts": [
          "The story is ",
          " woven."
        ],
        "full": "The story is INTRICATELY woven.",
        "jp": "その物語は複雑に織り込まれている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 351,
    "word": "INTRINSIC",
    "meaning_core": "本来備わっている",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "TRIN",
        "type": "strong"
      },
      {
        "text": "sic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INHERENT": "固有の",
      "INNATE": "生まれつきの",
      "ESSENTIAL": "本質的な"
    },
    "distractors": [
      "EXTRINSIC",
      "ACQUIRED",
      "EXTERNAL",
      "ACCIDENTAL"
    ],
    "meanings_expanded": [
      "本来備わっている",
      "固有の",
      "本質的な"
    ],
    "contexts": [
      {
        "parts": [
          "Gold has",
          "value."
        ],
        "full": "Gold has INTRINSIC value.",
        "jp": "金には本質的な価値がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The painting has great ",
          " value."
        ],
        "full": "The painting has great INTRINSIC value.",
        "jp": "その絵画は大きな本質的価値を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "Joy is an ",
          " human desire."
        ],
        "full": "Joy is an INTRINSIC human desire.",
        "jp": "喜びは本来備わっている人間の願望だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 352,
    "word": "INVALID",
    "meaning_core": "無効な",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "VAL",
        "type": "strong"
      },
      {
        "text": "id",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VOID": "無効の",
      "NULL": "無価値の",
      "FALSE": "誤った"
    },
    "distractors": [
      "VALID",
      "LEGAL",
      "TRUE",
      "SOUND"
    ],
    "meanings_expanded": [
      "無効な",
      "根拠のない"
    ],
    "contexts": [
      {
        "parts": [
          "Your passport is",
          "."
        ],
        "full": "Your passport is INVALID.",
        "jp": "あなたのパスポートは無効だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The ticket is now ",
          "."
        ],
        "full": "The ticket is now INVALID.",
        "jp": "そのチケットはもう無効だ。",
        "is_correct": true
      },
      {
        "parts": [
          "His argument was legally ",
          "."
        ],
        "full": "His argument was legally INVALID.",
        "jp": "彼の主張は法的に無効だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 353,
    "word": "INVARIABLY",
    "meaning_core": "いつも",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "VAR",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "bly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ALWAYS": "常に",
      "CONSTANTLY": "絶えず",
      "PERPETUALLY": "永続的に"
    },
    "distractors": [
      "NEVER",
      "RARELY",
      "SELDOM",
      "SOMETIMES"
    ],
    "meanings_expanded": [
      "いつも",
      "変わることなく",
      "必ず"
    ],
    "contexts": [
      {
        "parts": [
          "He is",
          "late for meetings."
        ],
        "full": "He is INVARIABLY late for meetings.",
        "jp": "彼は決まって（いつも）会議に遅れる。",
        "is_correct": true
      },
      {
        "parts": [
          "The train is ",
          " late."
        ],
        "full": "The train is INVARIABLY late.",
        "jp": "その電車はいつも遅れる。",
        "is_correct": true
      },
      {
        "parts": [
          "Success ",
          " requires hard work."
        ],
        "full": "Success INVARIABLY requires hard work.",
        "jp": "成功は常に勤勉さを必要とする。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 354,
    "word": "INVENT",
    "meaning_core": "発明する",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "VENT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CREATE": "創造する",
      "DEVISE": "考案する",
      "DESIGN": "設計する"
    },
    "distractors": [
      "DESTROY",
      "COPY",
      "IMITATE",
      "RUIN"
    ],
    "meanings_expanded": [
      "発明する",
      "考案する",
      "でっち上げる"
    ],
    "contexts": [
      {
        "parts": [
          "Edison didn't",
          "the light bulb alone."
        ],
        "full": "Edison didn't INVENT the light bulb alone.",
        "jp": "エジソンは一人で電球を発明したわけではない。",
        "is_correct": true
      },
      {
        "parts": [
          "Who did ",
          " the telephone?"
        ],
        "full": "Who did INVENT the telephone?",
        "jp": "誰が電話を発明したのか。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " a new solution."
        ],
        "full": "We need to INVENT a new solution.",
        "jp": "私たちは新しい解決策を発明する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 355,
    "word": "INVOLVE",
    "meaning_core": "～を伴う",
    "syllables": [
      {
        "text": "in",
        "type": "weak"
      },
      {
        "text": "VOLVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INCLUDE": "含む",
      "ENTAIL": "伴う",
      "REQUIRE": "必要とする"
    },
    "distractors": [
      "EXCLUDE",
      "OMIT",
      "IGNORE",
      "REJECT"
    ],
    "meanings_expanded": [
      "～を伴う",
      "巻き込む",
      "熱中させる"
    ],
    "contexts": [
      {
        "parts": [
          "The job will",
          "travel."
        ],
        "full": "The job will INVOLVE travel.",
        "jp": "その仕事は移動（出張）を伴うだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "me in your argument."
        ],
        "full": "Don't INVOLVE me in your argument.",
        "jp": "私を口論に巻き込まないで。",
        "is_correct": true
      },
      {
        "parts": [
          "The job will ",
          " travel."
        ],
        "full": "The job will INVOLVE travel.",
        "jp": "その仕事は旅行を伴うだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "How many people are ",
          "?"
        ],
        "full": "How many people are INVOLVE?",
        "jp": "何人の人が関わっていますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 356,
    "word": "IRRITATING",
    "meaning_core": "いらいらさせる",
    "syllables": [
      {
        "text": "IR",
        "type": "strong"
      },
      {
        "text": "ri",
        "type": "weak"
      },
      {
        "text": "tat",
        "type": "weak"
      },
      {
        "text": "ing",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANNOYING": "うっとうしい",
      "BATHERSOME": "厄介な",
      "FRUSTRATING": "イライラさせる"
    },
    "distractors": [
      "PLEASANT",
      "SOOTHING",
      "CALMING",
      "DELIGHTFUL"
    ],
    "meanings_expanded": [
      "いらいらさせる",
      "刺激する"
    ],
    "contexts": [
      {
        "parts": [
          "He has an",
          "habit."
        ],
        "full": "He has an IRRITATING habit.",
        "jp": "彼にはイライラさせる癖がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The constant noise is ",
          "."
        ],
        "full": "The constant noise is IRRITATING.",
        "jp": "絶え間ない騒音はいらいらさせる。",
        "is_correct": true
      },
      {
        "parts": [
          "His constant humming is ",
          "."
        ],
        "full": "His constant humming is IRRITATING.",
        "jp": "彼の絶え間ない鼻歌はいらいらさせる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 357,
    "word": "IRRITATION",
    "meaning_core": "いらだち",
    "syllables": [
      {
        "text": "ir",
        "type": "weak"
      },
      {
        "text": "ri",
        "type": "weak"
      },
      {
        "text": "TA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANNOYANCE": "いらだち",
      "ANGER": "怒り",
      "AGITATION": "動揺"
    },
    "distractors": [
      "PLEASURE",
      "JOY",
      "COMFORT",
      "DELIGHT"
    ],
    "meanings_expanded": [
      "いらだち",
      "炎症",
      "刺激"
    ],
    "contexts": [
      {
        "parts": [
          "He couldn't hide his",
          "."
        ],
        "full": "He couldn't hide his IRRITATION.",
        "jp": "彼はいらだちを隠せなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "The cream reduces skin",
          "."
        ],
        "full": "The cream reduces skin IRRITATION.",
        "jp": "そのクリームは肌の炎症を抑える。",
        "is_correct": true
      },
      {
        "parts": [
          "He expressed his ",
          "."
        ],
        "full": "He expressed his IRRITATION.",
        "jp": "彼は自分のいらだちを表明した。",
        "is_correct": true
      },
      {
        "parts": [
          "The rash caused skin ",
          "."
        ],
        "full": "The rash caused skin IRRITATION.",
        "jp": "その発疹は皮膚の炎症（いらだち）を引き起こした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 358,
    "word": "ITINERARY",
    "meaning_core": "旅程",
    "syllables": [
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "TIN",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ar",
        "type": "weak"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SCHEDULE": "予定",
      "ROUTE": "ルート",
      "PLAN": "計画"
    },
    "distractors": [
      "DESTINATION",
      "LUGGAGE",
      "PASSPORT",
      "TICKET"
    ],
    "meanings_expanded": [
      "旅程",
      "旅行計画"
    ],
    "contexts": [
      {
        "parts": [
          "Here is a copy of my",
          "."
        ],
        "full": "Here is a copy of my ITINERARY.",
        "jp": "これが私の旅程のコピーです。",
        "is_correct": true
      },
      {
        "parts": [
          "We reviewed the travel ",
          "."
        ],
        "full": "We reviewed the travel ITINERARY.",
        "jp": "私たちは旅行の旅程を確認した。",
        "is_correct": true
      },
      {
        "parts": [
          "Send me your detailed ",
          "."
        ],
        "full": "Send me your detailed ITINERARY.",
        "jp": "あなたの詳細な旅程を送ってください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 359,
    "word": "JUDICIOUSLY",
    "meaning_core": "賢明に",
    "syllables": [
      {
        "text": "ju",
        "type": "weak"
      },
      {
        "text": "DI",
        "type": "strong"
      },
      {
        "text": "cious",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WISELY": "賢く",
      "SENSIBLY": "分別を持って",
      "PRUDENTLY": "慎重に"
    },
    "distractors": [
      "FOOLISHLY",
      "RASHLY",
      "CARELESSLY",
      "STUPIDLY"
    ],
    "meanings_expanded": [
      "賢明に",
      "慎重に"
    ],
    "contexts": [
      {
        "parts": [
          "You should spend money",
          "."
        ],
        "full": "You should spend money JUDICIOUSLY.",
        "jp": "お金は賢明に使うべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Use your time ",
          "."
        ],
        "full": "Use your time JUDICIOUSLY.",
        "jp": "時間を賢明に使いなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "She invested her money ",
          "."
        ],
        "full": "She invested her money JUDICIOUSLY.",
        "jp": "彼女は賢明に自分の資金を投資した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 360,
    "word": "JUSTIFY",
    "meaning_core": "正当化する",
    "syllables": [
      {
        "text": "JUS",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "fy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEFEND": "弁護する",
      "VALIDATE": "正当と認める",
      "EXCUSE": "弁解する"
    },
    "distractors": [
      "CONDEMN",
      "CRITICIZE",
      "ATTACK",
      "BLAME"
    ],
    "meanings_expanded": [
      "正当化する",
      "弁明する",
      "正当な理由となる"
    ],
    "contexts": [
      {
        "parts": [
          "You can't",
          "stealing."
        ],
        "full": "You can't JUSTIFY stealing.",
        "jp": "盗みを正当化することはできない。",
        "is_correct": true
      },
      {
        "parts": [
          "The end does not",
          "the means."
        ],
        "full": "The end does not JUSTIFY the means.",
        "jp": "目的は手段を正当化しない。",
        "is_correct": true
      },
      {
        "parts": [
          "Nothing can ",
          " his actions."
        ],
        "full": "Nothing can JUSTIFY his actions.",
        "jp": "何も彼の行動を正当化することはできない。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " the expense?"
        ],
        "full": "Can you JUSTIFY the expense?",
        "jp": "その費用を正当化できますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 361,
    "word": "LANDSCAPE",
    "meaning_core": "風景",
    "syllables": [
      {
        "text": "LAND",
        "type": "strong"
      },
      {
        "text": "scape",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SCENERY": "景色",
      "VIEW": "眺め",
      "TERRAIN": "地形"
    },
    "distractors": [
      "PORTRAIT",
      "INDOORS",
      "BUILDING",
      "ROOM"
    ],
    "meanings_expanded": [
      "風景",
      "景観",
      "造園する"
    ],
    "contexts": [
      {
        "parts": [
          "The rural",
          "is beautiful."
        ],
        "full": "The rural LANDSCAPE is beautiful.",
        "jp": "田舎の風景は美しい。",
        "is_correct": true
      },
      {
        "parts": [
          "We admired the beautiful ",
          "."
        ],
        "full": "We admired the beautiful LANDSCAPE.",
        "jp": "私たちは美しい風景を鑑賞した。",
        "is_correct": true
      },
      {
        "parts": [
          "The economic ",
          " is changing."
        ],
        "full": "The economic LANDSCAPE is changing.",
        "jp": "経済の状況（風景）は変化している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 362,
    "word": "LAUNCH",
    "meaning_core": "送り出す",
    "syllables": [
      {
        "text": "LAUNCH",
        "type": "strong"
      }
    ],
    "synonyms": {
      "START": "始める",
      "INITIATE": "開始する",
      "FIRE": "発射する"
    },
    "distractors": [
      "STOP",
      "END",
      "LAND",
      "FINISH"
    ],
    "meanings_expanded": [
      "（ロケットを）打ち上げる",
      "（事業を）開始する",
      "送り出す"
    ],
    "contexts": [
      {
        "parts": [
          "We will",
          "a new product."
        ],
        "full": "We will LAUNCH a new product.",
        "jp": "私たちは新製品を発売（開始）する。",
        "is_correct": true
      },
      {
        "parts": [
          "The rocket will",
          "tomorrow."
        ],
        "full": "The rocket will LAUNCH tomorrow.",
        "jp": "ロケットは明日打ち上げられる。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " a new product soon."
        ],
        "full": "They will LAUNCH a new product soon.",
        "jp": "彼らはまもなく新製品を発売する。",
        "is_correct": true
      },
      {
        "parts": [
          "We watched the rocket ",
          "."
        ],
        "full": "We watched the rocket LAUNCH.",
        "jp": "私たちはロケットの打ち上げを見た。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 363,
    "word": "LEGIBLE",
    "meaning_core": "判読可能な",
    "syllables": [
      {
        "text": "LEG",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "READABLE": "読める",
      "CLEAR": "明瞭な",
      "DISTINCT": "はっきりした"
    },
    "distractors": [
      "ILLEGIBLE",
      "UNCLEAR",
      "MESSY",
      "OBSCURE"
    ],
    "meanings_expanded": [
      "判読可能な",
      "読みやすい"
    ],
    "contexts": [
      {
        "parts": [
          "His handwriting is barely",
          "."
        ],
        "full": "His handwriting is barely LEGIBLE.",
        "jp": "彼の筆跡はかろうじて判読可能だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Your handwriting is barely ",
          "."
        ],
        "full": "Your handwriting is barely LEGIBLE.",
        "jp": "あなたの手書き文字はかろうじて判読可能だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Ensure the signature is ",
          "."
        ],
        "full": "Ensure the signature is LEGIBLE.",
        "jp": "署名が判読可能であることを確認してください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 364,
    "word": "LEGISLATION",
    "meaning_core": "法律制定",
    "syllables": [
      {
        "text": "leg",
        "type": "weak"
      },
      {
        "text": "is",
        "type": "weak"
      },
      {
        "text": "LA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LAW": "法律",
      "STATUTE": "法令",
      "ACT": "条例"
    },
    "distractors": [
      "CRIME",
      "VIOLATION",
      "ANARCHY",
      "CHAOS"
    ],
    "meanings_expanded": [
      "法律制定",
      "立法",
      "法律"
    ],
    "contexts": [
      {
        "parts": [
          "New",
          "was passed today."
        ],
        "full": "New LEGISLATION was passed today.",
        "jp": "今日、新しい法律が可決された。",
        "is_correct": true
      },
      {
        "parts": [
          "New gun control ",
          " passed."
        ],
        "full": "New gun control LEGISLATION passed.",
        "jp": "新しい銃規制法が可決された。",
        "is_correct": true
      },
      {
        "parts": [
          "We debated the proposed ",
          "."
        ],
        "full": "We debated the proposed LEGISLATION.",
        "jp": "私たちは提案された法律制定について討論した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 365,
    "word": "LIABILITY",
    "meaning_core": "責任",
    "syllables": [
      {
        "text": "li",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "BIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RESPONSIBILITY": "責任",
      "DEBT": "負債",
      "ACCOUNTABILITY": "説明責任"
    },
    "distractors": [
      "ASSET",
      "BENEFIT",
      "ADVANTAGE",
      "GAIN"
    ],
    "meanings_expanded": [
      "法的責任",
      "負債",
      "不利な点"
    ],
    "contexts": [
      {
        "parts": [
          "The company admitted",
          "for the accident."
        ],
        "full": "The company admitted LIABILITY for the accident.",
        "jp": "会社は事故の法的責任を認めた。",
        "is_correct": true
      },
      {
        "parts": [
          "The company has limited ",
          "."
        ],
        "full": "The company has limited LIABILITY.",
        "jp": "その会社は有限責任を負っている。",
        "is_correct": true
      },
      {
        "parts": [
          "He admitted his ",
          "."
        ],
        "full": "He admitted his LIABILITY.",
        "jp": "彼は自分の責任を認めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 366,
    "word": "LIMITED",
    "meaning_core": "限られた",
    "syllables": [
      {
        "text": "LIM",
        "type": "strong"
      },
      {
        "text": "it",
        "type": "weak"
      },
      {
        "text": "ed",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RESTRICTED": "制限された",
      "FINITE": "有限の",
      "NARROW": "狭い"
    },
    "distractors": [
      "UNLIMITED",
      "INFINITE",
      "ENDLESS",
      "BOUNDLESS"
    ],
    "meanings_expanded": [
      "限られた",
      "有限の",
      "わずかな"
    ],
    "contexts": [
      {
        "parts": [
          "Space is",
          "in this room."
        ],
        "full": "Space is LIMITED in this room.",
        "jp": "この部屋のスペースは限られている。",
        "is_correct": true
      },
      {
        "parts": [
          "We have a very ",
          " budget."
        ],
        "full": "We have a very LIMITED budget.",
        "jp": "私たちには非常に限られた予算がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Space is ",
          "."
        ],
        "full": "Space is LIMITED.",
        "jp": "スペースは限られている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 367,
    "word": "LOITER",
    "meaning_core": "ぶらぶらする",
    "syllables": [
      {
        "text": "LOI",
        "type": "strong"
      },
      {
        "text": "ter",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LINGER": "長居する",
      "HANG AROUND": "うろつく",
      "DAWDLE": "ぐずぐずする"
    },
    "distractors": [
      "HURRY",
      "RUSH",
      "RUN",
      "LEAVE"
    ],
    "meanings_expanded": [
      "ぶらぶらする",
      "うろつく"
    ],
    "contexts": [
      {
        "parts": [
          "Do not",
          "in the lobby."
        ],
        "full": "Do not LOITER in the lobby.",
        "jp": "ロビーでぶらぶらしないでください。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " near the entrance."
        ],
        "full": "Do not LOITER near the entrance.",
        "jp": "入口付近でぶらぶらしてはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "Three men were seen ",
          " outside."
        ],
        "full": "Three men were seen LOITER outside.",
        "jp": "三人の男性が外でぶらぶらしているのが見られた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 368,
    "word": "LONG-TERM",
    "meaning_core": "長期的な",
    "syllables": [
      {
        "text": "LONG",
        "type": "strong"
      },
      {
        "text": "term",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LASTING": "長続きする",
      "PERMANENT": "永続的な",
      "PROLONGED": "長期の"
    },
    "distractors": [
      "SHORT-TERM",
      "TEMPORARY",
      "BRIEF",
      "FLEETING"
    ],
    "meanings_expanded": [
      "長期的な",
      "長期にわたる"
    ],
    "contexts": [
      {
        "parts": [
          "We need a",
          "plan."
        ],
        "full": "We need a LONG-TERM plan.",
        "jp": "私たちは長期的な計画が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " strategy."
        ],
        "full": "We need a LONG-TERM strategy.",
        "jp": "私たちには長期的な戦略が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a ",
          " investment."
        ],
        "full": "This is a LONG-TERM investment.",
        "jp": "これは長期的な投資だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 369,
    "word": "MAGNET",
    "meaning_core": "磁石",
    "syllables": [
      {
        "text": "MAG",
        "type": "strong"
      },
      {
        "text": "net",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ATTRACTION": "引きつけるもの",
      "DRAW": "呼び物"
    },
    "distractors": [
      "REPELLENT",
      "PLASTIC",
      "WOOD",
      "GLASS"
    ],
    "meanings_expanded": [
      "磁石",
      "人を引きつける人・物"
    ],
    "contexts": [
      {
        "parts": [
          "The city is a",
          "for tourists."
        ],
        "full": "The city is a MAGNET for tourists.",
        "jp": "その都市は観光客を引きつける場所だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Iron is attracted to a",
          "."
        ],
        "full": "Iron is attracted to a MAGNET.",
        "jp": "鉄は磁石に引き寄せられる。",
        "is_correct": true
      },
      {
        "parts": [
          "This material acts as a ",
          "."
        ],
        "full": "This material acts as a MAGNET.",
        "jp": "この物質は磁石として機能する。",
        "is_correct": true
      },
      {
        "parts": [
          "The city is a ",
          " for tourists."
        ],
        "full": "The city is a MAGNET for tourists.",
        "jp": "その都市は観光客にとっての魅力（磁石）だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 370,
    "word": "MAGNIFY",
    "meaning_core": "拡大する",
    "syllables": [
      {
        "text": "MAG",
        "type": "strong"
      },
      {
        "text": "ni",
        "type": "weak"
      },
      {
        "text": "fy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENLARGE": "大きくする",
      "AMPLIFY": "増幅する",
      "EXAGGERATE": "誇張する"
    },
    "distractors": [
      "REDUCE",
      "SHRINK",
      "DIMINISH",
      "MINIMIZE"
    ],
    "meanings_expanded": [
      "拡大する",
      "誇張する"
    ],
    "contexts": [
      {
        "parts": [
          "This lens will",
          "the object."
        ],
        "full": "This lens will MAGNIFY the object.",
        "jp": "このレンズは物体を拡大する。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "the problem."
        ],
        "full": "Don't exaggerate the problem.",
        "jp": "問題を誇張（拡大解釈）するな。",
        "is_correct": true
      },
      {
        "parts": [
          "The lens will ",
          " the image."
        ],
        "full": "The lens will MAGNIFY the image.",
        "jp": "そのレンズは画像を拡大するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't ",
          " the problem."
        ],
        "full": "Don't MAGNIFY the problem.",
        "jp": "問題を誇張しないで。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 371,
    "word": "MAJORITY",
    "meaning_core": "大多数",
    "syllables": [
      {
        "text": "ma",
        "type": "weak"
      },
      {
        "text": "JOR",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MOST": "大部分",
      "MASS": "大衆",
      "BULK": "大半"
    },
    "distractors": [
      "MINORITY",
      "FEW",
      "SOME",
      "NONE"
    ],
    "meanings_expanded": [
      "大多数",
      "過半数"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "of people voted yes."
        ],
        "full": "The MAJORITY of people voted yes.",
        "jp": "大多数の人々が賛成票を投じた。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " of people agreed."
        ],
        "full": "The MAJORITY of people agreed.",
        "jp": "大多数の人が同意した。",
        "is_correct": true
      },
      {
        "parts": [
          "She won by a small ",
          "."
        ],
        "full": "She won by a small MAJORITY.",
        "jp": "彼女はわずかな多数で勝利した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 372,
    "word": "MAMMAL",
    "meaning_core": "哺乳類",
    "syllables": [
      {
        "text": "MAM",
        "type": "strong"
      },
      {
        "text": "mal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANIMAL": "動物",
      "CREATURE": "生き物",
      "BEAST": "獣"
    },
    "distractors": [
      "REPTILE",
      "BIRD",
      "FISH",
      "INSECT"
    ],
    "meanings_expanded": [
      "哺乳類",
      "哺乳動物"
    ],
    "contexts": [
      {
        "parts": [
          "The whale is a large",
          "."
        ],
        "full": "The whale is a large MAMMAL.",
        "jp": "クジラは大型の哺乳類だ。",
        "is_correct": true
      },
      {
        "parts": [
          "A whale is a large ",
          "."
        ],
        "full": "A whale is a large MAMMAL.",
        "jp": "クジラは大きな哺乳類だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Humans are also ",
          "."
        ],
        "full": "Humans are also MAMMAL.",
        "jp": "人間も哺乳類だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 373,
    "word": "MANUAL",
    "meaning_core": "手作業の",
    "syllables": [
      {
        "text": "MAN",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HAND-OPERATED": "手動の",
      "PHYSICAL": "身体の",
      "GUIDEBOOK": "説明書"
    },
    "distractors": [
      "AUTOMATIC",
      "DIGITAL",
      "ELECTRONIC",
      "MENTAL"
    ],
    "meanings_expanded": [
      "手作業の",
      "手動の",
      "説明書"
    ],
    "contexts": [
      {
        "parts": [
          "He does",
          "labor."
        ],
        "full": "He does MANUAL labor.",
        "jp": "彼は肉体労働（手作業）をしている。",
        "is_correct": true
      },
      {
        "parts": [
          "The work is completely ",
          "."
        ],
        "full": "The work is completely MANUAL.",
        "jp": "その作業は完全に手作業だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I read the instruction ",
          "."
        ],
        "full": "I read the instruction MANUAL.",
        "jp": "私は取扱説明書（手引書）を読んだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 374,
    "word": "MARKET",
    "meaning_core": "市場",
    "syllables": [
      {
        "text": "MAR",
        "type": "strong"
      },
      {
        "text": "ket",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MARKETPLACE": "市場",
      "BAZAAR": "バザール",
      "TRADE": "取引"
    },
    "distractors": [
      "HOME",
      "SCHOOL",
      "OFFICE",
      "PRIVATE"
    ],
    "meanings_expanded": [
      "市場",
      "相場",
      "市況"
    ],
    "contexts": [
      {
        "parts": [
          "The stock",
          "crashed today."
        ],
        "full": "The stock MARKET crashed today.",
        "jp": "今日、株式市場が暴落した。",
        "is_correct": true
      },
      {
        "parts": [
          "We bought vegetables at the",
          "."
        ],
        "full": "We bought vegetables at the MARKET.",
        "jp": "私たちは市場で野菜を買った。",
        "is_correct": true
      },
      {
        "parts": [
          "The company entered the foreign ",
          "."
        ],
        "full": "The company entered the foreign MARKET.",
        "jp": "その会社は外国市場に参入した。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " the product next year."
        ],
        "full": "We will MARKET the product next year.",
        "jp": "私たちは来年その製品を売り出す。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 375,
    "word": "MEADOW",
    "meaning_core": "牧草地",
    "syllables": [
      {
        "text": "MEAD",
        "type": "strong"
      },
      {
        "text": "ow",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FIELD": "野原",
      "PASTURE": "牧草地",
      "GRASSLAND": "草原"
    },
    "distractors": [
      "FOREST",
      "DESERT",
      "CITY",
      "MOUNTAIN"
    ],
    "meanings_expanded": [
      "牧草地",
      "草地"
    ],
    "contexts": [
      {
        "parts": [
          "Cows were grazing in the",
          "."
        ],
        "full": "Cows were grazing in the MEADOW.",
        "jp": "牛たちが牧草地で草を食べていた。",
        "is_correct": true
      },
      {
        "parts": [
          "We walked across the green ",
          "."
        ],
        "full": "We walked across the green MEADOW.",
        "jp": "私たちは緑の牧草地を横切って歩いた。",
        "is_correct": true
      },
      {
        "parts": [
          "Flowers grew in the ",
          "."
        ],
        "full": "Flowers grew in the MEADOW.",
        "jp": "花が牧草地に咲いていた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 376,
    "word": "MEDITATE",
    "meaning_core": "瞑想する",
    "syllables": [
      {
        "text": "MED",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "tate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTEMPLATE": "沈思黙考する",
      "PONDER": "熟考する",
      "REFLECT": "内省する"
    },
    "distractors": [
      "IGNORE",
      "RUSH",
      "ACT",
      "SPEAK"
    ],
    "meanings_expanded": [
      "瞑想する",
      "熟考する",
      "企てる"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "every morning to relax."
        ],
        "full": "I MEDITATE every morning to relax.",
        "jp": "私はリラックスするために毎朝瞑想する。",
        "is_correct": true
      },
      {
        "parts": [
          "I try to ",
          " every morning."
        ],
        "full": "I try to MEDITATE every morning.",
        "jp": "私は毎朝瞑想しようとしている。",
        "is_correct": true
      },
      {
        "parts": [
          "She sat down to ",
          " silently."
        ],
        "full": "She sat down to MEDITATE silently.",
        "jp": "彼女は静かに瞑想するために座った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 377,
    "word": "MERELY",
    "meaning_core": "単に",
    "syllables": [
      {
        "text": "MERE",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ONLY": "ただ～だけ",
      "SIMPLY": "単に",
      "JUST": "ただ"
    },
    "distractors": [
      "COMPLETELY",
      "FULLY",
      "ABSOLUTELY",
      "EXTREMELY"
    ],
    "meanings_expanded": [
      "単に",
      "ただ～にすぎない"
    ],
    "contexts": [
      {
        "parts": [
          "I was",
          "joking."
        ],
        "full": "I was MERELY joking.",
        "jp": "私は単に冗談を言っていただけだ。",
        "is_correct": true
      },
      {
        "parts": [
          "It was ",
          " a suggestion."
        ],
        "full": "It was MERELY a suggestion.",
        "jp": "それは単なる提案だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He is ",
          " a child."
        ],
        "full": "He is MERELY a child.",
        "jp": "彼は単なる子供だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 378,
    "word": "MIMIC",
    "meaning_core": "まねる",
    "syllables": [
      {
        "text": "MIM",
        "type": "strong"
      },
      {
        "text": "ic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IMITATE": "模倣する",
      "COPY": "コピーする",
      "MOCK": "あざける"
    },
    "distractors": [
      "ORIGINATE",
      "CREATE",
      "INVENT",
      "IGNORE"
    ],
    "meanings_expanded": [
      "まねる",
      "模倣する",
      "（生物が）擬態する"
    ],
    "contexts": [
      {
        "parts": [
          "Parrots can",
          "human speech."
        ],
        "full": "Parrots can MIMIC human speech.",
        "jp": "オウムは人間の言葉をまねることができる。",
        "is_correct": true
      },
      {
        "parts": [
          "A parrot can ",
          " human speech."
        ],
        "full": "A parrot can MIMIC human speech.",
        "jp": "オウムは人間の話し方をまねることができる。",
        "is_correct": true
      },
      {
        "parts": [
          "She tried to ",
          " his voice."
        ],
        "full": "She tried to MIMIC his voice.",
        "jp": "彼女は彼の声をまねようとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 379,
    "word": "MODERNIZATION",
    "meaning_core": "近代化",
    "syllables": [
      {
        "text": "mod",
        "type": "weak"
      },
      {
        "text": "ern",
        "type": "weak"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ZA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEVELOPMENT": "開発",
      "UPDATE": "更新",
      "IMPROVEMENT": "改善"
    },
    "distractors": [
      "TRADITION",
      "DECLINE",
      "DECAY",
      "STAGNATION"
    ],
    "meanings_expanded": [
      "近代化",
      "現代化",
      "最新式にすること"
    ],
    "contexts": [
      {
        "parts": [
          "The rapid",
          "of the city."
        ],
        "full": "The rapid MODERNIZATION of the city.",
        "jp": "その都市の急速な近代化。",
        "is_correct": true
      },
      {
        "parts": [
          "The factory needs ",
          "."
        ],
        "full": "The factory needs MODERNIZATION.",
        "jp": "その工場は近代化が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We discussed the progress of ",
          "."
        ],
        "full": "We discussed the progress of MODERNIZATION.",
        "jp": "私たちは近代化の進捗について議論した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 380,
    "word": "MODIFY",
    "meaning_core": "修正する",
    "syllables": [
      {
        "text": "MOD",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "fy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CHANGE": "変える",
      "ALTER": "変更する",
      "ADJUST": "調整する"
    },
    "distractors": [
      "KEEP",
      "MAINTAIN",
      "PRESERVE",
      "STAY"
    ],
    "meanings_expanded": [
      "修正する",
      "変更する",
      "緩和する"
    ],
    "contexts": [
      {
        "parts": [
          "We need to",
          "the plan."
        ],
        "full": "We need to MODIFY the plan.",
        "jp": "私たちは計画を修正する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the system."
        ],
        "full": "We must MODIFY the system.",
        "jp": "私たちはシステムを修正しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "You can ",
          " the settings."
        ],
        "full": "You can MODIFY the settings.",
        "jp": "設定を変更できます。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 381,
    "word": "MONOPOLY",
    "meaning_core": "独占",
    "syllables": [
      {
        "text": "mo",
        "type": "weak"
      },
      {
        "text": "NOP",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTROL": "支配",
      "DOMINANCE": "優位",
      "TRUST": "企業合同"
    },
    "distractors": [
      "COMPETITION",
      "SHARING",
      "DISTRIBUTION",
      "DIVISION"
    ],
    "meanings_expanded": [
      "独占",
      "専売",
      "独り占め"
    ],
    "contexts": [
      {
        "parts": [
          "The company has a",
          "on the market."
        ],
        "full": "The company has a MONOPOLY on the market.",
        "jp": "その会社は市場を独占している。",
        "is_correct": true
      },
      {
        "parts": [
          "They have a complete ",
          "."
        ],
        "full": "They have a complete MONOPOLY.",
        "jp": "彼らは完全な独占状態にある。",
        "is_correct": true
      },
      {
        "parts": [
          "The state maintains a ",
          "."
        ],
        "full": "The state maintains a MONOPOLY.",
        "jp": "国家が独占を維持している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 382,
    "word": "MONOTONOUS",
    "meaning_core": "単調な",
    "syllables": [
      {
        "text": "mo",
        "type": "weak"
      },
      {
        "text": "NOT",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "nous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BORING": "退屈な",
      "DULL": "鈍い",
      "REPETITIVE": "繰り返しの"
    },
    "distractors": [
      "EXCITING",
      "VARIED",
      "INTERESTING",
      "DIVERSE"
    ],
    "meanings_expanded": [
      "単調な",
      "一本調子の",
      "変化のない"
    ],
    "contexts": [
      {
        "parts": [
          "He has a",
          "voice."
        ],
        "full": "He has a MONOTONOUS voice.",
        "jp": "彼は一本調子の（単調な）声をしている。",
        "is_correct": true
      },
      {
        "parts": [
          "The work became very ",
          "."
        ],
        "full": "The work became very MONOTONOUS.",
        "jp": "その仕事は非常に単調になった。",
        "is_correct": true
      },
      {
        "parts": [
          "She listened to the ",
          " sound."
        ],
        "full": "She listened to the MONOTONOUS sound.",
        "jp": "彼女は単調な音を聞いた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 383,
    "word": "MORAL",
    "meaning_core": "道徳的な",
    "syllables": [
      {
        "text": "MOR",
        "type": "strong"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ETHICAL": "倫理的な",
      "VIRTUOUS": "高潔な",
      "RIGHT": "正しい"
    },
    "distractors": [
      "IMMORAL",
      "WRONG",
      "BAD",
      "EVIL"
    ],
    "meanings_expanded": [
      "道徳的な",
      "倫理の",
      "教訓"
    ],
    "contexts": [
      {
        "parts": [
          "We have a",
          "obligation to help."
        ],
        "full": "We have a MORAL obligation to help.",
        "jp": "私たちには助けるという道徳的義務がある。",
        "is_correct": true
      },
      {
        "parts": [
          "This story has a clear ",
          "."
        ],
        "full": "This story has a clear MORAL.",
        "jp": "この物語には明確な教訓（道徳）がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They debated the ",
          " issue."
        ],
        "full": "They debated the MORAL issue.",
        "jp": "彼らは道徳的な問題について討論した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 384,
    "word": "MOREOVER",
    "meaning_core": "さらに",
    "syllables": [
      {
        "text": "more",
        "type": "weak"
      },
      {
        "text": "O",
        "type": "strong"
      },
      {
        "text": "ver",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FURTHERMORE": "その上",
      "BESIDES": "加えて",
      "ADDITIONALLY": "さらに"
    },
    "distractors": [
      "HOWEVER",
      "THEREFORE",
      "THUS",
      "INSTEAD"
    ],
    "meanings_expanded": [
      "さらに",
      "その上"
    ],
    "contexts": [
      {
        "parts": [
          "The rent is cheap;",
          ",",
          "the location is good."
        ],
        "full": "The rent is cheap; MOREOVER, the location is good.",
        "jp": "家賃は安い。さらに、立地も良い。",
        "is_correct": true
      },
      {
        "parts": [
          "It is cold; ",
          ", it is raining."
        ],
        "full": "It is cold; MOREOVER, it is raining.",
        "jp": "寒い。さらに、雨が降っている。",
        "is_correct": true
      },
      {
        "parts": [
          "She is smart and ",
          ", very kind."
        ],
        "full": "She is smart and MOREOVER, very kind.",
        "jp": "彼女は賢く、その上、とても親切だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 385,
    "word": "MORTALITY",
    "meaning_core": "死亡率",
    "syllables": [
      {
        "text": "mor",
        "type": "weak"
      },
      {
        "text": "TAL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEATH": "死",
      "FATALITY": "死亡者数"
    },
    "distractors": [
      "BIRTH",
      "LIFE",
      "SURVIVAL",
      "IMMORTALITY"
    ],
    "meanings_expanded": [
      "死亡率",
      "死ぬ運命",
      "死亡数"
    ],
    "contexts": [
      {
        "parts": [
          "The infant",
          "rate has decreased."
        ],
        "full": "The infant MORTALITY rate has decreased.",
        "jp": "乳幼児死亡率は低下した。",
        "is_correct": true
      },
      {
        "parts": [
          "The infant ",
          " rate dropped."
        ],
        "full": "The infant MORTALITY rate dropped.",
        "jp": "乳幼児の死亡率が低下した。",
        "is_correct": true
      },
      {
        "parts": [
          "They studied the causes of ",
          "."
        ],
        "full": "They studied the causes of MORTALITY.",
        "jp": "彼らは死亡の原因を研究した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 386,
    "word": "MUTUAL",
    "meaning_core": "相互の",
    "syllables": [
      {
        "text": "MU",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SHARED": "共有の",
      "JOINT": "共同の",
      "RECIPROCAL": "互恵的な"
    },
    "distractors": [
      "ONE-SIDED",
      "INDIVIDUAL",
      "SEPARATE",
      "SOLE"
    ],
    "meanings_expanded": [
      "相互の",
      "共通の"
    ],
    "contexts": [
      {
        "parts": [
          "Respect should be",
          "."
        ],
        "full": "Respect should be MUTUAL.",
        "jp": "尊敬は相互のものであるべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We have a ",
          " friend."
        ],
        "full": "We have a MUTUAL friend.",
        "jp": "私たちには共通の友人がいる。",
        "is_correct": true
      },
      {
        "parts": [
          "Respect should be ",
          "."
        ],
        "full": "Respect should be MUTUAL.",
        "jp": "尊敬は相互のものであるべきだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 387,
    "word": "MUTUALLY",
    "meaning_core": "相互に",
    "syllables": [
      {
        "text": "MU",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "JOINTLY": "共同で",
      "RECIPROCALLY": "お互いに"
    },
    "distractors": [
      "SEPARATELY",
      "INDIVIDUALLY",
      "ALONE",
      "SINGLY"
    ],
    "meanings_expanded": [
      "相互に",
      "互いに"
    ],
    "contexts": [
      {
        "parts": [
          "The agreement was",
          "beneficial."
        ],
        "full": "The agreement was MUTUALLY beneficial.",
        "jp": "その合意は相互に利益があった。",
        "is_correct": true
      },
      {
        "parts": [
          "They are ",
          " beneficial goals."
        ],
        "full": "They are MUTUALLY beneficial goals.",
        "jp": "それらは相互に有益な目標だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We ",
          " agreed on the price."
        ],
        "full": "We MUTUALLY agreed on the price.",
        "jp": "私たちは相互に価格に同意した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 388,
    "word": "NASTY",
    "meaning_core": "不快な",
    "syllables": [
      {
        "text": "NAS",
        "type": "strong"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "UNPLEASANT": "不愉快な",
      "MEAN": "意地悪な",
      "DISGUSTING": "むかつく"
    },
    "distractors": [
      "NICE",
      "PLEASANT",
      "KIND",
      "SWEET"
    ],
    "meanings_expanded": [
      "不快な",
      "意地悪な",
      "汚い"
    ],
    "contexts": [
      {
        "parts": [
          "He has a",
          "habit of biting his nails."
        ],
        "full": "He has a NASTY habit of biting his nails.",
        "jp": "彼には爪を噛むという不快な癖がある。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a ",
          " temper."
        ],
        "full": "He has a NASTY temper.",
        "jp": "彼には不快な気性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "That bug looks ",
          "."
        ],
        "full": "That bug looks NASTY.",
        "jp": "あの虫は不快に見える。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 389,
    "word": "NECESSARILY",
    "meaning_core": "必ずしも",
    "syllables": [
      {
        "text": "nec",
        "type": "weak"
      },
      {
        "text": "es",
        "type": "weak"
      },
      {
        "text": "SAR",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INEVITABLY": "必然的に",
      "AUTOMATICALLY": "自動的に"
    },
    "distractors": [
      "POSSIBLY",
      "PERHAPS",
      "MAYBE",
      "NEVER"
    ],
    "meanings_expanded": [
      "必ずしも（～ない）",
      "必然的に"
    ],
    "contexts": [
      {
        "parts": [
          "Big doesn't",
          "mean better."
        ],
        "full": "Big doesn't NECESSARILY mean better.",
        "jp": "大きいことが必ずしも良いこととは限らない。",
        "is_correct": true
      },
      {
        "parts": [
          "Rich people are not ",
          " happy."
        ],
        "full": "Rich people are not NECESSARILY happy.",
        "jp": "裕福な人が必ずしも幸せとは限らない。",
        "is_correct": true
      },
      {
        "parts": [
          "It does not ",
          " mean that."
        ],
        "full": "It does not NECESSARILY mean that.",
        "jp": "それは必ずしもそう意味するわけではない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 390,
    "word": "NEGLIGENCE",
    "meaning_core": "過失",
    "syllables": [
      {
        "text": "NEG",
        "type": "strong"
      },
      {
        "text": "li",
        "type": "weak"
      },
      {
        "text": "gence",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CARELESSNESS": "不注意",
      "NEGLECT": "怠慢",
      "FAILURE": "怠慢"
    },
    "distractors": [
      "CARE",
      "ATTENTION",
      "DILIGENCE",
      "CAUTION"
    ],
    "meanings_expanded": [
      "過失",
      "怠慢",
      "不注意"
    ],
    "contexts": [
      {
        "parts": [
          "The accident was caused by",
          "."
        ],
        "full": "The accident was caused by NEGLIGENCE.",
        "jp": "その事故は過失（不注意）によって引き起こされた。",
        "is_correct": true
      },
      {
        "parts": [
          "The accident was due to ",
          "."
        ],
        "full": "The accident was due to NEGLIGENCE.",
        "jp": "その事故は過失によるものだった。",
        "is_correct": true
      },
      {
        "parts": [
          "He was charged with ",
          "."
        ],
        "full": "He was charged with NEGLIGENCE.",
        "jp": "彼は過失で告発された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 391,
    "word": "NEGOTIATE",
    "meaning_core": "交渉する",
    "syllables": [
      {
        "text": "ne",
        "type": "weak"
      },
      {
        "text": "GO",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BARGAIN": "取引する",
      "DISCUSS": "議論する",
      "DEAL": "扱う"
    },
    "distractors": [
      "FIGHT",
      "ARGUE",
      "IGNORE",
      "REJECT"
    ],
    "meanings_expanded": [
      "交渉する",
      "取り決める",
      "（障害を）切り抜ける"
    ],
    "contexts": [
      {
        "parts": [
          "We need to",
          "the price."
        ],
        "full": "We need to NEGOTIATE the price.",
        "jp": "私たちは価格を交渉する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the contract terms."
        ],
        "full": "We need to NEGOTIATE the contract terms.",
        "jp": "私たちは契約条件を交渉する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They refused to ",
          "."
        ],
        "full": "They refused to NEGOTIATE.",
        "jp": "彼らは交渉を拒否した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 393,
    "word": "NOBLE",
    "meaning_core": "高潔な",
    "syllables": [
      {
        "text": "NO",
        "type": "strong"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HONORABLE": "名誉ある",
      "ARISTOCRATIC": "貴族の",
      "VIRTUOUS": "徳のある"
    },
    "distractors": [
      "BASE",
      "LOW",
      "MEAN",
      "COMMON"
    ],
    "meanings_expanded": [
      "高潔な",
      "貴族の",
      "崇高な"
    ],
    "contexts": [
      {
        "parts": [
          "It was a",
          "cause."
        ],
        "full": "It was a NOBLE cause.",
        "jp": "それは崇高な大義だった。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a ",
          " act of sacrifice."
        ],
        "full": "It was a NOBLE act of sacrifice.",
        "jp": "それは高潔な犠牲の行為だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He came from a ",
          " family."
        ],
        "full": "He came from a NOBLE family.",
        "jp": "彼は高貴な家柄の出身だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 394,
    "word": "NOMINATE",
    "meaning_core": "任命する",
    "syllables": [
      {
        "text": "NOM",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "nate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "APPOINT": "任命する",
      "PROPOSE": "提案する",
      "NAME": "指名する"
    },
    "distractors": [
      "DISMISS",
      "FIRE",
      "REJECT",
      "IGNORE"
    ],
    "meanings_expanded": [
      "任命する",
      "指名する",
      "推薦する"
    ],
    "contexts": [
      {
        "parts": [
          "I will",
          "him for president."
        ],
        "full": "I will NOMINATE him for president.",
        "jp": "私は彼を社長に推薦するつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We will ",
          " her for president."
        ],
        "full": "We will NOMINATE her for president.",
        "jp": "私たちは彼女を大統領に推薦する。",
        "is_correct": true
      },
      {
        "parts": [
          "Who did you ",
          " for the award?"
        ],
        "full": "Who did you NOMINATE for the award?",
        "jp": "あなたは誰をその賞に指名しましたか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 395,
    "word": "NOR",
    "meaning_core": "～もまたない",
    "syllables": [
      {
        "text": "NOR",
        "type": "strong"
      }
    ],
    "synonyms": {
      "NEITHER": "～もまたない"
    },
    "distractors": [
      "AND",
      "OR",
      "BUT",
      "ALSO"
    ],
    "meanings_expanded": [
      "～もまたない（否定の継続）"
    ],
    "contexts": [
      {
        "parts": [
          "He didn't go,",
          "did I."
        ],
        "full": "He didn't go, NOR did I.",
        "jp": "彼は行かなかったし、私も行かなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "I don't like it, ",
          " does he."
        ],
        "full": "I don't like it, NOR does he.",
        "jp": "私はそれが好きではないし、彼も好きではない。",
        "is_correct": true
      },
      {
        "parts": [
          "It is neither right ",
          " wrong."
        ],
        "full": "It is neither right NOR wrong.",
        "jp": "それは正しくもないし、間違ってもいない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 396,
    "word": "NORM",
    "meaning_core": "規範",
    "syllables": [
      {
        "text": "NORM",
        "type": "strong"
      }
    ],
    "synonyms": {
      "STANDARD": "基準",
      "RULE": "ルール",
      "AVERAGE": "平均"
    },
    "distractors": [
      "EXCEPTION",
      "ABNORMALITY",
      "DEVIATION",
      "ODDITY"
    ],
    "meanings_expanded": [
      "規範",
      "標準",
      "平均"
    ],
    "contexts": [
      {
        "parts": [
          "Working late is the",
          "here."
        ],
        "full": "Working late is the NORM here.",
        "jp": "ここでは残業が当たり前（標準）だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This behavior is the ",
          "."
        ],
        "full": "This behavior is the NORM.",
        "jp": "この振る舞いが規範だ。",
        "is_correct": true
      },
      {
        "parts": [
          "It deviates from the social ",
          "."
        ],
        "full": "It deviates from the social NORM.",
        "jp": "それは社会規範から逸脱している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 398,
    "word": "NOTION",
    "meaning_core": "概念",
    "syllables": [
      {
        "text": "NO",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IDEA": "考え",
      "CONCEPT": "概念",
      "BELIEF": "信念"
    },
    "distractors": [
      "FACT",
      "REALITY",
      "TRUTH",
      "PROOF"
    ],
    "meanings_expanded": [
      "概念",
      "考え",
      "意向"
    ],
    "contexts": [
      {
        "parts": [
          "I have no",
          "what you mean."
        ],
        "full": "I have no NOTION what you mean.",
        "jp": "君が何を言っているのか全く見当がつかない。",
        "is_correct": true
      },
      {
        "parts": [
          "I reject that ",
          "."
        ],
        "full": "I reject that NOTION.",
        "jp": "私はその概念を拒否する。",
        "is_correct": true
      },
      {
        "parts": [
          "It is a strange ",
          "."
        ],
        "full": "It is a strange NOTION.",
        "jp": "それは奇妙な考え（概念）だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 399,
    "word": "NUISANCE",
    "meaning_core": "厄介なこと",
    "syllables": [
      {
        "text": "NUI",
        "type": "strong"
      },
      {
        "text": "sance",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ANNOYANCE": "迷惑",
      "BOTHER": "面倒",
      "PEST": "害虫（厄介者）"
    },
    "distractors": [
      "JOY",
      "DELIGHT",
      "HELP",
      "PLEASURE"
    ],
    "meanings_expanded": [
      "厄介なこと",
      "迷惑な人",
      "不快なもの"
    ],
    "contexts": [
      {
        "parts": [
          "The noise is a real",
          "."
        ],
        "full": "The noise is a real NUISANCE.",
        "jp": "その騒音は本当に迷惑だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The noise is a public ",
          "."
        ],
        "full": "The noise is a public NUISANCE.",
        "jp": "その騒音は公共の迷惑だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a real ",
          "."
        ],
        "full": "He is a real NUISANCE.",
        "jp": "彼は本当に厄介な存在だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 400,
    "word": "NUTRIENT",
    "meaning_core": "栄養素",
    "syllables": [
      {
        "text": "NU",
        "type": "strong"
      },
      {
        "text": "tri",
        "type": "weak"
      },
      {
        "text": "ent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NOURISHMENT": "栄養",
      "FOOD": "食物",
      "VITAMIN": "ビタミン"
    },
    "distractors": [
      "POISON",
      "TOXIN",
      "WASTE",
      "GARBAGE"
    ],
    "meanings_expanded": [
      "栄養素",
      "滋養物"
    ],
    "contexts": [
      {
        "parts": [
          "Plants need",
          "from the soil."
        ],
        "full": "Plants need NUTRIENT from the soil.",
        "jp": "植物は土壌からの栄養素を必要とする。",
        "is_correct": true
      },
      {
        "parts": [
          "This soil lacks ",
          "."
        ],
        "full": "This soil lacks NUTRIENT.",
        "jp": "この土壌には栄養素が欠けている。",
        "is_correct": true
      },
      {
        "parts": [
          "We need vital ",
          "."
        ],
        "full": "We need vital NUTRIENT.",
        "jp": "私たちには不可欠な栄養素が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 401,
    "word": "NUTRITIOUS",
    "meaning_core": "栄養のある",
    "syllables": [
      {
        "text": "nu",
        "type": "weak"
      },
      {
        "text": "TRI",
        "type": "strong"
      },
      {
        "text": "tious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HEALTHY": "健康的な",
      "NOURISHING": "滋養のある",
      "WHOLESOME": "健康に良い"
    },
    "distractors": [
      "UNHEALTHY",
      "TOXIC",
      "BAD",
      "POOR"
    ],
    "meanings_expanded": [
      "栄養のある",
      "栄養価の高い"
    ],
    "contexts": [
      {
        "parts": [
          "Vegetables are very",
          "."
        ],
        "full": "Vegetables are very NUTRITIOUS.",
        "jp": "野菜はとても栄養がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Vegetables are very ",
          "."
        ],
        "full": "Vegetables are very NUTRITIOUS.",
        "jp": "野菜は非常に栄養がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Eat a ",
          " breakfast every day."
        ],
        "full": "Eat a NUTRITIOUS breakfast every day.",
        "jp": "毎日栄養のある朝食を食べなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 402,
    "word": "OBEDIENT",
    "meaning_core": "従順な",
    "syllables": [
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "BE",
        "type": "strong"
      },
      {
        "text": "di",
        "type": "weak"
      },
      {
        "text": "ent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLIANT": "言いなりになる",
      "SUBMISSIVE": "服従的な",
      "DUTIFUL": "義理堅い"
    },
    "distractors": [
      "REBELLIOUS",
      "STUBBORN",
      "WILD",
      "NAUGHTY"
    ],
    "meanings_expanded": [
      "従順な",
      "素直な"
    ],
    "contexts": [
      {
        "parts": [
          "The dog is very",
          "."
        ],
        "full": "The dog is very OBEDIENT.",
        "jp": "その犬はとても従順だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an ",
          " and quiet child."
        ],
        "full": "He is an OBEDIENT and quiet child.",
        "jp": "彼は従順でおとなしい子供だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Soldiers must be ",
          "."
        ],
        "full": "Soldiers must be OBEDIENT.",
        "jp": "兵士は従順でなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 403,
    "word": "OBJECTION",
    "meaning_core": "異議",
    "syllables": [
      {
        "text": "ob",
        "type": "weak"
      },
      {
        "text": "JEC",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PROTEST": "抗議",
      "COMPLAINT": "苦情",
      "OPPOSITION": "反対"
    },
    "distractors": [
      "AGREEMENT",
      "APPROVAL",
      "CONSENT",
      "SUPPORT"
    ],
    "meanings_expanded": [
      "異議",
      "反対",
      "欠点"
    ],
    "contexts": [
      {
        "parts": [
          "I have no",
          "to the plan."
        ],
        "full": "I have no OBJECTION to the plan.",
        "jp": "私はその計画に異議はない。",
        "is_correct": true
      },
      {
        "parts": [
          "We raised a strong ",
          "."
        ],
        "full": "We raised a strong OBJECTION.",
        "jp": "私たちは強い異議を申し立てた。",
        "is_correct": true
      },
      {
        "parts": [
          "The lawyer made an ",
          "."
        ],
        "full": "The lawyer made an OBJECTION.",
        "jp": "弁護士は異議を唱えた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 404,
    "word": "OBLIGE",
    "meaning_core": "義務付ける",
    "syllables": [
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "BLIGE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "FORCE": "強いる",
      "COMPEL": "強制する",
      "REQUIRE": "要求する"
    },
    "distractors": [
      "FREE",
      "ALLOW",
      "LET",
      "RELEASE"
    ],
    "meanings_expanded": [
      "義務付ける",
      "強いる",
      "恩義を施す"
    ],
    "contexts": [
      {
        "parts": [
          "The law",
          "us to pay taxes."
        ],
        "full": "The law obliges us to pay taxes.",
        "jp": "法律は私たちに納税を義務付けている。",
        "is_correct": true
      },
      {
        "parts": [
          "The law will ",
          " us to pay."
        ],
        "full": "The law will OBLIGE us to pay.",
        "jp": "法律は私たちに支払いを義務付けるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "I feel ",
          " to help him."
        ],
        "full": "I feel OBLIGE to help him.",
        "jp": "私は彼を助ける義務があると感じる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 405,
    "word": "OBLIVIOUS",
    "meaning_core": "気づかない",
    "syllables": [
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "BLIV",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "UNAWARE": "気づかない",
      "IGNORANT": "知らない",
      "UNMINDFUL": "気に留めない"
    },
    "distractors": [
      "AWARE",
      "CONSCIOUS",
      "MINDFUL",
      "ALERT"
    ],
    "meanings_expanded": [
      "気づかない",
      "忘れている"
    ],
    "contexts": [
      {
        "parts": [
          "He was",
          "to the danger."
        ],
        "full": "He was OBLIVIOUS to the danger.",
        "jp": "彼は危険に気づいていなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "We should not be",
          "to the lesson."
        ],
        "full": "We should not be OBLIVIOUS to the lesson.",
        "jp": "私たちはその教訓を忘れてはならない。",
        "is_correct": true
      },
      {
        "parts": [
          "He remained ",
          " to her feelings."
        ],
        "full": "He remained OBLIVIOUS to her feelings.",
        "jp": "彼は彼女の気持ちに気づかないままだった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 406,
    "word": "OBSOLETE",
    "meaning_core": "廃れた",
    "syllables": [
      {
        "text": "ob",
        "type": "weak"
      },
      {
        "text": "so",
        "type": "weak"
      },
      {
        "text": "LETE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "OUTDATED": "時代遅れの",
      "OLD-FASHIONED": "旧式の",
      "ARCHAIC": "古風な"
    },
    "distractors": [
      "MODERN",
      "NEW",
      "CURRENT",
      "LATEST"
    ],
    "meanings_expanded": [
      "廃れた",
      "時代遅れの",
      "陳腐化した"
    ],
    "contexts": [
      {
        "parts": [
          "Typewriters are now",
          "."
        ],
        "full": "Typewriters are now OBSOLETE.",
        "jp": "タイプライターは今や廃れている。",
        "is_correct": true
      },
      {
        "parts": [
          "This equipment is now ",
          "."
        ],
        "full": "This equipment is now OBSOLETE.",
        "jp": "この機器はもう廃れている。",
        "is_correct": true
      },
      {
        "parts": [
          "That technology is nearly ",
          "."
        ],
        "full": "That technology is nearly OBSOLETE.",
        "jp": "その技術はほぼ時代遅れだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 407,
    "word": "OBSTACLE",
    "meaning_core": "障害",
    "syllables": [
      {
        "text": "OB",
        "type": "strong"
      },
      {
        "text": "sta",
        "type": "weak"
      },
      {
        "text": "cle",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BARRIER": "障壁",
      "HURDLE": "ハードル",
      "BLOCK": "妨害"
    },
    "distractors": [
      "AID",
      "HELP",
      "ADVANTAGE",
      "OPENING"
    ],
    "meanings_expanded": [
      "障害",
      "邪魔者"
    ],
    "contexts": [
      {
        "parts": [
          "Fear is the biggest",
          "to success."
        ],
        "full": "Fear is the biggest OBSTACLE to success.",
        "jp": "恐怖は成功への最大の障害だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Fear is the greatest ",
          "."
        ],
        "full": "Fear is the greatest OBSTACLE.",
        "jp": "恐怖が最大の障害だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We faced an unexpected ",
          "."
        ],
        "full": "We faced an unexpected OBSTACLE.",
        "jp": "私たちは予期せぬ障害に直面した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 408,
    "word": "OBTAIN",
    "meaning_core": "手に入れる",
    "syllables": [
      {
        "text": "ob",
        "type": "weak"
      },
      {
        "text": "TAIN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "GET": "得る",
      "ACQUIRE": "獲得する",
      "GAIN": "手に入れる"
    },
    "distractors": [
      "LOSE",
      "MISS",
      "GIVE",
      "DONATE"
    ],
    "meanings_expanded": [
      "手に入れる",
      "獲得する",
      "通用する"
    ],
    "contexts": [
      {
        "parts": [
          "Where can I",
          "a map?"
        ],
        "full": "Where can I OBTAIN a map?",
        "jp": "どこで地図を手に入れられますか？",
        "is_correct": true
      },
      {
        "parts": [
          "You can ",
          " a visa easily."
        ],
        "full": "You can OBTAIN a visa easily.",
        "jp": "あなたは簡単にビザを取得できる。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the necessary data."
        ],
        "full": "We must OBTAIN the necessary data.",
        "jp": "私たちは必要なデータを手に入れなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 409,
    "word": "OCCASIONAL",
    "meaning_core": "時々の",
    "syllables": [
      {
        "text": "oc",
        "type": "weak"
      },
      {
        "text": "CA",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INFREQUENT": "まれな",
      "RARE": "珍しい",
      "SPORADIC": "散発的な"
    },
    "distractors": [
      "CONSTANT",
      "FREQUENT",
      "REGULAR",
      "USUAL"
    ],
    "meanings_expanded": [
      "時々の",
      "たまの"
    ],
    "contexts": [
      {
        "parts": [
          "We enjoy an",
          "glass of wine."
        ],
        "full": "We enjoy an OCCASIONAL glass of wine.",
        "jp": "私たちは時々ワインを楽しむ。",
        "is_correct": true
      },
      {
        "parts": [
          "We see ",
          " bursts of fire."
        ],
        "full": "We see OCCASIONAL bursts of fire.",
        "jp": "私たちは時折炎の噴出を見る。",
        "is_correct": true
      },
      {
        "parts": [
          "She makes ",
          " visits home."
        ],
        "full": "She makes OCCASIONAL visits home.",
        "jp": "彼女は時々実家を訪れる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 410,
    "word": "OCCUR",
    "meaning_core": "起こる",
    "syllables": [
      {
        "text": "oc",
        "type": "weak"
      },
      {
        "text": "CUR",
        "type": "strong"
      }
    ],
    "synonyms": {
      "HAPPEN": "起こる",
      "TAKE PLACE": "開催される",
      "ARISE": "生じる"
    },
    "distractors": [
      "STOP",
      "END",
      "CEASE",
      "PREVENT"
    ],
    "meanings_expanded": [
      "起こる",
      "生じる",
      "（心に）浮かぶ"
    ],
    "contexts": [
      {
        "parts": [
          "Accidents often",
          "at home."
        ],
        "full": "Accidents often OCCUR at home.",
        "jp": "事故は家でよく起こる。",
        "is_correct": true
      },
      {
        "parts": [
          "The change will ",
          " soon."
        ],
        "full": "The change will OCCUR soon.",
        "jp": "その変化はすぐに起こるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "When did the accident ",
          "?"
        ],
        "full": "When did the accident OCCUR?",
        "jp": "その事故はいつ起こりましたか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 413,
    "word": "OPERATE",
    "meaning_core": "操作する",
    "syllables": [
      {
        "text": "OP",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WORK": "動く",
      "FUNCTION": "機能する",
      "MANAGE": "管理する"
    },
    "distractors": [
      "BREAK",
      "STOP",
      "HALT",
      "IDLE"
    ],
    "meanings_expanded": [
      "操作する",
      "作動する",
      "手術する"
    ],
    "contexts": [
      {
        "parts": [
          "Do not",
          "machinery while drowsy."
        ],
        "full": "Do not OPERATE machinery while drowsy.",
        "jp": "眠い時は機械を操作しないでください。",
        "is_correct": true
      },
      {
        "parts": [
          "Can you ",
          " this machine?"
        ],
        "full": "Can you OPERATE this machine?",
        "jp": "あなたはこの機械を操作できますか。",
        "is_correct": true
      },
      {
        "parts": [
          "The hospital will ",
          " on him."
        ],
        "full": "The hospital will OPERATE on him.",
        "jp": "病院は彼を手術するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 414,
    "word": "OPPOSE",
    "meaning_core": "反対する",
    "syllables": [
      {
        "text": "op",
        "type": "weak"
      },
      {
        "text": "POSE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "RESIST": "抵抗する",
      "FIGHT": "戦う",
      "WITHSTAND": "逆らう"
    },
    "distractors": [
      "SUPPORT",
      "AGREE",
      "HELP",
      "AID"
    ],
    "meanings_expanded": [
      "反対する",
      "対抗する"
    ],
    "contexts": [
      {
        "parts": [
          "Many people",
          "the new tax."
        ],
        "full": "Many people OPPOSE the new tax.",
        "jp": "多くの人々が新税に反対している。",
        "is_correct": true
      },
      {
        "parts": [
          "I strongly ",
          " this new plan."
        ],
        "full": "I strongly OPPOSE this new plan.",
        "jp": "私はこの新しい計画に強く反対する。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " the merger."
        ],
        "full": "They will OPPOSE the merger.",
        "jp": "彼らは合併に反対するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 415,
    "word": "OPPOSITE",
    "meaning_core": "反対の",
    "syllables": [
      {
        "text": "OP",
        "type": "strong"
      },
      {
        "text": "po",
        "type": "weak"
      },
      {
        "text": "site",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTRARY": "正反対の",
      "REVERSE": "逆の",
      "CONFLICTING": "矛盾する"
    },
    "distractors": [
      "SAME",
      "SIMILAR",
      "ALIKE",
      "IDENTICAL"
    ],
    "meanings_expanded": [
      "反対の",
      "向かい側の"
    ],
    "contexts": [
      {
        "parts": [
          "They sat on",
          "sides of the table."
        ],
        "full": "They sat on OPPOSITE sides of the table.",
        "jp": "彼らはテーブルの反対側に座った。",
        "is_correct": true
      },
      {
        "parts": [
          "We live on the ",
          " side."
        ],
        "full": "We live on the OPPOSITE side.",
        "jp": "私たちは反対側に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "Black is the ",
          " of white."
        ],
        "full": "Black is the OPPOSITE of white.",
        "jp": "黒は白の反対だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 416,
    "word": "ORGANISM",
    "meaning_core": "生物",
    "syllables": [
      {
        "text": "OR",
        "type": "strong"
      },
      {
        "text": "gan",
        "type": "weak"
      },
      {
        "text": "ism",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CREATURE": "生き物",
      "BEING": "存在",
      "LIVING THING": "生物"
    },
    "distractors": [
      "OBJECT",
      "MINERAL",
      "ROCK",
      "MACHINE"
    ],
    "meanings_expanded": [
      "生物",
      "有機体"
    ],
    "contexts": [
      {
        "parts": [
          "A cell is the smallest unit of an",
          "."
        ],
        "full": "A cell is the smallest unit of an ORGANISM.",
        "jp": "細胞は生物の最小単位だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a single-celled ",
          "."
        ],
        "full": "This is a single-celled ORGANISM.",
        "jp": "これは単細胞生物だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We study living ",
          "."
        ],
        "full": "We study living ORGANISM.",
        "jp": "私たちは生きた生物を研究する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 417,
    "word": "OTHERWISE",
    "meaning_core": "さもなければ",
    "syllables": [
      {
        "text": "OTH",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "wise",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OR ELSE": "さもないと",
      "DIFFERENTLY": "別の方法で"
    },
    "distractors": [
      "SIMILARLY",
      "LIKEWISE",
      "ALSO",
      "TOO"
    ],
    "meanings_expanded": [
      "さもなければ",
      "そうでないと",
      "別の方法で"
    ],
    "contexts": [
      {
        "parts": [
          "Hurry up,",
          "you'll be late."
        ],
        "full": "Hurry up, OTHERWISE you'll be late.",
        "jp": "急ぎなさい、さもなければ遅刻するよ。",
        "is_correct": true
      },
      {
        "parts": [
          "Study hard, ",
          " you will fail."
        ],
        "full": "Study hard, OTHERWISE you will fail.",
        "jp": "熱心に勉強しなさい、さもなければ失敗するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "I believe it, unless proved ",
          "."
        ],
        "full": "I believe it, unless proved OTHERWISE.",
        "jp": "反証されない限り、私はそれを信じる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 419,
    "word": "OUTRAGEOUS",
    "meaning_core": "とんでもない",
    "syllables": [
      {
        "text": "out",
        "type": "weak"
      },
      {
        "text": "RA",
        "type": "strong"
      },
      {
        "text": "geous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SHOCKING": "衝撃的な",
      "SCANDALOUS": "不名誉な",
      "UNREASONABLE": "理不尽な"
    },
    "distractors": [
      "REASONABLE",
      "NORMAL",
      "FAIR",
      "MILD"
    ],
    "meanings_expanded": [
      "とんでもない",
      "法外な",
      "けしからん"
    ],
    "contexts": [
      {
        "parts": [
          "The price of the ticket was",
          "."
        ],
        "full": "The price of the ticket was OUTRAGEOUS.",
        "jp": "チケットの値段は法外だった。",
        "is_correct": true
      },
      {
        "parts": [
          "That price is absolutely ",
          "."
        ],
        "full": "That price is absolutely OUTRAGEOUS.",
        "jp": "その価格は全くもってとんでもない。",
        "is_correct": true
      },
      {
        "parts": [
          "He made an ",
          " remark."
        ],
        "full": "He made an OUTRAGEOUS remark.",
        "jp": "彼​​はとんでもない発言をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 420,
    "word": "OUTSIDE",
    "meaning_core": "～の外側に",
    "syllables": [
      {
        "text": "out",
        "type": "weak"
      },
      {
        "text": "SIDE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXTERIOR": "外部",
      "OUTDOORS": "屋外"
    },
    "distractors": [
      "INSIDE",
      "INTERIOR",
      "WITHIN",
      "IN"
    ],
    "meanings_expanded": [
      "～の外側に",
      "外側"
    ],
    "contexts": [
      {
        "parts": [
          "It is cold",
          "."
        ],
        "full": "It is cold OUTSIDE.",
        "jp": "外は寒い。",
        "is_correct": true
      },
      {
        "parts": [
          "The dog is waiting ",
          " the door."
        ],
        "full": "The dog is waiting OUTSIDE the door.",
        "jp": "犬はドアの外側で待っている。",
        "is_correct": true
      },
      {
        "parts": [
          "We must look ",
          " the box."
        ],
        "full": "We must look OUTSIDE the box.",
        "jp": "私たちは常識の外側（枠外）を見る必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 421,
    "word": "OUTSTANDING",
    "meaning_core": "目立った",
    "syllables": [
      {
        "text": "out",
        "type": "weak"
      },
      {
        "text": "STAND",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXCELLENT": "優れた",
      "REMARKABLE": "注目すべき",
      "UNPAID": "未払いの"
    },
    "distractors": [
      "AVERAGE",
      "ORDINARY",
      "POOR",
      "PAID"
    ],
    "meanings_expanded": [
      "目立った",
      "傑出した",
      "未払いの"
    ],
    "contexts": [
      {
        "parts": [
          "He did an",
          "job."
        ],
        "full": "He did an OUTSTANDING job.",
        "jp": "彼は素晴らしい仕事をした。",
        "is_correct": true
      },
      {
        "parts": [
          "I have an",
          "bill."
        ],
        "full": "I have an OUTSTANDING bill.",
        "jp": "私には未払いの請求書がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She gave an ",
          " performance."
        ],
        "full": "She gave an OUTSTANDING performance.",
        "jp": "彼女は目覚ましい演技をした。",
        "is_correct": true
      },
      {
        "parts": [
          "Your bill has an ",
          " balance."
        ],
        "full": "Your bill has an OUTSTANDING balance.",
        "jp": "あなたの請求書には未払いの残高がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 422,
    "word": "OVERLOOK",
    "meaning_core": "大目に見る",
    "syllables": [
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "ver",
        "type": "weak"
      },
      {
        "text": "LOOK",
        "type": "strong"
      }
    ],
    "synonyms": {
      "IGNORE": "無視する",
      "MISS": "見落とす",
      "FORGIVE": "許す"
    },
    "distractors": [
      "NOTICE",
      "OBSERVE",
      "SCRUTINIZE",
      "PUNISH"
    ],
    "meanings_expanded": [
      "大目に見る",
      "見渡す",
      "見落とす"
    ],
    "contexts": [
      {
        "parts": [
          "I will",
          "your mistake this time."
        ],
        "full": "I will OVERLOOK your mistake this time.",
        "jp": "今回だけは君の間違いを大目に見よう。",
        "is_correct": true
      },
      {
        "parts": [
          "The hotel room",
          "the ocean."
        ],
        "full": "The hotel room overlooks the ocean.",
        "jp": "ホテルの部屋からは海が見渡せる。",
        "is_correct": true
      },
      {
        "parts": [
          "The hotel rooms ",
          " the sea."
        ],
        "full": "The hotel rooms OVERLOOK the sea.",
        "jp": "ホテルの部屋からは海が見下ろせる。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " my small mistake."
        ],
        "full": "Please OVERLOOK my small mistake.",
        "jp": "私の小さな間違いを見逃してください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 423,
    "word": "OVERSEAS",
    "meaning_core": "海外の",
    "syllables": [
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "ver",
        "type": "weak"
      },
      {
        "text": "SEAS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ABROAD": "海外へ",
      "FOREIGN": "外国の",
      "INTERNATIONAL": "国際的な"
    },
    "distractors": [
      "DOMESTIC",
      "LOCAL",
      "HOME",
      "NATIVE"
    ],
    "meanings_expanded": [
      "海外の",
      "外国への"
    ],
    "contexts": [
      {
        "parts": [
          "He works",
          "."
        ],
        "full": "He works OVERSEAS.",
        "jp": "彼は海外で働いている。",
        "is_correct": true
      },
      {
        "parts": [
          "He is moving ",
          " next month."
        ],
        "full": "He is moving OVERSEAS next month.",
        "jp": "彼は来月海外へ引っ越す。",
        "is_correct": true
      },
      {
        "parts": [
          "They deal with ",
          " markets."
        ],
        "full": "They deal with OVERSEAS markets.",
        "jp": "彼らは海外市場と取引している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 424,
    "word": "OVERWHELMING",
    "meaning_core": "圧倒するような",
    "syllables": [
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "ver",
        "type": "weak"
      },
      {
        "text": "WHELM",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OVERPOWERING": "圧倒的な",
      "INTENSE": "強烈な",
      "STAGGERING": "驚異的な"
    },
    "distractors": [
      "WEAK",
      "MILD",
      "SMALL",
      "INSIGNIFICANT"
    ],
    "meanings_expanded": [
      "圧倒的な",
      "抵抗できない"
    ],
    "contexts": [
      {
        "parts": [
          "The evidence was",
          "."
        ],
        "full": "The evidence was OVERWHELMING.",
        "jp": "証拠は圧倒的だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He felt an",
          "joy."
        ],
        "full": "He felt an OVERWHELMING joy.",
        "jp": "彼は圧倒的な喜びを感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "The response was ",
          "."
        ],
        "full": "The response was OVERWHELMING.",
        "jp": "反応は圧倒的だった。",
        "is_correct": true
      },
      {
        "parts": [
          "She felt an ",
          " desire to quit."
        ],
        "full": "She felt an OVERWHELMING desire to quit.",
        "jp": "彼女は辞めたいという圧倒的な願望を感じた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 425,
    "word": "OXYGEN",
    "meaning_core": "酸素",
    "syllables": [
      {
        "text": "OX",
        "type": "strong"
      },
      {
        "text": "y",
        "type": "weak"
      },
      {
        "text": "gen",
        "type": "weak"
      }
    ],
    "synonyms": {
      "O2": "O2",
      "AIR": "空気"
    },
    "distractors": [
      "CARBON",
      "NITROGEN",
      "WATER",
      "POISON"
    ],
    "meanings_expanded": [
      "酸素"
    ],
    "contexts": [
      {
        "parts": [
          "Humans need",
          "to breathe."
        ],
        "full": "Humans need OXYGEN to breathe.",
        "jp": "人間は呼吸するために酸素が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Plants produce",
          "."
        ],
        "full": "Plants produce OXYGEN.",
        "jp": "植物は酸素を作り出す。",
        "is_correct": true
      },
      {
        "parts": [
          "We need fresh ",
          " in here."
        ],
        "full": "We need fresh OXYGEN in here.",
        "jp": "私たちはここに新鮮な酸素が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Plants produce ",
          "."
        ],
        "full": "Plants produce OXYGEN.",
        "jp": "植物は酸素を生成する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 426,
    "word": "PARADIGM",
    "meaning_core": "パラダイム",
    "syllables": [
      {
        "text": "PAR",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "digm",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MODEL": "模範",
      "PATTERN": "様式",
      "FRAMEWORK": "枠組み"
    },
    "distractors": [
      "CHAOS",
      "DISORDER",
      "EXCEPTION",
      "ANOMALY"
    ],
    "meanings_expanded": [
      "パラダイム",
      "思考の枠組み",
      "模範"
    ],
    "contexts": [
      {
        "parts": [
          "This is a new",
          "in science."
        ],
        "full": "This is a new PARADIGM in science.",
        "jp": "これは科学における新しいパラダイムだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to shift the",
          "."
        ],
        "full": "We need to shift the PARADIGM.",
        "jp": "私たちはパラダイムを転換する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "This event caused a major ",
          " shift."
        ],
        "full": "This event caused a major PARADIGM shift.",
        "jp": "この出来事は大きなパラダイムシフトを引き起こした。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a new business ",
          "."
        ],
        "full": "We need a new business PARADIGM.",
        "jp": "私たちには新しいビジネスモデル（パラダイム）が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 427,
    "word": "PARTICIPATE",
    "meaning_core": "参加する",
    "syllables": [
      {
        "text": "par",
        "type": "weak"
      },
      {
        "text": "TIC",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "pate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TAKE PART": "参加する",
      "JOIN": "加わる",
      "ENGAGE": "従事する"
    },
    "distractors": [
      "AVOID",
      "WATCH",
      "OBSERVE",
      "WITHDRAW"
    ],
    "meanings_expanded": [
      "参加する",
      "関与する"
    ],
    "contexts": [
      {
        "parts": [
          "I want to",
          "in the contest."
        ],
        "full": "I want to PARTICIPATE in the contest.",
        "jp": "私はコンテストに参加したい。",
        "is_correct": true
      },
      {
        "parts": [
          "You should ",
          " in the meeting."
        ],
        "full": "You should PARTICIPATE in the meeting.",
        "jp": "あなたは会議に参加すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "She chose not to ",
          " in the race."
        ],
        "full": "She chose not to PARTICIPATE in the race.",
        "jp": "彼女はレースに参加しないことを選んだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 428,
    "word": "PARTICULARLY",
    "meaning_core": "特に",
    "syllables": [
      {
        "text": "par",
        "type": "weak"
      },
      {
        "text": "TIC",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "lar",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ESPECIALLY": "特に",
      "SPECIFICALLY": "具体的に",
      "NOTABLY": "とりわけ"
    },
    "distractors": [
      "GENERALLY",
      "USUALLY",
      "BROADLY",
      "SLIGHTLY"
    ],
    "meanings_expanded": [
      "特に",
      "とりわけ"
    ],
    "contexts": [
      {
        "parts": [
          "I am",
          "interested in art."
        ],
        "full": "I am PARTICULARLY interested in art.",
        "jp": "私は特に芸術に興味がある。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " enjoyed the ending."
        ],
        "full": "I PARTICULARLY enjoyed the ending.",
        "jp": "私は特にエンディングを楽しんだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The weather is ",
          " cold today."
        ],
        "full": "The weather is PARTICULARLY cold today.",
        "jp": "今日の天気は特に寒い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 429,
    "word": "PATIENT",
    "meaning_core": "忍耐強い",
    "syllables": [
      {
        "text": "PA",
        "type": "strong"
      },
      {
        "text": "tient",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TOLERANT": "寛容な",
      "ENDURING": "辛抱強い",
      "CALM": "穏やかな"
    },
    "distractors": [
      "IMPATIENT",
      "HASTY",
      "ANGRY",
      "RUSHED"
    ],
    "meanings_expanded": [
      "忍耐強い",
      "患者（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "You must be",
          "with children."
        ],
        "full": "You must be PATIENT with children.",
        "jp": "子供に対しては忍耐強くなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The doctor examined the",
          "."
        ],
        "full": "The doctor examined the PATIENT.",
        "jp": "医師は患者を診察した。",
        "is_correct": true
      },
      {
        "parts": [
          "Be ",
          " and wait for your turn."
        ],
        "full": "Be PATIENT and wait for your turn.",
        "jp": "忍耐強くなって、あなたの番を待ちましょう。",
        "is_correct": true
      },
      {
        "parts": [
          "The doctor treated the ",
          " gently."
        ],
        "full": "The doctor treated the PATIENT gently.",
        "jp": "医者は患者を優しく治療した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 430,
    "word": "PENETRATE",
    "meaning_core": "貫通する",
    "syllables": [
      {
        "text": "PEN",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "trate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PIERCE": "突き通す",
      "ENTER": "入る",
      "PERMEATE": "浸透する"
    },
    "distractors": [
      "BOUNCE",
      "REFLECT",
      "STOP",
      "BLOCK"
    ],
    "meanings_expanded": [
      "貫通する",
      "浸透する",
      "見抜く"
    ],
    "contexts": [
      {
        "parts": [
          "The bullet failed to",
          "the armor."
        ],
        "full": "The bullet failed to PENETRATE the armor.",
        "jp": "弾丸は装甲を貫通しなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Sunlight can",
          "deep water."
        ],
        "full": "Sunlight can PENETRATE deep water.",
        "jp": "日光は深い水中まで届く（浸透する）。",
        "is_correct": true
      },
      {
        "parts": [
          "The light could not ",
          " the dark."
        ],
        "full": "The light could not PENETRATE the dark.",
        "jp": "光は暗闇を貫通できなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "The spies tried to ",
          " the office."
        ],
        "full": "The spies tried to PENETRATE the office.",
        "jp": "スパイは事務所に侵入しようとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 431,
    "word": "PERCEPTIBLE",
    "meaning_core": "知覚できる",
    "syllables": [
      {
        "text": "per",
        "type": "weak"
      },
      {
        "text": "CEP",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NOTICEABLE": "目立つ",
      "DETECTABLE": "検知できる",
      "VISIBLE": "目に見える"
    },
    "distractors": [
      "IMPERCEPTIBLE",
      "INVISIBLE",
      "HIDDEN",
      "UNNOTICEABLE"
    ],
    "meanings_expanded": [
      "知覚できる",
      "かなりの"
    ],
    "contexts": [
      {
        "parts": [
          "There was a",
          "change in temperature."
        ],
        "full": "There was a PERCEPTIBLE change in temperature.",
        "jp": "気温に知覚できるほどの変化があった。",
        "is_correct": true
      },
      {
        "parts": [
          "The change was barely ",
          "."
        ],
        "full": "The change was barely PERCEPTIBLE.",
        "jp": "その変化はかろうじて知覚できた。",
        "is_correct": true
      },
      {
        "parts": [
          "The decline was not ",
          "."
        ],
        "full": "The decline was not PERCEPTIBLE.",
        "jp": "その衰退は感知できなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 432,
    "word": "PERCEPTION",
    "meaning_core": "知覚",
    "syllables": [
      {
        "text": "per",
        "type": "weak"
      },
      {
        "text": "CEP",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AWARENESS": "認識",
      "SENSE": "感覚",
      "VIEW": "見方"
    },
    "distractors": [
      "IGNORANCE",
      "BLINDNESS",
      "REALITY",
      "FACT"
    ],
    "meanings_expanded": [
      "知覚",
      "認識",
      "見解"
    ],
    "contexts": [
      {
        "parts": [
          "His",
          "of reality is distorted."
        ],
        "full": "His PERCEPTION of reality is distorted.",
        "jp": "彼の現実認識は歪んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "Public",
          "has changed."
        ],
        "full": "Public PERCEPTION has changed.",
        "jp": "世間の見方は変わった。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a deep ",
          " of art."
        ],
        "full": "He has a deep PERCEPTION of art.",
        "jp": "彼は芸術に対する深い知覚を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "I suffer from visual ",
          "."
        ],
        "full": "I suffer from visual PERCEPTION.",
        "jp": "私は視覚の知覚に苦しんでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 433,
    "word": "PERILOUS",
    "meaning_core": "危険な",
    "syllables": [
      {
        "text": "PER",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "lous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DANGEROUS": "危険な",
      "HAZARDOUS": "有害な",
      "RISKY": "冒険的な"
    },
    "distractors": [
      "SAFE",
      "SECURE",
      "HARMLESS",
      "EASY"
    ],
    "meanings_expanded": [
      "危険な",
      "冒険的な"
    ],
    "contexts": [
      {
        "parts": [
          "The journey was",
          "."
        ],
        "full": "The journey was PERILOUS.",
        "jp": "その旅は危険だった。",
        "is_correct": true
      },
      {
        "parts": [
          "They made a ",
          " journey."
        ],
        "full": "They made a PERILOUS journey.",
        "jp": "彼らは危険な旅をした。",
        "is_correct": true
      },
      {
        "parts": [
          "The mountain path is ",
          "."
        ],
        "full": "The mountain path is PERILOUS.",
        "jp": "その山道は危険だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 434,
    "word": "PERMANENT",
    "meaning_core": "永久の",
    "syllables": [
      {
        "text": "PER",
        "type": "strong"
      },
      {
        "text": "ma",
        "type": "weak"
      },
      {
        "text": "nent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LASTING": "永続的な",
      "ETERNAL": "永遠の",
      "CONSTANT": "不変の"
    },
    "distractors": [
      "TEMPORARY",
      "BRIEF",
      "SHORT-TERM",
      "FLEETING"
    ],
    "meanings_expanded": [
      "永久の",
      "常設の",
      "耐久の"
    ],
    "contexts": [
      {
        "parts": [
          "He is looking for a",
          "job."
        ],
        "full": "He is looking for a PERMANENT job.",
        "jp": "彼は正社員（永久の職）を探している。",
        "is_correct": true
      },
      {
        "parts": [
          "She wants a ",
          " job."
        ],
        "full": "She wants a PERMANENT job.",
        "jp": "彼女は恒久的な仕事を望んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "The stain left a ",
          " mark."
        ],
        "full": "The stain left a PERMANENT mark.",
        "jp": "その染みは永久的な跡を残した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 435,
    "word": "PERMIT",
    "meaning_core": "許可する",
    "syllables": [
      {
        "text": "per",
        "type": "weak"
      },
      {
        "text": "MIT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ALLOW": "許す",
      "AUTHORIZE": "認可する",
      "GRANT": "与える"
    },
    "distractors": [
      "FORBID",
      "BAN",
      "PROHIBIT",
      "DENY"
    ],
    "meanings_expanded": [
      "許可する",
      "許す",
      "許可証（名詞・アクセント第一音節）"
    ],
    "contexts": [
      {
        "parts": [
          "Smoking is not",
          "here."
        ],
        "full": "Smoking is not permitted here.",
        "jp": "ここでは喫煙は許可されていない。",
        "is_correct": true
      },
      {
        "parts": [
          "The law does not ",
          " smoking here."
        ],
        "full": "The law does not PERMIT smoking here.",
        "jp": "法律はここでの喫煙を許可していない。",
        "is_correct": true
      },
      {
        "parts": [
          "Do you have a work ",
          "?"
        ],
        "full": "Do you have a work PERMIT?",
        "jp": "あなたは就労許可証を持っていますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 436,
    "word": "PERPETRATOR",
    "meaning_core": "犯人",
    "syllables": [
      {
        "text": "PER",
        "type": "strong"
      },
      {
        "text": "pe",
        "type": "weak"
      },
      {
        "text": "tra",
        "type": "weak"
      },
      {
        "text": "tor",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CRIMINAL": "犯罪者",
      "CULPRIT": "容疑者",
      "OFFENDER": "違反者"
    },
    "distractors": [
      "VICTIM",
      "POLICE",
      "WITNESS",
      "HERO"
    ],
    "meanings_expanded": [
      "犯人",
      "加害者"
    ],
    "contexts": [
      {
        "parts": [
          "Police are looking for the",
          "."
        ],
        "full": "Police are looking for the PERPETRATOR.",
        "jp": "警察は犯人を探している。",
        "is_correct": true
      },
      {
        "parts": [
          "Police are searching for the ",
          "."
        ],
        "full": "Police are searching for the PERPETRATOR.",
        "jp": "警察は犯人を捜している。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " of the fraud escaped."
        ],
        "full": "The PERPETRATOR of the fraud escaped.",
        "jp": "その詐欺の実行犯は逃亡した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 437,
    "word": "PERSUADE",
    "meaning_core": "説得する",
    "syllables": [
      {
        "text": "per",
        "type": "weak"
      },
      {
        "text": "SUADE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONVINCE": "納得させる",
      "INFLUENCE": "影響を与える",
      "URGE": "促す"
    },
    "distractors": [
      "DISSUADE",
      "FORCE",
      "ORDER",
      "PREVENT"
    ],
    "meanings_expanded": [
      "説得する",
      "信じさせる"
    ],
    "contexts": [
      {
        "parts": [
          "I tried to",
          "him to go."
        ],
        "full": "I tried to PERSUADE him to go.",
        "jp": "私は彼に行くように説得しようとした。",
        "is_correct": true
      },
      {
        "parts": [
          "I could not ",
          " him to stay."
        ],
        "full": "I could not PERSUADE him to stay.",
        "jp": "私は彼を引き留めるよう説得できなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to ",
          " her to change her mind."
        ],
        "full": "Try to PERSUADE her to change her mind.",
        "jp": "彼女に考えを変えるよう説得しなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 438,
    "word": "PHENOMENON",
    "meaning_core": "現象",
    "syllables": [
      {
        "text": "phe",
        "type": "weak"
      },
      {
        "text": "NOM",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "non",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OCCURRENCE": "出来事",
      "EVENT": "事象",
      "FACT": "事実"
    },
    "distractors": [
      "THEORY",
      "IDEA",
      "ILLUSION",
      "FANTASY"
    ],
    "meanings_expanded": [
      "現象",
      "事象",
      "非凡な人"
    ],
    "contexts": [
      {
        "parts": [
          "Gravity is a natural",
          "."
        ],
        "full": "Gravity is a natural PHENOMENON.",
        "jp": "重力は自然現象だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Global warming is a huge ",
          "."
        ],
        "full": "Global warming is a huge PHENOMENON.",
        "jp": "地球温暖化は巨大な現象だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We observed a strange ",
          "."
        ],
        "full": "We observed a strange PHENOMENON.",
        "jp": "私たちは奇妙な現象を観察した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 439,
    "word": "PIONEER",
    "meaning_core": "開拓者",
    "syllables": [
      {
        "text": "pi",
        "type": "weak"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "NEER",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INNOVATOR": "革新者",
      "LEADER": "指導者",
      "EXPLORER": "探検家"
    },
    "distractors": [
      "FOLLOWER",
      "IMITATOR",
      "LATECOMER",
      "FOE"
    ],
    "meanings_expanded": [
      "開拓者",
      "先駆者",
      "切り開く"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "in space travel."
        ],
        "full": "He is a PIONEER in space travel.",
        "jp": "彼は宇宙旅行の先駆者だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She was a ",
          " in medicine."
        ],
        "full": "She was a PIONEER in medicine.",
        "jp": "彼女は医学の開拓者だった。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " new technologies."
        ],
        "full": "We need to PIONEER new technologies.",
        "jp": "私たちは新しい技術を開拓する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 440,
    "word": "PLAUSIBLE",
    "meaning_core": "もっともらしい",
    "syllables": [
      {
        "text": "PLAU",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BELIEVABLE": "信じられる",
      "REASONABLE": "妥当な",
      "CREDIBLE": "信用できる"
    },
    "distractors": [
      "IMPLAUSIBLE",
      "UNLIKELY",
      "IMPOSSIBLE",
      "ABSURD"
    ],
    "meanings_expanded": [
      "もっともらしい",
      "まことしやかな"
    ],
    "contexts": [
      {
        "parts": [
          "His explanation sounds",
          "."
        ],
        "full": "His explanation sounds PLAUSIBLE.",
        "jp": "彼の説明はもっともらしく聞こえる。",
        "is_correct": true
      },
      {
        "parts": [
          "His excuse sounds quite ",
          "."
        ],
        "full": "His excuse sounds quite PLAUSIBLE.",
        "jp": "彼の言い訳はかなりもっともらしく聞こえる。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " explanation."
        ],
        "full": "We need a PLAUSIBLE explanation.",
        "jp": "私たちにはもっともらしい説明が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 441,
    "word": "PLAUSIBLY",
    "meaning_core": "もっともらしく",
    "syllables": [
      {
        "text": "PLAU",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "bly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BELIEVABLY": "信じられるように",
      "REASONABLY": "合理的に"
    },
    "distractors": [
      "IMPLAUSIBLY",
      "ABSURDLY",
      "RIDICULOUSLY",
      "FALSELY"
    ],
    "meanings_expanded": [
      "もっともらしく"
    ],
    "contexts": [
      {
        "parts": [
          "She argued",
          "that she was innocent."
        ],
        "full": "She argued PLAUSIBLY that she was innocent.",
        "jp": "彼女は自分が無実であるともっともらしく主張した。",
        "is_correct": true
      },
      {
        "parts": [
          "He argued his point ",
          "."
        ],
        "full": "He argued his point PLAUSIBLY.",
        "jp": "彼は自分の論点をそれらしく主張した。",
        "is_correct": true
      },
      {
        "parts": [
          "She could ",
          " deny the charge."
        ],
        "full": "She could PLAUSIBLY deny the charge.",
        "jp": "彼女はもっともらしくその告発を否定できた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 442,
    "word": "PLEA",
    "meaning_core": "嘆願",
    "syllables": [
      {
        "text": "PLEA",
        "type": "strong"
      }
    ],
    "synonyms": {
      "APPEAL": "懇願",
      "REQUEST": "要請",
      "PETITION": "請願"
    },
    "distractors": [
      "COMMAND",
      "ORDER",
      "DEMAND",
      "REFUSAL"
    ],
    "meanings_expanded": [
      "嘆願",
      "懇願",
      "弁解"
    ],
    "contexts": [
      {
        "parts": [
          "He made a",
          "for mercy."
        ],
        "full": "He made a PLEA for mercy.",
        "jp": "彼は慈悲を求めて嘆願した。",
        "is_correct": true
      },
      {
        "parts": [
          "They made a desperate ",
          " for help."
        ],
        "full": "They made a desperate PLEA for help.",
        "jp": "彼らは助けを求める必死の嘆願をした。",
        "is_correct": true
      },
      {
        "parts": [
          "The suspect entered a guilty ",
          "."
        ],
        "full": "The suspect entered a guilty PLEA.",
        "jp": "容疑者は有罪の答弁をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 443,
    "word": "PLEASANT",
    "meaning_core": "快適な",
    "syllables": [
      {
        "text": "PLEAS",
        "type": "strong"
      },
      {
        "text": "ant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AGREEABLE": "感じの良い",
      "NICE": "素敵な",
      "ENJOYABLE": "楽しい"
    },
    "distractors": [
      "UNPLEASANT",
      "BAD",
      "TERRIBLE",
      "NASTY"
    ],
    "meanings_expanded": [
      "快適な",
      "楽しい",
      "好感の持てる"
    ],
    "contexts": [
      {
        "parts": [
          "We had a",
          "evening."
        ],
        "full": "We had a PLEASANT evening.",
        "jp": "私たちは楽しい夜を過ごした。",
        "is_correct": true
      },
      {
        "parts": [
          "We had a very ",
          " journey."
        ],
        "full": "We had a very PLEASANT journey.",
        "jp": "私たちはとても快適な旅をした。",
        "is_correct": true
      },
      {
        "parts": [
          "She has a ",
          " smile."
        ],
        "full": "She has a PLEASANT smile.",
        "jp": "彼女は感じの良い笑顔を持っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 444,
    "word": "PLUMBER",
    "meaning_core": "配管工",
    "syllables": [
      {
        "text": "PLUM",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PIPE FITTER": "配管工"
    },
    "distractors": [
      "ELECTRICIAN",
      "CARPENTER",
      "DOCTOR",
      "TEACHER"
    ],
    "meanings_expanded": [
      "配管工",
      "水道屋"
    ],
    "contexts": [
      {
        "parts": [
          "Call a",
          "to fix the leak."
        ],
        "full": "Call a PLUMBER to fix the leak.",
        "jp": "水漏れを直すために配管工を呼びなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Call the ",
          " for the leak."
        ],
        "full": "Call the PLUMBER for the leak.",
        "jp": "水漏れのために配管工を呼びなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " fixed the pipe."
        ],
        "full": "The PLUMBER fixed the pipe.",
        "jp": "配管工がパイプを修理した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 445,
    "word": "POLICY",
    "meaning_core": "政策",
    "syllables": [
      {
        "text": "POL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STRATEGY": "戦略",
      "PLAN": "計画",
      "RULE": "規則"
    },
    "distractors": [
      "CHAOS",
      "CHANCE",
      "ACCIDENT",
      "LUCK"
    ],
    "meanings_expanded": [
      "政策",
      "方針",
      "保険証券"
    ],
    "contexts": [
      {
        "parts": [
          "Honesty is the best",
          "."
        ],
        "full": "Honesty is the best POLICY.",
        "jp": "正直は最良の策（方針）だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The new tax ",
          " is controversial."
        ],
        "full": "The new tax POLICY is controversial.",
        "jp": "新しい税制は物議を醸している。",
        "is_correct": true
      },
      {
        "parts": [
          "Our company has a strict refund ",
          "."
        ],
        "full": "Our company has a strict refund POLICY.",
        "jp": "私たちの会社は厳格な返金方針がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 446,
    "word": "POLLUTANT",
    "meaning_core": "汚染物質",
    "syllables": [
      {
        "text": "pol",
        "type": "weak"
      },
      {
        "text": "LU",
        "type": "strong"
      },
      {
        "text": "tant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTAMINANT": "汚染物質",
      "WASTE": "廃棄物",
      "POISON": "毒"
    },
    "distractors": [
      "PURIFIER",
      "CLEANER",
      "NUTRIENT",
      "FOOD"
    ],
    "meanings_expanded": [
      "汚染物質",
      "汚染源"
    ],
    "contexts": [
      {
        "parts": [
          "Carbon dioxide is a major",
          "."
        ],
        "full": "Carbon dioxide is a major POLLUTANT.",
        "jp": "二酸化炭素は主要な汚染物質だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Car exhaust is a major ",
          "."
        ],
        "full": "Car exhaust is a major POLLUTANT.",
        "jp": "車の排気ガスは主要な汚染物質だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We must reduce water ",
          "."
        ],
        "full": "We must reduce water POLLUTANT.",
        "jp": "私たちは水質汚染物質を減らさなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 447,
    "word": "PORTRAY",
    "meaning_core": "描写する",
    "syllables": [
      {
        "text": "por",
        "type": "weak"
      },
      {
        "text": "TRAY",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DEPICT": "描く",
      "DESCRIBE": "描写する",
      "REPRESENT": "表現する"
    },
    "distractors": [
      "HIDE",
      "CONCEAL",
      "IGNORE",
      "DISTORT"
    ],
    "meanings_expanded": [
      "描写する",
      "（役を）演じる",
      "肖像を描く"
    ],
    "contexts": [
      {
        "parts": [
          "The movie",
          "him as a hero."
        ],
        "full": "The movie portrays him as a hero.",
        "jp": "その映画は彼を英雄として描いている。",
        "is_correct": true
      },
      {
        "parts": [
          "The film will ",
          " her life."
        ],
        "full": "The film will PORTRAY her life.",
        "jp": "その映画は彼女の人生を描写するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "How does the media ",
          " politicians?"
        ],
        "full": "How does the media PORTRAY politicians?",
        "jp": "メディアは政治家をどのように描写していますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 448,
    "word": "POTENTIAL",
    "meaning_core": "潜在的な",
    "syllables": [
      {
        "text": "po",
        "type": "weak"
      },
      {
        "text": "TEN",
        "type": "strong"
      },
      {
        "text": "tial",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POSSIBLE": "可能性のある",
      "PROBABLE": "ありそうな",
      "LATENT": "潜伏している"
    },
    "distractors": [
      "IMPOSSIBLE",
      "ACTUAL",
      "REAL",
      "EXISTING"
    ],
    "meanings_expanded": [
      "潜在的な",
      "可能性",
      "見込み"
    ],
    "contexts": [
      {
        "parts": [
          "He has great",
          "as a pianist."
        ],
        "full": "He has great POTENTIAL as a pianist.",
        "jp": "彼はピアニストとして大きな可能性を秘めている。",
        "is_correct": true
      },
      {
        "parts": [
          "The job has great ",
          " for growth."
        ],
        "full": "The job has great POTENTIAL for growth.",
        "jp": "その仕事は成長の大きな潜在能力がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a ",
          " leader."
        ],
        "full": "She is a POTENTIAL leader.",
        "jp": "彼女は潜在的なリーダーだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 449,
    "word": "POVERTY",
    "meaning_core": "貧困",
    "syllables": [
      {
        "text": "POV",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NEED": "困窮",
      "DESTITUTION": "極貧",
      "SCARCITY": "欠乏"
    },
    "distractors": [
      "WEALTH",
      "RICHES",
      "AFFLUENCE",
      "PLENTY"
    ],
    "meanings_expanded": [
      "貧困",
      "貧乏",
      "欠乏"
    ],
    "contexts": [
      {
        "parts": [
          "Many people live in",
          "."
        ],
        "full": "Many people live in POVERTY.",
        "jp": "多くの人々が貧困の中で暮らしている。",
        "is_correct": true
      },
      {
        "parts": [
          "We must fight global ",
          "."
        ],
        "full": "We must fight global POVERTY.",
        "jp": "私たちは世界の貧困と戦わなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The family lived in abject ",
          "."
        ],
        "full": "The family lived in abject POVERTY.",
        "jp": "その家族は極度の貧困の中で暮らした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 450,
    "word": "PRECEDE",
    "meaning_core": "先行する",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "CEDE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "COME BEFORE": "先に来る",
      "LEAD": "先導する",
      "HERALD": "予告する"
    },
    "distractors": [
      "FOLLOW",
      "SUCCEED",
      "COME AFTER",
      "TRAIL"
    ],
    "meanings_expanded": [
      "先行する",
      "（地位などが）上位である"
    ],
    "contexts": [
      {
        "parts": [
          "Lightning usually",
          "thunder."
        ],
        "full": "Lightning usually precedes thunder.",
        "jp": "稲妻はたいてい雷鳴に先行する。",
        "is_correct": true
      },
      {
        "parts": [
          "The talk will ",
          " the dinner."
        ],
        "full": "The talk will PRECEDE the dinner.",
        "jp": "その講演は夕食に先行するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "A title should ",
          " the content."
        ],
        "full": "A title should PRECEDE the content.",
        "jp": "タイトルは内容に先行すべきだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 451,
    "word": "PRECIOUS",
    "meaning_core": "貴重な",
    "syllables": [
      {
        "text": "PRE",
        "type": "strong"
      },
      {
        "text": "cious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VALUABLE": "高価な",
      "PRICELESS": "プライスレスな",
      "DEAR": "愛しい"
    },
    "distractors": [
      "CHEAP",
      "WORTHLESS",
      "USELESS",
      "COMMON"
    ],
    "meanings_expanded": [
      "貴重な",
      "高価な",
      "大切な"
    ],
    "contexts": [
      {
        "parts": [
          "Time is",
          ", so don't waste it."
        ],
        "full": "Time is PRECIOUS, so don't waste it.",
        "jp": "時間は貴重だから、無駄にしてはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "Time is a ",
          " resource."
        ],
        "full": "Time is a PRECIOUS resource.",
        "jp": "時間は貴重な資源だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She kept the ",
          " family heirlooms."
        ],
        "full": "She kept the PRECIOUS family heirlooms.",
        "jp": "彼女は貴重な家宝を保管した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 452,
    "word": "PRECISE",
    "meaning_core": "正確な",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "CISE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXACT": "正確な",
      "ACCURATE": "精密な",
      "SPECIFIC": "特定の"
    },
    "distractors": [
      "VAGUE",
      "ROUGH",
      "UNCERTAIN",
      "APPROXIMATE"
    ],
    "meanings_expanded": [
      "正確な",
      "精密な",
      "寸分違わぬ"
    ],
    "contexts": [
      {
        "parts": [
          "Please give me a",
          "answer."
        ],
        "full": "Please give me a PRECISE answer.",
        "jp": "正確な答えをください。",
        "is_correct": true
      },
      {
        "parts": [
          "Give me a ",
          " answer."
        ],
        "full": "Give me a PRECISE answer.",
        "jp": "正確な答えをください。",
        "is_correct": true
      },
      {
        "parts": [
          "The measurements must be ",
          "."
        ],
        "full": "The measurements must be PRECISE.",
        "jp": "測定値は正確でなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 453,
    "word": "PRECISION",
    "meaning_core": "正確さ",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "CI",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ACCURACY": "正確度",
      "EXACTNESS": "厳密さ"
    },
    "distractors": [
      "ERROR",
      "MISTAKE",
      "GUESS",
      "ROUGHNESS"
    ],
    "meanings_expanded": [
      "正確さ",
      "精密",
      "几帳面さ"
    ],
    "contexts": [
      {
        "parts": [
          "The robot works with high",
          "."
        ],
        "full": "The robot works with high PRECISION.",
        "jp": "そのロボットは高い精度で動作する。",
        "is_correct": true
      },
      {
        "parts": [
          "The machine works with great ",
          "."
        ],
        "full": "The machine works with great PRECISION.",
        "jp": "その機械は高い正確さで動作する。",
        "is_correct": true
      },
      {
        "parts": [
          "We need surgical ",
          "."
        ],
        "full": "We need surgical PRECISION.",
        "jp": "私たちは外科的な正確さが必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 454,
    "word": "PREJUDICE",
    "meaning_core": "偏見",
    "syllables": [
      {
        "text": "PREJ",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "dice",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BIAS": "偏り",
      "DISCRIMINATION": "差別",
      "BIGOTRY": "偏狭"
    },
    "distractors": [
      "FAIRNESS",
      "JUSTICE",
      "EQUALITY",
      "TRUTH"
    ],
    "meanings_expanded": [
      "偏見",
      "先入観"
    ],
    "contexts": [
      {
        "parts": [
          "We must fight against racial",
          "."
        ],
        "full": "We must fight against racial PREJUDICE.",
        "jp": "私たちは人種的偏見と戦わなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "Avoid racial ",
          "."
        ],
        "full": "Avoid racial PREJUDICE.",
        "jp": "人種的偏見を避けなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "She fought against sex ",
          "."
        ],
        "full": "She fought against sex PREJUDICE.",
        "jp": "彼女は性差別（偏見）と闘った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 455,
    "word": "PRESCRIBE",
    "meaning_core": "処方する",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "SCRIBE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ORDER": "指示する",
      "DIRECT": "指図する"
    },
    "distractors": [
      "TAKE",
      "IGNORE",
      "REFUSE",
      "FORBID"
    ],
    "meanings_expanded": [
      "処方する",
      "規定する"
    ],
    "contexts": [
      {
        "parts": [
          "The doctor will",
          "medicine."
        ],
        "full": "The doctor will PRESCRIBE medicine.",
        "jp": "医師が薬を処方するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The doctor will ",
          " medicine."
        ],
        "full": "The doctor will PRESCRIBE medicine.",
        "jp": "医者は薬を処方するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The law ",
          " severe penalties."
        ],
        "full": "The law PRESCRIBE severe penalties.",
        "jp": "法律は厳しい罰則を規定する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 456,
    "word": "PRESCRIPTION",
    "meaning_core": "処方箋",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "SCRIP",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INSTRUCTION": "指示",
      "ORDER": "命令"
    },
    "distractors": [
      "DISEASE",
      "ILLNESS",
      "POISON",
      "SYMPTOM"
    ],
    "meanings_expanded": [
      "処方箋",
      "規定"
    ],
    "contexts": [
      {
        "parts": [
          "You need a",
          "to buy this drug."
        ],
        "full": "You need a PRESCRIPTION to buy this drug.",
        "jp": "この薬を買うには処方箋が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I picked up my ",
          "."
        ],
        "full": "I picked up my PRESCRIPTION.",
        "jp": "私は処方箋を受け取った。",
        "is_correct": true
      },
      {
        "parts": [
          "Do you need a new ",
          "?"
        ],
        "full": "Do you need a new PRESCRIPTION?",
        "jp": "新しい処方箋が必要ですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 457,
    "word": "PRESERVE",
    "meaning_core": "保存する",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "SERVE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PROTECT": "保護する",
      "MAINTAIN": "維持する",
      "SAVE": "守る"
    },
    "distractors": [
      "DESTROY",
      "RUIN",
      "DAMAGE",
      "WASTE"
    ],
    "meanings_expanded": [
      "保存する",
      "保護する",
      "保つ"
    ],
    "contexts": [
      {
        "parts": [
          "Salt helps to",
          "food."
        ],
        "full": "Salt helps to PRESERVE food.",
        "jp": "塩は食品を保存するのに役立つ。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the rainforests."
        ],
        "full": "We must PRESERVE the rainforests.",
        "jp": "私たちは熱帯雨林を保護しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "They work to ",
          " old customs."
        ],
        "full": "They work to PRESERVE old customs.",
        "jp": "彼らは古い習慣を維持するために働いている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 458,
    "word": "PRESTIGIOUS",
    "meaning_core": "著名な",
    "syllables": [
      {
        "text": "pres",
        "type": "weak"
      },
      {
        "text": "TIG",
        "type": "strong"
      },
      {
        "text": "ious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FAMOUS": "有名な",
      "DISTINGUISHED": "著名な",
      "ESTEEMED": "尊敬される"
    },
    "distractors": [
      "UNKNOWN",
      "COMMON",
      "OBSCURE",
      "ORDINARY"
    ],
    "meanings_expanded": [
      "著名な",
      "名声のある",
      "一流の"
    ],
    "contexts": [
      {
        "parts": [
          "She attends a",
          "university."
        ],
        "full": "She attends a PRESTIGIOUS university.",
        "jp": "彼女は名門大学に通っている。",
        "is_correct": true
      },
      {
        "parts": [
          "He won a ",
          " award."
        ],
        "full": "He won a PRESTIGIOUS award.",
        "jp": "彼は著名な賞を受賞した。",
        "is_correct": true
      },
      {
        "parts": [
          "She works at a ",
          " university."
        ],
        "full": "She works at a PRESTIGIOUS university.",
        "jp": "彼女は一流の大学で働いている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 459,
    "word": "PRETEXT",
    "meaning_core": "口実",
    "syllables": [
      {
        "text": "PRE",
        "type": "strong"
      },
      {
        "text": "text",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXCUSE": "言い訳",
      "PRETENSE": "見せかけ"
    },
    "distractors": [
      "TRUTH",
      "FACT",
      "REALITY",
      "HONESTY"
    ],
    "meanings_expanded": [
      "口実",
      "弁解"
    ],
    "contexts": [
      {
        "parts": [
          "He left early on the",
          "of illness."
        ],
        "full": "He left early on the PRETEXT of illness.",
        "jp": "彼は病気を口実に早退した。",
        "is_correct": true
      },
      {
        "parts": [
          "He called on the ",
          " of business."
        ],
        "full": "He called on the PRETEXT of business.",
        "jp": "彼はビジネスを口実として電話した。",
        "is_correct": true
      },
      {
        "parts": [
          "The argument was a mere ",
          "."
        ],
        "full": "The argument was a mere PRETEXT.",
        "jp": "その議論は単なる口実だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 460,
    "word": "PREVAIL",
    "meaning_core": "普及する",
    "syllables": [
      {
        "text": "pre",
        "type": "weak"
      },
      {
        "text": "VAIL",
        "type": "strong"
      }
    ],
    "synonyms": {
      "TRIUMPH": "勝利する",
      "SUCCEED": "成功する",
      "DOMINATE": "支配する"
    },
    "distractors": [
      "FAIL",
      "LOSE",
      "SURRENDER",
      "DISAPPEAR"
    ],
    "meanings_expanded": [
      "普及する",
      "優勢である",
      "打ち勝つ"
    ],
    "contexts": [
      {
        "parts": [
          "Justice will",
          "in the end."
        ],
        "full": "Justice will PREVAIL in the end.",
        "jp": "最後には正義が勝つ。",
        "is_correct": true
      },
      {
        "parts": [
          "Silence",
          "in the room."
        ],
        "full": "Silence prevailed in the room.",
        "jp": "部屋には静寂が支配していた。",
        "is_correct": true
      },
      {
        "parts": [
          "Justice will finally ",
          "."
        ],
        "full": "Justice will finally PREVAIL.",
        "jp": "正義は最終的に普及するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The custom continues to ",
          "."
        ],
        "full": "The custom continues to PREVAIL.",
        "jp": "その慣習は引き続き優勢だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 461,
    "word": "PREVALENT",
    "meaning_core": "普及している",
    "syllables": [
      {
        "text": "PREV",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "lent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMMON": "一般的な",
      "WIDESPREAD": "広まっている",
      "POPULAR": "人気のある"
    },
    "distractors": [
      "RARE",
      "UNCOMMON",
      "SCARCE",
      "UNIQUE"
    ],
    "meanings_expanded": [
      "普及している",
      "流行している"
    ],
    "contexts": [
      {
        "parts": [
          "Flu is",
          "in winter."
        ],
        "full": "Flu is PREVALENT in winter.",
        "jp": "インフルエンザは冬に流行する。",
        "is_correct": true
      },
      {
        "parts": [
          "That style is very ",
          " now."
        ],
        "full": "That style is very PREVALENT now.",
        "jp": "そのスタイルは今とても普及している。",
        "is_correct": true
      },
      {
        "parts": [
          "The disease is ",
          " in this area."
        ],
        "full": "The disease is PREVALENT in this area.",
        "jp": "その病気はこの地域に蔓延している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 462,
    "word": "PREVIOUSLY",
    "meaning_core": "以前に",
    "syllables": [
      {
        "text": "PRE",
        "type": "strong"
      },
      {
        "text": "vi",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BEFORE": "以前",
      "FORMERLY": "かつて",
      "EARLIER": "より早く"
    },
    "distractors": [
      "CURRENTLY",
      "NOW",
      "LATER",
      "FUTURE"
    ],
    "meanings_expanded": [
      "以前に",
      "前もって"
    ],
    "contexts": [
      {
        "parts": [
          "I have met him",
          "."
        ],
        "full": "I have met him PREVIOUSLY.",
        "jp": "私は以前彼に会ったことがある。",
        "is_correct": true
      },
      {
        "parts": [
          "I was ",
          " unaware of the risk."
        ],
        "full": "I was PREVIOUSLY unaware of the risk.",
        "jp": "私は以前そのリスクに気づいていなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "She had ",
          " worked in Tokyo."
        ],
        "full": "She had PREVIOUSLY worked in Tokyo.",
        "jp": "彼女は以前、東京で働いていた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 463,
    "word": "PRIMARILY",
    "meaning_core": "主に",
    "syllables": [
      {
        "text": "PRI",
        "type": "strong"
      },
      {
        "text": "ma",
        "type": "weak"
      },
      {
        "text": "ri",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MAINLY": "主に",
      "CHIEFLY": "主として",
      "MOSTLY": "大部分は"
    },
    "distractors": [
      "SECONDARILY",
      "FINALLY",
      "LASTLY",
      "RARELY"
    ],
    "meanings_expanded": [
      "主に",
      "第一に"
    ],
    "contexts": [
      {
        "parts": [
          "The diet consists",
          "of vegetables."
        ],
        "full": "The diet consists PRIMARILY of vegetables.",
        "jp": "その食事は主に野菜で構成されている。",
        "is_correct": true
      },
      {
        "parts": [
          "The issue is ",
          " economic."
        ],
        "full": "The issue is PRIMARILY economic.",
        "jp": "その問題は主として経済的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We cater ",
          " to students."
        ],
        "full": "We cater PRIMARILY to students.",
        "jp": "私たちはおもに学生を相手に商売をしている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 464,
    "word": "PRIME",
    "meaning_core": "最も重要な",
    "syllables": [
      {
        "text": "PRIME",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MAIN": "主な",
      "MAJOR": "主要な",
      "BEST": "最高の"
    },
    "distractors": [
      "MINOR",
      "WORST",
      "LAST",
      "LEAST"
    ],
    "meanings_expanded": [
      "最も重要な",
      "主要な",
      "最良の"
    ],
    "contexts": [
      {
        "parts": [
          "He is the",
          "suspect."
        ],
        "full": "He is the PRIME suspect.",
        "jp": "彼は主要な容疑者だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is the ",
          " example."
        ],
        "full": "This is the PRIME example.",
        "jp": "これが最も重要な例だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She is in the ",
          " of her career."
        ],
        "full": "She is in the PRIME of her career.",
        "jp": "彼女はキャリアの最盛期にある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 465,
    "word": "PRINCIPAL",
    "meaning_core": "主要な",
    "syllables": [
      {
        "text": "PRIN",
        "type": "strong"
      },
      {
        "text": "ci",
        "type": "weak"
      },
      {
        "text": "pal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MAIN": "主な",
      "CHIEF": "長の",
      "KEY": "重要な"
    },
    "distractors": [
      "MINOR",
      "SECONDARY",
      "TRIVIAL",
      "UNIMPORTANT"
    ],
    "meanings_expanded": [
      "主要な",
      "校長（名詞）",
      "主役"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "reason for his failure was laziness."
        ],
        "full": "The PRINCIPAL reason for his failure was laziness.",
        "jp": "彼の失敗の主な理由は怠惰だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He is the school",
          "."
        ],
        "full": "He is the school PRINCIPAL.",
        "jp": "彼は学校の校長だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " reason is the cost."
        ],
        "full": "The PRINCIPAL reason is the cost.",
        "jp": "主要な理由は費用だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is the school ",
          "."
        ],
        "full": "He is the school PRINCIPAL.",
        "jp": "彼は学校の校長だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 466,
    "word": "PRINCIPLE",
    "meaning_core": "原理",
    "syllables": [
      {
        "text": "PRIN",
        "type": "strong"
      },
      {
        "text": "ci",
        "type": "weak"
      },
      {
        "text": "ple",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RULE": "規則",
      "DOCTRINE": "教義",
      "BELIEF": "信念"
    },
    "distractors": [
      "EXCEPTION",
      "PRACTICE",
      "ACTION",
      "CHAOS"
    ],
    "meanings_expanded": [
      "原理",
      "原則",
      "主義"
    ],
    "contexts": [
      {
        "parts": [
          "It's a matter of",
          "."
        ],
        "full": "It's a matter of PRINCIPLE.",
        "jp": "それは主義の問題だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I agree in",
          "."
        ],
        "full": "I agree in PRINCIPLE.",
        "jp": "私は原則としては同意する。",
        "is_correct": true
      },
      {
        "parts": [
          "He stood firm on his ",
          "."
        ],
        "full": "He stood firm on his PRINCIPLE.",
        "jp": "彼は自分の原理を固く守った。",
        "is_correct": true
      },
      {
        "parts": [
          "The machine works on a simple ",
          "."
        ],
        "full": "The machine works on a simple PRINCIPLE.",
        "jp": "その機械は単純な原理で動作する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 467,
    "word": "PRIVILEGE",
    "meaning_core": "特権",
    "syllables": [
      {
        "text": "PRIV",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "lege",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HONOR": "名誉",
      "RIGHT": "権利",
      "ADVANTAGE": "利点"
    },
    "distractors": [
      "BURDEN",
      "DUTY",
      "DISADVANTAGE",
      "OBLIGATION"
    ],
    "meanings_expanded": [
      "特権",
      "名誉"
    ],
    "contexts": [
      {
        "parts": [
          "It is a",
          "to meet you."
        ],
        "full": "It is a PRIVILEGE to meet you.",
        "jp": "お会いできて光栄（特権）です。",
        "is_correct": true
      },
      {
        "parts": [
          "Education is a",
          ", not a right."
        ],
        "full": "Education is a PRIVILEGE, not a right.",
        "jp": "教育は特権であって、権利ではない（という意見もある）。",
        "is_correct": true
      },
      {
        "parts": [
          "It is a great ",
          " to meet you."
        ],
        "full": "It is a great PRIVILEGE to meet you.",
        "jp": "あなたにお会いできて大変光栄だ（特権だ）。",
        "is_correct": true
      },
      {
        "parts": [
          "Free speech is a ",
          "."
        ],
        "full": "Free speech is a PRIVILEGE.",
        "jp": "言論の自由は特権だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 468,
    "word": "PROBABLE",
    "meaning_core": "ありそうな",
    "syllables": [
      {
        "text": "PROB",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LIKELY": "ありそうな",
      "POSSIBLE": "可能な",
      "EXPECTED": "予想される"
    },
    "distractors": [
      "UNLIKELY",
      "IMPROBABLE",
      "IMPOSSIBLE",
      "RARE"
    ],
    "meanings_expanded": [
      "ありそうな",
      "確からしい"
    ],
    "contexts": [
      {
        "parts": [
          "It is",
          "that he will win."
        ],
        "full": "It is PROBABLE that he will win.",
        "jp": "彼が勝つ可能性が高い。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " cause is a short circuit."
        ],
        "full": "The PROBABLE cause is a short circuit.",
        "jp": "ありそうな原因はショートだ。",
        "is_correct": true
      },
      {
        "parts": [
          "It is highly ",
          " that he will win."
        ],
        "full": "It is highly PROBABLE that he will win.",
        "jp": "彼が勝つ可能性は非常に高い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 469,
    "word": "PROCEDURE",
    "meaning_core": "手順",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "CE",
        "type": "strong"
      },
      {
        "text": "dure",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PROCESS": "過程",
      "METHOD": "方法",
      "SYSTEM": "方式"
    },
    "distractors": [
      "CHAOS",
      "DISORDER",
      "RESULT",
      "END"
    ],
    "meanings_expanded": [
      "手順",
      "手続き",
      "処置"
    ],
    "contexts": [
      {
        "parts": [
          "Follow the correct",
          "."
        ],
        "full": "Follow the correct PROCEDURE.",
        "jp": "正しい手順に従いなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "Follow the correct safety ",
          "."
        ],
        "full": "Follow the correct safety PROCEDURE.",
        "jp": "正しい安全手順に従いなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "We have a standard appeal ",
          "."
        ],
        "full": "We have a standard appeal PROCEDURE.",
        "jp": "私たちには標準的な控訴の手順がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 470,
    "word": "PROFICIENCY",
    "meaning_core": "熟練",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "FI",
        "type": "strong"
      },
      {
        "text": "cien",
        "type": "weak"
      },
      {
        "text": "cy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SKILL": "技能",
      "EXPERTISE": "専門知識",
      "COMPETENCE": "能力"
    },
    "distractors": [
      "INCOMPETENCE",
      "IGNORANCE",
      "CLUMSINESS",
      "ABILITY"
    ],
    "meanings_expanded": [
      "熟練",
      "堪能",
      "実力"
    ],
    "contexts": [
      {
        "parts": [
          "He showed high",
          "in English."
        ],
        "full": "He showed high PROFICIENCY in English.",
        "jp": "彼は英語で高い熟練度を示した。",
        "is_correct": true
      },
      {
        "parts": [
          "He showed great ",
          " in English."
        ],
        "full": "He showed great PROFICIENCY in English.",
        "jp": "彼は英語に優れた熟練度を示した。",
        "is_correct": true
      },
      {
        "parts": [
          "We test for language ",
          "."
        ],
        "full": "We test for language PROFICIENCY.",
        "jp": "私たちは言語の習熟度をテストする。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 471,
    "word": "PROFITABLE",
    "meaning_core": "利益の上がる",
    "syllables": [
      {
        "text": "PROF",
        "type": "strong"
      },
      {
        "text": "it",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LUCRATIVE": "儲かる",
      "GAINFUL": "利益のある",
      "BENEFICIAL": "有益な"
    },
    "distractors": [
      "UNPROFITABLE",
      "USELESS",
      "LOSING",
      "WASTEFUL"
    ],
    "meanings_expanded": [
      "利益の上がる",
      "有益な",
      "儲かる"
    ],
    "contexts": [
      {
        "parts": [
          "The business is very",
          "."
        ],
        "full": "The business is very PROFITABLE.",
        "jp": "その事業は非常に利益が上がっている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 472,
    "word": "PROFOUND",
    "meaning_core": "深遠な",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "FOUND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DEEP": "深い",
      "INTENSE": "強烈な",
      "SERIOUS": "深刻な"
    },
    "distractors": [
      "SHALLOW",
      "SUPERFICIAL",
      "LIGHT",
      "MILD"
    ],
    "meanings_expanded": [
      "深遠な",
      "深い",
      "心からの"
    ],
    "contexts": [
      {
        "parts": [
          "He has a",
          "knowledge of history."
        ],
        "full": "He has a PROFOUND knowledge of history.",
        "jp": "彼は歴史について深遠な知識を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The book had a ",
          " effect on me."
        ],
        "full": "The book had a PROFOUND effect on me.",
        "jp": "その本は私に深遠な影響を与えた。",
        "is_correct": true
      },
      {
        "parts": [
          "He possesses ",
          " wisdom."
        ],
        "full": "He possesses PROFOUND wisdom.",
        "jp": "彼は深遠な知恵を持っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 473,
    "word": "PROFOUNDLY",
    "meaning_core": "深く",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "FOUND",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEEPLY": "深く",
      "GREATLY": "大いに",
      "EXTREMELY": "極めて"
    },
    "distractors": [
      "SLIGHTLY",
      "BARELY",
      "HARDLY",
      "LITTLE"
    ],
    "meanings_expanded": [
      "深く",
      "大いに",
      "心から"
    ],
    "contexts": [
      {
        "parts": [
          "I was",
          "moved by the movie."
        ],
        "full": "I was PROFOUNDLY moved by the movie.",
        "jp": "私はその映画に深く感動した。",
        "is_correct": true
      },
      {
        "parts": [
          "I was ",
          " influenced by her."
        ],
        "full": "I was PROFOUNDLY influenced by her.",
        "jp": "私は彼女に深く影響された。",
        "is_correct": true
      },
      {
        "parts": [
          "The news ",
          " shocked him."
        ],
        "full": "The news PROFOUNDLY shocked him.",
        "jp": "そのニュースは彼を深く驚かせた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 474,
    "word": "PROGRESSIVE",
    "meaning_core": "進歩的な",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "GRES",
        "type": "strong"
      },
      {
        "text": "sive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ADVANCED": "進んだ",
      "MODERN": "現代的な",
      "FORWARD": "前進する"
    },
    "distractors": [
      "CONSERVATIVE",
      "TRADITIONAL",
      "BACKWARD",
      "OLD"
    ],
    "meanings_expanded": [
      "進歩的な",
      "革新的な",
      "進行性の"
    ],
    "contexts": [
      {
        "parts": [
          "This school has a",
          "approach."
        ],
        "full": "This school has a PROGRESSIVE approach.",
        "jp": "この学校は進歩的なアプローチをとっている。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a ",
          " thinker."
        ],
        "full": "She is a PROGRESSIVE thinker.",
        "jp": "彼女は進歩的な思想家だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The disease is ",
          "."
        ],
        "full": "The disease is PROGRESSIVE.",
        "jp": "その病気は進行性だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 475,
    "word": "PROMOTE",
    "meaning_core": "促進する",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "MOTE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ENCOURAGE": "奨励する",
      "ADVANCE": "前進させる",
      "ADVERTISE": "宣伝する"
    },
    "distractors": [
      "HINDER",
      "BLOCK",
      "PREVENT",
      "STOP"
    ],
    "meanings_expanded": [
      "促進する",
      "昇進させる",
      "宣伝する"
    ],
    "contexts": [
      {
        "parts": [
          "Exercise helps to",
          "good health."
        ],
        "full": "Exercise helps to PROMOTE good health.",
        "jp": "運動は健康を促進するのに役立つ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " good health."
        ],
        "full": "We need to PROMOTE good health.",
        "jp": "私たちは健康を促進する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She was ",
          " to manager."
        ],
        "full": "She was PROMOTE to manager.",
        "jp": "彼女はマネージャーに昇進した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 476,
    "word": "PROPAGANDA",
    "meaning_core": "宣伝",
    "syllables": [
      {
        "text": "prop",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "GAN",
        "type": "strong"
      },
      {
        "text": "da",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PUBLICITY": "宣伝",
      "ADVERTISING": "広告",
      "HYPE": "誇大広告"
    },
    "distractors": [
      "TRUTH",
      "FACT",
      "REALITY",
      "HONESTY"
    ],
    "meanings_expanded": [
      "宣伝（活動）",
      "プロパガンダ"
    ],
    "contexts": [
      {
        "parts": [
          "The government used",
          "to influence people."
        ],
        "full": "The government used PROPAGANDA to influence people.",
        "jp": "政府は人々に影響を与えるためにプロパガンダを利用した。",
        "is_correct": true
      },
      {
        "parts": [
          "The state spread its ",
          "."
        ],
        "full": "The state spread its PROPAGANDA.",
        "jp": "国家はその宣伝を広めた。",
        "is_correct": true
      },
      {
        "parts": [
          "He saw through the enemy ",
          "."
        ],
        "full": "He saw through the enemy PROPAGANDA.",
        "jp": "彼は敵の宣伝を見抜いた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 477,
    "word": "PROPERLY",
    "meaning_core": "適切に",
    "syllables": [
      {
        "text": "PROP",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CORRECTLY": "正しく",
      "APPROPRIATELY": "適切に",
      "RIGHTLY": "正当に"
    },
    "distractors": [
      "INCORRECTLY",
      "WRONGLY",
      "BADLY",
      "POORLY"
    ],
    "meanings_expanded": [
      "適切に",
      "きちんと",
      "正しく"
    ],
    "contexts": [
      {
        "parts": [
          "Please behave",
          "."
        ],
        "full": "Please behave PROPERLY.",
        "jp": "きちんとした振る舞いをしてください。",
        "is_correct": true
      },
      {
        "parts": [
          "Do you know how to use it ",
          "?"
        ],
        "full": "Do you know how to use it PROPERLY?",
        "jp": "それを適切に使う方法を知っていますか。",
        "is_correct": true
      },
      {
        "parts": [
          "The door was not closed ",
          "."
        ],
        "full": "The door was not closed PROPERLY.",
        "jp": "ドアは適切に閉まっていなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 478,
    "word": "PROPERTY",
    "meaning_core": "財産",
    "syllables": [
      {
        "text": "PROP",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "POSSESSION": "所有物",
      "ASSET": "資産",
      "REAL ESTATE": "不動産"
    },
    "distractors": [
      "DEBT",
      "LIABILITY",
      "LOSS",
      "POVERTY"
    ],
    "meanings_expanded": [
      "財産",
      "不動産",
      "特性"
    ],
    "contexts": [
      {
        "parts": [
          "This land is private",
          "."
        ],
        "full": "This land is private PROPERTY.",
        "jp": "この土地は私有財産だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Water has the",
          "of being wet."
        ],
        "full": "Water has the PROPERTY of being wet.",
        "jp": "水には濡れているという特性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "This land is private ",
          "."
        ],
        "full": "This land is private PROPERTY.",
        "jp": "この土地は私有財産だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The house has excellent ",
          "."
        ],
        "full": "The house has excellent PROPERTY.",
        "jp": "その家には優れた特性がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 479,
    "word": "PROPORTION",
    "meaning_core": "割合",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "POR",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RATIO": "比率",
      "PERCENTAGE": "パーセンテージ",
      "SHARE": "分け前"
    },
    "distractors": [
      "WHOLE",
      "TOTALITY",
      "ALL",
      "ENTIRETY"
    ],
    "meanings_expanded": [
      "割合",
      "比率",
      "釣り合い"
    ],
    "contexts": [
      {
        "parts": [
          "A large",
          "of the budget is spent on food."
        ],
        "full": "A large PROPORTION of the budget is spent on food.",
        "jp": "予算の大部分が食費に使われる。",
        "is_correct": true
      },
      {
        "parts": [
          "The head is out of",
          "with the body."
        ],
        "full": "The head is out of PROPORTION with the body.",
        "jp": "頭が体と釣り合っていない。",
        "is_correct": true
      },
      {
        "parts": [
          "A small ",
          " of students failed."
        ],
        "full": "A small PROPORTION of students failed.",
        "jp": "わずかな割合の学生が不合格だった。",
        "is_correct": true
      },
      {
        "parts": [
          "Maintain the correct ",
          "."
        ],
        "full": "Maintain the correct PROPORTION.",
        "jp": "正しい比率を保ちなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 480,
    "word": "PROPOSE",
    "meaning_core": "提案する",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "POSE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SUGGEST": "提案する",
      "RECOMMEND": "推奨する",
      "OFFER": "申し出る"
    },
    "distractors": [
      "REJECT",
      "DENY",
      "WITHDRAW",
      "REFUSE"
    ],
    "meanings_expanded": [
      "提案する",
      "結婚を申し込む"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "a change in the plan."
        ],
        "full": "I PROPOSE a change in the plan.",
        "jp": "私は計画の変更を提案する。",
        "is_correct": true
      },
      {
        "parts": [
          "He plans to",
          "to her tonight."
        ],
        "full": "He plans to PROPOSE to her tonight.",
        "jp": "彼は今夜彼女にプロポーズするつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "I will ",
          " a new budget."
        ],
        "full": "I will PROPOSE a new budget.",
        "jp": "私は新しい予算を提案するつもりだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He plans to ",
          " to her soon."
        ],
        "full": "He plans to PROPOSE to her soon.",
        "jp": "彼はまもなく彼女にプロポーズする計画だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 481,
    "word": "PROSPECT",
    "meaning_core": "見通し",
    "syllables": [
      {
        "text": "PROS",
        "type": "strong"
      },
      {
        "text": "pect",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OUTLOOK": "見通し",
      "POSSIBILITY": "可能性",
      "CHANCE": "機会"
    },
    "distractors": [
      "PAST",
      "HISTORY",
      "MEMORY",
      "REALITY"
    ],
    "meanings_expanded": [
      "見通し",
      "可能性",
      "有望な人"
    ],
    "contexts": [
      {
        "parts": [
          "There is little",
          "of success."
        ],
        "full": "There is little PROSPECT of success.",
        "jp": "成功の見込みはほとんどない。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a promising",
          "for the team."
        ],
        "full": "He is a promising PROSPECT for the team.",
        "jp": "彼はチームにとって有望な新人だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The job has a good future ",
          "."
        ],
        "full": "The job has a good future PROSPECT.",
        "jp": "その仕事には良い将来の見通しがある。",
        "is_correct": true
      },
      {
        "parts": [
          "There is little ",
          " of rain."
        ],
        "full": "There is little PROSPECT of rain.",
        "jp": "雨が降る見込みはほとんどない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 482,
    "word": "PROTOCOL",
    "meaning_core": "議定書",
    "syllables": [
      {
        "text": "PRO",
        "type": "strong"
      },
      {
        "text": "to",
        "type": "weak"
      },
      {
        "text": "col",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PROCEDURE": "手順",
      "RULE": "規則",
      "AGREEMENT": "協定"
    },
    "distractors": [
      "CHAOS",
      "DISORDER",
      "ANARCHY",
      "CONFUSION"
    ],
    "meanings_expanded": [
      "議定書",
      "手順",
      "儀礼"
    ],
    "contexts": [
      {
        "parts": [
          "You must follow the safety",
          "."
        ],
        "full": "You must follow the safety PROTOCOL.",
        "jp": "安全手順（プロトコル）に従わなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "They signed the Kyoto",
          "."
        ],
        "full": "They signed the Kyoto PROTOCOL.",
        "jp": "彼らは京都議定書に署名した。",
        "is_correct": true
      },
      {
        "parts": [
          "They followed diplomatic ",
          "."
        ],
        "full": "They followed diplomatic PROTOCOL.",
        "jp": "彼らは外交儀礼（議定書）に従った。",
        "is_correct": true
      },
      {
        "parts": [
          "We established a new security ",
          "."
        ],
        "full": "We established a new security PROTOCOL.",
        "jp": "私たちは新しいセキュリティ規約を確立した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 484,
    "word": "PROVOKE",
    "meaning_core": "引き起こす",
    "syllables": [
      {
        "text": "pro",
        "type": "weak"
      },
      {
        "text": "VOKE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CAUSE": "引き起こす",
      "INCITE": "扇動する",
      "ANGER": "怒らせる"
    },
    "distractors": [
      "CALM",
      "SOOTHE",
      "PACIFY",
      "PLEASE"
    ],
    "meanings_expanded": [
      "引き起こす",
      "怒らせる",
      "挑発する"
    ],
    "contexts": [
      {
        "parts": [
          "His rude remark",
          "an argument."
        ],
        "full": "His rude remark provoked an argument.",
        "jp": "彼の失礼な発言が口論を引き起こした。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "the dog."
        ],
        "full": "Don't PROVOKE the dog.",
        "jp": "その犬を挑発するな。",
        "is_correct": true
      },
      {
        "parts": [
          "His words will ",
          " a reaction."
        ],
        "full": "His words will PROVOKE a reaction.",
        "jp": "彼の言葉は反応を引き起こすだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't ",
          " the dog."
        ],
        "full": "Don't PROVOKE the dog.",
        "jp": "犬を刺激しないでください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 485,
    "word": "PRUDENTLY",
    "meaning_core": "賢明に",
    "syllables": [
      {
        "text": "PRU",
        "type": "strong"
      },
      {
        "text": "dent",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WISELY": "賢く",
      "CAUTIOUSLY": "用心深く",
      "SENSIBLY": "分別を持って"
    },
    "distractors": [
      "FOOLISHLY",
      "RASHLY",
      "CARELESSLY",
      "RECKLESSLY"
    ],
    "meanings_expanded": [
      "賢明に",
      "慎重に"
    ],
    "contexts": [
      {
        "parts": [
          "She spent her money",
          "."
        ],
        "full": "She spent her money PRUDENTLY.",
        "jp": "彼女はお金を賢明に使った。",
        "is_correct": true
      },
      {
        "parts": [
          "She handled the money ",
          "."
        ],
        "full": "She handled the money PRUDENTLY.",
        "jp": "彼女は賢明にそのお金を処理した。",
        "is_correct": true
      },
      {
        "parts": [
          "He acted ",
          " in the crisis."
        ],
        "full": "He acted PRUDENTLY in the crisis.",
        "jp": "彼は危機において賢明に行動した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 486,
    "word": "PSYCHOLOGICAL",
    "meaning_core": "心理的な",
    "syllables": [
      {
        "text": "psy",
        "type": "weak"
      },
      {
        "text": "cho",
        "type": "weak"
      },
      {
        "text": "LOG",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MENTAL": "精神の",
      "EMOTIONAL": "感情の",
      "INNER": "内面の"
    },
    "distractors": [
      "PHYSICAL",
      "BODILY",
      "EXTERNAL",
      "MATERIAL"
    ],
    "meanings_expanded": [
      "心理的な",
      "精神の"
    ],
    "contexts": [
      {
        "parts": [
          "The problem is",
          ", not physical."
        ],
        "full": "The problem is PSYCHOLOGICAL, not physical.",
        "jp": "その問題は心理的なものであり、身体的なものではない。",
        "is_correct": true
      },
      {
        "parts": [
          "He suffered",
          "damage."
        ],
        "full": "He suffered PSYCHOLOGICAL damage.",
        "jp": "彼は精神的なダメージを受けた。",
        "is_correct": true
      },
      {
        "parts": [
          "He suffered from ",
          " stress."
        ],
        "full": "He suffered from PSYCHOLOGICAL stress.",
        "jp": "彼は心理的なストレスに苦しんだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We study ",
          " effects."
        ],
        "full": "We study PSYCHOLOGICAL effects.",
        "jp": "私たちは心理的な影響を研究する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 487,
    "word": "PURSUE",
    "meaning_core": "追求する",
    "syllables": [
      {
        "text": "pur",
        "type": "weak"
      },
      {
        "text": "SUE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CHASE": "追う",
      "FOLLOW": "従う",
      "SEEK": "求める"
    },
    "distractors": [
      "AVOID",
      "FLEE",
      "IGNORE",
      "GIVE UP"
    ],
    "meanings_expanded": [
      "追求する",
      "追跡する",
      "従事する"
    ],
    "contexts": [
      {
        "parts": [
          "He decided to",
          "a career in music."
        ],
        "full": "He decided to PURSUE a career in music.",
        "jp": "彼は音楽の道を追求することに決めた。",
        "is_correct": true
      },
      {
        "parts": [
          "The police",
          "the thief."
        ],
        "full": "The police pursued the thief.",
        "jp": "警察は泥棒を追跡した。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " the fleeing suspect."
        ],
        "full": "They will PURSUE the fleeing suspect.",
        "jp": "彼らは逃走中の容疑者を追跡するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "I want to ",
          " a career in art."
        ],
        "full": "I want to PURSUE a career in art.",
        "jp": "私は芸術のキャリアを追求したい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 488,
    "word": "QUARREL",
    "meaning_core": "口論",
    "syllables": [
      {
        "text": "QUAR",
        "type": "strong"
      },
      {
        "text": "rel",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ARGUMENT": "議論",
      "DISPUTE": "論争",
      "FIGHT": "喧嘩"
    },
    "distractors": [
      "AGREEMENT",
      "HARMONY",
      "PEACE",
      "ACCORD"
    ],
    "meanings_expanded": [
      "口論",
      "喧嘩"
    ],
    "contexts": [
      {
        "parts": [
          "They had a",
          "about money."
        ],
        "full": "They had a QUARREL about money.",
        "jp": "彼らはお金について口論した。",
        "is_correct": true
      },
      {
        "parts": [
          "They had a bitter ",
          " over money."
        ],
        "full": "They had a bitter QUARREL over money.",
        "jp": "彼らは金銭をめぐって激しい口論をした。",
        "is_correct": true
      },
      {
        "parts": [
          "Please do not ",
          " with him."
        ],
        "full": "Please do not QUARREL with him.",
        "jp": "彼と口論しないでください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 489,
    "word": "RAMPAGE",
    "meaning_core": "暴動",
    "syllables": [
      {
        "text": "RAM",
        "type": "strong"
      },
      {
        "text": "page",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RIOT": "暴動",
      "FRENZY": "狂乱",
      "UPROAR": "騒動"
    },
    "distractors": [
      "CALM",
      "PEACE",
      "ORDER",
      "QUIET"
    ],
    "meanings_expanded": [
      "暴れ回ること",
      "凶暴な行動"
    ],
    "contexts": [
      {
        "parts": [
          "The elephant went on a",
          "."
        ],
        "full": "The elephant went on a RAMPAGE.",
        "jp": "その象は暴れ回った。",
        "is_correct": true
      },
      {
        "parts": [
          "The animal went on a ",
          "."
        ],
        "full": "The animal went on a RAMPAGE.",
        "jp": "その動物は暴れ回った。",
        "is_correct": true
      },
      {
        "parts": [
          "He went on a drunken ",
          "."
        ],
        "full": "He went on a drunken RAMPAGE.",
        "jp": "彼は酔っぱらって暴れた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 490,
    "word": "RANGE",
    "meaning_core": "範囲",
    "syllables": [
      {
        "text": "RANGE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SCOPE": "範囲",
      "EXTENT": "程度",
      "VARIETY": "多様性"
    },
    "distractors": [
      "POINT",
      "LIMIT",
      "STAGNATION",
      "FIXEDNESS"
    ],
    "meanings_expanded": [
      "範囲",
      "山脈",
      "（範囲が）及ぶ"
    ],
    "contexts": [
      {
        "parts": [
          "The price",
          "is from $10 to $20."
        ],
        "full": "The price RANGE is from $10 to $20.",
        "jp": "価格帯は10ドルから20ドルだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The mountains",
          "from north to south."
        ],
        "full": "The mountains RANGE from north to south.",
        "jp": "山脈は北から南へと連なっている。",
        "is_correct": true
      },
      {
        "parts": [
          "The prices ",
          " from $5 to $50."
        ],
        "full": "The prices RANGE from $5 to $50.",
        "jp": "価格は5ドルから50ドルの範囲だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The mountain ",
          " is very long."
        ],
        "full": "The mountain RANGE is very long.",
        "jp": "その山脈はとても長い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 491,
    "word": "RATIONAL",
    "meaning_core": "合理的な",
    "syllables": [
      {
        "text": "RA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LOGICAL": "論理的な",
      "REASONABLE": "妥当な",
      "SENSIBLE": "分別のある"
    },
    "distractors": [
      "IRRATIONAL",
      "EMOTIONAL",
      "FOOLISH",
      "ABSURD"
    ],
    "meanings_expanded": [
      "合理的な",
      "理性的な"
    ],
    "contexts": [
      {
        "parts": [
          "Let's make a",
          "decision."
        ],
        "full": "Let's make a RATIONAL decision.",
        "jp": "合理的な決定を下そう。",
        "is_correct": true
      },
      {
        "parts": [
          "His decision was not ",
          "."
        ],
        "full": "His decision was not RATIONAL.",
        "jp": "彼の決定は合理的ではなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " approach."
        ],
        "full": "We need a RATIONAL approach.",
        "jp": "私たちには合理的なアプローチが必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 492,
    "word": "RAW",
    "meaning_core": "生の",
    "syllables": [
      {
        "text": "RAW",
        "type": "strong"
      }
    ],
    "synonyms": {
      "UNCOOKED": "未調理の",
      "CRUDE": "粗野な",
      "UNPROCESSED": "未加工の"
    },
    "distractors": [
      "COOKED",
      "PROCESSED",
      "REFINED",
      "DONE"
    ],
    "meanings_expanded": [
      "生の",
      "未加工の",
      "未熟な"
    ],
    "contexts": [
      {
        "parts": [
          "Sushi is made with",
          "fish."
        ],
        "full": "Sushi is made with RAW fish.",
        "jp": "寿司は生の魚で作られる。",
        "is_correct": true
      },
      {
        "parts": [
          "We export",
          "materials."
        ],
        "full": "We export RAW materials.",
        "jp": "私たちは原材料を輸出している。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not eat ",
          " meat."
        ],
        "full": "Do not eat RAW meat.",
        "jp": "生肉を食べてはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "The data is still ",
          "."
        ],
        "full": "The data is still RAW.",
        "jp": "そのデータはまだ未加工だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 493,
    "word": "RECESSION",
    "meaning_core": "不況",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "CES",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DOWNTURN": "下降",
      "SLUMP": "不振",
      "DEPRESSION": "不景気"
    },
    "distractors": [
      "BOOM",
      "GROWTH",
      "RECOVERY",
      "PROSPERITY"
    ],
    "meanings_expanded": [
      "不況",
      "景気後退"
    ],
    "contexts": [
      {
        "parts": [
          "The economy is in a deep",
          "."
        ],
        "full": "The economy is in a deep RECESSION.",
        "jp": "経済は深刻な不況にある。",
        "is_correct": true
      },
      {
        "parts": [
          "The country is in a deep ",
          "."
        ],
        "full": "The country is in a deep RECESSION.",
        "jp": "その国は深刻な不況にある。",
        "is_correct": true
      },
      {
        "parts": [
          "We are facing a global ",
          "."
        ],
        "full": "We are facing a global RECESSION.",
        "jp": "私たちは世界的な景気後退に直面している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 494,
    "word": "RECKLESSLY",
    "meaning_core": "向こう見ずに",
    "syllables": [
      {
        "text": "RECK",
        "type": "strong"
      },
      {
        "text": "less",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CARELESSLY": "不注意に",
      "RASHLY": "軽率に",
      "WILDLY": "乱暴に"
    },
    "distractors": [
      "CAREFULLY",
      "CAUTIOUSLY",
      "PRUDENTLY",
      "WISELY"
    ],
    "meanings_expanded": [
      "向こう見ずに",
      "無謀に"
    ],
    "contexts": [
      {
        "parts": [
          "He drove",
          "down the highway."
        ],
        "full": "He drove RECKLESSLY down the highway.",
        "jp": "彼は高速道路を無謀に運転した。",
        "is_correct": true
      },
      {
        "parts": [
          "He drove his car ",
          "."
        ],
        "full": "He drove his car RECKLESSLY.",
        "jp": "彼は向こう見ずに車を運転した。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not act ",
          "."
        ],
        "full": "Do not act RECKLESSLY.",
        "jp": "向こう見ずに行動しないでください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 495,
    "word": "RECONCILIATION",
    "meaning_core": "和解",
    "syllables": [
      {
        "text": "rec",
        "type": "weak"
      },
      {
        "text": "on",
        "type": "weak"
      },
      {
        "text": "cil",
        "type": "weak"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "A",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AGREEMENT": "合意",
      "HARMONY": "調和",
      "SETTLEMENT": "解決"
    },
    "distractors": [
      "CONFLICT",
      "WAR",
      "DISPUTE",
      "FIGHT"
    ],
    "meanings_expanded": [
      "和解",
      "仲直り",
      "調停"
    ],
    "contexts": [
      {
        "parts": [
          "They reached a",
          "after the fight."
        ],
        "full": "They reached a RECONCILIATION after the fight.",
        "jp": "彼らは喧嘩の後、和解に達した。",
        "is_correct": true
      },
      {
        "parts": [
          "They achieved a full ",
          "."
        ],
        "full": "They achieved a full RECONCILIATION.",
        "jp": "彼らは完全な和解を達成した。",
        "is_correct": true
      },
      {
        "parts": [
          "We hope for family ",
          "."
        ],
        "full": "We hope for family RECONCILIATION.",
        "jp": "私たちは家族の和解を望んでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 496,
    "word": "REFER",
    "meaning_core": "言及する",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "FER",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MENTION": "言及する",
      "CONSULT": "参照する",
      "RELATE": "関連する"
    },
    "distractors": [
      "IGNORE",
      "HIDE",
      "CONCEAL",
      "FORGET"
    ],
    "meanings_expanded": [
      "言及する",
      "参照する",
      "紹介する"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "to the manual."
        ],
        "full": "Please REFER to the manual.",
        "jp": "マニュアルを参照してください。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "to that incident."
        ],
        "full": "Don't REFER to that incident.",
        "jp": "その事件には言及しないで。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " to the manual."
        ],
        "full": "Please REFER to the manual.",
        "jp": "マニュアルを参照してください。",
        "is_correct": true
      },
      {
        "parts": [
          "The document must ",
          " to the contract."
        ],
        "full": "The document must REFER to the contract.",
        "jp": "その文書は契約書に言及しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 497,
    "word": "REFLECT",
    "meaning_core": "反映する",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "FLECT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MIRROR": "映す",
      "SHOW": "示す",
      "THINK": "熟考する"
    },
    "distractors": [
      "ABSORB",
      "HIDE",
      "IGNORE",
      "FORGET"
    ],
    "meanings_expanded": [
      "反映する",
      "反射する",
      "熟考する"
    ],
    "contexts": [
      {
        "parts": [
          "The mirror",
          "your face."
        ],
        "full": "The mirror reflects your face.",
        "jp": "鏡はあなたの顔を映す。",
        "is_correct": true
      },
      {
        "parts": [
          "His grades",
          "his effort."
        ],
        "full": "His grades REFLECT his effort.",
        "jp": "彼の成績は彼の努力を反映している。",
        "is_correct": true
      },
      {
        "parts": [
          "The water will ",
          " the sky."
        ],
        "full": "The water will REFLECT the sky.",
        "jp": "水は空を映すだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "His work ",
          " his values."
        ],
        "full": "His work REFLECT his values.",
        "jp": "彼の仕事は彼の価値観を反映している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 498,
    "word": "REGARD",
    "meaning_core": "みなす",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "GARD",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONSIDER": "みなす",
      "VIEW": "見る",
      "RESPECT": "尊敬する"
    },
    "distractors": [
      "IGNORE",
      "DISREGARD",
      "SCORN",
      "NEGLECT"
    ],
    "meanings_expanded": [
      "みなす",
      "評価する",
      "敬意"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "him as a friend."
        ],
        "full": "I REGARD him as a friend.",
        "jp": "私は彼を友人とみなしている。",
        "is_correct": true
      },
      {
        "parts": [
          "We ",
          " her as a friend."
        ],
        "full": "We REGARD her as a friend.",
        "jp": "私たちは彼女を友達とみなす。",
        "is_correct": true
      },
      {
        "parts": [
          "Please give my best ",
          " to him."
        ],
        "full": "Please give my best REGARD to him.",
        "jp": "彼によろしくお伝えください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 500,
    "word": "REGULATE",
    "meaning_core": "規制する",
    "syllables": [
      {
        "text": "REG",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "late",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTROL": "管理する",
      "MANAGE": "運営する",
      "GOVERN": "統治する"
    },
    "distractors": [
      "DEREGULATE",
      "CHAOS",
      "CONFUSE",
      "DISORDER"
    ],
    "meanings_expanded": [
      "規制する",
      "調整する",
      "取り締まる"
    ],
    "contexts": [
      {
        "parts": [
          "The law is designed to",
          "trade."
        ],
        "full": "The law is designed to REGULATE trade.",
        "jp": "その法律は貿易を規制するために作られた。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to",
          "the temperature."
        ],
        "full": "We need to REGULATE the temperature.",
        "jp": "私たちは温度を調整する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The government must ",
          " the banks."
        ],
        "full": "The government must REGULATE the banks.",
        "jp": "政府は銀行を規制しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "This device will ",
          " the temperature."
        ],
        "full": "This device will REGULATE the temperature.",
        "jp": "この装置が温度を調整するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 501,
    "word": "REGULATION",
    "meaning_core": "規制",
    "syllables": [
      {
        "text": "reg",
        "type": "weak"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "LA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RULE": "規則",
      "CONTROL": "管理",
      "RESTRICTION": "制限"
    },
    "distractors": [
      "FREEDOM",
      "CHAOS",
      "LIBERTY",
      "LICENSE"
    ],
    "meanings_expanded": [
      "規制",
      "規則",
      "調整"
    ],
    "contexts": [
      {
        "parts": [
          "We must follow the safety",
          "."
        ],
        "full": "We must follow the safety REGULATION.",
        "jp": "私たちは安全規則に従わなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We follow strict safety ",
          "."
        ],
        "full": "We follow strict safety REGULATION.",
        "jp": "私たちは厳格な安全規制に従う。",
        "is_correct": true
      },
      {
        "parts": [
          "The new ",
          " takes effect soon."
        ],
        "full": "The new REGULATION takes effect soon.",
        "jp": "新しい規制がまもなく施行される。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 502,
    "word": "REIGN",
    "meaning_core": "統治",
    "syllables": [
      {
        "text": "REIGN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "RULE": "支配",
      "GOVERNMENT": "政治",
      "SOVEREIGNTY": "主権"
    },
    "distractors": [
      "SERVITUDE",
      "SLAVERY",
      "OBEDIENCE",
      "SUBMISSION"
    ],
    "meanings_expanded": [
      "統治",
      "治世",
      "支配する"
    ],
    "contexts": [
      {
        "parts": [
          "The queen's",
          "lasted for 50 years."
        ],
        "full": "The queen's REIGN lasted for 50 years.",
        "jp": "女王の治世は50年続いた。",
        "is_correct": true
      },
      {
        "parts": [
          "The Queen's ",
          " lasted 50 years."
        ],
        "full": "The Queen's REIGN lasted 50 years.",
        "jp": "女王の統治は50年間続いた。",
        "is_correct": true
      },
      {
        "parts": [
          "Peace will soon ",
          "."
        ],
        "full": "Peace will soon REIGN.",
        "jp": "平和はすぐに支配するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 503,
    "word": "RELATE",
    "meaning_core": "関連づける",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "LATE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONNECT": "結びつける",
      "LINK": "関連させる",
      "ASSOCIATE": "連想する"
    },
    "distractors": [
      "SEPARATE",
      "DISCONNECT",
      "ISOLATE",
      "DIVIDE"
    ],
    "meanings_expanded": [
      "関連づける",
      "（話を）物語る",
      "共感する"
    ],
    "contexts": [
      {
        "parts": [
          "It is difficult to",
          "theory to practice."
        ],
        "full": "It is difficult to RELATE theory to practice.",
        "jp": "理論を実践に関連づけるのは難しい。",
        "is_correct": true
      },
      {
        "parts": [
          "This event might ",
          " to the crime."
        ],
        "full": "This event might RELATE to the crime.",
        "jp": "この出来事は犯罪に関連するかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "He finds it hard to ",
          " to people."
        ],
        "full": "He finds it hard to RELATE to people.",
        "jp": "彼は人とうまく付き合う（関連づける）のが難しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 504,
    "word": "RELATIVE",
    "meaning_core": "相対的な",
    "syllables": [
      {
        "text": "REL",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPARATIVE": "比較の",
      "RELEVANT": "関連した"
    },
    "distractors": [
      "ABSOLUTE",
      "TOTAL",
      "COMPLETE",
      "INDEPENDENT"
    ],
    "meanings_expanded": [
      "相対的な",
      "親戚（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "merits of the two plans."
        ],
        "full": "The RELATIVE merits of the two plans.",
        "jp": "その2つの計画の相対的なメリット。",
        "is_correct": true
      },
      {
        "parts": [
          "Her income is ",
          " to her expenses."
        ],
        "full": "Her income is RELATIVE to her expenses.",
        "jp": "彼女の収入は支出に比例している（相対的だ）。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a distant ",
          " of mine."
        ],
        "full": "He is a distant RELATIVE of mine.",
        "jp": "彼は私の遠い親戚だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 505,
    "word": "RELATIVELY",
    "meaning_core": "比較的",
    "syllables": [
      {
        "text": "REL",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "tive",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPARATIVELY": "比較的に",
      "RATHER": "いくぶん",
      "SOMEWHAT": "多少"
    },
    "distractors": [
      "ABSOLUTELY",
      "COMPLETELY",
      "TOTALLY",
      "ENTIRELY"
    ],
    "meanings_expanded": [
      "比較的",
      "割合に"
    ],
    "contexts": [
      {
        "parts": [
          "The test was",
          "easy."
        ],
        "full": "The test was RELATIVELY easy.",
        "jp": "そのテストは比較的簡単だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The task was ",
          " easy."
        ],
        "full": "The task was RELATIVELY easy.",
        "jp": "その作業は比較的簡単だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He is ",
          " unknown here."
        ],
        "full": "He is RELATIVELY unknown here.",
        "jp": "彼はここでは比較的無名だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 506,
    "word": "RELEVANT",
    "meaning_core": "関連のある",
    "syllables": [
      {
        "text": "REL",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "vant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PERTINENT": "適切な",
      "APPLICABLE": "適用できる",
      "RELATED": "関係のある"
    },
    "distractors": [
      "IRRELEVANT",
      "UNRELATED",
      "USELESS",
      "POINTLESS"
    ],
    "meanings_expanded": [
      "関連のある",
      "適切な",
      "今日的な意義のある"
    ],
    "contexts": [
      {
        "parts": [
          "Please provide",
          "documents."
        ],
        "full": "Please provide RELEVANT documents.",
        "jp": "関連書類を提出してください。",
        "is_correct": true
      },
      {
        "parts": [
          "Is this information ",
          " to the topic?"
        ],
        "full": "Is this information RELEVANT to the topic?",
        "jp": "この情報は話題に関連していますか。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to find ",
          " facts."
        ],
        "full": "We need to find RELEVANT facts.",
        "jp": "私たちには関連性のある事実を見つける必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 507,
    "word": "RELIABLE",
    "meaning_core": "信頼できる",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "LI",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DEPENDABLE": "頼りになる",
      "TRUSTWORTHY": "信用できる",
      "CREDIBLE": "確かな"
    },
    "distractors": [
      "UNRELIABLE",
      "DOUBTFUL",
      "FALSE",
      "UNTRUSTWORTHY"
    ],
    "meanings_expanded": [
      "信頼できる",
      "頼りになる",
      "確実な"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "source of information."
        ],
        "full": "He is a RELIABLE source of information.",
        "jp": "彼は信頼できる情報源だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " source of news."
        ],
        "full": "We need a RELIABLE source of news.",
        "jp": "私たちには信頼できるニュース源が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The car is old but ",
          "."
        ],
        "full": "The car is old but RELIABLE.",
        "jp": "その車は古いけれど信頼できる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 508,
    "word": "RELIGIOUS",
    "meaning_core": "宗教の",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "LI",
        "type": "strong"
      },
      {
        "text": "gious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SPIRITUAL": "精神的な",
      "DEVOUT": "信心深い",
      "HOLY": "神聖な"
    },
    "distractors": [
      "SECULAR",
      "ATHEIST",
      "WORLDLY",
      "IRRELIGIOUS"
    ],
    "meanings_expanded": [
      "宗教の",
      "信心深い"
    ],
    "contexts": [
      {
        "parts": [
          "Freedom of",
          "belief is important."
        ],
        "full": "Freedom of RELIGIOUS belief is important.",
        "jp": "宗教的信条の自由は重要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is not very",
          "."
        ],
        "full": "He is not very RELIGIOUS.",
        "jp": "彼はあまり信心深くない。",
        "is_correct": true
      },
      {
        "parts": [
          "She has strong ",
          " beliefs."
        ],
        "full": "She has strong RELIGIOUS beliefs.",
        "jp": "彼女は強い宗教上の信念を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "They practice a strict ",
          " tradition."
        ],
        "full": "They practice a strict RELIGIOUS tradition.",
        "jp": "彼らは厳格な宗教的伝統を実践している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 509,
    "word": "RELY",
    "meaning_core": "頼る",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "LY",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DEPEND": "依存する",
      "COUNT ON": "当てにする",
      "TRUST": "信頼する"
    },
    "distractors": [
      "DOUBT",
      "DISTRUST",
      "IGNORE",
      "REJECT"
    ],
    "meanings_expanded": [
      "～に頼る",
      "信頼する"
    ],
    "contexts": [
      {
        "parts": [
          "You can",
          "on me."
        ],
        "full": "You can RELY on me.",
        "jp": "私を頼りにしていいよ。",
        "is_correct": true
      },
      {
        "parts": [
          "You can always ",
          " on my help."
        ],
        "full": "You can always RELY on my help.",
        "jp": "あなたはいつでも私の助けを頼りにできる。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " on our own skills."
        ],
        "full": "We must RELY on our own skills.",
        "jp": "私たちは自分自身のスキルに頼らなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 510,
    "word": "REMARKABLE",
    "meaning_core": "注目すべき",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "MARK",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EXTRAORDINARY": "並外れた",
      "NOTABLE": "注目に値する",
      "IMPRESSIVE": "印象的な"
    },
    "distractors": [
      "ORDINARY",
      "COMMON",
      "AVERAGE",
      "UNREMARKABLE"
    ],
    "meanings_expanded": [
      "注目すべき",
      "驚くべき",
      "非凡な"
    ],
    "contexts": [
      {
        "parts": [
          "She has a",
          "talent."
        ],
        "full": "She has a REMARKABLE talent.",
        "jp": "彼女は驚くべき才能を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "She made a ",
          " recovery."
        ],
        "full": "She made a REMARKABLE recovery.",
        "jp": "彼女は注目すべき回復をした。",
        "is_correct": true
      },
      {
        "parts": [
          "His talent is truly ",
          "."
        ],
        "full": "His talent is truly REMARKABLE.",
        "jp": "彼の才能は本当に優れている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 511,
    "word": "REMIND",
    "meaning_core": "思い出させる",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "MIND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PROMPT": "促す",
      "RECALL": "思い出させる",
      "ALERT": "警告する"
    },
    "distractors": [
      "FORGET",
      "IGNORE",
      "SUPPRESS",
      "HIDE"
    ],
    "meanings_expanded": [
      "思い出させる",
      "気づかせる"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "me to call him."
        ],
        "full": "Please REMIND me to call him.",
        "jp": "彼に電話するのを思い出させてください。",
        "is_correct": true
      },
      {
        "parts": [
          "Please ",
          " me to call him."
        ],
        "full": "Please REMIND me to call him.",
        "jp": "彼に電話することを思い出させてください。",
        "is_correct": true
      },
      {
        "parts": [
          "The song ",
          " me of my youth."
        ],
        "full": "The song REMIND me of my youth.",
        "jp": "その歌は私に若かりし頃を思い出させる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 512,
    "word": "REMNANT",
    "meaning_core": "残り",
    "syllables": [
      {
        "text": "REM",
        "type": "strong"
      },
      {
        "text": "nant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REMAINS": "遺跡・残り",
      "RESIDUE": "残留物",
      "FRAGMENT": "破片"
    },
    "distractors": [
      "WHOLE",
      "TOTALITY",
      "BULK",
      "MASS"
    ],
    "meanings_expanded": [
      "残り",
      "面影",
      "残余"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "of an ancient city."
        ],
        "full": "The REMNANT of an ancient city.",
        "jp": "古代都市の遺跡（残り）。",
        "is_correct": true
      },
      {
        "parts": [
          "We found the ",
          " of an old wall."
        ],
        "full": "We found the REMNANT of an old wall.",
        "jp": "私たちは古い壁の残骸を見つけた。",
        "is_correct": true
      },
      {
        "parts": [
          "",
          " of snow were visible."
        ],
        "full": "REMNANT of snow were visible.",
        "jp": "雪の残りが見えた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 513,
    "word": "REMOTE",
    "meaning_core": "遠い",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "MOTE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DISTANT": "遠い",
      "ISOLATED": "孤立した",
      "FARAWAY": "はるか彼方の"
    },
    "distractors": [
      "NEAR",
      "CLOSE",
      "ADJACENT",
      "LOCAL"
    ],
    "meanings_expanded": [
      "遠い",
      "へんぴな",
      "（可能性が）わずかな"
    ],
    "contexts": [
      {
        "parts": [
          "He lives in a",
          "village."
        ],
        "full": "He lives in a REMOTE village.",
        "jp": "彼はへんぴな村に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "The village is in a ",
          " area."
        ],
        "full": "The village is in a REMOTE area.",
        "jp": "その村は遠隔地にある。",
        "is_correct": true
      },
      {
        "parts": [
          "We use a ",
          " control."
        ],
        "full": "We use a REMOTE control.",
        "jp": "私たちはリモコンを使う。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 514,
    "word": "REPERTOIRE",
    "meaning_core": "レパートリー",
    "syllables": [
      {
        "text": "REP",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "toire",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COLLECTION": "コレクション",
      "RANGE": "範囲",
      "STOCK": "蓄え"
    },
    "distractors": [
      "LACK",
      "SHORTAGE",
      "DEFICIT",
      "NEED"
    ],
    "meanings_expanded": [
      "レパートリー",
      "上演目録",
      "演奏曲目"
    ],
    "contexts": [
      {
        "parts": [
          "The pianist has a wide",
          "."
        ],
        "full": "The pianist has a wide REPERTOIRE.",
        "jp": "そのピアニストは広いレパートリーを持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a wide ",
          "."
        ],
        "full": "He has a wide REPERTOIRE.",
        "jp": "彼は幅広いレパートリーを持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The band expanded their ",
          "."
        ],
        "full": "The band expanded their REPERTOIRE.",
        "jp": "そのバンドはレパートリーを広げた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 515,
    "word": "REPLACE",
    "meaning_core": "取って代わる",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "PLACE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SUBSTITUTE": "代用する",
      "EXCHANGE": "交換する",
      "SUPPLANT": "取って代わる"
    },
    "distractors": [
      "KEEP",
      "MAINTAIN",
      "PRESERVE",
      "HOLD"
    ],
    "meanings_expanded": [
      "取って代わる",
      "取り替える",
      "交換する"
    ],
    "contexts": [
      {
        "parts": [
          "Robots may",
          "human workers."
        ],
        "full": "Robots may REPLACE human workers.",
        "jp": "ロボットが人間の労働者に取って代わるかもしれない。",
        "is_correct": true
      },
      {
        "parts": [
          "Technology will soon ",
          " the job."
        ],
        "full": "Technology will soon REPLACE the job.",
        "jp": "テクノロジーはすぐにその仕事に取って代わるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the broken part."
        ],
        "full": "We must REPLACE the broken part.",
        "jp": "私たちは壊れた部品を交換しなければならない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 516,
    "word": "REPRESENT",
    "meaning_core": "代表する",
    "syllables": [
      {
        "text": "rep",
        "type": "weak"
      },
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "SENT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SYMBOLIZE": "象徴する",
      "STAND FOR": "表す",
      "SPEAK FOR": "代弁する"
    },
    "distractors": [
      "MISREPRESENT",
      "HIDE",
      "CONCEAL",
      "IGNORE"
    ],
    "meanings_expanded": [
      "代表する",
      "表す",
      "象徴する"
    ],
    "contexts": [
      {
        "parts": [
          "The stars",
          "the states."
        ],
        "full": "The stars REPRESENT the states.",
        "jp": "星は州を象徴している。",
        "is_correct": true
      },
      {
        "parts": [
          "I will ",
          " the company at the meeting."
        ],
        "full": "I will REPRESENT the company at the meeting.",
        "jp": "私は会議で会社を代表する。",
        "is_correct": true
      },
      {
        "parts": [
          "These figures ",
          " the total cost."
        ],
        "full": "These figures REPRESENT the total cost.",
        "jp": "これらの数字が総費用を示している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 517,
    "word": "RESIDE",
    "meaning_core": "居住する",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "SIDE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "LIVE": "住む",
      "DWELL": "居住する",
      "INHABIT": "生息する"
    },
    "distractors": [
      "VISIT",
      "LEAVE",
      "DEPART",
      "VACATE"
    ],
    "meanings_expanded": [
      "居住する",
      "（性質などが）備わっている"
    ],
    "contexts": [
      {
        "parts": [
          "He",
          "in New York."
        ],
        "full": "He resides in New York.",
        "jp": "彼はニューヨークに住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "He continues to ",
          " in London."
        ],
        "full": "He continues to RESIDE in London.",
        "jp": "彼はロンドンに住み続けている。",
        "is_correct": true
      },
      {
        "parts": [
          "The main office ",
          " in Tokyo."
        ],
        "full": "The main office RESIDE in Tokyo.",
        "jp": "本社は東京に存在する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 518,
    "word": "RESILIENT",
    "meaning_core": "回復力のある",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "SIL",
        "type": "strong"
      },
      {
        "text": "ient",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TOUGH": "たくましい",
      "STRONG": "強い",
      "FLEXIBLE": "柔軟な"
    },
    "distractors": [
      "FRAGILE",
      "WEAK",
      "DELICATE",
      "BRITTLE"
    ],
    "meanings_expanded": [
      "回復力のある",
      "立ち直りの早い",
      "弾力のある"
    ],
    "contexts": [
      {
        "parts": [
          "Children are remarkably",
          "."
        ],
        "full": "Children are remarkably RESILIENT.",
        "jp": "子供たちは驚くほど回復力がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The economy proved highly ",
          "."
        ],
        "full": "The economy proved highly RESILIENT.",
        "jp": "経済は非常に回復力があると証明された。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a ",
          " young woman."
        ],
        "full": "She is a RESILIENT young woman.",
        "jp": "彼女は立ち直りの早い（回復力のある）若い女性だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 519,
    "word": "RESOLUTION",
    "meaning_core": "決意",
    "syllables": [
      {
        "text": "res",
        "type": "weak"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "LU",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DECISION": "決定",
      "DETERMINATION": "決意",
      "SOLUTION": "解決"
    },
    "distractors": [
      "HESITATION",
      "INDECISION",
      "DOUBT",
      "PROBLEM"
    ],
    "meanings_expanded": [
      "決意",
      "解決",
      "解像度"
    ],
    "contexts": [
      {
        "parts": [
          "She made a New Year's",
          "."
        ],
        "full": "She made a New Year's RESOLUTION.",
        "jp": "彼女は新年の抱負（決意）を立てた。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a",
          "to the problem."
        ],
        "full": "We need a solution to the problem.",
        "jp": "我々には問題の解決策が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We passed a clear ",
          "."
        ],
        "full": "We passed a clear RESOLUTION.",
        "jp": "私たちは明確な決議（決意）を採択した。",
        "is_correct": true
      },
      {
        "parts": [
          "He made a New Year's ",
          "."
        ],
        "full": "He made a New Year's RESOLUTION.",
        "jp": "彼は新年の抱負（決意）を立てた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 520,
    "word": "RESONATE",
    "meaning_core": "共鳴する",
    "syllables": [
      {
        "text": "RES",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "nate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ECHO": "響く",
      "VIBRATE": "振動する",
      "APPEAL": "訴えかける"
    },
    "distractors": [
      "DAMPEN",
      "SILENCE",
      "MUFFLE",
      "IGNORE"
    ],
    "meanings_expanded": [
      "共鳴する",
      "響き渡る",
      "心に響く"
    ],
    "contexts": [
      {
        "parts": [
          "His words",
          "with the audience."
        ],
        "full": "His words resonated with the audience.",
        "jp": "彼の言葉は聴衆の心に響いた（共鳴した）。",
        "is_correct": true
      },
      {
        "parts": [
          "His words strongly ",
          " with me."
        ],
        "full": "His words strongly RESONATE with me.",
        "jp": "彼の言葉は私に強く共鳴する。",
        "is_correct": true
      },
      {
        "parts": [
          "The sound will ",
          " in the hall."
        ],
        "full": "The sound will RESONATE in the hall.",
        "jp": "その音はホールに響き渡るだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 521,
    "word": "RESOURCE",
    "meaning_core": "資源",
    "syllables": [
      {
        "text": "RE",
        "type": "strong"
      },
      {
        "text": "source",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SUPPLY": "供給",
      "ASSET": "資産",
      "MEANS": "手段"
    },
    "distractors": [
      "LACK",
      "DEBT",
      "WASTE",
      "TRASH"
    ],
    "meanings_expanded": [
      "資源",
      "財源",
      "資質"
    ],
    "contexts": [
      {
        "parts": [
          "Water is a vital",
          "."
        ],
        "full": "Water is a vital RESOURCE.",
        "jp": "水は不可欠な資源だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Time is a valuable ",
          "."
        ],
        "full": "Time is a valuable RESOURCE.",
        "jp": "時間は貴重な資源だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need more financial ",
          "."
        ],
        "full": "We need more financial RESOURCE.",
        "jp": "私たちにはもっと財源が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 522,
    "word": "RESPONSIBILITY",
    "meaning_core": "責任",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "spon",
        "type": "weak"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "BIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DUTY": "義務",
      "OBLIGATION": "責務",
      "LIABILITY": "責任"
    },
    "distractors": [
      "FREEDOM",
      "EXCUSE",
      "EXEMPTION",
      "FUN"
    ],
    "meanings_expanded": [
      "責任",
      "義務"
    ],
    "contexts": [
      {
        "parts": [
          "It is your",
          "to finish the work."
        ],
        "full": "It is your RESPONSIBILITY to finish the work.",
        "jp": "仕事を終わらせるのは君の責任だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I have no",
          "to help you."
        ],
        "full": "I have no obligation to help you.",
        "jp": "君を助ける義務はない。",
        "is_correct": true
      },
      {
        "parts": [
          "The manager takes full ",
          "."
        ],
        "full": "The manager takes full RESPONSIBILITY.",
        "jp": "マネージャーが全責任を負う。",
        "is_correct": true
      },
      {
        "parts": [
          "It is my ",
          " to lead."
        ],
        "full": "It is my RESPONSIBILITY to lead.",
        "jp": "それは私が導くべき責任だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 523,
    "word": "RESPONSIBLE",
    "meaning_core": "責任がある",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "SPON",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ACCOUNTABLE": "説明責任がある",
      "IN CHARGE": "担当して",
      "RELIABLE": "信頼できる"
    },
    "distractors": [
      "IRRESPONSIBLE",
      "FREE",
      "CARELESS",
      "INNOCENT"
    ],
    "meanings_expanded": [
      "責任がある",
      "原因である"
    ],
    "contexts": [
      {
        "parts": [
          "Who is",
          "for this mess?"
        ],
        "full": "Who is RESPONSIBLE for this mess?",
        "jp": "この散らかりの責任は誰にあるのか？",
        "is_correct": true
      },
      {
        "parts": [
          "Who is ",
          " for this mistake?"
        ],
        "full": "Who is RESPONSIBLE for this mistake?",
        "jp": "誰がこの間違いに責任があるのか。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a very ",
          " worker."
        ],
        "full": "He is a very RESPONSIBLE worker.",
        "jp": "彼は非常に責任感のある労働者だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 524,
    "word": "RESTRAIN",
    "meaning_core": "抑制する",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "STRAIN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONTROL": "制御する",
      "HOLD BACK": "抑える",
      "LIMIT": "制限する"
    },
    "distractors": [
      "RELEASE",
      "FREE",
      "ENCOURAGE",
      "INCITE"
    ],
    "meanings_expanded": [
      "抑制する",
      "制止する",
      "拘束する"
    ],
    "contexts": [
      {
        "parts": [
          "He could barely",
          "his anger."
        ],
        "full": "He could barely RESTRAIN his anger.",
        "jp": "彼は怒りをかろうじて抑えた。",
        "is_correct": true
      },
      {
        "parts": [
          "She struggled to ",
          " her anger."
        ],
        "full": "She struggled to RESTRAIN her anger.",
        "jp": "彼女は怒りを抑えようと苦闘した。",
        "is_correct": true
      },
      {
        "parts": [
          "The guards had to ",
          " the prisoner."
        ],
        "full": "The guards had to RESTRAIN the prisoner.",
        "jp": "警備員は囚人を抑制しなければならなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 525,
    "word": "RETAIN",
    "meaning_core": "保持する",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "TAIN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "KEEP": "保つ",
      "MAINTAIN": "維持する",
      "HOLD": "保有する"
    },
    "distractors": [
      "LOSE",
      "DISCARD",
      "DROP",
      "ABANDON"
    ],
    "meanings_expanded": [
      "保持する",
      "雇っておく",
      "記憶しておく"
    ],
    "contexts": [
      {
        "parts": [
          "This soil",
          "water well."
        ],
        "full": "This soil retains water well.",
        "jp": "この土壌は水をよく保つ（保水性が良い）。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to ",
          " the information."
        ],
        "full": "Try to RETAIN the information.",
        "jp": "その情報を保持するように努めなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "He will ",
          " control of the company."
        ],
        "full": "He will RETAIN control of the company.",
        "jp": "彼は会社の支配権を維持するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 526,
    "word": "REVENUE",
    "meaning_core": "収益",
    "syllables": [
      {
        "text": "REV",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "nue",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INCOME": "所得",
      "PROFIT": "利益",
      "EARNINGS": "稼ぎ"
    },
    "distractors": [
      "EXPENSE",
      "COST",
      "LOSS",
      "DEBT"
    ],
    "meanings_expanded": [
      "収益",
      "歳入",
      "収入"
    ],
    "contexts": [
      {
        "parts": [
          "The company's",
          "increased significantly."
        ],
        "full": "The company's REVENUE increased significantly.",
        "jp": "会社の収益は大幅に増加した。",
        "is_correct": true
      },
      {
        "parts": [
          "The government collects tax ",
          "."
        ],
        "full": "The government collects tax REVENUE.",
        "jp": "政府は税収を集めている。",
        "is_correct": true
      },
      {
        "parts": [
          "Sales increased the company's ",
          "."
        ],
        "full": "Sales increased the company's REVENUE.",
        "jp": "売上が会社の収益を増やした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 527,
    "word": "REVISION",
    "meaning_core": "改訂",
    "syllables": [
      {
        "text": "re",
        "type": "weak"
      },
      {
        "text": "VI",
        "type": "strong"
      },
      {
        "text": "sion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CORRECTION": "訂正",
      "AMENDMENT": "修正",
      "REVIEW": "見直し"
    },
    "distractors": [
      "CREATION",
      "ORIGIN",
      "START",
      "DESTRUCTION"
    ],
    "meanings_expanded": [
      "改訂",
      "修正",
      "復習"
    ],
    "contexts": [
      {
        "parts": [
          "The book needs a",
          "."
        ],
        "full": "The book needs a REVISION.",
        "jp": "その本は改訂が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a major ",
          " of the plan."
        ],
        "full": "We need a major REVISION of the plan.",
        "jp": "私たちには計画の大幅な改訂が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The book is in its third ",
          "."
        ],
        "full": "The book is in its third REVISION.",
        "jp": "その本は第3版（改訂）だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 528,
    "word": "RIGID",
    "meaning_core": "厳格な",
    "syllables": [
      {
        "text": "RIG",
        "type": "strong"
      },
      {
        "text": "id",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STIFF": "硬い",
      "INFLEXIBLE": "曲がらない",
      "STRICT": "厳しい"
    },
    "distractors": [
      "FLEXIBLE",
      "SOFT",
      "ELASTIC",
      "GENTLE"
    ],
    "meanings_expanded": [
      "厳格な",
      "硬直した",
      "曲がらない"
    ],
    "contexts": [
      {
        "parts": [
          "The rules are very",
          "."
        ],
        "full": "The rules are very RIGID.",
        "jp": "そのルールは非常に厳格だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He has very ",
          " opinions."
        ],
        "full": "He has very RIGID opinions.",
        "jp": "彼は非常に厳格な意見を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The material is not ",
          "."
        ],
        "full": "The material is not RIGID.",
        "jp": "その素材は硬直していない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 529,
    "word": "RIGOROUS",
    "meaning_core": "厳しい",
    "syllables": [
      {
        "text": "RIG",
        "type": "strong"
      },
      {
        "text": "or",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STRICT": "厳しい",
      "THOROUGH": "徹底的な",
      "SEVERE": "過酷な"
    },
    "distractors": [
      "EASY",
      "LAX",
      "GENTLE",
      "MILD"
    ],
    "meanings_expanded": [
      "厳しい",
      "厳密な",
      "徹底的な"
    ],
    "contexts": [
      {
        "parts": [
          "The training was",
          "."
        ],
        "full": "The training was RIGOROUS.",
        "jp": "その訓練は厳しかった。",
        "is_correct": true
      },
      {
        "parts": [
          "They conducted a ",
          " analysis."
        ],
        "full": "They conducted a RIGOROUS analysis.",
        "jp": "彼らは厳しい分析を行った。",
        "is_correct": true
      },
      {
        "parts": [
          "The course is quite ",
          "."
        ],
        "full": "The course is quite RIGOROUS.",
        "jp": "その講座はかなり厳しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 530,
    "word": "RURAL",
    "meaning_core": "田舎の",
    "syllables": [
      {
        "text": "RU",
        "type": "strong"
      },
      {
        "text": "ral",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COUNTRY": "田舎の",
      "RUSTIC": "素朴な",
      "PASTORAL": "牧歌的な"
    },
    "distractors": [
      "URBAN",
      "CITY",
      "METROPOLITAN",
      "MODERN"
    ],
    "meanings_expanded": [
      "田舎の",
      "農村の"
    ],
    "contexts": [
      {
        "parts": [
          "He lives in a",
          "area."
        ],
        "full": "He lives in a RURAL area.",
        "jp": "彼は田舎の地域に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "We live in a quiet ",
          " area."
        ],
        "full": "We live in a quiet RURAL area.",
        "jp": "私たちは静かな田舎の地域に住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "He prefers ",
          " life."
        ],
        "full": "He prefers RURAL life.",
        "jp": "彼は田舎の生活を好む。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 531,
    "word": "SARCASTIC",
    "meaning_core": "皮肉な",
    "syllables": [
      {
        "text": "sar",
        "type": "weak"
      },
      {
        "text": "CAS",
        "type": "strong"
      },
      {
        "text": "tic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IRONIC": "皮肉な",
      "MOCKING": "あざける",
      "CYNICAL": "冷笑的な"
    },
    "distractors": [
      "SINCERE",
      "HONEST",
      "KIND",
      "SERIOUS"
    ],
    "meanings_expanded": [
      "皮肉な",
      "嫌味な"
    ],
    "contexts": [
      {
        "parts": [
          "He made a",
          "remark."
        ],
        "full": "He made a SARCASTIC remark.",
        "jp": "彼は皮肉な発言をした。",
        "is_correct": true
      },
      {
        "parts": [
          "He made a ",
          " comment."
        ],
        "full": "He made a SARCASTIC comment.",
        "jp": "彼は皮肉なコメントをした。",
        "is_correct": true
      },
      {
        "parts": [
          "Her tone was ",
          "."
        ],
        "full": "Her tone was SARCASTIC.",
        "jp": "彼女の口調は皮肉だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 532,
    "word": "SATELLITE",
    "meaning_core": "衛星",
    "syllables": [
      {
        "text": "SAT",
        "type": "strong"
      },
      {
        "text": "el",
        "type": "weak"
      },
      {
        "text": "lite",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MOON": "衛星（月）",
      "ORBITER": "周回機"
    },
    "distractors": [
      "PLANET",
      "STAR",
      "SUN",
      "CORE"
    ],
    "meanings_expanded": [
      "衛星",
      "人工衛星"
    ],
    "contexts": [
      {
        "parts": [
          "The moon is a",
          "of the Earth."
        ],
        "full": "The moon is a SATELLITE of the Earth.",
        "jp": "月は地球の衛星だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They launched a new weather ",
          "."
        ],
        "full": "They launched a new weather SATELLITE.",
        "jp": "彼らは新しい気象衛星を打ち上げた。",
        "is_correct": true
      },
      {
        "parts": [
          "The company uses a communications ",
          "."
        ],
        "full": "The company uses a communications SATELLITE.",
        "jp": "その会社は通信衛星を使用している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 533,
    "word": "SATISFACTION",
    "meaning_core": "満足",
    "syllables": [
      {
        "text": "sat",
        "type": "weak"
      },
      {
        "text": "is",
        "type": "weak"
      },
      {
        "text": "FAC",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTENTMENT": "満足感",
      "PLEASURE": "喜び",
      "FULFILLMENT": "充実感"
    },
    "distractors": [
      "DISSATISFACTION",
      "DISAPPOINTMENT",
      "ANGER",
      "FRUSTRATION"
    ],
    "meanings_expanded": [
      "満足",
      "充足"
    ],
    "contexts": [
      {
        "parts": [
          "Customer",
          "is our goal."
        ],
        "full": "Customer SATISFACTION is our goal.",
        "jp": "顧客満足が私たちの目標だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Customer ",
          " is our goal."
        ],
        "full": "Customer SATISFACTION is our goal.",
        "jp": "顧客の満足が私たちの目標だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She expressed her deep ",
          "."
        ],
        "full": "She expressed her deep SATISFACTION.",
        "jp": "彼女は深い満足を表明した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 534,
    "word": "SCALE",
    "meaning_core": "規模",
    "syllables": [
      {
        "text": "SCALE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SIZE": "大きさ",
      "EXTENT": "程度",
      "DEGREE": "度合い"
    },
    "distractors": [
      "POINT",
      "DOT",
      "DETAIL",
      "NOTHING"
    ],
    "meanings_expanded": [
      "規模",
      "尺度",
      "（魚などの）うろこ"
    ],
    "contexts": [
      {
        "parts": [
          "This map is drawn to",
          "."
        ],
        "full": "This map is drawn to SCALE.",
        "jp": "この地図は縮尺通りに描かれている。",
        "is_correct": true
      },
      {
        "parts": [
          "The",
          "of the disaster was huge."
        ],
        "full": "The SCALE of the disaster was huge.",
        "jp": "災害の規模は甚大だった。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to increase the ",
          " of production."
        ],
        "full": "We need to increase the SCALE of production.",
        "jp": "私たちは生産の規模を拡大する必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The map is drawn to ",
          "."
        ],
        "full": "The map is drawn to SCALE.",
        "jp": "その地図は縮尺通りに描かれている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 535,
    "word": "SCARCE",
    "meaning_core": "乏しい",
    "syllables": [
      {
        "text": "SCARCE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "RARE": "珍しい",
      "LIMITED": "限られた",
      "INSUFFICIENT": "不十分な"
    },
    "distractors": [
      "ABUNDANT",
      "PLENTIFUL",
      "COMMON",
      "ENOUGH"
    ],
    "meanings_expanded": [
      "乏しい",
      "不足している",
      "稀な"
    ],
    "contexts": [
      {
        "parts": [
          "Food was",
          "during the war."
        ],
        "full": "Food was SCARCE during the war.",
        "jp": "戦時中は食料が乏しかった。",
        "is_correct": true
      },
      {
        "parts": [
          "Food was becoming ",
          "."
        ],
        "full": "Food was becoming SCARCE.",
        "jp": "食糧が乏しくなっていた。",
        "is_correct": true
      },
      {
        "parts": [
          "Clean water is a ",
          " commodity."
        ],
        "full": "Clean water is a SCARCE commodity.",
        "jp": "きれいな水は乏しい必需品だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 536,
    "word": "SCARCELY",
    "meaning_core": "ほとんど～ない",
    "syllables": [
      {
        "text": "SCARCE",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HARDLY": "ほとんど～ない",
      "BARELY": "かろうじて",
      "RARELY": "めったに～ない"
    },
    "distractors": [
      "FREQUENTLY",
      "OFTEN",
      "ALWAYS",
      "COMPLETELY"
    ],
    "meanings_expanded": [
      "ほとんど～ない",
      "かろうじて"
    ],
    "contexts": [
      {
        "parts": [
          "I could",
          "believe my eyes."
        ],
        "full": "I could SCARCELY believe my eyes.",
        "jp": "私は自分の目をほとんど信じられなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "I could ",
          " hear the music."
        ],
        "full": "I could SCARCELY hear the music.",
        "jp": "私はかろうじて音楽が聞こえる程度だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He had ",
          " any money left."
        ],
        "full": "He had SCARCELY any money left.",
        "jp": "彼にはほとんどお金が残っていなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 537,
    "word": "SECONDARY",
    "meaning_core": "第二の",
    "syllables": [
      {
        "text": "SEC",
        "type": "strong"
      },
      {
        "text": "on",
        "type": "weak"
      },
      {
        "text": "dar",
        "type": "weak"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MINOR": "重要でない",
      "SUBORDINATE": "従属的な",
      "LESSER": "より小さい"
    },
    "distractors": [
      "PRIMARY",
      "MAIN",
      "MAJOR",
      "FIRST"
    ],
    "meanings_expanded": [
      "第二の",
      "中等の",
      "二次的な"
    ],
    "contexts": [
      {
        "parts": [
          "Money is of",
          "importance."
        ],
        "full": "Money is of SECONDARY importance.",
        "jp": "お金は二の次（二次的な重要性）だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is only a ",
          " issue."
        ],
        "full": "This is only a SECONDARY issue.",
        "jp": "これは単なる第二の問題だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She teaches ",
          " school students."
        ],
        "full": "She teaches SECONDARY school students.",
        "jp": "彼女は中等学校の生徒を教えている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 538,
    "word": "SEEK",
    "meaning_core": "探し求める",
    "syllables": [
      {
        "text": "SEEK",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SEARCH FOR": "探す",
      "LOOK FOR": "探す",
      "PURSUE": "追求する"
    },
    "distractors": [
      "IGNORE",
      "AVOID",
      "HIDE",
      "FIND"
    ],
    "meanings_expanded": [
      "探し求める",
      "～しようと努める"
    ],
    "contexts": [
      {
        "parts": [
          "They",
          "shelter from the rain."
        ],
        "full": "They SEEK shelter from the rain.",
        "jp": "彼らは雨宿りする場所を探し求めている。",
        "is_correct": true
      },
      {
        "parts": [
          "Don't",
          "trouble."
        ],
        "full": "Don't SEEK trouble.",
        "jp": "トラブルを自ら招くな（探し求めるな）。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " justice for all."
        ],
        "full": "We must SEEK justice for all.",
        "jp": "私たちは皆のために正義を追い求めるべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He came here to ",
          " his fortune."
        ],
        "full": "He came here to SEEK his fortune.",
        "jp": "彼は財産を求めてここに来た。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 539,
    "word": "SEEMINGLY",
    "meaning_core": "どうやら〜らしい",
    "syllables": [
      {
        "text": "SEEM",
        "type": "strong"
      },
      {
        "text": "ing",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "APPARENTLY": "見たところ",
      "OUTWARDLY": "表面上は",
      "SUPPOSEDLY": "たぶん"
    },
    "distractors": [
      "ACTUALLY",
      "REALLY",
      "TRULY",
      "DEFINITELY"
    ],
    "meanings_expanded": [
      "どうやら～らしい",
      "見たところ"
    ],
    "contexts": [
      {
        "parts": [
          "It was a",
          "impossible task."
        ],
        "full": "It was a SEEMINGLY impossible task.",
        "jp": "それは一見不可能に思える仕事だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The injury was ",
          " minor."
        ],
        "full": "The injury was SEEMINGLY minor.",
        "jp": "その怪我は一見すると軽微だった。",
        "is_correct": true
      },
      {
        "parts": [
          "He ",
          " ignored my question."
        ],
        "full": "He SEEMINGLY ignored my question.",
        "jp": "どうやら彼は私の質問を無視したらしい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 540,
    "word": "SENIOR",
    "meaning_core": "年上の",
    "syllables": [
      {
        "text": "SEN",
        "type": "strong"
      },
      {
        "text": "ior",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ELDER": "年長の",
      "SUPERIOR": "上位の",
      "HIGHER": "より高い"
    },
    "distractors": [
      "JUNIOR",
      "YOUNGER",
      "INFERIOR",
      "MINOR"
    ],
    "meanings_expanded": [
      "年上の",
      "先輩の",
      "上級の"
    ],
    "contexts": [
      {
        "parts": [
          "He is",
          "to me by two years."
        ],
        "full": "He is SENIOR to me by two years.",
        "jp": "彼は私より2歳年上だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is three years my ",
          "."
        ],
        "full": "He is three years my SENIOR.",
        "jp": "彼は私より3歳年上だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " manager handles the case."
        ],
        "full": "The SENIOR manager handles the case.",
        "jp": "上級管理職がその案件を扱う。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 541,
    "word": "SENSIBLE",
    "meaning_core": "分別のある",
    "syllables": [
      {
        "text": "SEN",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "REASONABLE": "合理的な",
      "PRACTICAL": "実用的な",
      "WISE": "賢い"
    },
    "distractors": [
      "FOOLISH",
      "STUPID",
      "SENSELESS",
      "CRAZY"
    ],
    "meanings_expanded": [
      "分別のある",
      "賢明な",
      "実用的な"
    ],
    "contexts": [
      {
        "parts": [
          "That was a",
          "decision."
        ],
        "full": "That was a SENSIBLE decision.",
        "jp": "それは賢明な判断だった。",
        "is_correct": true
      },
      {
        "parts": [
          "That is a very ",
          " idea."
        ],
        "full": "That is a very SENSIBLE idea.",
        "jp": "それはとても分別のある考えだ。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a very ",
          " person."
        ],
        "full": "She is a very SENSIBLE person.",
        "jp": "彼女はとても分別のある人だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 542,
    "word": "SENSITIVE",
    "meaning_core": "敏感な",
    "syllables": [
      {
        "text": "SEN",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "tive",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DELICATE": "繊細な",
      "RESPONSIVE": "反応する",
      "TOUCHY": "怒りっぽい"
    },
    "distractors": [
      "INSENSITIVE",
      "TOUGH",
      "NUMB",
      "INDIFFERENT"
    ],
    "meanings_expanded": [
      "敏感な",
      "繊細な",
      "傷つきやすい"
    ],
    "contexts": [
      {
        "parts": [
          "She is very",
          "to criticism."
        ],
        "full": "She is very SENSITIVE to criticism.",
        "jp": "彼女は批判に対してとても敏感だ。",
        "is_correct": true
      },
      {
        "parts": [
          "My teeth are",
          "to cold."
        ],
        "full": "My teeth are SENSITIVE to cold.",
        "jp": "私の歯は冷たいものにしみる（敏感だ）。",
        "is_correct": true
      },
      {
        "parts": [
          "He is very ",
          " about his weight."
        ],
        "full": "He is very SENSITIVE about his weight.",
        "jp": "彼は自分の体重について非常に敏感だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The skin is ",
          " to sunlight."
        ],
        "full": "The skin is SENSITIVE to sunlight.",
        "jp": "皮膚は日光に敏感だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 543,
    "word": "SEPARATE",
    "meaning_core": "別々の",
    "syllables": [
      {
        "text": "SEP",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "rate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISTINCT": "別個の",
      "DETACHED": "離れた",
      "DIFFERENT": "異なる"
    },
    "distractors": [
      "CONNECTED",
      "JOINED",
      "UNITED",
      "SAME"
    ],
    "meanings_expanded": [
      "別々の",
      "離れた",
      "分離する（動詞）"
    ],
    "contexts": [
      {
        "parts": [
          "We have",
          "rooms."
        ],
        "full": "We have SEPARATE rooms.",
        "jp": "私たちは別々の部屋を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "They arrived at ",
          " times."
        ],
        "full": "They arrived at SEPARATE times.",
        "jp": "彼らは別々の時間に到着した。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the white clothes."
        ],
        "full": "We need to SEPARATE the white clothes.",
        "jp": "私たちは白い服を分ける必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 544,
    "word": "SEQUEL",
    "meaning_core": "続編",
    "syllables": [
      {
        "text": "SE",
        "type": "strong"
      },
      {
        "text": "quel",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FOLLOW-UP": "続編",
      "CONTINUATION": "続き",
      "PART TWO": "パート2"
    },
    "distractors": [
      "PREQUEL",
      "ORIGINAL",
      "BEGINNING",
      "START"
    ],
    "meanings_expanded": [
      "続編",
      "後日談",
      "成り行き"
    ],
    "contexts": [
      {
        "parts": [
          "The movie",
          "was disappointing."
        ],
        "full": "The movie SEQUEL was disappointing.",
        "jp": "映画の続編は期待外れだった。",
        "is_correct": true
      },
      {
        "parts": [
          "The film's ",
          " was very popular."
        ],
        "full": "The film's SEQUEL was very popular.",
        "jp": "その映画の続編はとても人気があった。",
        "is_correct": true
      },
      {
        "parts": [
          "Is there a book ",
          " to this?"
        ],
        "full": "Is there a book SEQUEL to this?",
        "jp": "これに続く本の続編はありますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 545,
    "word": "SEQUEL",
    "meaning_core": "続編",
    "syllables": [
      {
        "text": "SE",
        "type": "strong"
      },
      {
        "text": "quel",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONTINUATION": "続き",
      "SUCCESSOR": "後継"
    },
    "distractors": [
      "ORIGIN",
      "SOURCE",
      "PREFACE"
    ],
    "meanings_expanded": [
      "続編",
      "結果"
    ],
    "contexts": [
      {
        "parts": [
          "I am writing a",
          "to my book."
        ],
        "full": "I am writing a SEQUEL to my book.",
        "jp": "私は自分の本の続編を書いている。",
        "is_correct": true
      },
      {
        "parts": [
          "The film's ",
          " was very popular."
        ],
        "full": "The film's SEQUEL was very popular.",
        "jp": "その映画の続編はとても人気があった。",
        "is_correct": true
      },
      {
        "parts": [
          "Is there a book ",
          " to this?"
        ],
        "full": "Is there a book SEQUEL to this?",
        "jp": "これに続く本の続編はありますか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 546,
    "word": "SERENE",
    "meaning_core": "穏やかな",
    "syllables": [
      {
        "text": "se",
        "type": "weak"
      },
      {
        "text": "RENE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CALM": "静かな",
      "PEACEFUL": "平和な",
      "TRANQUIL": "平穏な"
    },
    "distractors": [
      "STORMY",
      "CHAOTIC",
      "NOISY",
      "AGITATED"
    ],
    "meanings_expanded": [
      "穏やかな",
      "静かな",
      "落ち着いた"
    ],
    "contexts": [
      {
        "parts": [
          "The lake looked",
          "in the moonlight."
        ],
        "full": "The lake looked SERENE in the moonlight.",
        "jp": "月光の中で湖は穏やかに見えた。",
        "is_correct": true
      },
      {
        "parts": [
          "The lake was calm and ",
          "."
        ],
        "full": "The lake was calm and SERENE.",
        "jp": "その湖は穏やかで静かだった。",
        "is_correct": true
      },
      {
        "parts": [
          "She had a ",
          " look on her face."
        ],
        "full": "She had a SERENE look on her face.",
        "jp": "彼女は顔に穏やかな表情を浮かべていた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 547,
    "word": "SERENELY",
    "meaning_core": "穏やかに",
    "syllables": [
      {
        "text": "se",
        "type": "weak"
      },
      {
        "text": "RENE",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CALMLY": "静かに",
      "PEACEFULLY": "平和に"
    },
    "distractors": [
      "ANGRILY",
      "VIOLENTLY",
      "LOUDLY",
      "WILDLY"
    ],
    "meanings_expanded": [
      "穏やかに",
      "静かに"
    ],
    "contexts": [
      {
        "parts": [
          "She smiled",
          "."
        ],
        "full": "She smiled SERENELY.",
        "jp": "彼女は穏やかに微笑んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He smiled ",
          " at the world."
        ],
        "full": "He smiled SERENELY at the world.",
        "jp": "彼は世界に穏やかに微笑んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "She walked ",
          " through the park."
        ],
        "full": "She walked SERENELY through the park.",
        "jp": "彼女は公園を静かに通り抜けた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 548,
    "word": "SEVERE",
    "meaning_core": "厳しい",
    "syllables": [
      {
        "text": "se",
        "type": "weak"
      },
      {
        "text": "VERE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "STRICT": "厳格な",
      "HARSH": "過酷な",
      "SERIOUS": "深刻な"
    },
    "distractors": [
      "MILD",
      "GENTLE",
      "MINOR",
      "LIGHT"
    ],
    "meanings_expanded": [
      "厳しい",
      "深刻な",
      "激しい"
    ],
    "contexts": [
      {
        "parts": [
          "He suffered",
          "injuries."
        ],
        "full": "He suffered SEVERE injuries.",
        "jp": "彼は重傷（深刻な怪我）を負った。",
        "is_correct": true
      },
      {
        "parts": [
          "The damage was quite ",
          "."
        ],
        "full": "The damage was quite SEVERE.",
        "jp": "損害はかなり厳しかった。",
        "is_correct": true
      },
      {
        "parts": [
          "We faced a ",
          " winter storm."
        ],
        "full": "We faced a SEVERE winter storm.",
        "jp": "私たちは厳しい冬の嵐に直面した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 549,
    "word": "SHORT-TERM",
    "meaning_core": "短期的な",
    "syllables": [
      {
        "text": "SHORT",
        "type": "strong"
      },
      {
        "text": "term",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TEMPORARY": "一時的な",
      "BRIEF": "短い",
      "FLEETING": "つかの間の"
    },
    "distractors": [
      "LONG-TERM",
      "PERMANENT",
      "LASTING",
      "FOREVER"
    ],
    "meanings_expanded": [
      "短期的な",
      "短期間の"
    ],
    "contexts": [
      {
        "parts": [
          "This is a",
          "solution."
        ],
        "full": "This is a SHORT-TERM solution.",
        "jp": "これは短期的な解決策だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " loan."
        ],
        "full": "We need a SHORT-TERM loan.",
        "jp": "私たちには短期的な融資が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a ",
          " solution only."
        ],
        "full": "This is a SHORT-TERM solution only.",
        "jp": "これは短期的な解決策にすぎない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 550,
    "word": "SHRED",
    "meaning_core": "ちぎる",
    "syllables": [
      {
        "text": "SHRED",
        "type": "strong"
      }
    ],
    "synonyms": {
      "TEAR": "引き裂く",
      "RIP": "破る",
      "CUT": "切る"
    },
    "distractors": [
      "MEND",
      "REPAIR",
      "FIX",
      "JOIN"
    ],
    "meanings_expanded": [
      "ちぎる",
      "細断する",
      "断片"
    ],
    "contexts": [
      {
        "parts": [
          "Please",
          "these documents."
        ],
        "full": "Please SHRED these documents.",
        "jp": "これらの書類をシュレッダーにかけて（細断して）ください。",
        "is_correct": true
      },
      {
        "parts": [
          "There is not a",
          "of evidence."
        ],
        "full": "There is not a SHRED of evidence.",
        "jp": "証拠のかけらもない。",
        "is_correct": true
      },
      {
        "parts": [
          "The dog will ",
          " the paper."
        ],
        "full": "The dog will SHRED the paper.",
        "jp": "犬は紙を細かくちぎるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "There is not a ",
          " of evidence."
        ],
        "full": "There is not a SHRED of evidence.",
        "jp": "証拠は微塵もない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 551,
    "word": "SIGNIFICANTLY",
    "meaning_core": "かなり",
    "syllables": [
      {
        "text": "sig",
        "type": "weak"
      },
      {
        "text": "NIF",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cant",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONSIDERABLY": "相当に",
      "NOTABLY": "著しく",
      "GREATLY": "大いに"
    },
    "distractors": [
      "SLIGHTLY",
      "BARELY",
      "HARDLY",
      "LITTLE"
    ],
    "meanings_expanded": [
      "かなり",
      "著しく",
      "意味ありげに"
    ],
    "contexts": [
      {
        "parts": [
          "Sales have increased",
          "."
        ],
        "full": "Sales have increased SIGNIFICANTLY.",
        "jp": "売上がかなり増加した。",
        "is_correct": true
      },
      {
        "parts": [
          "The price dropped ",
          "."
        ],
        "full": "The price dropped SIGNIFICANTLY.",
        "jp": "価格はかなり下落した。",
        "is_correct": true
      },
      {
        "parts": [
          "Her health improved ",
          "."
        ],
        "full": "Her health improved SIGNIFICANTLY.",
        "jp": "彼女の健康は著しく改善した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 552,
    "word": "SINCERITY",
    "meaning_core": "誠実さ",
    "syllables": [
      {
        "text": "sin",
        "type": "weak"
      },
      {
        "text": "CER",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HONESTY": "正直",
      "GENUINENESS": "純粋さ",
      "TRUTH": "真実"
    },
    "distractors": [
      "HYPOCRISY",
      "DECEIT",
      "LIES",
      "DISHONESTY"
    ],
    "meanings_expanded": [
      "誠実さ",
      "正直",
      "本心"
    ],
    "contexts": [
      {
        "parts": [
          "I doubt his",
          "."
        ],
        "full": "I doubt his SINCERITY.",
        "jp": "私は彼の誠実さを疑っている。",
        "is_correct": true
      },
      {
        "parts": [
          "We doubt his ",
          "."
        ],
        "full": "We doubt his SINCERITY.",
        "jp": "私たちは彼の誠実さを疑う。",
        "is_correct": true
      },
      {
        "parts": [
          "She spoke with great ",
          "."
        ],
        "full": "She spoke with great SINCERITY.",
        "jp": "彼女は非常に誠実に話した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 553,
    "word": "SKEPTICAL",
    "meaning_core": "懐疑的な",
    "syllables": [
      {
        "text": "SKEP",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DOUBTFUL": "疑っている",
      "SUSPICIOUS": "怪しんでいる",
      "CYNICAL": "冷笑的な"
    },
    "distractors": [
      "CERTAIN",
      "SURE",
      "CONFIDENT",
      "CONVINCED"
    ],
    "meanings_expanded": [
      "懐疑的な",
      "疑い深い"
    ],
    "contexts": [
      {
        "parts": [
          "I am",
          "about the plan."
        ],
        "full": "I am SKEPTICAL about the plan.",
        "jp": "私はその計画に懐疑的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I am ",
          " about his claims."
        ],
        "full": "I am SKEPTICAL about his claims.",
        "jp": "私は彼の主張に懐疑的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The audience remained ",
          "."
        ],
        "full": "The audience remained SKEPTICAL.",
        "jp": "聴衆は懐疑的なままだった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 554,
    "word": "SLIGHT",
    "meaning_core": "わずかな",
    "syllables": [
      {
        "text": "SLIGHT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SMALL": "小さい",
      "MINOR": "些細な",
      "TINY": "ごくわずかな"
    },
    "distractors": [
      "HUGE",
      "SIGNIFICANT",
      "MAJOR",
      "LARGE"
    ],
    "meanings_expanded": [
      "わずかな",
      "少しの",
      "ほっそりした"
    ],
    "contexts": [
      {
        "parts": [
          "There is a",
          "chance of rain."
        ],
        "full": "There is a SLIGHT chance of rain.",
        "jp": "雨の可能性がわずかにある。",
        "is_correct": true
      },
      {
        "parts": [
          "There was a ",
          " change in temperature."
        ],
        "full": "There was a SLIGHT change in temperature.",
        "jp": "気温にわずかな変化があった。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a ",
          " fever."
        ],
        "full": "He has a SLIGHT fever.",
        "jp": "彼は微熱がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 555,
    "word": "SLUGGISH",
    "meaning_core": "不景気な",
    "syllables": [
      {
        "text": "SLUG",
        "type": "strong"
      },
      {
        "text": "gish",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SLOW": "遅い",
      "INACTIVE": "不活発な",
      "STAGNANT": "停滞した"
    },
    "distractors": [
      "ACTIVE",
      "FAST",
      "BOOMING",
      "ENERGETIC"
    ],
    "meanings_expanded": [
      "不景気な",
      "停滞した",
      "のろい"
    ],
    "contexts": [
      {
        "parts": [
          "The economy is",
          "."
        ],
        "full": "The economy is SLUGGISH.",
        "jp": "経済は停滞している（不景気だ）。",
        "is_correct": true
      },
      {
        "parts": [
          "The economy remains ",
          "."
        ],
        "full": "The economy remains SLUGGISH.",
        "jp": "経済は依然として不景気だ。",
        "is_correct": true
      },
      {
        "parts": [
          "My computer is very ",
          " today."
        ],
        "full": "My computer is very SLUGGISH today.",
        "jp": "私のコンピューターは今日とても動作が遅い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 556,
    "word": "SOCIALIZE",
    "meaning_core": "つきあう",
    "syllables": [
      {
        "text": "SO",
        "type": "strong"
      },
      {
        "text": "cial",
        "type": "weak"
      },
      {
        "text": "ize",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MINGLE": "交わる",
      "MIX": "交流する",
      "ASSOCIATE": "交際する"
    },
    "distractors": [
      "ISOLATE",
      "AVOID",
      "WITHDRAW",
      "HIDE"
    ],
    "meanings_expanded": [
      "社交的に交わる",
      "付き合う",
      "社会化する"
    ],
    "contexts": [
      {
        "parts": [
          "He likes to",
          "with his colleagues."
        ],
        "full": "He likes to SOCIALIZE with his colleagues.",
        "jp": "彼は同僚と付き合う（交流する）のが好きだ。",
        "is_correct": true
      },
      {
        "parts": [
          "I like to ",
          " with my friends."
        ],
        "full": "I like to SOCIALIZE with my friends.",
        "jp": "私は友達とつきあうのが好きだ。",
        "is_correct": true
      },
      {
        "parts": [
          "They rarely ",
          " outside work."
        ],
        "full": "They rarely SOCIALIZE outside work.",
        "jp": "彼らは仕事以外でめったに人と交流しない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 557,
    "word": "SOOTHE",
    "meaning_core": "なだめる",
    "syllables": [
      {
        "text": "SOOTHE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CALM": "落ち着かせる",
      "COMFORT": "慰める",
      "RELIEVE": "和らげる"
    },
    "distractors": [
      "AGITATE",
      "UPSET",
      "ANNOY",
      "PROVOKE"
    ],
    "meanings_expanded": [
      "なだめる",
      "和らげる",
      "落ち着かせる"
    ],
    "contexts": [
      {
        "parts": [
          "Music can",
          "the mind."
        ],
        "full": "Music can SOOTHE the mind.",
        "jp": "音楽は心をなだめることができる。",
        "is_correct": true
      },
      {
        "parts": [
          "The music will ",
          " your nerves."
        ],
        "full": "The music will SOOTHE your nerves.",
        "jp": "その音楽はあなたの神経をなだめるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to ",
          " the crying baby."
        ],
        "full": "Try to SOOTHE the crying baby.",
        "jp": "泣いている赤ちゃんをなだめようとしなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 558,
    "word": "SOPHISTICATED",
    "meaning_core": "洗練された",
    "syllables": [
      {
        "text": "so",
        "type": "weak"
      },
      {
        "text": "PHIS",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "cat",
        "type": "weak"
      },
      {
        "text": "ed",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ADVANCED": "高度な",
      "REFINED": "上品な",
      "COMPLEX": "精巧な"
    },
    "distractors": [
      "SIMPLE",
      "PRIMITIVE",
      "CRUDE",
      "NAIVE"
    ],
    "meanings_expanded": [
      "洗練された",
      "精巧な",
      "教養のある"
    ],
    "contexts": [
      {
        "parts": [
          "This is a",
          "machine."
        ],
        "full": "This is a SOPHISTICATED machine.",
        "jp": "これは精巧な（洗練された）機械だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The system is highly ",
          "."
        ],
        "full": "The system is highly SOPHISTICATED.",
        "jp": "そのシステムは非常に洗練されている。",
        "is_correct": true
      },
      {
        "parts": [
          "She has ",
          " taste in fashion."
        ],
        "full": "She has SOPHISTICATED taste in fashion.",
        "jp": "彼女はファッションに洗練された趣味を持っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 559,
    "word": "SPARKLE",
    "meaning_core": "輝く",
    "syllables": [
      {
        "text": "SPAR",
        "type": "strong"
      },
      {
        "text": "kle",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SHINE": "光る",
      "GLITTER": "きらめく",
      "TWINKLE": "またたく"
    },
    "distractors": [
      "DULL",
      "FADE",
      "DARKEN",
      "DIM"
    ],
    "meanings_expanded": [
      "輝く",
      "きらめく",
      "活気にあふれる"
    ],
    "contexts": [
      {
        "parts": [
          "Her eyes",
          "with joy."
        ],
        "full": "Her eyes SPARKLE with joy.",
        "jp": "彼女の目は喜びで輝いている。",
        "is_correct": true
      },
      {
        "parts": [
          "Her eyes began to ",
          " with joy."
        ],
        "full": "Her eyes began to SPARKLE with joy.",
        "jp": "彼女の目は喜びで輝き始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "We saw the diamond ",
          "."
        ],
        "full": "We saw the diamond SPARKLE.",
        "jp": "私たちはダイヤモンドが輝くのを見た。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 560,
    "word": "SPARSELY",
    "meaning_core": "まばらに",
    "syllables": [
      {
        "text": "SPARSE",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "THINLY": "薄く",
      "SCANTILY": "乏しく"
    },
    "distractors": [
      "DENSELY",
      "THICKLY",
      "HEAVILY",
      "CROWDEDLY"
    ],
    "meanings_expanded": [
      "まばらに",
      "ちらほらと"
    ],
    "contexts": [
      {
        "parts": [
          "The area is",
          "populated."
        ],
        "full": "The area is SPARSELY populated.",
        "jp": "その地域は人口がまばらだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The area is ",
          " populated."
        ],
        "full": "The area is SPARSELY populated.",
        "jp": "その地域はまばらに人が住んでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "Trees were ",
          " distributed."
        ],
        "full": "Trees were SPARSELY distributed.",
        "jp": "木々はまばらに分布していた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 561,
    "word": "SPECIES",
    "meaning_core": "種",
    "syllables": [
      {
        "text": "SPE",
        "type": "strong"
      },
      {
        "text": "cies",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TYPE": "種類",
      "KIND": "種",
      "BREED": "品種"
    },
    "distractors": [
      "INDIVIDUAL",
      "OBJECT",
      "THING",
      "ROCK"
    ],
    "meanings_expanded": [
      "（生物の）種",
      "種類"
    ],
    "contexts": [
      {
        "parts": [
          "This",
          "is endangered."
        ],
        "full": "This SPECIES is endangered.",
        "jp": "この種は絶滅の危機に瀕している。",
        "is_correct": true
      },
      {
        "parts": [
          "The new ",
          " of bird was found."
        ],
        "full": "The new SPECIES of bird was found.",
        "jp": "新しい種の鳥が見つかった。",
        "is_correct": true
      },
      {
        "parts": [
          "We study endangered ",
          "."
        ],
        "full": "We study endangered SPECIES.",
        "jp": "私たちは絶滅危惧種を研究する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 562,
    "word": "SPECIFIC",
    "meaning_core": "具体的な",
    "syllables": [
      {
        "text": "spe",
        "type": "weak"
      },
      {
        "text": "CIF",
        "type": "strong"
      },
      {
        "text": "ic",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PARTICULAR": "特定の",
      "PRECISE": "明確な",
      "EXACT": "正確な"
    },
    "distractors": [
      "GENERAL",
      "VAGUE",
      "BROAD",
      "UNCLEAR"
    ],
    "meanings_expanded": [
      "具体的な",
      "特定の",
      "特有の"
    ],
    "contexts": [
      {
        "parts": [
          "Can you be more",
          "?"
        ],
        "full": "Can you be more SPECIFIC?",
        "jp": "もっと具体的にお願いできますか？",
        "is_correct": true
      },
      {
        "parts": [
          "Can you give me a ",
          " example?"
        ],
        "full": "Can you give me a SPECIFIC example?",
        "jp": "具体的な例を挙げていただけますか。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " date."
        ],
        "full": "We need a SPECIFIC date.",
        "jp": "私たちには特定の（具体的な）日付が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 563,
    "word": "SPECIFICALLY",
    "meaning_core": "具体的に",
    "syllables": [
      {
        "text": "spe",
        "type": "weak"
      },
      {
        "text": "CIF",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PARTICULARLY": "特に",
      "ESPECIALLY": "とりわけ",
      "PRECISELY": "正確に"
    },
    "distractors": [
      "GENERALLY",
      "BROADLY",
      "VAGUELY",
      "ROUGHLY"
    ],
    "meanings_expanded": [
      "具体的に",
      "特に",
      "明確に"
    ],
    "contexts": [
      {
        "parts": [
          "I bought this",
          "for you."
        ],
        "full": "I bought this SPECIFICALLY for you.",
        "jp": "私はこれを特にあなたのために買った。",
        "is_correct": true
      },
      {
        "parts": [
          "I came here ",
          " to see you."
        ],
        "full": "I came here SPECIFICALLY to see you.",
        "jp": "私はあなたに会うために具体的にここに来た。",
        "is_correct": true
      },
      {
        "parts": [
          "The law applies ",
          " to businesses."
        ],
        "full": "The law applies SPECIFICALLY to businesses.",
        "jp": "その法律は特に企業に適用される。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 564,
    "word": "SPECULATE",
    "meaning_core": "推測する",
    "syllables": [
      {
        "text": "SPEC",
        "type": "strong"
      },
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "late",
        "type": "weak"
      }
    ],
    "synonyms": {
      "GUESS": "推測する",
      "THEORIZE": "理論づける",
      "INVEST": "投機する"
    },
    "distractors": [
      "KNOW",
      "PROVE",
      "VERIFY",
      "MEASURE"
    ],
    "meanings_expanded": [
      "推測する",
      "投機する",
      "思索する"
    ],
    "contexts": [
      {
        "parts": [
          "We can only",
          "about the future."
        ],
        "full": "We can only SPECULATE about the future.",
        "jp": "私たちは未来について推測することしかできない。",
        "is_correct": true
      },
      {
        "parts": [
          "We can only ",
          " about his motives."
        ],
        "full": "We can only SPECULATE about his motives.",
        "jp": "私たちは彼の動機について推測することしかできない。",
        "is_correct": true
      },
      {
        "parts": [
          "The market began to ",
          "."
        ],
        "full": "The market began to SPECULATE.",
        "jp": "市場は投機を始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 565,
    "word": "SPONTANEOUS",
    "meaning_core": "自発的な",
    "syllables": [
      {
        "text": "spon",
        "type": "weak"
      },
      {
        "text": "TA",
        "type": "strong"
      },
      {
        "text": "ne",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "UNPLANNED": "計画外の",
      "NATURAL": "自然な",
      "IMPULSIVE": "衝動的な"
    },
    "distractors": [
      "FORCED",
      "PLANNED",
      "PREPARED",
      "DELIBERATE"
    ],
    "meanings_expanded": [
      "自発的な",
      "自然に起こる",
      "のびのびとした"
    ],
    "contexts": [
      {
        "parts": [
          "The crowd burst into",
          "applause."
        ],
        "full": "The crowd burst into SPONTANEOUS applause.",
        "jp": "群衆から自発的な拍手が沸き起こった。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a ",
          " decision."
        ],
        "full": "It was a SPONTANEOUS decision.",
        "jp": "それは自発的な決定だった。",
        "is_correct": true
      },
      {
        "parts": [
          "We heard a ",
          " burst of applause."
        ],
        "full": "We heard a SPONTANEOUS burst of applause.",
        "jp": "私たちは自然発生的な拍手の爆発を聞いた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 566,
    "word": "SPONTANEOUSLY",
    "meaning_core": "自発的に",
    "syllables": [
      {
        "text": "spon",
        "type": "weak"
      },
      {
        "text": "TA",
        "type": "strong"
      },
      {
        "text": "ne",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "NATURALLY": "自然に",
      "INSTINCTIVELY": "本能的に"
    },
    "distractors": [
      "DELIBERATELY",
      "INTENTIONALLY",
      "FORCEDLY",
      "PLANNEDLY"
    ],
    "meanings_expanded": [
      "自発的に",
      "自然に"
    ],
    "contexts": [
      {
        "parts": [
          "They started dancing",
          "."
        ],
        "full": "They started dancing SPONTANEOUSLY.",
        "jp": "彼らは自然と踊り始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "She laughed ",
          " at the joke."
        ],
        "full": "She laughed SPONTANEOUSLY at the joke.",
        "jp": "彼女はジョークに自発的に笑った。",
        "is_correct": true
      },
      {
        "parts": [
          "The crowd cheered ",
          "."
        ],
        "full": "The crowd cheered SPONTANEOUSLY.",
        "jp": "群衆は自然に歓声を上げた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 567,
    "word": "STABLE",
    "meaning_core": "安定した",
    "syllables": [
      {
        "text": "STA",
        "type": "strong"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STEADY": "着実な",
      "FIRM": "堅固な",
      "SECURE": "安全な"
    },
    "distractors": [
      "UNSTABLE",
      "SHAKY",
      "VARIABLE",
      "WEAK"
    ],
    "meanings_expanded": [
      "安定した",
      "しっかりした",
      "馬小屋（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "The patient is in",
          "condition."
        ],
        "full": "The patient is in STABLE condition.",
        "jp": "患者の容体は安定している。",
        "is_correct": true
      },
      {
        "parts": [
          "The ladder felt very ",
          "."
        ],
        "full": "The ladder felt very STABLE.",
        "jp": "そのはしごは非常に安定していると感じた。",
        "is_correct": true
      },
      {
        "parts": [
          "We hope for a ",
          " government."
        ],
        "full": "We hope for a STABLE government.",
        "jp": "私たちは安定した政府を望んでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 568,
    "word": "STARVATION",
    "meaning_core": "飢餓",
    "syllables": [
      {
        "text": "star",
        "type": "weak"
      },
      {
        "text": "VA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HUNGER": "飢え",
      "FAMINE": "飢饉"
    },
    "distractors": [
      "FEAST",
      "PLENTY",
      "FULLNESS",
      "GLUTTONY"
    ],
    "meanings_expanded": [
      "飢餓",
      "餓死"
    ],
    "contexts": [
      {
        "parts": [
          "Many people died of",
          "."
        ],
        "full": "Many people died of STARVATION.",
        "jp": "多くの人々が餓死した。",
        "is_correct": true
      },
      {
        "parts": [
          "They faced mass ",
          "."
        ],
        "full": "They faced mass STARVATION.",
        "jp": "彼らは集団飢餓に直面した。",
        "is_correct": true
      },
      {
        "parts": [
          "Aid workers fight ",
          "."
        ],
        "full": "Aid workers fight STARVATION.",
        "jp": "援助隊員は飢餓と闘っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 569,
    "word": "STEADY",
    "meaning_core": "着実な",
    "syllables": [
      {
        "text": "STEAD",
        "type": "strong"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONSTANT": "一定の",
      "STABLE": "安定した",
      "REGULAR": "規則的な"
    },
    "distractors": [
      "UNSTEADY",
      "SHAKY",
      "SUDDEN",
      "VARIABLE"
    ],
    "meanings_expanded": [
      "着実な",
      "安定した",
      "固定された"
    ],
    "contexts": [
      {
        "parts": [
          "Slow and",
          "wins the race."
        ],
        "full": "Slow and STEADY wins the race.",
        "jp": "急がば回れ（ゆっくり着実なのがレースに勝つ）。",
        "is_correct": true
      },
      {
        "parts": [
          "Maintain a ",
          " pace."
        ],
        "full": "Maintain a STEADY pace.",
        "jp": "着実なペースを保ちなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a ",
          " job."
        ],
        "full": "He has a STEADY job.",
        "jp": "彼には安定した仕事がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 570,
    "word": "STERN",
    "meaning_core": "厳格な",
    "syllables": [
      {
        "text": "STERN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "STRICT": "厳しい",
      "HARSH": "過酷な",
      "SEVERE": "深刻な"
    },
    "distractors": [
      "GENTLE",
      "KIND",
      "MILD",
      "SOFT"
    ],
    "meanings_expanded": [
      "厳格な",
      "いかめしい",
      "船尾（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "He gave me a",
          "look."
        ],
        "full": "He gave me a STERN look.",
        "jp": "彼は私に厳しい視線を向けた。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave a ",
          " warning."
        ],
        "full": "He gave a STERN warning.",
        "jp": "彼は厳格な警告を与えた。",
        "is_correct": true
      },
      {
        "parts": [
          "She had a ",
          " look on her face."
        ],
        "full": "She had a STERN look on her face.",
        "jp": "彼女は顔に厳しい表情を浮かべていた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 571,
    "word": "STING",
    "meaning_core": "刺す",
    "syllables": [
      {
        "text": "STING",
        "type": "strong"
      }
    ],
    "synonyms": {
      "BITE": "噛む",
      "PRICK": "刺す",
      "HURT": "痛む"
    },
    "distractors": [
      "SOOTHE",
      "HEAL",
      "COMFORT",
      "CURE"
    ],
    "meanings_expanded": [
      "刺す",
      "ヒリヒリする",
      "針"
    ],
    "contexts": [
      {
        "parts": [
          "Bees can",
          "you."
        ],
        "full": "Bees can STING you.",
        "jp": "蜂は君を刺すことがある。",
        "is_correct": true
      },
      {
        "parts": [
          "The bee will ",
          " you."
        ],
        "full": "The bee will STING you.",
        "jp": "その蜂があなたを刺すだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The medicine might ",
          " a little."
        ],
        "full": "The medicine might STING a little.",
        "jp": "その薬は少しヒリヒリするかもしれない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 572,
    "word": "STRAIGHTFORWARD",
    "meaning_core": "率直な",
    "syllables": [
      {
        "text": "straight",
        "type": "strong"
      },
      {
        "text": "FOR",
        "type": "strong"
      },
      {
        "text": "ward",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SIMPLE": "単純な",
      "HONEST": "正直な",
      "DIRECT": "直接的な"
    },
    "distractors": [
      "COMPLICATED",
      "CONFUSING",
      "DISHONEST",
      "INDIRECT"
    ],
    "meanings_expanded": [
      "率直な",
      "簡単な",
      "まっすぐな"
    ],
    "contexts": [
      {
        "parts": [
          "It was a",
          "answer."
        ],
        "full": "It was a STRAIGHTFORWARD answer.",
        "jp": "それは率直な答えだった。",
        "is_correct": true
      },
      {
        "parts": [
          "The answer is ",
          "."
        ],
        "full": "The answer is STRAIGHTFORWARD.",
        "jp": "答えは率直だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a very ",
          " person."
        ],
        "full": "He is a very STRAIGHTFORWARD person.",
        "jp": "彼​​は非常に正直（率直）な人だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 573,
    "word": "STRAIN",
    "meaning_core": "負担",
    "syllables": [
      {
        "text": "STRAIN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "STRESS": "ストレス",
      "TENSION": "緊張",
      "PRESSURE": "圧力"
    },
    "distractors": [
      "RELAXATION",
      "EASE",
      "COMFORT",
      "RELIEF"
    ],
    "meanings_expanded": [
      "負担",
      "緊張",
      "（筋肉を）痛める"
    ],
    "contexts": [
      {
        "parts": [
          "He is under a lot of",
          "."
        ],
        "full": "He is under a lot of STRAIN.",
        "jp": "彼は多くの負担（重圧）を感じている。",
        "is_correct": true
      },
      {
        "parts": [
          "The conflict caused great ",
          "."
        ],
        "full": "The conflict caused great STRAIN.",
        "jp": "その対立は大きな負担を引き起こした。",
        "is_correct": true
      },
      {
        "parts": [
          "I felt a muscle ",
          " in my leg."
        ],
        "full": "I felt a muscle STRAIN in my leg.",
        "jp": "私は脚に肉離れ（負担）を感じた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 574,
    "word": "STRATEGY",
    "meaning_core": "戦略",
    "syllables": [
      {
        "text": "STRAT",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "gy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PLAN": "計画",
      "TACTIC": "戦術",
      "POLICY": "方針"
    },
    "distractors": [
      "CHAOS",
      "LUCK",
      "CHANCE",
      "ACCIDENT"
    ],
    "meanings_expanded": [
      "戦略",
      "策略"
    ],
    "contexts": [
      {
        "parts": [
          "We need a marketing",
          "."
        ],
        "full": "We need a marketing STRATEGY.",
        "jp": "私たちにはマーケティング戦略が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a new marketing ",
          "."
        ],
        "full": "We need a new marketing STRATEGY.",
        "jp": "私たちには新しいマーケティング戦略が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "His political ",
          " failed."
        ],
        "full": "His political STRATEGY failed.",
        "jp": "彼の政治戦略は失敗した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 575,
    "word": "STROLL",
    "meaning_core": "ぶらぶらする",
    "syllables": [
      {
        "text": "STROLL",
        "type": "strong"
      }
    ],
    "synonyms": {
      "WALK": "歩く",
      "WANDER": "さまよう",
      "RAMBLE": "散策する"
    },
    "distractors": [
      "RUN",
      "RUSH",
      "SPRINT",
      "HURRY"
    ],
    "meanings_expanded": [
      "ぶらぶら歩く",
      "散歩する"
    ],
    "contexts": [
      {
        "parts": [
          "Let's",
          "in the park."
        ],
        "full": "Let's STROLL in the park.",
        "jp": "公園をぶらぶら歩こう。",
        "is_correct": true
      },
      {
        "parts": [
          "We took a leisurely ",
          " in the park."
        ],
        "full": "We took a leisurely STROLL in the park.",
        "jp": "私たちは公園をゆっくりと散歩した。",
        "is_correct": true
      },
      {
        "parts": [
          "They went for an evening ",
          "."
        ],
        "full": "They went for an evening STROLL.",
        "jp": "彼らは夕方の散歩に出かけた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 576,
    "word": "STUN",
    "meaning_core": "唖然とさせる",
    "syllables": [
      {
        "text": "STUN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SHOCK": "衝撃を与える",
      "AMAZE": "びっくりさせる",
      "DAZE": "呆然とさせる"
    },
    "distractors": [
      "BORE",
      "CALM",
      "EXPECT",
      "SOOTHE"
    ],
    "meanings_expanded": [
      "唖然とさせる",
      "気絶させる"
    ],
    "contexts": [
      {
        "parts": [
          "The news will",
          "everyone."
        ],
        "full": "The news will STUN everyone.",
        "jp": "そのニュースは皆を唖然とさせるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The news will ",
          " him."
        ],
        "full": "The news will STUN him.",
        "jp": "そのニュースは彼を唖然とさせるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "I was ",
          " by the bright light."
        ],
        "full": "I was STUN by the bright light.",
        "jp": "私は明るい光に目がくらんだ（唖然とさせられた）。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 577,
    "word": "STURDY",
    "meaning_core": "頑健な",
    "syllables": [
      {
        "text": "STUR",
        "type": "strong"
      },
      {
        "text": "dy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "STRONG": "強い",
      "ROBUST": "たくましい",
      "DURABLE": "耐久性のある"
    },
    "distractors": [
      "WEAK",
      "FRAGILE",
      "DELICATE",
      "FLIMSY"
    ],
    "meanings_expanded": [
      "頑健な",
      "丈夫な",
      "不屈の"
    ],
    "contexts": [
      {
        "parts": [
          "This table is very",
          "."
        ],
        "full": "This table is very STURDY.",
        "jp": "このテーブルはとても頑丈だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The chair is very ",
          "."
        ],
        "full": "The chair is very STURDY.",
        "jp": "その椅子はとても頑丈だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a ",
          " build."
        ],
        "full": "He has a STURDY build.",
        "jp": "彼はがっしりした体格をしている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 578,
    "word": "SUBLIME",
    "meaning_core": "崇高な",
    "syllables": [
      {
        "text": "sub",
        "type": "weak"
      },
      {
        "text": "LIME",
        "type": "strong"
      }
    ],
    "synonyms": {
      "MAGNIFICENT": "壮大な",
      "NOBLE": "高潔な",
      "GRAND": "雄大な"
    },
    "distractors": [
      "ORDINARY",
      "BAD",
      "LOW",
      "COMMON"
    ],
    "meanings_expanded": [
      "崇高な",
      "荘厳な",
      "卓越した"
    ],
    "contexts": [
      {
        "parts": [
          "The view was",
          "."
        ],
        "full": "The view was SUBLIME.",
        "jp": "その景色は崇高（壮大）だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The music was truly ",
          "."
        ],
        "full": "The music was truly SUBLIME.",
        "jp": "その音楽は本当に崇高だった。",
        "is_correct": true
      },
      {
        "parts": [
          "She felt a ",
          " happiness."
        ],
        "full": "She felt a SUBLIME happiness.",
        "jp": "彼女は至高の（崇高な）幸福を感じた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 579,
    "word": "SUBSIDIES",
    "meaning_core": "補助金",
    "syllables": [
      {
        "text": "SUB",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "dies",
        "type": "weak"
      }
    ],
    "synonyms": {
      "GRANTS": "助成金",
      "FUNDS": "資金",
      "AID": "援助"
    },
    "distractors": [
      "TAXES",
      "DEBTS",
      "FINES",
      "COSTS"
    ],
    "meanings_expanded": [
      "補助金",
      "助成金"
    ],
    "contexts": [
      {
        "parts": [
          "Farmers receive government",
          "."
        ],
        "full": "Farmers receive government SUBSIDIES.",
        "jp": "農家は政府の補助金を受け取っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The government cut farm ",
          "."
        ],
        "full": "The government cut farm SUBSIDIES.",
        "jp": "政府は農業補助金を削減した。",
        "is_correct": true
      },
      {
        "parts": [
          "They rely on state ",
          "."
        ],
        "full": "They rely on state SUBSIDIES.",
        "jp": "彼らは国の補助金に頼っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 580,
    "word": "SUBSIDIZE",
    "meaning_core": "助成金を払う",
    "syllables": [
      {
        "text": "SUB",
        "type": "strong"
      },
      {
        "text": "si",
        "type": "weak"
      },
      {
        "text": "dize",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FUND": "資金を提供する",
      "SUPPORT": "支援する",
      "FINANCE": "融資する"
    },
    "distractors": [
      "TAX",
      "CHARGE",
      "FINE",
      "BILL"
    ],
    "meanings_expanded": [
      "助成金を支給する",
      "援助する"
    ],
    "contexts": [
      {
        "parts": [
          "The state will",
          "housing."
        ],
        "full": "The state will SUBSIDIZE housing.",
        "jp": "州は住宅に助成金を出す予定だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The state will ",
          " the arts."
        ],
        "full": "The state will SUBSIDIZE the arts.",
        "jp": "国が芸術に助成金を出すだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to ",
          " the public transport."
        ],
        "full": "We need to SUBSIDIZE the public transport.",
        "jp": "私たちは公共交通機関に補助金を出す必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 581,
    "word": "SUBTLE",
    "meaning_core": "微妙な",
    "syllables": [
      {
        "text": "SUB",
        "type": "strong"
      },
      {
        "text": "tle",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FAINT": "かすかな",
      "SLIGHT": "わずかな",
      "DELICATE": "繊細な"
    },
    "distractors": [
      "OBVIOUS",
      "CLEAR",
      "STRONG",
      "PLAIN"
    ],
    "meanings_expanded": [
      "微妙な",
      "かすかな",
      "巧妙な"
    ],
    "contexts": [
      {
        "parts": [
          "There is a",
          "difference."
        ],
        "full": "There is a SUBTLE difference.",
        "jp": "微妙な違いがある。",
        "is_correct": true
      },
      {
        "parts": [
          "I noticed a ",
          " change in her voice."
        ],
        "full": "I noticed a SUBTLE change in her voice.",
        "jp": "私は彼女の声に微妙な変化に気づいた。",
        "is_correct": true
      },
      {
        "parts": [
          "The difference is very ",
          "."
        ],
        "full": "The difference is very SUBTLE.",
        "jp": "その違いは非常に微妙だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 582,
    "word": "SUBTLY",
    "meaning_core": "微妙に",
    "syllables": [
      {
        "text": "SUB",
        "type": "strong"
      },
      {
        "text": "tly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SLIGHTLY": "わずかに",
      "FAINTLY": "かすかに"
    },
    "distractors": [
      "OBVIOUSLY",
      "CLEARLY",
      "GREATLY",
      "STRONGLY"
    ],
    "meanings_expanded": [
      "微妙に",
      "かすかに"
    ],
    "contexts": [
      {
        "parts": [
          "The flavor changed",
          "."
        ],
        "full": "The flavor changed SUBTLY.",
        "jp": "味が微妙に変わった。",
        "is_correct": true
      },
      {
        "parts": [
          "He ",
          " changed the topic."
        ],
        "full": "He SUBTLY changed the topic.",
        "jp": "彼は微妙に話題を変えた。",
        "is_correct": true
      },
      {
        "parts": [
          "The flavor was ",
          " enhanced."
        ],
        "full": "The flavor was SUBTLY enhanced.",
        "jp": "風味は微妙に高められた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 583,
    "word": "SUCCINCT",
    "meaning_core": "簡潔な",
    "syllables": [
      {
        "text": "suc",
        "type": "weak"
      },
      {
        "text": "CINCT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "CONCISE": "簡潔な",
      "BRIEF": "短い",
      "SHORT": "短い"
    },
    "distractors": [
      "WORDY",
      "LONG",
      "LENGTHY",
      "VERBOSE"
    ],
    "meanings_expanded": [
      "簡潔な",
      "簡明な"
    ],
    "contexts": [
      {
        "parts": [
          "Give a",
          "summary."
        ],
        "full": "Give a SUCCINCT summary.",
        "jp": "簡潔な要約を出しなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "His speech was clear and ",
          "."
        ],
        "full": "His speech was clear and SUCCINCT.",
        "jp": "彼のスピーチは明確で簡潔だった。",
        "is_correct": true
      },
      {
        "parts": [
          "Give a ",
          " summary."
        ],
        "full": "Give a SUCCINCT summary.",
        "jp": "簡潔な要約を与えなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 584,
    "word": "SUCCINCTLY",
    "meaning_core": "簡潔に",
    "syllables": [
      {
        "text": "suc",
        "type": "weak"
      },
      {
        "text": "CINCT",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BRIEFLY": "手短に",
      "CONCISELY": "簡潔に"
    },
    "distractors": [
      "WORDILY",
      "AT LENGTH",
      "LONG",
      "VERBOSELY"
    ],
    "meanings_expanded": [
      "簡潔に",
      "手短に"
    ],
    "contexts": [
      {
        "parts": [
          "Please state your point",
          "."
        ],
        "full": "Please state your point SUCCINCTLY.",
        "jp": "要点を簡潔に述べてください。",
        "is_correct": true
      },
      {
        "parts": [
          "He explained the problem ",
          "."
        ],
        "full": "He explained the problem SUCCINCTLY.",
        "jp": "彼はその問題を簡潔に説明した。",
        "is_correct": true
      },
      {
        "parts": [
          "Please state your case ",
          "."
        ],
        "full": "Please state your case SUCCINCTLY.",
        "jp": "あなたの主張を簡潔に述べなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 585,
    "word": "SUFFER",
    "meaning_core": "苦しむ",
    "syllables": [
      {
        "text": "SUF",
        "type": "strong"
      },
      {
        "text": "fer",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENDURE": "耐える",
      "EXPERIENCE": "経験する",
      "BEAR": "我慢する"
    },
    "distractors": [
      "ENJOY",
      "FLOURISH",
      "PROSPER",
      "BENEFIT"
    ],
    "meanings_expanded": [
      "～に苦しむ",
      "（損害などを）受ける"
    ],
    "contexts": [
      {
        "parts": [
          "Many people",
          "from allergies."
        ],
        "full": "Many people SUFFER from allergies.",
        "jp": "多くの人がアレルギーに苦しんでいる。",
        "is_correct": true
      },
      {
        "parts": [
          "She will ",
          " from the cold."
        ],
        "full": "She will SUFFER from the cold.",
        "jp": "彼女は寒さに苦しむだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The company will ",
          " losses."
        ],
        "full": "The company will SUFFER losses.",
        "jp": "その会社は損失を被るだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 586,
    "word": "SUFFICIENT",
    "meaning_core": "十分な",
    "syllables": [
      {
        "text": "suf",
        "type": "weak"
      },
      {
        "text": "FI",
        "type": "strong"
      },
      {
        "text": "cient",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENOUGH": "十分な",
      "ADEQUATE": "適切な",
      "AMPLE": "豊富な"
    },
    "distractors": [
      "INSUFFICIENT",
      "LACKING",
      "SCARCE",
      "POOR"
    ],
    "meanings_expanded": [
      "十分な",
      "足りる"
    ],
    "contexts": [
      {
        "parts": [
          "We have",
          "food."
        ],
        "full": "We have SUFFICIENT food.",
        "jp": "私たちには十分な食料がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We have ",
          " food for everyone."
        ],
        "full": "We have SUFFICIENT food for everyone.",
        "jp": "私たちは皆のための十分な食糧がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Is your salary ",
          "?"
        ],
        "full": "Is your salary SUFFICIENT?",
        "jp": "あなたの給料は十分ですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 587,
    "word": "SUPPOSE",
    "meaning_core": "～だと思う",
    "syllables": [
      {
        "text": "sup",
        "type": "weak"
      },
      {
        "text": "POSE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ASSUME": "仮定する",
      "THINK": "思う",
      "GUESS": "推測する"
    },
    "distractors": [
      "KNOW",
      "PROVE",
      "VERIFY",
      "DENY"
    ],
    "meanings_expanded": [
      "～だと思う",
      "仮定する",
      "（be supposed toで）～することになっている"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "he is right."
        ],
        "full": "I SUPPOSE he is right.",
        "jp": "彼は正しいと思う。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " he is right."
        ],
        "full": "I SUPPOSE he is right.",
        "jp": "私は彼が正しいと思う。",
        "is_correct": true
      },
      {
        "parts": [
          "Let's ",
          " the worst happens."
        ],
        "full": "Let's SUPPOSE the worst happens.",
        "jp": "最悪の事態が起こると仮定しよう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 588,
    "word": "SUPPRESS",
    "meaning_core": "抑圧する",
    "syllables": [
      {
        "text": "sup",
        "type": "weak"
      },
      {
        "text": "PRESS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "REPRESS": "抑制する",
      "CRUSH": "押しつぶす",
      "STIFLE": "抑える"
    },
    "distractors": [
      "RELEASE",
      "EXPRESS",
      "ENCOURAGE",
      "FREE"
    ],
    "meanings_expanded": [
      "抑圧する",
      "鎮圧する",
      "（感情を）抑える"
    ],
    "contexts": [
      {
        "parts": [
          "The army was sent to",
          "the rebellion."
        ],
        "full": "The army was sent to SUPPRESS the rebellion.",
        "jp": "軍隊は反乱を鎮圧するために派遣された。",
        "is_correct": true
      },
      {
        "parts": [
          "The police tried to ",
          " the riot."
        ],
        "full": "The police tried to SUPPRESS the riot.",
        "jp": "警察は暴動を鎮圧しようとした。",
        "is_correct": true
      },
      {
        "parts": [
          "He could not ",
          " his laughter."
        ],
        "full": "He could not SUPPRESS his laughter.",
        "jp": "彼は笑いを抑えられなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 589,
    "word": "SURPASS",
    "meaning_core": "上回る",
    "syllables": [
      {
        "text": "sur",
        "type": "weak"
      },
      {
        "text": "PASS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXCEED": "超える",
      "OUTDO": "しのぐ",
      "BEAT": "勝る"
    },
    "distractors": [
      "FAIL",
      "LOSE",
      "TRAIL",
      "FALL BEHIND"
    ],
    "meanings_expanded": [
      "上回る",
      "まさる",
      "越える"
    ],
    "contexts": [
      {
        "parts": [
          "Sales will",
          "expectations."
        ],
        "full": "Sales will SURPASS expectations.",
        "jp": "売上は予想を上回るだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "His score will ",
          " all records."
        ],
        "full": "His score will SURPASS all records.",
        "jp": "彼の得点はすべての記録を上回るだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "We hope to ",
          " expectations."
        ],
        "full": "We hope to SURPASS expectations.",
        "jp": "私たちは期待を超えることを望んでいる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 590,
    "word": "SURRENDER",
    "meaning_core": "降伏する",
    "syllables": [
      {
        "text": "sur",
        "type": "weak"
      },
      {
        "text": "REN",
        "type": "strong"
      },
      {
        "text": "der",
        "type": "weak"
      }
    ],
    "synonyms": {
      "YIELD": "屈する",
      "GIVE UP": "あきらめる",
      "SUBMIT": "服従する"
    },
    "distractors": [
      "FIGHT",
      "RESIST",
      "WIN",
      "CONQUER"
    ],
    "meanings_expanded": [
      "降伏する",
      "引き渡す",
      "あけ渡す"
    ],
    "contexts": [
      {
        "parts": [
          "The enemy was forced to",
          "."
        ],
        "full": "The enemy was forced to SURRENDER.",
        "jp": "敵は降伏を余儀なくされた。",
        "is_correct": true
      },
      {
        "parts": [
          "The enemy decided to ",
          "."
        ],
        "full": "The enemy decided to SURRENDER.",
        "jp": "敵は降伏することを決定した。",
        "is_correct": true
      },
      {
        "parts": [
          "Never ",
          " your dreams."
        ],
        "full": "Never SURRENDER your dreams.",
        "jp": "あなたの夢を諦めてはいけない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 591,
    "word": "SUSPEND",
    "meaning_core": "一時停止する",
    "syllables": [
      {
        "text": "sus",
        "type": "weak"
      },
      {
        "text": "PEND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DELAY": "遅らせる",
      "PAUSE": "中断する",
      "HANG": "つるす"
    },
    "distractors": [
      "CONTINUE",
      "RESUME",
      "START",
      "BEGIN"
    ],
    "meanings_expanded": [
      "一時停止する",
      "つるす",
      "停職にする"
    ],
    "contexts": [
      {
        "parts": [
          "They agreed to",
          "the talks."
        ],
        "full": "They agreed to SUSPEND the talks.",
        "jp": "彼らは会談を一時中断することに合意した。",
        "is_correct": true
      },
      {
        "parts": [
          "They will ",
          " his driver's license."
        ],
        "full": "They will SUSPEND his driver's license.",
        "jp": "彼らは彼の運転免許証を一時停止するだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The talks were temporarily ",
          "."
        ],
        "full": "The talks were temporarily SUSPEND.",
        "jp": "会談は一時的に中断された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 592,
    "word": "SYMBOL",
    "meaning_core": "象徴",
    "syllables": [
      {
        "text": "SYM",
        "type": "strong"
      },
      {
        "text": "bol",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SIGN": "記号",
      "EMBLEM": "紋章",
      "TOKEN": "しるし"
    },
    "distractors": [
      "REALITY",
      "FACT",
      "THING",
      "OBJECT"
    ],
    "meanings_expanded": [
      "象徴",
      "シンボル",
      "記号"
    ],
    "contexts": [
      {
        "parts": [
          "The dove is a",
          "of peace."
        ],
        "full": "The dove is a SYMBOL of peace.",
        "jp": "鳩は平和の象徴だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The dove is a ",
          " of peace."
        ],
        "full": "The dove is a SYMBOL of peace.",
        "jp": "鳩は平和の象徴だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This flower is the city's ",
          "."
        ],
        "full": "This flower is the city's SYMBOL.",
        "jp": "この花は市の象徴だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 593,
    "word": "SYMPATHY",
    "meaning_core": "同情",
    "syllables": [
      {
        "text": "SYM",
        "type": "strong"
      },
      {
        "text": "pa",
        "type": "weak"
      },
      {
        "text": "thy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPASSION": "哀れみ",
      "PITY": "同情",
      "UNDERSTANDING": "理解"
    },
    "distractors": [
      "CRUELTY",
      "INDIFFERENCE",
      "HATRED",
      "APATHY"
    ],
    "meanings_expanded": [
      "同情",
      "共感",
      "思いやり"
    ],
    "contexts": [
      {
        "parts": [
          "I have deep",
          "for the victims."
        ],
        "full": "I have deep SYMPATHY for the victims.",
        "jp": "私は被害者に深い同情を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "I feel deep ",
          " for her."
        ],
        "full": "I feel deep SYMPATHY for her.",
        "jp": "私は彼女に深い同情を感じる。",
        "is_correct": true
      },
      {
        "parts": [
          "They offered their sincere ",
          "."
        ],
        "full": "They offered their sincere SYMPATHY.",
        "jp": "彼らは心からの哀悼の意（同情）を表明した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 594,
    "word": "SYMPTOM",
    "meaning_core": "症状",
    "syllables": [
      {
        "text": "SYMP",
        "type": "strong"
      },
      {
        "text": "tom",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SIGN": "兆候",
      "INDICATION": "しるし",
      "MARK": "徴候"
    },
    "distractors": [
      "CURE",
      "REMEDY",
      "HEALTH",
      "SOLUTION"
    ],
    "meanings_expanded": [
      "症状",
      "兆候",
      "しるし"
    ],
    "contexts": [
      {
        "parts": [
          "Fever is a common",
          "of the flu."
        ],
        "full": "Fever is a common SYMPTOM of the flu.",
        "jp": "発熱はインフルエンザの一般的な症状だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Fever is a common ",
          "."
        ],
        "full": "Fever is a common SYMPTOM.",
        "jp": "発熱は一般的な症状だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We monitor his ",
          "."
        ],
        "full": "We monitor his SYMPTOM.",
        "jp": "私たちは彼の症状を監視している。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 595,
    "word": "TACITLY",
    "meaning_core": "暗黙のうちに",
    "syllables": [
      {
        "text": "TAC",
        "type": "strong"
      },
      {
        "text": "it",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IMPLICITLY": "暗黙に",
      "SILENTLY": "無言で"
    },
    "distractors": [
      "EXPLICITLY",
      "OPENLY",
      "CLEARLY",
      "LOUDLY"
    ],
    "meanings_expanded": [
      "暗黙のうちに",
      "それとなく"
    ],
    "contexts": [
      {
        "parts": [
          "They",
          "agreed to the deal."
        ],
        "full": "They TACITLY agreed to the deal.",
        "jp": "彼らは暗黙のうちにその取引に合意した。",
        "is_correct": true
      },
      {
        "parts": [
          "The board ",
          " approved the plan."
        ],
        "full": "The board TACITLY approved the plan.",
        "jp": "取締役会は暗黙のうちに計画を承認した。",
        "is_correct": true
      },
      {
        "parts": [
          "They ",
          " agreed to the terms."
        ],
        "full": "They TACITLY agreed to the terms.",
        "jp": "彼らは暗黙のうちに条件に同意した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 596,
    "word": "TACKLE",
    "meaning_core": "取り組む",
    "syllables": [
      {
        "text": "TACK",
        "type": "strong"
      },
      {
        "text": "le",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ADDRESS": "対処する",
      "DEAL WITH": "扱う",
      "UNDERTAKE": "引き受ける"
    },
    "distractors": [
      "AVOID",
      "IGNORE",
      "DODGE",
      "EVADE"
    ],
    "meanings_expanded": [
      "取り組む",
      "タックルする",
      "道具"
    ],
    "contexts": [
      {
        "parts": [
          "We need to",
          "the problem immediately."
        ],
        "full": "We need to TACKLE the problem immediately.",
        "jp": "私たちは直ちにその問題に取り組む必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " this problem now."
        ],
        "full": "We must TACKLE this problem now.",
        "jp": "私たちは今すぐこの問題に取り組まなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "He tried to ",
          " the runner."
        ],
        "full": "He tried to TACKLE the runner.",
        "jp": "彼はランナーにタックルしようとした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 597,
    "word": "TACTFULLY",
    "meaning_core": "巧みに",
    "syllables": [
      {
        "text": "TACT",
        "type": "strong"
      },
      {
        "text": "ful",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DIPLOMATICALLY": "外交的に",
      "POLITELY": "丁寧に",
      "SKILLFULLY": "巧みに"
    },
    "distractors": [
      "RUDELY",
      "BLUNTLY",
      "CLUMSILY",
      "AWKWARDLY"
    ],
    "meanings_expanded": [
      "巧みに",
      "そつなく",
      "機転を利かせて"
    ],
    "contexts": [
      {
        "parts": [
          "She handled the situation",
          "."
        ],
        "full": "She handled the situation TACTFULLY.",
        "jp": "彼女はその状況を巧みに処理した。",
        "is_correct": true
      },
      {
        "parts": [
          "He handled the difficult situation ",
          "."
        ],
        "full": "He handled the difficult situation TACTFULLY.",
        "jp": "彼はその難しい状況を巧みに処理した。",
        "is_correct": true
      },
      {
        "parts": [
          "She spoke ",
          " about the error."
        ],
        "full": "She spoke TACTFULLY about the error.",
        "jp": "彼女は間違いについて巧みに話した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 598,
    "word": "TAME",
    "meaning_core": "飼い慣らされた",
    "syllables": [
      {
        "text": "TAME",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DOMESTICATED": "家畜化された",
      "GENTLE": "おとなしい",
      "OBEDIENT": "従順な"
    },
    "distractors": [
      "WILD",
      "FERAL",
      "AGGRESSIVE",
      "SAVAGE"
    ],
    "meanings_expanded": [
      "飼い慣らされた",
      "退屈な",
      "従順な"
    ],
    "contexts": [
      {
        "parts": [
          "The lion was quite",
          "."
        ],
        "full": "The lion was quite TAME.",
        "jp": "そのライオンはかなり飼い慣らされていた。",
        "is_correct": true
      },
      {
        "parts": [
          "The lion was surprisingly ",
          "."
        ],
        "full": "The lion was surprisingly TAME.",
        "jp": "そのライオンは驚くほど飼い慣らされていた。",
        "is_correct": true
      },
      {
        "parts": [
          "We try to ",
          " the wild horse."
        ],
        "full": "We try to TAME the wild horse.",
        "jp": "私たちはその野生の馬を飼い慣らそうとしている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 599,
    "word": "TANGIBLE",
    "meaning_core": "明白な",
    "syllables": [
      {
        "text": "TAN",
        "type": "strong"
      },
      {
        "text": "gi",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONCRETE": "具体的な",
      "REAL": "実在する",
      "PALPABLE": "明白な"
    },
    "distractors": [
      "INTANGIBLE",
      "ABSTRACT",
      "VAGUE",
      "IMAGINARY"
    ],
    "meanings_expanded": [
      "明白な",
      "触れられる",
      "有形の"
    ],
    "contexts": [
      {
        "parts": [
          "We need",
          "evidence."
        ],
        "full": "We need TANGIBLE evidence.",
        "jp": "私たちには明白な（形のある）証拠が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We seek ",
          " results now."
        ],
        "full": "We seek TANGIBLE results now.",
        "jp": "私たちは今、明白な結果を求めている。",
        "is_correct": true
      },
      {
        "parts": [
          "There is no ",
          " evidence."
        ],
        "full": "There is no TANGIBLE evidence.",
        "jp": "明白な証拠はない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 600,
    "word": "TARIFF",
    "meaning_core": "関税",
    "syllables": [
      {
        "text": "TAR",
        "type": "strong"
      },
      {
        "text": "iff",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TAX": "税金",
      "DUTY": "関税",
      "LEVY": "徴税"
    },
    "distractors": [
      "SUBSIDY",
      "GRANT",
      "DISCOUNT",
      "REFUND"
    ],
    "meanings_expanded": [
      "関税",
      "料金表"
    ],
    "contexts": [
      {
        "parts": [
          "The government imposed a",
          "on imports."
        ],
        "full": "The government imposed a TARIFF on imports.",
        "jp": "政府は輸入品に関税を課した。",
        "is_correct": true
      },
      {
        "parts": [
          "The government imposed a new ",
          "."
        ],
        "full": "The government imposed a new TARIFF.",
        "jp": "政府は新しい関税を課した。",
        "is_correct": true
      },
      {
        "parts": [
          "They reduced the import ",
          "."
        ],
        "full": "They reduced the import TARIFF.",
        "jp": "彼らは輸入関税を削減した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 601,
    "word": "TAX",
    "meaning_core": "税金",
    "syllables": [
      {
        "text": "TAX",
        "type": "strong"
      }
    ],
    "synonyms": {
      "LEVY": "徴税",
      "DUTY": "関税",
      "TARIFF": "税率"
    },
    "distractors": [
      "REFUND",
      "GIFT",
      "GRANT",
      "INCOME"
    ],
    "meanings_expanded": [
      "税金",
      "重荷"
    ],
    "contexts": [
      {
        "parts": [
          "We have to pay",
          "on our income."
        ],
        "full": "We have to pay TAX on our income.",
        "jp": "私たちは所得に対して税金を払わなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We must pay our income ",
          "."
        ],
        "full": "We must pay our income TAX.",
        "jp": "私たちは所得税を支払わなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The government will ",
          " luxury goods."
        ],
        "full": "The government will TAX luxury goods.",
        "jp": "政府は贅沢品に課税するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 602,
    "word": "TECHNOLOGY",
    "meaning_core": "技術",
    "syllables": [
      {
        "text": "tech",
        "type": "weak"
      },
      {
        "text": "NOL",
        "type": "strong"
      },
      {
        "text": "o",
        "type": "weak"
      },
      {
        "text": "gy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENGINEERING": "工学",
      "INNOVATION": "革新",
      "TECHNIQUE": "技法"
    },
    "distractors": [
      "NATURE",
      "TRADITION",
      "HISTORY",
      "BIOLOGY"
    ],
    "meanings_expanded": [
      "科学技術",
      "テクノロジー"
    ],
    "contexts": [
      {
        "parts": [
          "Modern",
          "has changed our lives."
        ],
        "full": "Modern TECHNOLOGY has changed our lives.",
        "jp": "現代の科学技術は私たちの生活を変えた。",
        "is_correct": true
      },
      {
        "parts": [
          "We rely on advanced ",
          "."
        ],
        "full": "We rely on advanced TECHNOLOGY.",
        "jp": "私たちは高度な技術に頼っている。",
        "is_correct": true
      },
      {
        "parts": [
          "He teaches information ",
          "."
        ],
        "full": "He teaches information TECHNOLOGY.",
        "jp": "彼は情報技術を教えている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 603,
    "word": "TEMPER",
    "meaning_core": "気性",
    "syllables": [
      {
        "text": "TEM",
        "type": "strong"
      },
      {
        "text": "per",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MOOD": "機嫌",
      "DISPOSITION": "気質",
      "ANGER": "怒り"
    },
    "distractors": [
      "CALM",
      "PEACE",
      "SILENCE",
      "JOY"
    ],
    "meanings_expanded": [
      "気性",
      "かんしゃく",
      "落ち着き"
    ],
    "contexts": [
      {
        "parts": [
          "He has a short",
          "."
        ],
        "full": "He has a short TEMPER.",
        "jp": "彼は短気だ（気性が短い）。",
        "is_correct": true
      },
      {
        "parts": [
          "She lost her",
          "."
        ],
        "full": "She lost her TEMPER.",
        "jp": "彼女は腹を立てた（落ち着きを失った）。",
        "is_correct": true
      },
      {
        "parts": [
          "He lost his ",
          " completely."
        ],
        "full": "He lost his TEMPER completely.",
        "jp": "彼は完全に平静（気性）を失った。",
        "is_correct": true
      },
      {
        "parts": [
          "She has a difficult ",
          "."
        ],
        "full": "She has a difficult TEMPER.",
        "jp": "彼女は難しい気性を持っている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 604,
    "word": "TEMPORARY",
    "meaning_core": "一時的な",
    "syllables": [
      {
        "text": "TEM",
        "type": "strong"
      },
      {
        "text": "po",
        "type": "weak"
      },
      {
        "text": "rar",
        "type": "weak"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BRIEF": "短い",
      "INTERIM": "当座の",
      "MOMENTARY": "瞬間的な"
    },
    "distractors": [
      "PERMANENT",
      "ETERNAL",
      "LASTING",
      "FOREVER"
    ],
    "meanings_expanded": [
      "一時的な",
      "仮の"
    ],
    "contexts": [
      {
        "parts": [
          "This is a",
          "solution."
        ],
        "full": "This is a TEMPORARY solution.",
        "jp": "これは一時的な解決策だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is only a ",
          " solution."
        ],
        "full": "This is only a TEMPORARY solution.",
        "jp": "これは一時的な解決策にすぎない。",
        "is_correct": true
      },
      {
        "parts": [
          "She has a ",
          " job."
        ],
        "full": "She has a TEMPORARY job.",
        "jp": "彼女は一時的な仕事に就いている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 605,
    "word": "TENACIOUS",
    "meaning_core": "粘り強い",
    "syllables": [
      {
        "text": "te",
        "type": "weak"
      },
      {
        "text": "NA",
        "type": "strong"
      },
      {
        "text": "cious",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PERSISTENT": "しつこい",
      "DETERMINED": "決意の固い",
      "STUBBORN": "頑固な"
    },
    "distractors": [
      "WEAK",
      "YIELDING",
      "LAZY",
      "FRAGILE"
    ],
    "meanings_expanded": [
      "粘り強い",
      "執拗な",
      "固執する"
    ],
    "contexts": [
      {
        "parts": [
          "She is a",
          "negotiator."
        ],
        "full": "She is a TENACIOUS negotiator.",
        "jp": "彼女は粘り強い交渉人だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a ",
          " grip on power."
        ],
        "full": "He has a TENACIOUS grip on power.",
        "jp": "彼は権力を粘り強く握っている。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a very ",
          " athlete."
        ],
        "full": "She is a very TENACIOUS athlete.",
        "jp": "彼女はとても粘り強い運動選手だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 606,
    "word": "TEND",
    "meaning_core": "～する傾向がある",
    "syllables": [
      {
        "text": "TEND",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INCLINE": "～したいと思う",
      "BE APT": "～しがちである",
      "CARE FOR": "世話をする"
    },
    "distractors": [
      "AVOID",
      "REFUSE",
      "IGNORE",
      "NEGLECT"
    ],
    "meanings_expanded": [
      "傾向がある",
      "世話をする"
    ],
    "contexts": [
      {
        "parts": [
          "Prices",
          "to rise in summer."
        ],
        "full": "Prices TEND to rise in summer.",
        "jp": "夏には価格が上がる傾向がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She",
          "to her garden."
        ],
        "full": "She tends to her garden.",
        "jp": "彼女は庭の手入れをする。",
        "is_correct": true
      },
      {
        "parts": [
          "I ",
          " to forget names."
        ],
        "full": "I TEND to forget names.",
        "jp": "私は名前を忘れる傾向がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Prices ",
          " to rise in summer."
        ],
        "full": "Prices TEND to rise in summer.",
        "jp": "価格は夏に上がる傾向がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 607,
    "word": "TERM",
    "meaning_core": "期間",
    "syllables": [
      {
        "text": "TERM",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PERIOD": "期間",
      "WORD": "言葉",
      "CONDITION": "条件"
    },
    "distractors": [
      "SILENCE",
      "PAUSE",
      "BREAK",
      "GAP"
    ],
    "meanings_expanded": [
      "用語",
      "期間",
      "学期",
      "条件"
    ],
    "contexts": [
      {
        "parts": [
          "The President serves a four-year",
          "."
        ],
        "full": "The President serves a four-year TERM.",
        "jp": "大統領の任期は4年だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is a technical",
          "."
        ],
        "full": "This is a technical TERM.",
        "jp": "これは専門用語だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He served a three-year ",
          "."
        ],
        "full": "He served a three-year TERM.",
        "jp": "彼は3年間の任期を務めた。",
        "is_correct": true
      },
      {
        "parts": [
          "We agreed to the long ",
          "."
        ],
        "full": "We agreed to the long TERM.",
        "jp": "私たちは長期契約（期間）に同意した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 608,
    "word": "TESTIMONY",
    "meaning_core": "証言",
    "syllables": [
      {
        "text": "TES",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "mo",
        "type": "weak"
      },
      {
        "text": "ny",
        "type": "weak"
      }
    ],
    "synonyms": {
      "EVIDENCE": "証拠",
      "STATEMENT": "陳述",
      "PROOF": "証明"
    },
    "distractors": [
      "LIE",
      "SILENCE",
      "DENIAL",
      "SECRET"
    ],
    "meanings_expanded": [
      "証言",
      "証拠"
    ],
    "contexts": [
      {
        "parts": [
          "His",
          "convinced the jury."
        ],
        "full": "His TESTIMONY convinced the jury.",
        "jp": "彼の証言は陪審員を納得させた。",
        "is_correct": true
      },
      {
        "parts": [
          "She refused to give",
          "."
        ],
        "full": "She refused to give TESTIMONY.",
        "jp": "彼女は証言を拒否した。",
        "is_correct": true
      },
      {
        "parts": [
          "The jury heard the expert's ",
          "."
        ],
        "full": "The jury heard the expert's TESTIMONY.",
        "jp": "陪審は専門家の証言を聞いた。",
        "is_correct": true
      },
      {
        "parts": [
          "His actions serve as a ",
          " to his courage."
        ],
        "full": "His actions serve as a TESTIMONY to his courage.",
        "jp": "彼の行動は彼の勇気の証拠（証言）となる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 609,
    "word": "THERAPY",
    "meaning_core": "治療",
    "syllables": [
      {
        "text": "THER",
        "type": "strong"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "py",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TREATMENT": "治療",
      "CURE": "治療法",
      "HEALING": "癒やし"
    },
    "distractors": [
      "DISEASE",
      "INJURY",
      "HARM",
      "PAIN"
    ],
    "meanings_expanded": [
      "療法",
      "治療"
    ],
    "contexts": [
      {
        "parts": [
          "He is undergoing physical",
          "."
        ],
        "full": "He is undergoing physical THERAPY.",
        "jp": "彼は理学療法を受けている。",
        "is_correct": true
      },
      {
        "parts": [
          "She needs physical ",
          "."
        ],
        "full": "She needs physical THERAPY.",
        "jp": "彼女には理学療法（治療）が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is undergoing drug ",
          "."
        ],
        "full": "He is undergoing drug THERAPY.",
        "jp": "彼は薬物療法を受けている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 610,
    "word": "THESIS",
    "meaning_core": "論文",
    "syllables": [
      {
        "text": "THE",
        "type": "strong"
      },
      {
        "text": "sis",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISSERTATION": "学位論文",
      "THEORY": "理論",
      "ARGUMENT": "主張"
    },
    "distractors": [
      "FACT",
      "DATA",
      "PROOF",
      "TRUTH"
    ],
    "meanings_expanded": [
      "論文",
      "主題",
      "命題"
    ],
    "contexts": [
      {
        "parts": [
          "She is writing her master's",
          "."
        ],
        "full": "She is writing her master's THESIS.",
        "jp": "彼女は修士論文を書いている。",
        "is_correct": true
      },
      {
        "parts": [
          "She is writing her master's ",
          "."
        ],
        "full": "She is writing her master's THESIS.",
        "jp": "彼女は修士論文を書いている。",
        "is_correct": true
      },
      {
        "parts": [
          "The main ",
          " of the book is simple."
        ],
        "full": "The main THESIS of the book is simple.",
        "jp": "その本の主要な論旨は単純だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 611,
    "word": "THOROUGH",
    "meaning_core": "徹底的な",
    "syllables": [
      {
        "text": "THOR",
        "type": "strong"
      },
      {
        "text": "ough",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLETE": "完全な",
      "COMPREHENSIVE": "包括的な",
      "CAREFUL": "注意深い"
    },
    "distractors": [
      "PARTIAL",
      "INCOMPLETE",
      "CARELESS",
      "SUPERFICIAL"
    ],
    "meanings_expanded": [
      "徹底的な",
      "完全な",
      "几帳面な"
    ],
    "contexts": [
      {
        "parts": [
          "The police conducted a",
          "search."
        ],
        "full": "The police conducted a THOROUGH search.",
        "jp": "警察は徹底的な捜索を行った。",
        "is_correct": true
      },
      {
        "parts": [
          "We need a ",
          " inspection."
        ],
        "full": "We need a THOROUGH inspection.",
        "jp": "私たちには徹底的な検査が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is known for his ",
          " work."
        ],
        "full": "He is known for his THOROUGH work.",
        "jp": "彼は徹底した仕事ぶりで知られている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 612,
    "word": "THOROUGHLY",
    "meaning_core": "徹底的に",
    "syllables": [
      {
        "text": "THOR",
        "type": "strong"
      },
      {
        "text": "ough",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COMPLETELY": "完全に",
      "FULLY": "十分に",
      "TOTALLY": "全く"
    },
    "distractors": [
      "PARTIALLY",
      "BARELY",
      "SLIGHTLY",
      "HARDLY"
    ],
    "meanings_expanded": [
      "徹底的に",
      "完全に"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "enjoyed the show."
        ],
        "full": "I THOROUGHLY enjoyed the show.",
        "jp": "私はショーを心から（徹底的に）楽しんだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Please wash your hands ",
          "."
        ],
        "full": "Please wash your hands THOROUGHLY.",
        "jp": "手を徹底的に洗いなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "The room was cleaned ",
          "."
        ],
        "full": "The room was cleaned THOROUGHLY.",
        "jp": "部屋は徹底的に掃除された。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 613,
    "word": "THREAT",
    "meaning_core": "脅威",
    "syllables": [
      {
        "text": "THREAT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "DANGER": "危険",
      "RISK": "リスク",
      "MENACE": "脅し"
    },
    "distractors": [
      "SAFETY",
      "PROTECTION",
      "SECURITY",
      "HELP"
    ],
    "meanings_expanded": [
      "脅威",
      "脅し",
      "予兆"
    ],
    "contexts": [
      {
        "parts": [
          "Pollution is a",
          "to the environment."
        ],
        "full": "Pollution is a THREAT to the environment.",
        "jp": "汚染は環境への脅威だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The storm poses a major ",
          "."
        ],
        "full": "The storm poses a major THREAT.",
        "jp": "その嵐は大きな脅威をもたらす。",
        "is_correct": true
      },
      {
        "parts": [
          "He ignored her empty ",
          "."
        ],
        "full": "He ignored her empty THREAT.",
        "jp": "彼は彼女の空虚な脅しを無視した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 614,
    "word": "THREATEN",
    "meaning_core": "脅かす",
    "syllables": [
      {
        "text": "THREAT",
        "type": "strong"
      },
      {
        "text": "en",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INTIMIDATE": "脅す",
      "ENDANGER": "危険にさらす",
      "WARN": "警告する"
    },
    "distractors": [
      "PROTECT",
      "SAVE",
      "DEFEND",
      "ASSURE"
    ],
    "meanings_expanded": [
      "脅す",
      "脅かす",
      "～の恐れがある"
    ],
    "contexts": [
      {
        "parts": [
          "Don't",
          "me."
        ],
        "full": "Don't THREATEN me.",
        "jp": "私を脅さないで。",
        "is_correct": true
      },
      {
        "parts": [
          "Dark clouds",
          "rain."
        ],
        "full": "Dark clouds THREATEN rain.",
        "jp": "暗い雲は雨の恐れがある（雨を予兆させる）。",
        "is_correct": true
      },
      {
        "parts": [
          "The company will ",
          " legal action."
        ],
        "full": "The company will THREATEN legal action.",
        "jp": "会社は法的措置をちらつかせるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Clouds ",
          " rain."
        ],
        "full": "Clouds THREATEN rain.",
        "jp": "雲が雨を脅かしている（降りそうだ）。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 615,
    "word": "THROUGHOUT",
    "meaning_core": "～の至る所で",
    "syllables": [
      {
        "text": "through",
        "type": "weak"
      },
      {
        "text": "OUT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "ALL OVER": "～中",
      "DURING": "～の間ずっと"
    },
    "distractors": [
      "OUTSIDE",
      "WITHOUT",
      "EXCEPT"
    ],
    "meanings_expanded": [
      "～の至る所で",
      "～の間中ずっと"
    ],
    "contexts": [
      {
        "parts": [
          "He traveled",
          "Europe."
        ],
        "full": "He traveled THROUGHOUT Europe.",
        "jp": "彼はヨーロッパ中を旅行した。",
        "is_correct": true
      },
      {
        "parts": [
          "She slept",
          "the movie."
        ],
        "full": "She slept THROUGHOUT the movie.",
        "jp": "彼女は映画の間ずっと眠っていた。",
        "is_correct": true
      },
      {
        "parts": [
          "The sound echoed ",
          " the hall."
        ],
        "full": "The sound echoed THROUGHOUT the hall.",
        "jp": "その音はホールの至る所に響き渡った。",
        "is_correct": true
      },
      {
        "parts": [
          "She traveled ",
          " the country."
        ],
        "full": "She traveled THROUGHOUT the country.",
        "jp": "彼女は国の至る所を旅した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 616,
    "word": "THUS",
    "meaning_core": "したがって",
    "syllables": [
      {
        "text": "THUS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "THEREFORE": "それゆえ",
      "SO": "だから",
      "HENCE": "したがって"
    },
    "distractors": [
      "BUT",
      "HOWEVER",
      "ALTHOUGH",
      "YET"
    ],
    "meanings_expanded": [
      "したがって",
      "このようにして"
    ],
    "contexts": [
      {
        "parts": [
          "He didn't study;",
          ",",
          "he failed."
        ],
        "full": "He didn't study; THUS, he failed.",
        "jp": "彼は勉強しなかった。したがって、彼は落ちた。",
        "is_correct": true
      },
      {
        "parts": [
          "She was busy, and ",
          " could not attend."
        ],
        "full": "She was busy, and THUS could not attend.",
        "jp": "彼女は忙しかった。したがって出席できなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "The test failed, ",
          " proving my point."
        ],
        "full": "The test failed, THUS proving my point.",
        "jp": "テストは失敗し、したがって私の論点を証明した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 617,
    "word": "TIGHTROPE",
    "meaning_core": "綱渡り",
    "syllables": [
      {
        "text": "TIGHT",
        "type": "strong"
      },
      {
        "text": "rope",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WIRE": "ワイヤー"
    },
    "distractors": [
      "GROUND",
      "FLOOR",
      "ROAD",
      "SIDEWALK"
    ],
    "meanings_expanded": [
      "綱渡り",
      "危ない橋"
    ],
    "contexts": [
      {
        "parts": [
          "The acrobat walked the",
          "."
        ],
        "full": "The acrobat walked the TIGHTROPE.",
        "jp": "アクロバットは綱渡りをした。",
        "is_correct": true
      },
      {
        "parts": [
          "He walked a dangerous ",
          "."
        ],
        "full": "He walked a dangerous TIGHTROPE.",
        "jp": "彼は危険な綱渡りをした。",
        "is_correct": true
      },
      {
        "parts": [
          "Negotiations are a delicate ",
          "."
        ],
        "full": "Negotiations are a delicate TIGHTROPE.",
        "jp": "交渉は繊細な綱渡りだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 618,
    "word": "TOKEN",
    "meaning_core": "しるし",
    "syllables": [
      {
        "text": "TO",
        "type": "strong"
      },
      {
        "text": "ken",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SYMBOL": "象徴",
      "SIGN": "しるし",
      "MARK": "証拠"
    },
    "distractors": [
      "REALITY",
      "FACT",
      "NOTHING",
      "VOID"
    ],
    "meanings_expanded": [
      "しるし",
      "形見",
      "代用貨幣"
    ],
    "contexts": [
      {
        "parts": [
          "Please accept this gift as a",
          "of my gratitude."
        ],
        "full": "Please accept this gift as a TOKEN of my gratitude.",
        "jp": "感謝のしるしとしてこの贈り物を受け取ってください。",
        "is_correct": true
      },
      {
        "parts": [
          "This coin is a bus",
          "."
        ],
        "full": "This coin is a bus TOKEN.",
        "jp": "このコインはバスの代用貨幣だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This gift is a ",
          " of my love."
        ],
        "full": "This gift is a TOKEN of my love.",
        "jp": "この贈り物は私の愛のしるしだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Please accept this ",
          " of thanks."
        ],
        "full": "Please accept this TOKEN of thanks.",
        "jp": "この感謝のしるしを受け取ってください。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 619,
    "word": "TOLERANCE",
    "meaning_core": "寛容",
    "syllables": [
      {
        "text": "TOL",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ance",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PATIENCE": "忍耐",
      "ACCEPTANCE": "受容",
      "ENDURANCE": "我慢"
    },
    "distractors": [
      "INTOLERANCE",
      "PREJUDICE",
      "BIGOTRY",
      "HATRED"
    ],
    "meanings_expanded": [
      "寛容",
      "忍耐力",
      "耐性"
    ],
    "contexts": [
      {
        "parts": [
          "We need more",
          "for others."
        ],
        "full": "We need more TOLERANCE for others.",
        "jp": "私たちは他人に対してもっと寛容である必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a low",
          "for alcohol."
        ],
        "full": "He has a low TOLERANCE for alcohol.",
        "jp": "彼はアルコールへの耐性が低い（お酒に弱い）。",
        "is_correct": true
      },
      {
        "parts": [
          "We should show religious ",
          "."
        ],
        "full": "We should show religious TOLERANCE.",
        "jp": "私たちは宗教的寛容を示すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "He has a low ",
          " for pain."
        ],
        "full": "He has a low TOLERANCE for pain.",
        "jp": "彼は痛みの許容度が低い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 620,
    "word": "TOLERATE",
    "meaning_core": "許容する",
    "syllables": [
      {
        "text": "TOL",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      },
      {
        "text": "ate",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENDURE": "耐える",
      "BEAR": "我慢する",
      "ALLOW": "許す"
    },
    "distractors": [
      "FORBID",
      "BAN",
      "PROHIBIT",
      "STOP"
    ],
    "meanings_expanded": [
      "許容する",
      "大目に見る",
      "耐える"
    ],
    "contexts": [
      {
        "parts": [
          "I cannot",
          "such behavior."
        ],
        "full": "I cannot TOLERATE such behavior.",
        "jp": "そのような振る舞いは許容できない。",
        "is_correct": true
      },
      {
        "parts": [
          "I cannot ",
          " this noise."
        ],
        "full": "I cannot TOLERATE this noise.",
        "jp": "私はこの騒音を許容できない。",
        "is_correct": true
      },
      {
        "parts": [
          "The plants will ",
          " the cold well."
        ],
        "full": "The plants will TOLERATE the cold well.",
        "jp": "その植物は寒さに十分耐えるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 621,
    "word": "TORMENT",
    "meaning_core": "苦しめる",
    "syllables": [
      {
        "text": "tor",
        "type": "weak"
      },
      {
        "text": "MENT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "TORTURE": "拷問にかける",
      "DISTRESS": "苦しめる",
      "PLAGUE": "悩ます"
    },
    "distractors": [
      "COMFORT",
      "SOOTHE",
      "PLEASE",
      "AID"
    ],
    "meanings_expanded": [
      "苦しめる",
      "悩ます",
      "激痛（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "Guilt continued to",
          "him."
        ],
        "full": "Guilt continued to TORMENT him.",
        "jp": "罪悪感が彼を苦しめ続けた。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " the animals."
        ],
        "full": "Do not TORMENT the animals.",
        "jp": "動物を苦しめてはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "He suffered mental ",
          "."
        ],
        "full": "He suffered mental TORMENT.",
        "jp": "彼は精神的な苦痛に苦しんだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 622,
    "word": "TOWARD",
    "meaning_core": "～の方へ",
    "syllables": [
      {
        "text": "TO",
        "type": "strong"
      },
      {
        "text": "ward",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TOWARDS": "～の方へ",
      "IN THE DIRECTION OF": "～の方向へ"
    },
    "distractors": [
      "AWAY FROM",
      "AGAINST",
      "FROM"
    ],
    "meanings_expanded": [
      "～の方へ",
      "～に向かって"
    ],
    "contexts": [
      {
        "parts": [
          "He walked",
          "the door."
        ],
        "full": "He walked TOWARD the door.",
        "jp": "彼はドアの方へ歩いた。",
        "is_correct": true
      },
      {
        "parts": [
          "We walked ",
          " the beach."
        ],
        "full": "We walked TOWARD the beach.",
        "jp": "私たちはビーチの方へ歩いた。",
        "is_correct": true
      },
      {
        "parts": [
          "She showed kindness ",
          " the poor."
        ],
        "full": "She showed kindness TOWARD the poor.",
        "jp": "彼女は貧しい人々に対して親切を示した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 623,
    "word": "TRANSFORMATION",
    "meaning_core": "変形",
    "syllables": [
      {
        "text": "trans",
        "type": "weak"
      },
      {
        "text": "for",
        "type": "weak"
      },
      {
        "text": "MA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CHANGE": "変化",
      "CONVERSION": "転換",
      "ALTERATION": "変更"
    },
    "distractors": [
      "STABILITY",
      "CONSTANCY",
      "PRESERVATION",
      "SAMENESS"
    ],
    "meanings_expanded": [
      "変形",
      "変質",
      "変化"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "from caterpillar to butterfly."
        ],
        "full": "The TRANSFORMATION from caterpillar to butterfly.",
        "jp": "芋虫から蝶への変身。",
        "is_correct": true
      },
      {
        "parts": [
          "The city saw a total ",
          "."
        ],
        "full": "The city saw a total TRANSFORMATION.",
        "jp": "その都市は完全な変貌を遂げた。",
        "is_correct": true
      },
      {
        "parts": [
          "He achieved personal ",
          "."
        ],
        "full": "He achieved personal TRANSFORMATION.",
        "jp": "彼は個人的な変革を達成した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 624,
    "word": "TRANSMIT",
    "meaning_core": "送る",
    "syllables": [
      {
        "text": "trans",
        "type": "weak"
      },
      {
        "text": "MIT",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SEND": "送る",
      "BROADCAST": "放送する",
      "CONVEY": "伝える"
    },
    "distractors": [
      "RECEIVE",
      "GET",
      "KEEP",
      "HOLD"
    ],
    "meanings_expanded": [
      "送る",
      "伝える",
      "感染させる"
    ],
    "contexts": [
      {
        "parts": [
          "Mosquitoes can",
          "diseases."
        ],
        "full": "Mosquitoes can TRANSMIT diseases.",
        "jp": "蚊は病気を媒介する（送る）ことがある。",
        "is_correct": true
      },
      {
        "parts": [
          "The radio tower will ",
          " the signal."
        ],
        "full": "The radio tower will TRANSMIT the signal.",
        "jp": "そのラジオ塔が信号を送るだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "Mosquitoes can ",
          " diseases."
        ],
        "full": "Mosquitoes can TRANSMIT diseases.",
        "jp": "蚊は病気を伝染させることができる。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 625,
    "word": "TRANSPARENCY",
    "meaning_core": "透明性",
    "syllables": [
      {
        "text": "trans",
        "type": "weak"
      },
      {
        "text": "PAR",
        "type": "strong"
      },
      {
        "text": "en",
        "type": "weak"
      },
      {
        "text": "cy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CLARITY": "明快さ",
      "OPENNESS": "開放性",
      "CLEARNESS": "透明度"
    },
    "distractors": [
      "OPACITY",
      "SECRECY",
      "DARKNESS",
      "OBSCURITY"
    ],
    "meanings_expanded": [
      "透明性",
      "透明度"
    ],
    "contexts": [
      {
        "parts": [
          "We need more",
          "in government."
        ],
        "full": "We need more TRANSPARENCY in government.",
        "jp": "政府にはもっと透明性が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The company promises full ",
          "."
        ],
        "full": "The company promises full TRANSPARENCY.",
        "jp": "会社は完全な透明性を約束する。",
        "is_correct": true
      },
      {
        "parts": [
          "We demand greater government ",
          "."
        ],
        "full": "We demand greater government TRANSPARENCY.",
        "jp": "私たちは政府のより大きな透明性を要求する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 626,
    "word": "TREMENDOUS",
    "meaning_core": "すさまじい",
    "syllables": [
      {
        "text": "tre",
        "type": "weak"
      },
      {
        "text": "MEN",
        "type": "strong"
      },
      {
        "text": "dous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "HUGE": "巨大な",
      "ENORMOUS": "莫大な",
      "IMMENSE": "計り知れない"
    },
    "distractors": [
      "TINY",
      "SMALL",
      "LITTLE",
      "INSIGNIFICANT"
    ],
    "meanings_expanded": [
      "すさまじい",
      "ものすごい",
      "巨大な"
    ],
    "contexts": [
      {
        "parts": [
          "It was a",
          "success."
        ],
        "full": "It was a TREMENDOUS success.",
        "jp": "それはものすごい成功だった。",
        "is_correct": true
      },
      {
        "parts": [
          "It was a ",
          " amount of work."
        ],
        "full": "It was a TREMENDOUS amount of work.",
        "jp": "それはすさまじい量の仕事だった。",
        "is_correct": true
      },
      {
        "parts": [
          "She showed ",
          " courage."
        ],
        "full": "She showed TREMENDOUS courage.",
        "jp": "彼女はとてつもない勇気を示した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 627,
    "word": "TRESPASS",
    "meaning_core": "侵入する",
    "syllables": [
      {
        "text": "TRES",
        "type": "strong"
      },
      {
        "text": "pass",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INTRUDE": "侵入する",
      "INVADE": "侵略する",
      "ENTER": "入る"
    },
    "distractors": [
      "LEAVE",
      "EXIT",
      "RETREAT",
      "WITHDRAW"
    ],
    "meanings_expanded": [
      "不法侵入する",
      "侵害する"
    ],
    "contexts": [
      {
        "parts": [
          "Do not",
          "on private property."
        ],
        "full": "Do not TRESPASS on private property.",
        "jp": "私有地に不法侵入してはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "Do not ",
          " on this private land."
        ],
        "full": "Do not TRESPASS on this private land.",
        "jp": "この私有地に侵入してはいけない。",
        "is_correct": true
      },
      {
        "parts": [
          "The law prohibits criminal ",
          "."
        ],
        "full": "The law prohibits criminal TRESPASS.",
        "jp": "法律は犯罪的な侵入を禁じている。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 628,
    "word": "TRIGGER",
    "meaning_core": "引き起こす",
    "syllables": [
      {
        "text": "TRIG",
        "type": "strong"
      },
      {
        "text": "ger",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CAUSE": "引き起こす",
      "ACTIVATE": "作動させる",
      "START": "始める"
    },
    "distractors": [
      "STOP",
      "PREVENT",
      "BLOCK",
      "END"
    ],
    "meanings_expanded": [
      "引き起こす",
      "きっかけとなる",
      "引き金（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "Smoke can",
          "the alarm."
        ],
        "full": "Smoke can TRIGGER the alarm.",
        "jp": "煙は警報を作動させる（引き起こす）可能性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The police pulled the",
          "."
        ],
        "full": "The police pulled the TRIGGER.",
        "jp": "警察は引き金を引いた。",
        "is_correct": true
      },
      {
        "parts": [
          "The alarm will ",
          " if the door opens."
        ],
        "full": "The alarm will TRIGGER if the door opens.",
        "jp": "ドアが開くとアラームが作動する。",
        "is_correct": true
      },
      {
        "parts": [
          "The news may ",
          " a panic."
        ],
        "full": "The news may TRIGGER a panic.",
        "jp": "そのニュースはパニックを引き起こすかもしれない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 629,
    "word": "TRIUMPH",
    "meaning_core": "勝利",
    "syllables": [
      {
        "text": "TRI",
        "type": "strong"
      },
      {
        "text": "umph",
        "type": "weak"
      }
    ],
    "synonyms": {
      "VICTORY": "勝利",
      "SUCCESS": "成功",
      "CONQUEST": "征服"
    },
    "distractors": [
      "DEFEAT",
      "FAILURE",
      "LOSS",
      "DISASTER"
    ],
    "meanings_expanded": [
      "勝利",
      "征服",
      "大成功"
    ],
    "contexts": [
      {
        "parts": [
          "It was a great",
          "for our team."
        ],
        "full": "It was a great TRIUMPH for our team.",
        "jp": "それは私たちのチームにとって大勝利だった。",
        "is_correct": true
      },
      {
        "parts": [
          "The victory was a great ",
          "."
        ],
        "full": "The victory was a great TRIUMPH.",
        "jp": "その勝利は大きな勝利だった。",
        "is_correct": true
      },
      {
        "parts": [
          "We celebrate their sporting ",
          "."
        ],
        "full": "We celebrate their sporting TRIUMPH.",
        "jp": "私たちは彼らのスポーツでの勝利を祝う。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 630,
    "word": "TUITION",
    "meaning_core": "授業料",
    "syllables": [
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "I",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FEES": "料金",
      "INSTRUCTION": "指導",
      "TEACHING": "教育"
    },
    "distractors": [
      "SALARY",
      "WAGE",
      "INCOME",
      "PAYMENT"
    ],
    "meanings_expanded": [
      "授業料",
      "授業"
    ],
    "contexts": [
      {
        "parts": [
          "College",
          "is very expensive."
        ],
        "full": "College TUITION is very expensive.",
        "jp": "大学の授業料はとても高い。",
        "is_correct": true
      },
      {
        "parts": [
          "College ",
          " is very expensive."
        ],
        "full": "College TUITION is very expensive.",
        "jp": "大学の授業料は非常に高価だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I paid the annual ",
          "."
        ],
        "full": "I paid the annual TUITION.",
        "jp": "私は年間の授業料を支払った。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 631,
    "word": "TYPICALLY",
    "meaning_core": "典型的に",
    "syllables": [
      {
        "text": "TYP",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "cal",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "USUALLY": "たいてい",
      "GENERALLY": "一般的に",
      "NORMALLY": "普通は"
    },
    "distractors": [
      "RARELY",
      "NEVER",
      "UNUSUALLY",
      "SELDOM"
    ],
    "meanings_expanded": [
      "典型的に",
      "一般的に",
      "概して"
    ],
    "contexts": [
      {
        "parts": [
          "He",
          "arrives at 9 a.m."
        ],
        "full": "He TYPICALLY arrives at 9 a.m.",
        "jp": "彼は概して（典型的には）午前9時に到着する。",
        "is_correct": true
      },
      {
        "parts": [
          "He ",
          " eats lunch at noon."
        ],
        "full": "He TYPICALLY eats lunch at noon.",
        "jp": "彼は典型的に正午に昼食をとる。",
        "is_correct": true
      },
      {
        "parts": [
          "The weather is ",
          " hot here."
        ],
        "full": "The weather is TYPICALLY hot here.",
        "jp": "ここでは天候は一般的に暑い。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 632,
    "word": "UNANIMOUS",
    "meaning_core": "満場一致の",
    "syllables": [
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "NAN",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "mous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AGREED": "合意した",
      "UNITED": "団結した",
      "UNDIVIDED": "分裂していない"
    },
    "distractors": [
      "DIVIDED",
      "SPLIT",
      "CONFLICTING",
      "DIFFERENT"
    ],
    "meanings_expanded": [
      "満場一致の",
      "異口同音の"
    ],
    "contexts": [
      {
        "parts": [
          "The jury reached a",
          "verdict."
        ],
        "full": "The jury reached a UNANIMOUS verdict.",
        "jp": "陪審員は満場一致の評決に達した。",
        "is_correct": true
      },
      {
        "parts": [
          "The jury reached a ",
          " verdict."
        ],
        "full": "The jury reached a UNANIMOUS verdict.",
        "jp": "陪審は満場一致の評決に達した。",
        "is_correct": true
      },
      {
        "parts": [
          "The vote was ",
          "."
        ],
        "full": "The vote was UNANIMOUS.",
        "jp": "投票は満場一致だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 633,
    "word": "UNANIMOUSLY",
    "meaning_core": "満場一致で",
    "syllables": [
      {
        "text": "u",
        "type": "weak"
      },
      {
        "text": "NAN",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "mous",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COLLECTIVELY": "集合的に",
      "JOINTLY": "共同で"
    },
    "distractors": [
      "SEPARATELY",
      "INDIVIDUALLY",
      "PARTIALLY",
      "SINGLY"
    ],
    "meanings_expanded": [
      "満場一致で"
    ],
    "contexts": [
      {
        "parts": [
          "They voted",
          "to pass the law."
        ],
        "full": "They voted UNANIMOUSLY to pass the law.",
        "jp": "彼らは満場一致でその法律を可決した。",
        "is_correct": true
      },
      {
        "parts": [
          "The motion was passed ",
          "."
        ],
        "full": "The motion was passed UNANIMOUSLY.",
        "jp": "その動議は満場一致で可決された。",
        "is_correct": true
      },
      {
        "parts": [
          "They ",
          " supported the new leader."
        ],
        "full": "They UNANIMOUSLY supported the new leader.",
        "jp": "彼らは満場一致で新しい指導者を支持した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 634,
    "word": "UNAWARE",
    "meaning_core": "気づかない",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "WARE",
        "type": "strong"
      }
    ],
    "synonyms": {
      "IGNORANT": "知らない",
      "OBLIVIOUS": "気づいていない",
      "UNCONSCIOUS": "意識していない"
    },
    "distractors": [
      "AWARE",
      "CONSCIOUS",
      "KNOWING",
      "MINDFUL"
    ],
    "meanings_expanded": [
      "気づかない",
      "知らない"
    ],
    "contexts": [
      {
        "parts": [
          "He was",
          "of the danger."
        ],
        "full": "He was UNAWARE of the danger.",
        "jp": "彼は危険に気づいていなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "She was ",
          " of the danger."
        ],
        "full": "She was UNAWARE of the danger.",
        "jp": "彼女は危険に気づかなかった。",
        "is_correct": true
      },
      {
        "parts": [
          "He remained completely ",
          " of his error."
        ],
        "full": "He remained completely UNAWARE of his error.",
        "jp": "彼は自分の間違いに全く気づかないままだった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 635,
    "word": "UNDERGO",
    "meaning_core": "経験する",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "der",
        "type": "weak"
      },
      {
        "text": "GO",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXPERIENCE": "経験する",
      "ENDURE": "耐える",
      "GO THROUGH": "経験する"
    },
    "distractors": [
      "AVOID",
      "SKIP",
      "MISS",
      "ESCAPE"
    ],
    "meanings_expanded": [
      "（変化・試練などを）経験する",
      "受ける"
    ],
    "contexts": [
      {
        "parts": [
          "He must",
          "surgery."
        ],
        "full": "He must UNDERGO surgery.",
        "jp": "彼は手術を受けなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "She will ",
          " surgery tomorrow."
        ],
        "full": "She will UNDERGO surgery tomorrow.",
        "jp": "彼女は明日手術を受ける（経験する）だろう。",
        "is_correct": true
      },
      {
        "parts": [
          "The building will ",
          " major repairs."
        ],
        "full": "The building will UNDERGO major repairs.",
        "jp": "その建物は大規模な修理を受けるだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 636,
    "word": "UNEXPECTED",
    "meaning_core": "予期しない",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "ex",
        "type": "weak"
      },
      {
        "text": "PEC",
        "type": "strong"
      },
      {
        "text": "ted",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SURPRISING": "驚くべき",
      "SUDDEN": "突然の",
      "UNFORESEEN": "予見していない"
    },
    "distractors": [
      "EXPECTED",
      "PREDICTABLE",
      "PLANNED",
      "KNOWN"
    ],
    "meanings_expanded": [
      "予期しない",
      "思いがけない"
    ],
    "contexts": [
      {
        "parts": [
          "The news was completely",
          "."
        ],
        "full": "The news was completely UNEXPECTED.",
        "jp": "そのニュースは完全に予期しないものだった。",
        "is_correct": true
      },
      {
        "parts": [
          "We faced an ",
          " delay."
        ],
        "full": "We faced an UNEXPECTED delay.",
        "jp": "私たちは予期しない遅延に直面した。",
        "is_correct": true
      },
      {
        "parts": [
          "The news came as an ",
          " shock."
        ],
        "full": "The news came as an UNEXPECTED shock.",
        "jp": "そのニュースは予期しない衝撃として伝わった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 637,
    "word": "UNIFORM",
    "meaning_core": "均一の",
    "syllables": [
      {
        "text": "U",
        "type": "strong"
      },
      {
        "text": "ni",
        "type": "weak"
      },
      {
        "text": "form",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONSISTENT": "一貫した",
      "SAME": "同じ",
      "EVEN": "平らな"
    },
    "distractors": [
      "VARIED",
      "DIFFERENT",
      "DIVERSE",
      "CHANGING"
    ],
    "meanings_expanded": [
      "均一の",
      "一定の",
      "制服（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "The temperature should be",
          "."
        ],
        "full": "The temperature should be UNIFORM.",
        "jp": "温度は均一でなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The quality is entirely ",
          "."
        ],
        "full": "The quality is entirely UNIFORM.",
        "jp": "品質は完全に均一だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Students wear a school ",
          "."
        ],
        "full": "Students wear a school UNIFORM.",
        "jp": "学生は学校の制服を着る。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 638,
    "word": "UNIVERSE",
    "meaning_core": "宇宙",
    "syllables": [
      {
        "text": "U",
        "type": "strong"
      },
      {
        "text": "ni",
        "type": "weak"
      },
      {
        "text": "verse",
        "type": "weak"
      }
    ],
    "synonyms": {
      "COSMOS": "宇宙",
      "SPACE": "宇宙空間",
      "WORLD": "世界"
    },
    "distractors": [
      "EARTH",
      "ATOM",
      "PARTICLE",
      "NOTHING"
    ],
    "meanings_expanded": [
      "宇宙",
      "万物"
    ],
    "contexts": [
      {
        "parts": [
          "The",
          "is expanding."
        ],
        "full": "The UNIVERSE is expanding.",
        "jp": "宇宙は膨張している。",
        "is_correct": true
      },
      {
        "parts": [
          "The ",
          " is vast and mysterious."
        ],
        "full": "The UNIVERSE is vast and mysterious.",
        "jp": "宇宙は広大で神秘的だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We study the origin of the ",
          "."
        ],
        "full": "We study the origin of the UNIVERSE.",
        "jp": "私たちは宇宙の起源を研究する。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 639,
    "word": "UNKNOWN",
    "meaning_core": "未知の",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "KNOWN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "UNFAMILIAR": "なじみのない",
      "STRANGE": "奇妙な",
      "MYSTERIOUS": "神秘的な"
    },
    "distractors": [
      "KNOWN",
      "FAMOUS",
      "FAMILIAR",
      "POPULAR"
    ],
    "meanings_expanded": [
      "未知の",
      "知られていない",
      "無名の"
    ],
    "contexts": [
      {
        "parts": [
          "The cause of the fire is",
          "."
        ],
        "full": "The cause of the fire is UNKNOWN.",
        "jp": "火事の原因は不明（未知）だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The cause of the fire is ",
          "."
        ],
        "full": "The cause of the fire is UNKNOWN.",
        "jp": "火災の原因は不明だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He explored the great ",
          "."
        ],
        "full": "He explored the great UNKNOWN.",
        "jp": "彼は偉大な未知の領域を探検した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 640,
    "word": "UNLESS",
    "meaning_core": "もし～でなければ",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "LESS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "EXCEPT IF": "～の場合を除いて"
    },
    "distractors": [
      "IF",
      "BECAUSE",
      "SINCE",
      "WHEN"
    ],
    "meanings_expanded": [
      "もし～でなければ"
    ],
    "contexts": [
      {
        "parts": [
          "I won't go",
          "you go."
        ],
        "full": "I won't go UNLESS you go.",
        "jp": "君が行かないなら私も行かない。",
        "is_correct": true
      },
      {
        "parts": [
          "We cannot win ",
          " we work together."
        ],
        "full": "We cannot win UNLESS we work together.",
        "jp": "協力しない限り、私たちは勝てない。",
        "is_correct": true
      },
      {
        "parts": [
          "I will go, ",
          " I hear from you."
        ],
        "full": "I will go, UNLESS I hear from you.",
        "jp": "あなたから連絡がない限り、私は行く。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 641,
    "word": "UNLIKELY",
    "meaning_core": "～しそうにない",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "LIKE",
        "type": "strong"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "IMPROBABLE": "ありそうもない",
      "DOUBTFUL": "疑わしい"
    },
    "distractors": [
      "LIKELY",
      "PROBABLE",
      "CERTAIN",
      "SURE"
    ],
    "meanings_expanded": [
      "～しそうにない",
      "ありそうもない"
    ],
    "contexts": [
      {
        "parts": [
          "It is",
          "to rain today."
        ],
        "full": "It is UNLIKELY to rain today.",
        "jp": "今日は雨が降りそうにない。",
        "is_correct": true
      },
      {
        "parts": [
          "It is ",
          " to rain today."
        ],
        "full": "It is UNLIKELY to rain today.",
        "jp": "今日は雨が降りそうにない。",
        "is_correct": true
      },
      {
        "parts": [
          "He is an ",
          " candidate for the job."
        ],
        "full": "He is an UNLIKELY candidate for the job.",
        "jp": "彼はその仕事の候補者にはなりそうもない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 642,
    "word": "UNPRECEDENTED",
    "meaning_core": "前例のない",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "PREC",
        "type": "strong"
      },
      {
        "text": "e",
        "type": "weak"
      },
      {
        "text": "den",
        "type": "weak"
      },
      {
        "text": "ted",
        "type": "weak"
      }
    ],
    "synonyms": {
      "UNPARALLELED": "並ぶもののない",
      "NEW": "新しい",
      "EXTRAORDINARY": "異常な"
    },
    "distractors": [
      "COMMON",
      "USUAL",
      "NORMAL",
      "TYPICAL"
    ],
    "meanings_expanded": [
      "前例のない",
      "空前の"
    ],
    "contexts": [
      {
        "parts": [
          "This is an",
          "event."
        ],
        "full": "This is an UNPRECEDENTED event.",
        "jp": "これは前例のない出来事だ。",
        "is_correct": true
      },
      {
        "parts": [
          "This is an ",
          " situation."
        ],
        "full": "This is an UNPRECEDENTED situation.",
        "jp": "これは前例のない状況だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The crisis reached an ",
          " level."
        ],
        "full": "The crisis reached an UNPRECEDENTED level.",
        "jp": "その危機は前例のないレベルに達した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 643,
    "word": "UNREST",
    "meaning_core": "不安",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "REST",
        "type": "strong"
      }
    ],
    "synonyms": {
      "TURMOIL": "騒乱",
      "DISTURBANCE": "騒動",
      "AGITATION": "動揺"
    },
    "distractors": [
      "PEACE",
      "CALM",
      "ORDER",
      "TRANQUILITY"
    ],
    "meanings_expanded": [
      "（社会的な）不安",
      "動揺",
      "不穏"
    ],
    "contexts": [
      {
        "parts": [
          "Political",
          "is growing."
        ],
        "full": "Political UNREST is growing.",
        "jp": "政治的不安が高まっている。",
        "is_correct": true
      },
      {
        "parts": [
          "There is social ",
          " in the city."
        ],
        "full": "There is social UNREST in the city.",
        "jp": "その都市には社会的な不安がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The leader calmed the public ",
          "."
        ],
        "full": "The leader calmed the public UNREST.",
        "jp": "指導者は国民の不安を鎮めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 644,
    "word": "UNUSUAL",
    "meaning_core": "普通でない",
    "syllables": [
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "U",
        "type": "strong"
      },
      {
        "text": "su",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RARE": "珍しい",
      "STRANGE": "奇妙な",
      "UNCOMMON": "一般的でない"
    },
    "distractors": [
      "USUAL",
      "COMMON",
      "NORMAL",
      "TYPICAL"
    ],
    "meanings_expanded": [
      "普通でない",
      "珍しい",
      "異常な"
    ],
    "contexts": [
      {
        "parts": [
          "It is",
          "for him to be late."
        ],
        "full": "It is UNUSUAL for him to be late.",
        "jp": "彼が遅刻するのは珍しい（普通ではない）。",
        "is_correct": true
      },
      {
        "parts": [
          "She showed an ",
          " degree of skill."
        ],
        "full": "She showed an UNUSUAL degree of skill.",
        "jp": "彼女は異常なほどの熟練度を示した。",
        "is_correct": true
      },
      {
        "parts": [
          "The animal is quite ",
          "."
        ],
        "full": "The animal is quite UNUSUAL.",
        "jp": "その動物は非常に珍しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 645,
    "word": "UPHOLD",
    "meaning_core": "支持する",
    "syllables": [
      {
        "text": "up",
        "type": "weak"
      },
      {
        "text": "HOLD",
        "type": "strong"
      }
    ],
    "synonyms": {
      "SUPPORT": "支持する",
      "MAINTAIN": "維持する",
      "DEFEND": "守る"
    },
    "distractors": [
      "OPPOSE",
      "REJECT",
      "DESTROY",
      "ABOLISH"
    ],
    "meanings_expanded": [
      "支持する",
      "（法などを）守る",
      "確認する"
    ],
    "contexts": [
      {
        "parts": [
          "We must",
          "the law."
        ],
        "full": "We must UPHOLD the law.",
        "jp": "私たちは法律を守ら（支持し）なければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the law."
        ],
        "full": "We must UPHOLD the law.",
        "jp": "私たちは法律を支持しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "The court will ",
          " the decision."
        ],
        "full": "The court will UPHOLD the decision.",
        "jp": "裁判所はその決定を支持するだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 646,
    "word": "URGENT",
    "meaning_core": "緊急の",
    "syllables": [
      {
        "text": "UR",
        "type": "strong"
      },
      {
        "text": "gent",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PRESSING": "差し迫った",
      "CRITICAL": "重大な",
      "IMMEDIATE": "即座の"
    },
    "distractors": [
      "TRIVIAL",
      "MINOR",
      "UNIMPORTANT",
      "DELAYED"
    ],
    "meanings_expanded": [
      "緊急の",
      "差し迫った"
    ],
    "contexts": [
      {
        "parts": [
          "I have an",
          "message."
        ],
        "full": "I have an URGENT message.",
        "jp": "緊急のメッセージがあります。",
        "is_correct": true
      },
      {
        "parts": [
          "The matter is extremely ",
          "."
        ],
        "full": "The matter is extremely URGENT.",
        "jp": "その件は極めて緊急だ。",
        "is_correct": true
      },
      {
        "parts": [
          "I have an ",
          " message for you."
        ],
        "full": "I have an URGENT message for you.",
        "jp": "あなたへの緊急のメッセージがある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 647,
    "word": "USELESS",
    "meaning_core": "役に立たない",
    "syllables": [
      {
        "text": "USE",
        "type": "strong"
      },
      {
        "text": "less",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FUTILE": "無駄な",
      "WORTHLESS": "価値のない",
      "INEFFECTIVE": "効果のない"
    },
    "distractors": [
      "USEFUL",
      "HELPFUL",
      "VALUABLE",
      "EFFECTIVE"
    ],
    "meanings_expanded": [
      "役に立たない",
      "無駄な"
    ],
    "contexts": [
      {
        "parts": [
          "This tool is broken and",
          "."
        ],
        "full": "This tool is broken and USELESS.",
        "jp": "この道具は壊れていて役に立たない。",
        "is_correct": true
      },
      {
        "parts": [
          "The old map is entirely ",
          "."
        ],
        "full": "The old map is entirely USELESS.",
        "jp": "その古い地図は全く役に立たない。",
        "is_correct": true
      },
      {
        "parts": [
          "Arguing with him is ",
          "."
        ],
        "full": "Arguing with him is USELESS.",
        "jp": "彼と議論するのは無駄だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 648,
    "word": "UTILIZE",
    "meaning_core": "利用する",
    "syllables": [
      {
        "text": "U",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "lize",
        "type": "weak"
      }
    ],
    "synonyms": {
      "USE": "使う",
      "EMPLOY": "用いる",
      "EXPLOIT": "活用する"
    },
    "distractors": [
      "WASTE",
      "IGNORE",
      "NEGLECT",
      "DISCARD"
    ],
    "meanings_expanded": [
      "利用する",
      "活用する"
    ],
    "contexts": [
      {
        "parts": [
          "We should",
          "solar energy."
        ],
        "full": "We should UTILIZE solar energy.",
        "jp": "私たちは太陽エネルギーを利用すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "We should ",
          " the new software."
        ],
        "full": "We should UTILIZE the new software.",
        "jp": "私たちは新しいソフトウェアを利用すべきだ。",
        "is_correct": true
      },
      {
        "parts": [
          "Try to ",
          " your time better."
        ],
        "full": "Try to UTILIZE your time better.",
        "jp": "あなたの時間をより有効に活用するようにしなさい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 649,
    "word": "VALIDATION",
    "meaning_core": "検証",
    "syllables": [
      {
        "text": "val",
        "type": "weak"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "DA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CONFIRMATION": "確認",
      "VERIFICATION": "立証",
      "APPROVAL": "承認"
    },
    "distractors": [
      "REJECTION",
      "DENIAL",
      "REFUSAL",
      "INVALIDATION"
    ],
    "meanings_expanded": [
      "検証",
      "確認",
      "承認"
    ],
    "contexts": [
      {
        "parts": [
          "The results require",
          "."
        ],
        "full": "The results require VALIDATION.",
        "jp": "結果には検証が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We need independent ",
          "."
        ],
        "full": "We need independent VALIDATION.",
        "jp": "私たちには独立した検証が必要だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She sought professional ",
          " for her work."
        ],
        "full": "She sought professional VALIDATION for her work.",
        "jp": "彼女は自分の仕事に対する専門的な検証を求めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 650,
    "word": "VALUE",
    "meaning_core": "尊重する",
    "syllables": [
      {
        "text": "VAL",
        "type": "strong"
      },
      {
        "text": "ue",
        "type": "weak"
      }
    ],
    "synonyms": {
      "APPRECIATE": "評価する",
      "CHERISH": "大事にする",
      "RESPECT": "尊重する"
    },
    "distractors": [
      "SCORN",
      "HATE",
      "DISREGARD",
      "IGNORE"
    ],
    "meanings_expanded": [
      "尊重する",
      "評価する",
      "価値（名詞）"
    ],
    "contexts": [
      {
        "parts": [
          "I",
          "your friendship."
        ],
        "full": "I VALUE your friendship.",
        "jp": "私はあなたの友情を尊重している。",
        "is_correct": true
      },
      {
        "parts": [
          "She seems to ",
          " his opinion."
        ],
        "full": "She seems to VALUE his opinion.",
        "jp": "彼女は彼の意見を尊重しているようだ。",
        "is_correct": true
      },
      {
        "parts": [
          "I do not ",
          " money highly."
        ],
        "full": "I do not VALUE money highly.",
        "jp": "私はお金を高く評価しない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 651,
    "word": "VANDALISM",
    "meaning_core": "器物損壊",
    "syllables": [
      {
        "text": "VAN",
        "type": "strong"
      },
      {
        "text": "dal",
        "type": "weak"
      },
      {
        "text": "ism",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DESTRUCTION": "破壊",
      "DAMAGE": "損害",
      "DEFACEMENT": "汚損"
    },
    "distractors": [
      "CONSTRUCTION",
      "REPAIR",
      "ART",
      "CREATION"
    ],
    "meanings_expanded": [
      "器物損壊",
      "芸術破壊",
      "公共物汚損"
    ],
    "contexts": [
      {
        "parts": [
          "Graffiti is a form of",
          "."
        ],
        "full": "Graffiti is a form of VANDALISM.",
        "jp": "落書きは器物損壊の一形態だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The police reported widespread ",
          "."
        ],
        "full": "The police reported widespread VANDALISM.",
        "jp": "警察は広範囲にわたる器物損壊を報告した。",
        "is_correct": true
      },
      {
        "parts": [
          "We repaired the damage from ",
          "."
        ],
        "full": "We repaired the damage from VANDALISM.",
        "jp": "私たちは器物損壊による損害を修理した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 652,
    "word": "VANISH",
    "meaning_core": "消える",
    "syllables": [
      {
        "text": "VAN",
        "type": "strong"
      },
      {
        "text": "ish",
        "type": "weak"
      }
    ],
    "synonyms": {
      "DISAPPEAR": "姿を消す",
      "FADE": "薄れる",
      "EVAPORATE": "蒸発する"
    },
    "distractors": [
      "APPEAR",
      "ARRIVE",
      "STAY",
      "REMAIN"
    ],
    "meanings_expanded": [
      "消える",
      "見えなくなる",
      "消滅する"
    ],
    "contexts": [
      {
        "parts": [
          "The magician made the rabbit",
          "."
        ],
        "full": "The magician made the rabbit VANISH.",
        "jp": "手品師はウサギを消した。",
        "is_correct": true
      },
      {
        "parts": [
          "The ship will ",
          " below the horizon."
        ],
        "full": "The ship will VANISH below the horizon.",
        "jp": "船は水平線の下に消えるだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "My money began to ",
          "."
        ],
        "full": "My money began to VANISH.",
        "jp": "私のお金が消え始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 653,
    "word": "VAST",
    "meaning_core": "広大な",
    "syllables": [
      {
        "text": "VAST",
        "type": "strong"
      }
    ],
    "synonyms": {
      "HUGE": "巨大な",
      "IMMENSE": "計り知れない",
      "ENORMOUS": "莫大な"
    },
    "distractors": [
      "TINY",
      "SMALL",
      "NARROW",
      "LIMITED"
    ],
    "meanings_expanded": [
      "広大な",
      "莫大な",
      "広がり"
    ],
    "contexts": [
      {
        "parts": [
          "The Sahara is a",
          "desert."
        ],
        "full": "The Sahara is a VAST desert.",
        "jp": "サハラ砂漠は広大な砂漠だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The desert is a ",
          " area."
        ],
        "full": "The desert is a VAST area.",
        "jp": "砂漠は広大な地域だ。",
        "is_correct": true
      },
      {
        "parts": [
          "They discovered a ",
          " cave system."
        ],
        "full": "They discovered a VAST cave system.",
        "jp": "彼らは巨大な洞窟システムを発見した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 654,
    "word": "VEHEMENT",
    "meaning_core": "猛烈な",
    "syllables": [
      {
        "text": "VE",
        "type": "strong"
      },
      {
        "text": "he",
        "type": "weak"
      },
      {
        "text": "ment",
        "type": "weak"
      }
    ],
    "synonyms": {
      "INTENSE": "激しい",
      "PASSIONATE": "情熱的な",
      "FIERCE": "どう猛な"
    },
    "distractors": [
      "MILD",
      "CALM",
      "GENTLE",
      "WEAK"
    ],
    "meanings_expanded": [
      "猛烈な",
      "熱烈な",
      "激しい"
    ],
    "contexts": [
      {
        "parts": [
          "He issued a",
          "denial."
        ],
        "full": "He issued a VEHEMENT denial.",
        "jp": "彼は猛烈に否定した。",
        "is_correct": true
      },
      {
        "parts": [
          "He gave a ",
          " denial."
        ],
        "full": "He gave a VEHEMENT denial.",
        "jp": "彼は猛烈な否定をした。",
        "is_correct": true
      },
      {
        "parts": [
          "She showed ",
          " opposition."
        ],
        "full": "She showed VEHEMENT opposition.",
        "jp": "彼女は激しい反対を示した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 655,
    "word": "VENTILATE",
    "meaning_core": "換気する",
    "syllables": [
      {
        "text": "VEN",
        "type": "strong"
      },
      {
        "text": "ti",
        "type": "weak"
      },
      {
        "text": "late",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AIR": "風を通す",
      "AERATE": "通気する",
      "FRESHEN": "一新する"
    },
    "distractors": [
      "CLOSE",
      "SEAL",
      "BLOCK",
      "SUFFOCATE"
    ],
    "meanings_expanded": [
      "換気する",
      "（感情を）出し切る"
    ],
    "contexts": [
      {
        "parts": [
          "Open the window to",
          "the room."
        ],
        "full": "Open the window to VENTILATE the room.",
        "jp": "部屋を換気するために窓を開けなさい。",
        "is_correct": true
      },
      {
        "parts": [
          "We must ",
          " the room well."
        ],
        "full": "We must VENTILATE the room well.",
        "jp": "私たちは部屋をよく換気しなければならない。",
        "is_correct": true
      },
      {
        "parts": [
          "This fan helps to ",
          " the area."
        ],
        "full": "This fan helps to VENTILATE the area.",
        "jp": "この扇風機はその場所の換気を助ける。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 656,
    "word": "VENUE",
    "meaning_core": "会場",
    "syllables": [
      {
        "text": "VEN",
        "type": "strong"
      },
      {
        "text": "ue",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LOCATION": "場所",
      "SITE": "現場",
      "PLACE": "所"
    },
    "distractors": [
      "TIME",
      "DATE",
      "PERSON",
      "EVENT"
    ],
    "meanings_expanded": [
      "会場",
      "開催地"
    ],
    "contexts": [
      {
        "parts": [
          "The stadium is a popular",
          "for concerts."
        ],
        "full": "The stadium is a popular VENUE for concerts.",
        "jp": "そのスタジアムはコンサートの人気会場だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The wedding ",
          " was beautiful."
        ],
        "full": "The wedding VENUE was beautiful.",
        "jp": "結婚式の会場は美しかった。",
        "is_correct": true
      },
      {
        "parts": [
          "We need to book a new ",
          "."
        ],
        "full": "We need to book a new VENUE.",
        "jp": "私たちには新しい会場を予約する必要がある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 657,
    "word": "VERBAL",
    "meaning_core": "言葉の",
    "syllables": [
      {
        "text": "VER",
        "type": "strong"
      },
      {
        "text": "bal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ORAL": "口頭の",
      "SPOKEN": "話された",
      "LINGUISTIC": "言語の"
    },
    "distractors": [
      "WRITTEN",
      "VISUAL",
      "NONVERBAL",
      "SILENT"
    ],
    "meanings_expanded": [
      "言葉の",
      "口頭の",
      "動詞の"
    ],
    "contexts": [
      {
        "parts": [
          "They made a",
          "agreement."
        ],
        "full": "They made a VERBAL agreement.",
        "jp": "彼らは口頭で合意した。",
        "is_correct": true
      },
      {
        "parts": [
          "She gave a ",
          " agreement."
        ],
        "full": "She gave a VERBAL agreement.",
        "jp": "彼女は口頭での合意を与えた。",
        "is_correct": true
      },
      {
        "parts": [
          "We need written, not ",
          " instructions."
        ],
        "full": "We need written, not VERBAL instructions.",
        "jp": "私たちには口頭ではなく、書面による指示が必要だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 658,
    "word": "VIBRANT",
    "meaning_core": "活気に満ちた",
    "syllables": [
      {
        "text": "VI",
        "type": "strong"
      },
      {
        "text": "brant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "LIVELY": "生き生きとした",
      "BRIGHT": "鮮やかな",
      "ENERGETIC": "精力的な"
    },
    "distractors": [
      "DULL",
      "PALE",
      "WEAK",
      "LIFELESS"
    ],
    "meanings_expanded": [
      "活気に満ちた",
      "鮮やかな",
      "振動する"
    ],
    "contexts": [
      {
        "parts": [
          "Tokyo is a",
          "city."
        ],
        "full": "Tokyo is a VIBRANT city.",
        "jp": "東京は活気に満ちた都市だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The city has a ",
          " nightlife."
        ],
        "full": "The city has a VIBRANT nightlife.",
        "jp": "その都市には活気に満ちた夜の生活がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She chose a ",
          " blue color."
        ],
        "full": "She chose a VIBRANT blue color.",
        "jp": "彼女は鮮やかな青色を選んだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 659,
    "word": "VIRTUALLY",
    "meaning_core": "事実上",
    "syllables": [
      {
        "text": "VIR",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "al",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "PRACTICALLY": "実際的に",
      "ALMOST": "ほとんど",
      "NEARLY": "ほぼ"
    },
    "distractors": [
      "EXACTLY",
      "PRECISELY",
      "LITERALLY",
      "COMPLETELY"
    ],
    "meanings_expanded": [
      "事実上",
      "実質的に",
      "仮想的に"
    ],
    "contexts": [
      {
        "parts": [
          "The disease has been",
          "eliminated."
        ],
        "full": "The disease has been VIRTUALLY eliminated.",
        "jp": "その病気は事実上根絶された。",
        "is_correct": true
      },
      {
        "parts": [
          "The project is ",
          " complete."
        ],
        "full": "The project is VIRTUALLY complete.",
        "jp": "そのプロジェクトは事実上完了している。",
        "is_correct": true
      },
      {
        "parts": [
          "It is ",
          " impossible to fail."
        ],
        "full": "It is VIRTUALLY impossible to fail.",
        "jp": "失敗することは実質的にあり得ない。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 660,
    "word": "VIRTUOUS",
    "meaning_core": "有徳な",
    "syllables": [
      {
        "text": "VIR",
        "type": "strong"
      },
      {
        "text": "tu",
        "type": "weak"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "MORAL": "道徳的な",
      "GOOD": "善良な",
      "RIGHTEOUS": "正義の"
    },
    "distractors": [
      "WICKED",
      "EVIL",
      "BAD",
      "SINFUL"
    ],
    "meanings_expanded": [
      "有徳な",
      "高潔な",
      "貞淑な"
    ],
    "contexts": [
      {
        "parts": [
          "She lived a",
          "life."
        ],
        "full": "She lived a VIRTUOUS life.",
        "jp": "彼女は高潔な人生を送った。",
        "is_correct": true
      },
      {
        "parts": [
          "He is known as a ",
          " leader."
        ],
        "full": "He is known as a VIRTUOUS leader.",
        "jp": "彼は有徳な指導者として知られている。",
        "is_correct": true
      },
      {
        "parts": [
          "We strive to live a ",
          " life."
        ],
        "full": "We strive to live a VIRTUOUS life.",
        "jp": "私たちは徳のある生活を送るように努める。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 661,
    "word": "VISIBLE",
    "meaning_core": "目に見える",
    "syllables": [
      {
        "text": "VIS",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "SEEABLE": "見える",
      "APPARENT": "明らかな",
      "CLEAR": "はっきりした"
    },
    "distractors": [
      "INVISIBLE",
      "HIDDEN",
      "OBSCURE",
      "UNSEEN"
    ],
    "meanings_expanded": [
      "目に見える",
      "明白な"
    ],
    "contexts": [
      {
        "parts": [
          "The stars are",
          "tonight."
        ],
        "full": "The stars are VISIBLE tonight.",
        "jp": "今夜は星が見える。",
        "is_correct": true
      },
      {
        "parts": [
          "The moon is clearly ",
          " tonight."
        ],
        "full": "The moon is clearly VISIBLE tonight.",
        "jp": "今夜は月がはっきり目に見える。",
        "is_correct": true
      },
      {
        "parts": [
          "There was no ",
          " damage."
        ],
        "full": "There was no VISIBLE damage.",
        "jp": "目に見える損傷はなかった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 662,
    "word": "VITAL",
    "meaning_core": "不可欠な",
    "syllables": [
      {
        "text": "VI",
        "type": "strong"
      },
      {
        "text": "tal",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ESSENTIAL": "不可欠な",
      "CRUCIAL": "極めて重要な",
      "IMPORTANT": "重要な"
    },
    "distractors": [
      "UNIMPORTANT",
      "TRIVIAL",
      "MINOR",
      "USELESS"
    ],
    "meanings_expanded": [
      "不可欠な",
      "生命の",
      "活気のある"
    ],
    "contexts": [
      {
        "parts": [
          "Water is",
          "for life."
        ],
        "full": "Water is VITAL for life.",
        "jp": "水は生命にとって不可欠だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Water is ",
          " for human survival."
        ],
        "full": "Water is VITAL for human survival.",
        "jp": "水は人間の生存に不可欠だ。",
        "is_correct": true
      },
      {
        "parts": [
          "We played a ",
          " role in the talks."
        ],
        "full": "We played a VITAL role in the talks.",
        "jp": "私たちは会談で極めて重要な役割を果たした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 663,
    "word": "VIVID",
    "meaning_core": "鮮やかな",
    "syllables": [
      {
        "text": "VIV",
        "type": "strong"
      },
      {
        "text": "id",
        "type": "weak"
      }
    ],
    "synonyms": {
      "BRIGHT": "明るい",
      "CLEAR": "鮮明な",
      "INTENSE": "強烈な"
    },
    "distractors": [
      "DULL",
      "PALE",
      "FADED",
      "VAGUE"
    ],
    "meanings_expanded": [
      "鮮やかな",
      "生き生きとした",
      "鮮明な"
    ],
    "contexts": [
      {
        "parts": [
          "I have",
          "memories of my childhood."
        ],
        "full": "I have VIVID memories of my childhood.",
        "jp": "私には子供の頃の鮮明な記憶がある。",
        "is_correct": true
      },
      {
        "parts": [
          "I have a ",
          " memory of that day."
        ],
        "full": "I have a VIVID memory of that day.",
        "jp": "私はその日の鮮やかな記憶を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "She gave a ",
          " description."
        ],
        "full": "She gave a VIVID description.",
        "jp": "彼女は鮮明な描写をした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 664,
    "word": "VOCATION",
    "meaning_core": "天職",
    "syllables": [
      {
        "text": "vo",
        "type": "weak"
      },
      {
        "text": "CA",
        "type": "strong"
      },
      {
        "text": "tion",
        "type": "weak"
      }
    ],
    "synonyms": {
      "CALLING": "天職",
      "CAREER": "経歴",
      "JOB": "仕事"
    },
    "distractors": [
      "HOBBY",
      "PASTIME",
      "VACATION",
      "LEISURE"
    ],
    "meanings_expanded": [
      "天職",
      "職業",
      "使命感"
    ],
    "contexts": [
      {
        "parts": [
          "Teaching is her",
          "."
        ],
        "full": "Teaching is her VOCATION.",
        "jp": "教えることは彼女の天職だ。",
        "is_correct": true
      },
      {
        "parts": [
          "Teaching is his true ",
          "."
        ],
        "full": "Teaching is his true VOCATION.",
        "jp": "教えることは彼の真の天職だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She found her ",
          "."
        ],
        "full": "She found her VOCATION.",
        "jp": "彼女は自分の天職を見つけた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 665,
    "word": "VOID",
    "meaning_core": "無効の",
    "syllables": [
      {
        "text": "VOID",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INVALID": "無効な",
      "EMPTY": "空の",
      "NULL": "無価値の"
    },
    "distractors": [
      "VALID",
      "FULL",
      "FILLED",
      "LEGAL"
    ],
    "meanings_expanded": [
      "無効の",
      "空の",
      "空間"
    ],
    "contexts": [
      {
        "parts": [
          "The contract is null and",
          "."
        ],
        "full": "The contract is null and VOID.",
        "jp": "その契約は無効だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The contract is null and ",
          "."
        ],
        "full": "The contract is null and VOID.",
        "jp": "その契約は無効である。",
        "is_correct": true
      },
      {
        "parts": [
          "He stared into the dark ",
          "."
        ],
        "full": "He stared into the dark VOID.",
        "jp": "彼は暗い空間（無効）をじっと見つめた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 666,
    "word": "VOLUNTARY",
    "meaning_core": "自発的な",
    "syllables": [
      {
        "text": "VOL",
        "type": "strong"
      },
      {
        "text": "un",
        "type": "weak"
      },
      {
        "text": "tar",
        "type": "weak"
      },
      {
        "text": "y",
        "type": "weak"
      }
    ],
    "synonyms": {
      "OPTIONAL": "任意の",
      "WILLING": "自ら進んでやる",
      "FREE": "自由な"
    },
    "distractors": [
      "COMPULSORY",
      "MANDATORY",
      "FORCED",
      "REQUIRED"
    ],
    "meanings_expanded": [
      "自発的な",
      "任意の",
      "ボランティアの"
    ],
    "contexts": [
      {
        "parts": [
          "Attendance is",
          "."
        ],
        "full": "Attendance is VOLUNTARY.",
        "jp": "出席は任意（自発的）だ。",
        "is_correct": true
      },
      {
        "parts": [
          "The action was entirely ",
          "."
        ],
        "full": "The action was entirely VOLUNTARY.",
        "jp": "その行動は完全に自発的だった。",
        "is_correct": true
      },
      {
        "parts": [
          "They offered ",
          " service."
        ],
        "full": "They offered VOLUNTARY service.",
        "jp": "彼らは自発的な奉仕を提供した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 667,
    "word": "VULNERABILITY",
    "meaning_core": "脆弱性",
    "syllables": [
      {
        "text": "vul",
        "type": "weak"
      },
      {
        "text": "ner",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "BIL",
        "type": "strong"
      },
      {
        "text": "i",
        "type": "weak"
      },
      {
        "text": "ty",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WEAKNESS": "弱点",
      "FRAGILITY": "もろさ",
      "SUSCEPTIBILITY": "感受性"
    },
    "distractors": [
      "STRENGTH",
      "SECURITY",
      "SAFETY",
      "RESILIENCE"
    ],
    "meanings_expanded": [
      "脆弱性",
      "傷つきやすさ",
      "弱点"
    ],
    "contexts": [
      {
        "parts": [
          "The system has a security",
          "."
        ],
        "full": "The system has a security VULNERABILITY.",
        "jp": "そのシステムにはセキュリティ上の脆弱性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "The system has a critical ",
          "."
        ],
        "full": "The system has a critical VULNERABILITY.",
        "jp": "そのシステムには致命的な脆弱性がある。",
        "is_correct": true
      },
      {
        "parts": [
          "She shared her feelings of ",
          "."
        ],
        "full": "She shared her feelings of VULNERABILITY.",
        "jp": "彼女は自分の脆弱性の感情を共有した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 668,
    "word": "VULNERABLE",
    "meaning_core": "傷つきやすい",
    "syllables": [
      {
        "text": "VUL",
        "type": "strong"
      },
      {
        "text": "ner",
        "type": "weak"
      },
      {
        "text": "a",
        "type": "weak"
      },
      {
        "text": "ble",
        "type": "weak"
      }
    ],
    "synonyms": {
      "WEAK": "弱い",
      "DEFENSELESS": "無防備な",
      "SUSCEPTIBLE": "影響を受けやすい"
    },
    "distractors": [
      "STRONG",
      "SAFE",
      "SECURE",
      "PROTECTED"
    ],
    "meanings_expanded": [
      "傷つきやすい",
      "攻撃されやすい",
      "弱い"
    ],
    "contexts": [
      {
        "parts": [
          "Children are",
          "to infection."
        ],
        "full": "Children are VULNERABLE to infection.",
        "jp": "子供は感染症にかかりやすい（脆弱だ）。",
        "is_correct": true
      },
      {
        "parts": [
          "Children are ",
          " to illness."
        ],
        "full": "Children are VULNERABLE to illness.",
        "jp": "子供は病気にかかりやすい（傷つきやすい）。",
        "is_correct": true
      },
      {
        "parts": [
          "The fortress was surprisingly ",
          "."
        ],
        "full": "The fortress was surprisingly VULNERABLE.",
        "jp": "その要塞は驚くほど脆弱だった。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 669,
    "word": "WARRANT",
    "meaning_core": "令状",
    "syllables": [
      {
        "text": "WAR",
        "type": "strong"
      },
      {
        "text": "rant",
        "type": "weak"
      }
    ],
    "synonyms": {
      "AUTHORIZATION": "認可",
      "PERMIT": "許可証",
      "LICENSE": "免許"
    },
    "distractors": [
      "DENIAL",
      "REFUSAL",
      "BAN",
      "PROHIBITION"
    ],
    "meanings_expanded": [
      "令状",
      "正当な理由",
      "保証する（動詞）"
    ],
    "contexts": [
      {
        "parts": [
          "The police have a search",
          "."
        ],
        "full": "The police have a search WARRANT.",
        "jp": "警察は捜索令状を持っている。",
        "is_correct": true
      },
      {
        "parts": [
          "The police obtained a search ",
          "."
        ],
        "full": "The police obtained a search WARRANT.",
        "jp": "警察は捜索令状を取得した。",
        "is_correct": true
      },
      {
        "parts": [
          "Do his actions ",
          " an arrest?"
        ],
        "full": "Do his actions WARRANT an arrest?",
        "jp": "彼の行動は逮捕を正当化する（令状を保証する）か。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 670,
    "word": "WEALTHY",
    "meaning_core": "裕福な",
    "syllables": [
      {
        "text": "WEAL",
        "type": "strong"
      },
      {
        "text": "thy",
        "type": "weak"
      }
    ],
    "synonyms": {
      "RICH": "金持ちの",
      "AFFLUENT": "裕福な",
      "PROSPEROUS": "繁栄している"
    },
    "distractors": [
      "POOR",
      "NEEDY",
      "BROKE",
      "DESTITUTE"
    ],
    "meanings_expanded": [
      "裕福な",
      "豊富な"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "businessman."
        ],
        "full": "He is a WEALTHY businessman.",
        "jp": "彼は裕福な実業家だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a very ",
          " man."
        ],
        "full": "He is a very WEALTHY man.",
        "jp": "彼は非常に裕福な男性だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She married into a ",
          " family."
        ],
        "full": "She married into a WEALTHY family.",
        "jp": "彼女は裕福な家庭に嫁いだ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 671,
    "word": "WEARY",
    "meaning_core": "疲れた",
    "syllables": [
      {
        "text": "WEA",
        "type": "strong"
      },
      {
        "text": "ry",
        "type": "weak"
      }
    ],
    "synonyms": {
      "TIRED": "疲れた",
      "EXHAUSTED": "疲れ切った",
      "FATIGUED": "疲労した"
    },
    "distractors": [
      "ENERGETIC",
      "FRESH",
      "ACTIVE",
      "LIVELY"
    ],
    "meanings_expanded": [
      "疲れた",
      "飽き飽きした"
    ],
    "contexts": [
      {
        "parts": [
          "I am",
          "after a long day."
        ],
        "full": "I am WEARY after a long day.",
        "jp": "長い一日を終えて私は疲れている。",
        "is_correct": true
      },
      {
        "parts": [
          "I feel ",
          " after the long trip."
        ],
        "full": "I feel WEARY after the long trip.",
        "jp": "長旅の後で疲れたと感じる。",
        "is_correct": true
      },
      {
        "parts": [
          "She grew ",
          " of the constant fighting."
        ],
        "full": "She grew WEARY of the constant fighting.",
        "jp": "彼女は絶え間ない争いにうんざりした。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 672,
    "word": "WHEREAS",
    "meaning_core": "～である一方",
    "syllables": [
      {
        "text": "where",
        "type": "weak"
      },
      {
        "text": "AS",
        "type": "strong"
      }
    ],
    "synonyms": {
      "WHILE": "～の一方で",
      "ALTHOUGH": "～だけれども"
    },
    "distractors": [
      "BECAUSE",
      "SINCE",
      "THEREFORE",
      "SO"
    ],
    "meanings_expanded": [
      "～である一方",
      "ところが"
    ],
    "contexts": [
      {
        "parts": [
          "He likes coffee,",
          "I like tea."
        ],
        "full": "He likes coffee, WHEREAS I like tea.",
        "jp": "彼はコーヒーが好きだが、私はお茶が好きだ。",
        "is_correct": true
      },
      {
        "parts": [
          "I like tea, ",
          " he prefers coffee."
        ],
        "full": "I like tea, WHEREAS he prefers coffee.",
        "jp": "私はお茶が好きである一方、彼はコーヒーを好む。",
        "is_correct": true
      },
      {
        "parts": [
          "He is rich, ",
          " I am poor."
        ],
        "full": "He is rich, WHEREAS I am poor.",
        "jp": "彼は裕福である一方、私は貧しい。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 673,
    "word": "WILLING",
    "meaning_core": "～するのをいとわない",
    "syllables": [
      {
        "text": "WIL",
        "type": "strong"
      },
      {
        "text": "ling",
        "type": "weak"
      }
    ],
    "synonyms": {
      "READY": "準備ができている",
      "EAGER": "熱望している",
      "PREPARED": "覚悟ができている"
    },
    "distractors": [
      "UNWILLING",
      "RELUCTANT",
      "REFUSING",
      "HESITANT"
    ],
    "meanings_expanded": [
      "～するのをいとわない",
      "自発的な"
    ],
    "contexts": [
      {
        "parts": [
          "I am",
          "to help you."
        ],
        "full": "I am WILLING to help you.",
        "jp": "喜んであなたを助けます（助けるのをいとわない）。",
        "is_correct": true
      },
      {
        "parts": [
          "I am ",
          " to help."
        ],
        "full": "I am WILLING to help.",
        "jp": "私は喜んで（いとわないで）手伝う。",
        "is_correct": true
      },
      {
        "parts": [
          "Are you ",
          " to take the risk?"
        ],
        "full": "Are you WILLING to take the risk?",
        "jp": "あなたはリスクを負うことをいとわないですか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 674,
    "word": "WITHDRAW",
    "meaning_core": "引き出す",
    "syllables": [
      {
        "text": "with",
        "type": "weak"
      },
      {
        "text": "DRAW",
        "type": "strong"
      }
    ],
    "synonyms": {
      "REMOVE": "取り除く",
      "RETREAT": "撤退する",
      "EXTRACT": "引き抜く"
    },
    "distractors": [
      "DEPOSIT",
      "INSERT",
      "ENTER",
      "ADVANCE"
    ],
    "meanings_expanded": [
      "引き出す",
      "撤退する",
      "取り下げる"
    ],
    "contexts": [
      {
        "parts": [
          "I need to",
          "money from the bank."
        ],
        "full": "I need to WITHDRAW money from the bank.",
        "jp": "私は銀行からお金を引き出す必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "I need to ",
          " cash from the bank."
        ],
        "full": "I need to WITHDRAW cash from the bank.",
        "jp": "私は銀行から現金を下ろす必要がある。",
        "is_correct": true
      },
      {
        "parts": [
          "They decided to ",
          " the troops."
        ],
        "full": "They decided to WITHDRAW the troops.",
        "jp": "彼らは軍隊を撤退させることを決定した。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 675,
    "word": "WITHER",
    "meaning_core": "しぼむ",
    "syllables": [
      {
        "text": "WITH",
        "type": "strong"
      },
      {
        "text": "er",
        "type": "weak"
      }
    ],
    "synonyms": {
      "FADE": "あせる",
      "DRY UP": "干からびる",
      "DECAY": "衰える"
    },
    "distractors": [
      "BLOOM",
      "FLOURISH",
      "GROW",
      "THRIVE"
    ],
    "meanings_expanded": [
      "しぼむ",
      "枯れる",
      "衰える"
    ],
    "contexts": [
      {
        "parts": [
          "The flowers began to",
          "."
        ],
        "full": "The flowers began to WITHER.",
        "jp": "花がしぼみ始めた。",
        "is_correct": true
      },
      {
        "parts": [
          "The flowers will ",
          " in the heat."
        ],
        "full": "The flowers will WITHER in the heat.",
        "jp": "その花は暑さでしぼむだろう。",
        "is_correct": true
      },
      {
        "parts": [
          "His enthusiasm began to ",
          "."
        ],
        "full": "His enthusiasm began to WITHER.",
        "jp": "彼の熱意は衰え始めた。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 676,
    "word": "WITHIN",
    "meaning_core": "～以内に",
    "syllables": [
      {
        "text": "with",
        "type": "weak"
      },
      {
        "text": "IN",
        "type": "strong"
      }
    ],
    "synonyms": {
      "INSIDE": "内側に",
      "IN": "中に"
    },
    "distractors": [
      "OUTSIDE",
      "BEYOND",
      "WITHOUT"
    ],
    "meanings_expanded": [
      "～以内に",
      "～の範囲内で"
    ],
    "contexts": [
      {
        "parts": [
          "Please finish",
          "an hour."
        ],
        "full": "Please finish WITHIN an hour.",
        "jp": "1時間以内に終わらせてください。",
        "is_correct": true
      },
      {
        "parts": [
          "Please reply ",
          " ten days."
        ],
        "full": "Please reply WITHIN ten days.",
        "jp": "10日以内に返信してください。",
        "is_correct": true
      },
      {
        "parts": [
          "The answer is ",
          " the book."
        ],
        "full": "The answer is WITHIN the book.",
        "jp": "答えはその本の中にある。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 677,
    "word": "WORTH",
    "meaning_core": "価値がある",
    "syllables": [
      {
        "text": "WORTH",
        "type": "strong"
      }
    ],
    "synonyms": {
      "VALUE": "価値",
      "MERIT": "長所"
    },
    "distractors": [
      "WORTHLESS",
      "USELESS",
      "WASTE"
    ],
    "meanings_expanded": [
      "～の価値がある",
      "価値"
    ],
    "contexts": [
      {
        "parts": [
          "This book is",
          "reading."
        ],
        "full": "This book is WORTH reading.",
        "jp": "この本は読む価値がある。",
        "is_correct": true
      },
      {
        "parts": [
          "It is",
          "trying."
        ],
        "full": "It is WORTH trying.",
        "jp": "試してみる価値はある。",
        "is_correct": true
      },
      {
        "parts": [
          "The painting is ",
          " millions."
        ],
        "full": "The painting is WORTH millions.",
        "jp": "その絵画は何百万ドルの価値がある。",
        "is_correct": true
      },
      {
        "parts": [
          "Is the effort really ",
          " it?"
        ],
        "full": "Is the effort really WORTH it?",
        "jp": "その努力は本当にそれに値するのか。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 678,
    "word": "YIELD",
    "meaning_core": "収穫",
    "syllables": [
      {
        "text": "YIELD",
        "type": "strong"
      }
    ],
    "synonyms": {
      "PRODUCE": "産出する",
      "HARVEST": "収穫",
      "SURRENDER": "降伏する"
    },
    "distractors": [
      "KEEP",
      "RETAIN",
      "HOLD",
      "RESIST"
    ],
    "meanings_expanded": [
      "収穫",
      "産出する",
      "屈する"
    ],
    "contexts": [
      {
        "parts": [
          "The farm has a high",
          "."
        ],
        "full": "The farm has a high YIELD.",
        "jp": "その農場は収穫量が多い。",
        "is_correct": true
      },
      {
        "parts": [
          "He refused to",
          "."
        ],
        "full": "He refused to YIELD.",
        "jp": "彼は屈することを拒んだ。",
        "is_correct": true
      },
      {
        "parts": [
          "The farmers had a good crop ",
          "."
        ],
        "full": "The farmers had a good crop YIELD.",
        "jp": "農家は良い収穫高を得た。",
        "is_correct": true
      },
      {
        "parts": [
          "The soil will ",
          " a poor harvest."
        ],
        "full": "The soil will YIELD a poor harvest.",
        "jp": "その土壌は貧しい収穫をもたらすだろう。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 679,
    "word": "ZEALOUS",
    "meaning_core": "熱心な",
    "syllables": [
      {
        "text": "ZEAL",
        "type": "strong"
      },
      {
        "text": "ous",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENTHUSIASTIC": "熱狂的な",
      "EAGER": "熱望している",
      "PASSIONATE": "情熱的な"
    },
    "distractors": [
      "APATHETIC",
      "INDIFFERENT",
      "BORED",
      "LAZY"
    ],
    "meanings_expanded": [
      "熱心な",
      "熱狂的な"
    ],
    "contexts": [
      {
        "parts": [
          "He is a",
          "supporter."
        ],
        "full": "He is a ZEALOUS supporter.",
        "jp": "彼は熱心な支持者だ。",
        "is_correct": true
      },
      {
        "parts": [
          "He is a ",
          " supporter of the team."
        ],
        "full": "He is a ZEALOUS supporter of the team.",
        "jp": "彼はそのチームの熱心な支持者だ。",
        "is_correct": true
      },
      {
        "parts": [
          "She is a ",
          " advocate for peace."
        ],
        "full": "She is a ZEALOUS advocate for peace.",
        "jp": "彼女は平和のための熱心な主唱者だ。",
        "is_correct": true
      }
    ]
  },
  {
    "id": 680,
    "word": "ZEALOUSLY",
    "meaning_core": "熱心に",
    "syllables": [
      {
        "text": "ZEAL",
        "type": "strong"
      },
      {
        "text": "ous",
        "type": "weak"
      },
      {
        "text": "ly",
        "type": "weak"
      }
    ],
    "synonyms": {
      "ENTHUSIASTICALLY": "熱狂的に",
      "EAGERLY": "熱心に"
    },
    "distractors": [
      "APATHETICALLY",
      "INDIFFERENTLY",
      "LAZILY"
    ],
    "meanings_expanded": [
      "熱心に",
      "熱狂的に"
    ],
    "contexts": [
      {
        "parts": [
          "They worked",
          "to finish the project."
        ],
        "full": "They worked ZEALOUSLY to finish the project.",
        "jp": "彼らはプロジェクトを終わらせるために熱心に働いた。",
        "is_correct": true
      },
      {
        "parts": [
          "He worked ",
          " to achieve the goal."
        ],
        "full": "He worked ZEALOUSLY to achieve the goal.",
        "jp": "彼は目標を達成するために熱心に働いた。",
        "is_correct": true
      },
      {
        "parts": [
          "She guarded her privacy ",
          "."
        ],
        "full": "She guarded her privacy ZEALOUSLY.",
        "jp": "彼女は自分のプライバシーを熱心に守った。",
        "is_correct": true
      }
    ]
  }
  ,
  {
    "id": 8,
    "word": "ACHIEVE",
    "meaning_core": "達成する",
    "syllables": [
      { "text": "a", "type": "weak" },
      { "text": "CHIEVE", "type": "strong" }
    ],
    "synonyms": {
      "ACCOMPLISH": "成し遂げる",
      "ATTAIN": "到達する",
      "REACH": "達する"
    },
    "distractors": [ "FAIL", "LOSE", "MISS", "GIVE UP" ],
    "meanings_expanded": [ "達成する", "成し遂げる", "獲得する" ],
    "contexts": [
      { "parts": [ "We will ", " our goals." ], "full": "We will ACHIEVE our goals.", "jp": "私たちは目標を達成するだろう。", "is_correct": true },
      { "parts": [ "Hard work helps you ", " success." ], "full": "Hard work helps you ACHIEVE success.", "jp": "勤勉は成功を達成するのに役立つ。", "is_correct": true },
      { "parts": [ "She managed to ", " a high score." ], "full": "She managed to ACHIEVE a high score.", "jp": "彼女は高得点を達成することができた。", "is_correct": true }
    ]
  },
  {
    "id": 50,
    "word": "ARTICULATE",
    "meaning_core": "はっきりと述べる",
    "syllables": [
      { "text": "ar", "type": "weak" },
      { "text": "TIC", "type": "strong" },
      { "text": "u", "type": "weak" },
      { "text": "late", "type": "weak" }
    ],
    "synonyms": {
      "EXPRESS": "表現する",
      "STATE": "述べる",
      "VOICE": "声に出す"
    },
    "distractors": [ "MUMBLE", "MUTE", "HIDE", "SILENCE" ],
    "meanings_expanded": [ "はっきりと述べる", "明瞭に表現する", "理路整然とした" ],
    "contexts": [
      { "parts": [ "He could not ", " his thoughts." ], "full": "He could not ARTICULATE his thoughts.", "jp": "彼は自分の考えをはっきりと述べられなかった。", "is_correct": true },
      { "parts": [ "She is highly ", "." ], "full": "She is highly ARTICULATE.", "jp": "彼女は非常に理路整然としている。", "is_correct": true },
      { "parts": [ "Please ", " your plan clearly." ], "full": "Please ARTICULATE your plan clearly.", "jp": "あなたの計画をはっきりと説明してください。", "is_correct": true }
    ]
  },
  {
    "id": 197,
    "word": "DURATION",
    "meaning_core": "継続期間",
    "syllables": [
      { "text": "du", "type": "weak" },
      { "text": "RA", "type": "strong" },
      { "text": "tion", "type": "weak" }
    ],
    "synonyms": {
      "PERIOD": "期間",
      "LENGTH": "長さ",
      "TERM": "期間"
    },
    "distractors": [ "MOMENT", "INSTANT", "END", "FLASH" ],
    "meanings_expanded": [ "継続期間", "持続" ],
    "contexts": [
      { "parts": [ "The ", " of the flight is ten hours." ], "full": "The DURATION of the flight is ten hours.", "jp": "フライトの所要時間は10時間だ。", "is_correct": true },
      { "parts": [ "He stayed for the ", " of the war." ], "full": "He stayed for the DURATION of the war.", "jp": "彼は戦争の期間中ずっととどまった。", "is_correct": true },
      { "parts": [ "Increase the ", " of the exercise." ], "full": "Increase the DURATION of the exercise.", "jp": "運動の継続時間を増やしなさい。", "is_correct": true }
    ]
  },
  {
    "id": 202,
    "word": "EFFORT",
    "meaning_core": "努力",
    "syllables": [
      { "text": "EF", "type": "strong" },
      { "text": "fort", "type": "weak" }
    ],
    "synonyms": {
      "ATTEMPT": "試み",
      "STRUGGLE": "奮闘",
      "WORK": "労働"
    },
    "distractors": [ "LAZINESS", "EASE", "REST", "IDLENESS" ],
    "meanings_expanded": [ "努力", "奮闘", "取り組み" ],
    "contexts": [
      { "parts": [ "It takes a lot of ", "." ], "full": "It takes a lot of EFFORT.", "jp": "それは多大な努力を要する。", "is_correct": true },
      { "parts": [ "We made every ", " to win." ], "full": "We made every EFFORT to win.", "jp": "私たちは勝つためにあらゆる努力をした。", "is_correct": true },
      { "parts": [ "His ", " was rewarded." ], "full": "His EFFORT was rewarded.", "jp": "彼の努力は報われた。", "is_correct": true }
    ]
  },
  {
    "id": 233,
    "word": "EVENTUAL",
    "meaning_core": "最終的な",
    "syllables": [
      { "text": "e", "type": "weak" },
      { "text": "VEN", "type": "strong" },
      { "text": "tu", "type": "weak" },
      { "text": "al", "type": "weak" }
    ],
    "synonyms": {
      "FINAL": "最後の",
      "ULTIMATE": "究極の",
      "CONCLUDING": "結びの"
    },
    "distractors": [ "INITIAL", "FIRST", "BEGINNING", "STARTING" ],
    "meanings_expanded": [ "最終的な", "結果として起こる" ],
    "contexts": [
      { "parts": [ "His ", " success was guaranteed." ], "full": "His EVENTUAL success was guaranteed.", "jp": "彼の最終的な成功は保証されていた。", "is_correct": true },
      { "parts": [ "We awaited the ", " outcome." ], "full": "We awaited the EVENTUAL outcome.", "jp": "私たちは最終的な結果を待った。", "is_correct": true },
      { "parts": [ "The ", " cost was very high." ], "full": "The EVENTUAL cost was very high.", "jp": "最終的な費用は非常に高かった。", "is_correct": true }
    ]
  },
  {
    "id": 234,
    "word": "EXAMINE",
    "meaning_core": "調査する",
    "syllables": [
      { "text": "ex", "type": "weak" },
      { "text": "AM", "type": "strong" },
      { "text": "ine", "type": "weak" }
    ],
    "synonyms": {
      "INSPECT": "検査する",
      "ANALYZE": "分析する",
      "INVESTIGATE": "捜査する"
    },
    "distractors": [ "IGNORE", "OVERLOOK", "NEGLECT", "MISS" ],
    "meanings_expanded": [ "調査する", "検査する", "審査する" ],
    "contexts": [
      { "parts": [ "The doctor will ", " the patient." ], "full": "The doctor will EXAMINE the patient.", "jp": "医者は患者を診察するだろう。", "is_correct": true },
      { "parts": [ "We need to ", " the evidence." ], "full": "We need to EXAMINE the evidence.", "jp": "私たちは証拠を調査する必要がある。", "is_correct": true },
      { "parts": [ "Carefully ", " the document." ], "full": "Carefully EXAMINE the document.", "jp": "その文書を注意深く調べなさい。", "is_correct": true }
    ]
  },
  {
    "id": 316,
    "word": "IMPROVE",
    "meaning_core": "改善する",
    "syllables": [
      { "text": "im", "type": "weak" },
      { "text": "PROVE", "type": "strong" }
    ],
    "synonyms": {
      "BETTER": "より良くする",
      "UPGRADE": "向上させる",
      "ENHANCE": "高める"
    },
    "distractors": [ "WORSEN", "DAMAGE", "RUIN", "DECREASE" ],
    "meanings_expanded": [ "改善する", "向上させる", "良くなる" ],
    "contexts": [
      { "parts": [ "I want to ", " my English." ], "full": "I want to IMPROVE my English.", "jp": "私は英語を上達させたい。", "is_correct": true },
      { "parts": [ "The weather will ", " tomorrow." ], "full": "The weather will IMPROVE tomorrow.", "jp": "明日は天気が回復するだろう。", "is_correct": true },
      { "parts": [ "We must ", " our services." ], "full": "We must IMPROVE our services.", "jp": "私たちはサービスを改善しなければならない。", "is_correct": true }
    ]
  },
  {
    "id": 317,
    "word": "INADEQUATE",
    "meaning_core": "不十分な",
    "syllables": [
      { "text": "in", "type": "weak" },
      { "text": "AD", "type": "strong" },
      { "text": "e", "type": "weak" },
      { "text": "quate", "type": "weak" }
    ],
    "synonyms": {
      "INSUFFICIENT": "足りない",
      "DEFICIENT": "欠陥のある",
      "POOR": "貧弱な"
    },
    "distractors": [ "ADEQUATE", "SUFFICIENT", "ENOUGH", "AMPLE" ],
    "meanings_expanded": [ "不十分な", "不適切な", "力不足の" ],
    "contexts": [
      { "parts": [ "The food supply was ", "." ], "full": "The food supply was INADEQUATE.", "jp": "食糧供給は不十分だった。", "is_correct": true },
      { "parts": [ "He felt ", " for the task." ], "full": "He felt INADEQUATE for the task.", "jp": "彼はその仕事には力不足だと感じた。", "is_correct": true },
      { "parts": [ "Their response was totally ", "." ], "full": "Their response was totally INADEQUATE.", "jp": "彼らの対応は全く不十分だった。", "is_correct": true }
    ]
  },
  {
    "id": 318,
    "word": "INCIDENT",
    "meaning_core": "出来事",
    "syllables": [
      { "text": "IN", "type": "strong" },
      { "text": "ci", "type": "weak" },
      { "text": "dent", "type": "weak" }
    ],
    "synonyms": {
      "EVENT": "事象",
      "OCCURRENCE": "発生",
      "EPISODE": "エピソード"
    },
    "distractors": [ "PLAN", "INTENTION", "NOTHING", "STILLNESS" ],
    "meanings_expanded": [ "出来事", "事件", "紛争" ],
    "contexts": [
      { "parts": [ "The ", " happened yesterday." ], "full": "The INCIDENT happened yesterday.", "jp": "その事件は昨日起こった。", "is_correct": true },
      { "parts": [ "Police are investigating the ", "." ], "full": "Police are investigating the INCIDENT.", "jp": "警察はその事件を捜査している。", "is_correct": true },
      { "parts": [ "It was a minor ", "." ], "full": "It was a minor INCIDENT.", "jp": "それは些細な出来事だった。", "is_correct": true }
    ]
  },
  {
    "id": 319,
    "word": "INCLINE",
    "meaning_core": "傾く",
    "syllables": [
      { "text": "in", "type": "weak" },
      { "text": "CLINE", "type": "strong" }
    ],
    "synonyms": {
      "LEAN": "傾斜する",
      "TEND": "傾向がある",
      "SLOPE": "傾斜"
    },
    "distractors": [ "STRAIGHTEN", "FLATTEN", "LEVEL", "STAND" ],
    "meanings_expanded": [ "傾く", "～したい気持ちにさせる", "傾向がある" ],
    "contexts": [
      { "parts": [ "I ", " to agree with you." ], "full": "I INCLINE to agree with you.", "jp": "私はあなたに同意したい気がする。", "is_correct": true },
      { "parts": [ "The road begins to ", " here." ], "full": "The road begins to INCLINE here.", "jp": "道はここから傾斜し始める。", "is_correct": true },
      { "parts": [ "He is ", "d to be lazy." ], "full": "He is INCLINEd to be lazy.", "jp": "彼は怠けがちだ。", "is_correct": true }
    ]
  },
  {
    "id": 320,
    "word": "INCLUSIVE",
    "meaning_core": "包括的な",
    "syllables": [
      { "text": "in", "type": "weak" },
      { "text": "CLU", "type": "strong" },
      { "text": "sive", "type": "weak" }
    ],
    "synonyms": {
      "COMPREHENSIVE": "総合的な",
      "ALL-EMBRACING": "すべてを含む",
      "BROAD": "広い"
    },
    "distractors": [ "EXCLUSIVE", "LIMITED", "NARROW", "RESTRICTED" ],
    "meanings_expanded": [ "包括的な", "すべてを含んだ" ],
    "contexts": [
      { "parts": [ "The price is fully ", "." ], "full": "The price is fully INCLUSIVE.", "jp": "その価格はすべて込みです。", "is_correct": true },
      { "parts": [ "We aim for an ", " society." ], "full": "We aim for an INCLUSIVE society.", "jp": "私たちは包摂的な社会を目指している。", "is_correct": true },
      { "parts": [ "From Monday to Friday ", "." ], "full": "From Monday to Friday INCLUSIVE.", "jp": "月曜から金曜まで（両日を含む）。", "is_correct": true }
    ]
  },
  {
    "id": 321,
    "word": "INDICATE",
    "meaning_core": "示す",
    "syllables": [
      { "text": "IN", "type": "strong" },
      { "text": "di", "type": "weak" },
      { "text": "cate", "type": "weak" }
    ],
    "synonyms": {
      "SHOW": "見せる",
      "POINT OUT": "指摘する",
      "SUGGEST": "示唆する"
    },
    "distractors": [ "HIDE", "CONCEAL", "DENY", "IGNORE" ],
    "meanings_expanded": [ "示す", "指摘する", "ほのめかす" ],
    "contexts": [
      { "parts": [ "The map will ", " the route." ], "full": "The map will INDICATE the route.", "jp": "地図がルートを示すだろう。", "is_correct": true },
      { "parts": [ "His silence ", "s agreement." ], "full": "His silence INDICATEs agreement.", "jp": "彼の沈黙は同意を示している。", "is_correct": true },
      { "parts": [ "Please ", " your choice." ], "full": "Please INDICATE your choice.", "jp": "あなたの選択を示してください。", "is_correct": true }
    ]
  },
  {
    "id": 322,
    "word": "INFER",
    "meaning_core": "推論する",
    "syllables": [
      { "text": "in", "type": "weak" },
      { "text": "FER", "type": "strong" }
    ],
    "synonyms": {
      "DEDUCE": "演繹する",
      "CONCLUDE": "結論づける",
      "GUESS": "推測する"
    },
    "distractors": [ "STATE", "DECLARE", "PROVE", "EXPRESS" ],
    "meanings_expanded": [ "推論する", "察する", "暗示する" ],
    "contexts": [
      { "parts": [ "What can we ", " from this?" ], "full": "What can we INFER from this?", "jp": "これから何を推論できますか。", "is_correct": true },
      { "parts": [ "I ", " that you are busy." ], "full": "I INFER that you are busy.", "jp": "あなたが忙しいとお察しします。", "is_correct": true },
      { "parts": [ "Readers can ", " the meaning." ], "full": "Readers can INFER the meaning.", "jp": "読者はその意味を推測できる。", "is_correct": true }
    ]
  },
  {
    "id": 392,
    "word": "NEUTRAL",
    "meaning_core": "中立の",
    "syllables": [
      { "text": "NEU", "type": "strong" },
      { "text": "tral", "type": "weak" }
    ],
    "synonyms": {
      "IMPARTIAL": "公平な",
      "UNBIASED": "偏見のない",
      "OBJECTIVE": "客観的な"
    },
    "distractors": [ "BIASED", "PARTIAL", "PREJUDICED", "INVOLVED" ],
    "meanings_expanded": [ "中立の", "公平な", "はっきりしない" ],
    "contexts": [
      { "parts": [ "Switzerland remained ", "." ], "full": "Switzerland remained NEUTRAL.", "jp": "スイスは中立を保った。", "is_correct": true },
      { "parts": [ "He took a ", " position." ], "full": "He took a NEUTRAL position.", "jp": "彼は中立的な立場をとった。", "is_correct": true },
      { "parts": [ "The color is very ", "." ], "full": "The color is very NEUTRAL.", "jp": "その色はとても中間的だ。", "is_correct": true }
    ]
  },
  {
    "id": 397,
    "word": "NOTABLE",
    "meaning_core": "注目すべき",
    "syllables": [
      { "text": "NO", "type": "strong" },
      { "text": "ta", "type": "weak" },
      { "text": "ble", "type": "weak" }
    ],
    "synonyms": {
      "REMARKABLE": "驚くべき",
      "OUTSTANDING": "傑出した",
      "SIGNIFICANT": "重要な"
    },
    "distractors": [ "ORDINARY", "COMMON", "NORMAL", "UNKNOWN" ],
    "meanings_expanded": [ "注目すべき", "有名な", "著名人" ],
    "contexts": [
      { "parts": [ "It was a ", " achievement." ], "full": "It was a NOTABLE achievement.", "jp": "それは注目すべき業績だった。", "is_correct": true },
      { "parts": [ "He is a ", " scientist." ], "full": "He is a NOTABLE scientist.", "jp": "彼は著名な科学者だ。", "is_correct": true },
      { "parts": [ "There is a ", " difference." ], "full": "There is a NOTABLE difference.", "jp": "顕著な違いがある。", "is_correct": true }
    ]
  },
  {
    "id": 411,
    "word": "OMIT",
    "meaning_core": "省略する",
    "syllables": [
      { "text": "o", "type": "weak" },
      { "text": "MIT", "type": "strong" }
    ],
    "synonyms": {
      "LEAVE OUT": "省く",
      "EXCLUDE": "除外する",
      "SKIP": "飛ばす"
    },
    "distractors": [ "INCLUDE", "ADD", "INSERT", "RETAIN" ],
    "meanings_expanded": [ "省略する", "除外する", "～し忘れる" ],
    "contexts": [
      { "parts": [ "Please ", " this paragraph." ], "full": "Please OMIT this paragraph.", "jp": "この段落は省略してください。", "is_correct": true },
      { "parts": [ "He ", "ted my name from the list." ], "full": "He OMITted my name from the list.", "jp": "彼はリストから私の名前を省いた。", "is_correct": true },
      { "parts": [ "Do not ", " any details." ], "full": "Do not OMIT any details.", "jp": "詳細を一切省かないでください。", "is_correct": true }
    ]
  },
  {
    "id": 412,
    "word": "ONGOING",
    "meaning_core": "進行中の",
    "syllables": [
      { "text": "ON", "type": "strong" },
      { "text": "go", "type": "weak" },
      { "text": "ing", "type": "weak" }
    ],
    "synonyms": {
      "CONTINUING": "続いている",
      "IN PROGRESS": "進行中で",
      "CURRENT": "現在の"
    },
    "distractors": [ "FINISHED", "COMPLETED", "ENDED", "PAST" ],
    "meanings_expanded": [ "進行中の", "継続している" ],
    "contexts": [
      { "parts": [ "It is an ", " project." ], "full": "It is an ONGOING project.", "jp": "それは進行中のプロジェクトだ。", "is_correct": true },
      { "parts": [ "The investigation is ", "." ], "full": "The investigation is ONGOING.", "jp": "捜査は進行中だ。", "is_correct": true },
      { "parts": [ "We have an ", " relationship." ], "full": "We have an ONGOING relationship.", "jp": "私たちは継続的な関係を持っている。", "is_correct": true }
    ]
  },
  {
    "id": 418,
    "word": "OUTCOME",
    "meaning_core": "結果",
    "syllables": [
      { "text": "OUT", "type": "strong" },
      { "text": "come", "type": "weak" }
    ],
    "synonyms": {
      "RESULT": "結果",
      "CONSEQUENCE": "結末",
      "EFFECT": "影響"
    },
    "distractors": [ "CAUSE", "ORIGIN", "START", "SOURCE" ],
    "meanings_expanded": [ "結果", "成果", "結末" ],
    "contexts": [
      { "parts": [ "What was the ", " of the meeting?" ], "full": "What was the OUTCOME of the meeting?", "jp": "会議の結果はどうでしたか。", "is_correct": true },
      { "parts": [ "We await the final ", "." ], "full": "We await the final OUTCOME.", "jp": "私たちは最終結果を待っている。", "is_correct": true },
      { "parts": [ "The ", " was highly successful." ], "full": "The OUTCOME was highly successful.", "jp": "その結果は非常に成功したものだった。", "is_correct": true }
    ]
  },
  {
    "id": 483,
    "word": "PROVINCE",
    "meaning_core": "州",
    "syllables": [
      { "text": "PROV", "type": "strong" },
      { "text": "ince", "type": "weak" }
    ],
    "synonyms": {
      "REGION": "地域",
      "TERRITORY": "領土",
      "AREA": "領域"
    },
    "distractors": [ "CITY", "CAPITAL", "CENTER", "METROPOLIS" ],
    "meanings_expanded": [ "（カナダなどの）州", "地方", "分野" ],
    "contexts": [
      { "parts": [ "Quebec is a Canadian ", "." ], "full": "Quebec is a Canadian PROVINCE.", "jp": "ケベックはカナダの州だ。", "is_correct": true },
      { "parts": [ "He grew up in the ", "s." ], "full": "He grew up in the PROVINCEs.", "jp": "彼は地方で育った。", "is_correct": true },
      { "parts": [ "That is outside my ", "." ], "full": "That is outside my PROVINCE.", "jp": "それは私の専門分野外だ。", "is_correct": true }
    ]
  },
  {
    "id": 499,
    "word": "REGIME",
    "meaning_core": "政権",
    "syllables": [
      { "text": "re", "type": "weak" },
      { "text": "GIME", "type": "strong" }
    ],
    "synonyms": {
      "GOVERNMENT": "政府",
      "RULE": "支配",
      "SYSTEM": "体制"
    },
    "distractors": [ "ANARCHY", "CHAOS", "CITIZEN", "PEOPLE" ],
    "meanings_expanded": [ "政権", "体制", "管理体制" ],
    "contexts": [
      { "parts": [ "The old ", " was overthrown." ], "full": "The old REGIME was overthrown.", "jp": "旧政権は打倒された。", "is_correct": true },
      { "parts": [ "They lived under a strict ", "." ], "full": "They lived under a strict REGIME.", "jp": "彼らは厳格な体制の下で暮らした。", "is_correct": true },
      { "parts": [ "He started a new fitness ", "." ], "full": "He started a new fitness REGIME.", "jp": "彼は新しいフィットネス管理（体制）を始めた。", "is_correct": true }
    ]
  }
];